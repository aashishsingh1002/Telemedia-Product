import Button from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";

const StyledButton = withStyles((theme) => ({
  root: {
    textTransform: "capitalize",
    background: "#ff1921",
    // letterSpacing: "-1px",
    fontWeight: "400",
    color: "#fff",
    fontSize: "16px",
    borderRadius: "50px",
    padding: "6px 50px",
    "&:hover": {
      opacity: 0.8,
      background: "#ff1921",
    },
  },
}))(Button);

export default StyledButton;

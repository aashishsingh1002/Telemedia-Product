const languages = {
    English: {
        value: 'en',
    },
    Spanish: {
        value: 'es'
    },
};
export default languages;
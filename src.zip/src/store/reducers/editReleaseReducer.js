import * as actionTypes from '../actions/actionTypes';

const initialState = {
    releaseData: {},
};

const insideRelease = (state, action) => {
    return {
        ...state,
        releaseData: { ...action.releaseData },
    }
};


const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.INSIDE_RELEASE: return insideRelease(state, action);
        default:
            return state;
    }
};

export default reducer;
import React, { Component } from "react";
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import axios from "../../axios-epc";
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";
import { withStyles } from "@material-ui/core/styles";
import Loader from "../../UI/Loader/Loader";
import Grid from "@material-ui/core/Grid";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Typography from "@material-ui/core/Typography";
import Packages from "./Packages";
import Brands from "./Brands";
import Arpu from "./Arpu";
import { Fade } from "react-awesome-reveal";
import Title from "../../UI/Typography/Title";

const useStyles = (theme) => ({
  cardHeader: {
    background: "#546D7A",
    height: "4.5vh",
  },
  subheader: {
    color: "white",
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "96%",
    flexShrink: 0,
  },
});

class ProductPerformance extends Component {
  _isMounted = false;

  state = {
    loading: false,
    performanceType: "Package",
    layout: "choosePerformance",
    arpuData: {},
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;
  }

  render() {
    const { classes } = this.props;

    let productPerformance = (
      <div>
        <Title>Product Performance</Title>
        {/* <Card style={{ overflow: "visible", marginTop: "1%" }}>
          <CardHeader
            className={classes.cardHeader}
            classes={{
              subheader: classes.subheader,
            }}
            subheader={"Product Performance"}
          />

          <CardContent style={{ overflow: "visible" }}> */}
        {this.state.layout == "choosePerformance" ? (
          <React.Fragment>
            <Grid
              container
              alignContent="flex-end"
              spacing={2}
              style={{ overflow: "visible" }}
            >
              <Grid
                item
                xs={4}
                sm={4}
                md={2}
                style={{
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <Typography variant="subtitle1"> Performance</Typography>
              </Grid>
              <Grid item xs={8} sm={8} md={10}>
                <RadioGroup
                  row
                  aria-label="position"
                  name="position"
                  defaultValue="top"
                  value={this.state.performanceType}
                  onChange={(event) => {
                    this.setState({
                      performanceType: event.target.value,
                    });
                  }}
                >
                  <FormControlLabel
                    value={"Package"}
                    control={<Radio style={{ color: "#ff1921" }} />}
                    label="Package"
                  />
                  <FormControlLabel
                    value="Brand"
                    control={<Radio style={{ color: "#ff1921" }} />}
                    label="Brand"
                  />
                </RadioGroup>
              </Grid>
            </Grid>
            <div style={{ marginTop: "4vh" }}>
              <Fade top>
                {this.state.performanceType == "Package" && (
                  <Packages
                    click={(data) => {
                      this.setState({ arpuData: data });
                      this.setState({ layout: "graph" });
                    }}
                  />
                )}
              </Fade>
              <Fade top>
                {this.state.performanceType == "Brand" && (
                  <Brands
                    click={(data) => {
                      this.setState({ arpuData: data });
                      this.setState({ layout: "graph" });
                    }}
                  />
                )}
              </Fade>
            </div>
          </React.Fragment>
        ) : (
          <Arpu
            data={this.state.arpuData}
            click={() => {
              this.setState({ layout: "choosePerformance" });
            }}
          />
        )}
        {/* </CardContent>
        </Card> */}
      </div>
    );
    if (this.state.loading) productPerformance = <Loader />;

    return productPerformance;
  }
}

export default withStyles(useStyles)(
  WithErrorHandler(ProductPerformance, axios)
);

import React, { Component } from "react";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import Drawer from "@material-ui/core/Drawer";
import AppBar from "@material-ui/core/AppBar";
import CssBaseline from "@material-ui/core/CssBaseline";
import Toolbar from "@material-ui/core/Toolbar";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import WorkIcon from "@material-ui/icons/Work";
import Avatar from "@material-ui/core/Avatar";
import Divider from "@material-ui/core/Divider";
import IconButton from "@material-ui/core/IconButton";
import MenuIcon from "@material-ui/icons/Menu";
import clsx from "clsx";
import * as actionTypes from "../../store/actions/actionTypes";
import { withRouter } from "react-router-dom";
import ExitToAppIcon from "@material-ui/icons/ExitToApp";
import Collapse from "@material-ui/core/Collapse";
import PermDataSettingIcon from "@material-ui/icons/PermDataSetting";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";
import AppsIcon from "@material-ui/icons/Apps";
import { createMuiTheme } from "@material-ui/core/styles";
import { ThemeProvider } from "@material-ui/styles";
import Autocomplete from "@material-ui/lab/Autocomplete";
import Grid from "@material-ui/core/Grid";
import SearchIcon from "@material-ui/icons/Search";
import BrightnessAutoIcon from "@material-ui/icons/BrightnessAuto";
import MoneyIcon from "@material-ui/icons/Money";
import LibraryBooksIcon from "@material-ui/icons/LibraryBooks";
import StoreIcon from "@material-ui/icons/Store";
import LocalOfferIcon from "@material-ui/icons/LocalOffer";
import MenuBookIcon from "@material-ui/icons/MenuBook";
import LocalAtmIcon from "@material-ui/icons/LocalAtm";
import AccountCircleIcon from "@material-ui/icons/AccountCircle";
import { setLocale } from "react-redux-i18n";
import { Translate } from "react-redux-i18n";
import Logo from "../../assests/images/logo.jpg";
import AccountCircle from "@material-ui/icons/AccountCircle";
import TurnedInNotIcon from "@material-ui/icons/TurnedInNot";
import AllInboxIcon from "@material-ui/icons/AllInbox";
// import IdleTimer from "react-idle-timer";
import ModalAction from "../../UI/ModalAction/ModalAction";
import axios from "axios";

const theme = createMuiTheme({
  typography: {
    body1: {
      fontSize: 15,
    },
  },
});

const drawerWidth = 240;

const useStyles = (theme) => ({
  logoutButton: {
    position: "absolute",
    right: "0",
    color: "white",
  },
  logout: {
    position: "absolute",
    right: "20px",
    color: "white",
    cursor: "pointer",
  },
  language: {
    position: "absolute",
    right: "0",
    color: "white",
    marginRight: "70px",
    backgroundColor: "white",
    padding: "20",
  },
  large: {
    width: theme.spacing(17),
    height: theme.spacing(17),
  },
  center: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    marginTop: "25px",
    marginBottom: "25px",
  },
  root: {
    display: "flex",
  },
  avatar: {
    width: theme.spacing(20),
    height: theme.spacing(20),
    backgroundColor: "#229ee6",
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    backgroundColor: "#229ee6",
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
  },
  drawerPaper: {
    width: drawerWidth,
    height: window.screen.height + 0.2 * window.screen.height,
  },
  drawerContainer: {
    overflow: "auto",
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
  contentShift: {
    transition: theme.transitions.create("margin", {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
    marginLeft: 0,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
    transition: theme.transitions.create("margin", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    marginLeft: -drawerWidth,
  },
  navIcon: {
    minWidth: "0px",
    paddingRight: "5%",
  },
});

class Layout extends Component {
  state = {
    open: true,
    planConfig: false,
    plan: false,
    product: false,
    offerability: false,
    contract: false,
    contractProfile: false,
    ratePlan: false,
    rental: false,
    discount: false,
    user: false,
    workflow: false,
    library: false,
    show: false,
    timerConfig: {},
  };

  constructor(props) {
    super(props);
    this.idleTimerRef = React.createRef();
    this.sessionTimerRef = React.createRef();
  }

  componentDidMount() {
    console.log("layout mounted");
    axios
      .get(process.env.REACT_APP_URL + "telemediaDashboard/telemediaPopup")
      .then((res) => {
        console.log(res);
        this.setState({
          timerConfig: res.data.data,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  }

  logoutHandler = () => {
    this.setState({
      show: false,
    });
    sessionStorage.clear();
    this.props.onLogout();
    this.props.history.replace("/login");
    // this.props.changeLocale('en')
    // var cookies = document.cookie.split(";");

    // for (var i = 0; i < cookies.length; i++) {
    //     var cookie = cookies[i];
    //     var eqPos = cookie.indexOf("=");
    //     var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
    //     console.log(name)
    //     document.cookie = name + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT; path=/;domain=ace.airtelworld.in;';
    // }

    // window.location.replace("https://ace.airtelworld.in/EPCLogin");
  };

  drawerHandler = () => {
    this.setState((prevState) => {
      return { open: !prevState.open };
    });
  };

  handleClick = (item) => {
    this.setState((prevState) => {
      return { [item]: !prevState[item] };
    });
  };

  render() {
    const { classes } = this.props;
    let layout = (
      <ThemeProvider theme={theme}>
        <div className={classes.root}>
          {/* {Object.keys(this.props.userInfo).length > 0 &&
            Object.keys(this.state.timerConfig).length > 0 && (
              <IdleTimer
                ref={this.idleTimerRef}
                timeout={Number(this.state.timerConfig.inactiveTime)}
                onIdle={() => {
                  console.log("idle timer log");
                  this.setState({ show: true });
                  this.sessionTimerRef.current = setTimeout(
                    this.logoutHandler,
                    Number(this.state.timerConfig.autoLogout)
                  );
                }}
              ></IdleTimer>
            )} */}

          <ModalAction
            show={this.state.show}
            modalClosed={() => {
              clearTimeout(this.sessionTimerRef.current);
              this.setState({ show: false });
            }}
            actionText={"Log me out"}
            closeText={"Keep me signed in"}
            title={"Timeout"}
            action={() => {
              clearTimeout(this.sessionTimerRef.current);
              this.logoutHandler();
            }}
          >
            <div style={{ padding: "20" }}>
              <h2>You've been idle for a while!</h2>
              <p>You will be logged out soon</p>
            </div>
          </ModalAction>

          <CssBaseline />
          <AppBar position="fixed" className={classes.appBar}>
            <Toolbar>
              <IconButton
                edge="start"
                className={classes.menuButton}
                color="inherit"
                aria-label="menu"
                onClick={this.drawerHandler}
              >
                <MenuIcon />
              </IconButton>

              {/* <img src={Logo}
                                style={{
                                    cursor: 'pointer',
                                    height: '6vh',
                                }}
                                onClick={() => this.props.history.push("/")}
                            /> */}
              {(this.props.location.pathname == "/planConfiguration" ||
                this.props.location.pathname == "/productConfiguration") && (
                <div style={{ marginLeft: "5%" }}>
                  <Grid container spacing={1} alignItems="flex-end">
                    <Grid item style={{ marginRight: "4vw" }}>
                      <SearchIcon />
                    </Grid>
                    <Grid item>
                      <Autocomplete
                        value={this.props.searchValue}
                        onChange={(event, value) => {
                          if (value) {
                            this.props.setSearchValue(value);
                            if (this.props.entity == "PACKAGE") {
                              this.props.changePackageActiveStep(0);
                              let pkgData = { ...this.props.packageData };
                              pkgData["packageId"] = value.split("/")[0];
                              this.props.onPackageEnter(pkgData);
                              this.props.changePackageKey(
                                this.props.pkgKey + "1"
                              );
                              this.props.history.push("/planConfiguration");
                            } else if (this.props.entity == "PRODUCT") {
                              this.props.changeProductActiveStep(0);
                              let proData = { ...this.props.productData };
                              proData["productId"] = value.split("/")[0];
                              this.props.onProductEnter(proData);
                              this.props.changeProductKey(
                                this.props.productKey + "1"
                              );
                              this.props.history.push("/productConfiguration");
                            }
                            this.props.setSearchValue(null);
                          }
                        }}
                        options={this.props.searchItems}
                        renderInput={(params) => (
                          <div ref={params.InputProps.ref}>
                            <input
                              style={{
                                width: "30vw",
                                height: "4vh",
                                transform: "scale(1.25)",
                              }}
                              type="text"
                              {...params.inputProps}
                            />
                          </div>
                        )}
                      />
                    </Grid>
                  </Grid>
                </div>
              )}
              {/* <div className={classes.language} >

                                <LanguageSwitcher />
                            </div> */}

              <div className={classes.logout} onClick={this.logoutHandler}>
                <IconButton
                  style={{ color: "white" }}
                  disableRipple
                  disableFocusRipple
                >
                  <ExitToAppIcon />
                  <span
                    style={{
                      marginLeft: "10px",
                      fontSize: "16px",
                      fontWeight: "600",
                    }}
                  >
                    Logout
                  </span>
                </IconButton>
              </div>
            </Toolbar>
          </AppBar>
          <Drawer
            className={classes.drawer}
            variant="persistent"
            anchor="left"
            open={this.state.open}
            classes={{
              paper: classes.drawerPaper,
            }}
          >
            <Toolbar />
            <div className={classes.drawerContainer}>
              <div
                style={{
                  height: "35vh",
                }}
              >
                <div className={classes.center}>
                  <Avatar className={classes.avatar}>
                    <AccountCircle className={classes.large} />
                  </Avatar>
                </div>
                <div style={{ marginLeft: "20px" }}>
                  <Grid
                    container
                    alignContent="center"
                    style={{ marginBottom: "5px" }}
                  >
                    <span
                      style={{
                        fontWeight: "bold",
                        width: drawerWidth,
                        wordBreak: "break-all",
                        paddingLeft: "10px",
                        paddingRight: "10px",
                      }}
                    >
                      {" " +
                        this.props.userInfo.firstName +
                        " " +
                        this.props.userInfo.lastName}
                    </span>
                  </Grid>
                  <Grid alignContent="center">
                    {this.props.approversData && this.props.userInfo.group && (
                      <React.Fragment>
                        {this.props.userInfo.group.map((grp) => {
                          return (
                            this.props.approversData[grp] && (
                              <Grid
                                container
                                alignContent="center"
                                style={{ marginBottom: "5px" }}
                              >
                                <span
                                  style={{
                                    fontWeight: "bold",
                                    width: drawerWidth,
                                    wordBreak: "break-all",
                                    paddingLeft: "10px",
                                    paddingRight: "10px",
                                  }}
                                >
                                  {this.props.approversData[grp]}
                                </span>
                              </Grid>
                            )
                          );
                        })}
                      </React.Fragment>
                    )}
                  </Grid>
                </div>
              </div>

              <Divider style={{ marginTop: "30px" }} />

              {this.props.userInfo.group &&
                this.props.userInfo.group.includes("TelemediaProductManager") && (
                  <List
                    style={{
                      overflow: "auto",
                      maxHeight: "75vh",
                    }}
                  >
                    <ListItem
                      button
                      onClick={() => this.props.history.push("/")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <TurnedInNotIcon style={{ color: "green" }} />
                      </ListItemIcon>
                      <ListItemText primary="My Releases" />
                    </ListItem>

                    {this.props.releaseData.releaseId && (
                      <React.Fragment>
                        <ListItem
                          button
                          onClick={() => this.handleClick("planConfig")}
                        >
                          <ListItemIcon className={classes.navIcon}>
                            <PermDataSettingIcon style={{ color: "#009B88" }} />
                          </ListItemIcon>
                          <ListItemText
                            primary={<Translate value="dashboard.proConfig" />}
                          />
                          {this.state.planConfig ? (
                            <ExpandLess style={{ fontSize: "18px" }} />
                          ) : (
                            <ExpandMore style={{ fontSize: "18px" }} />
                          )}
                        </ListItem>
                        <Collapse
                          in={this.state.planConfig}
                          timeout="auto"
                          unmountOnExit
                        >
                          <List component="div" disablePadding>
                            <ListItem
                              button
                              className={classes.nested}
                              onClick={() => {
                                console.log(this.props.pkgKey);
                                this.props.changePackageActiveStep(0);
                                this.props.onPackageEnter({});
                                this.props.changePackageKey(
                                  this.props.pkgKey + "1"
                                );
                                this.props.history.push("/planConfiguration");
                              }}
                            >
                              <ListItemIcon>
                                <AppsIcon />
                              </ListItemIcon>
                              <ListItemText
                                primary={
                                  <Translate value="dashboard.bundles" />
                                }
                              />
                            </ListItem>
                            <ListItem
                              button
                              className={classes.nested}
                              onClick={() => {
                                this.props.changeProductActiveStep(0);
                                this.props.onProductEnter({});
                                this.props.changeProductKey(
                                  this.props.productKey + "1"
                                );
                                this.props.history.push(
                                  "/productConfiguration"
                                );
                              }}
                            >
                              <ListItemIcon>
                                <AppsIcon />
                              </ListItemIcon>
                              <ListItemText
                                primary={
                                  <Translate value="dashboard.products" />
                                }
                              />
                            </ListItem>
                            <ListItem
                              button
                              className={classes.nested}
                              onClick={() =>
                                this.props.history.push(
                                  "/ratePlanConfiguration"
                                )
                              }
                            >
                              <ListItemIcon>
                                <AppsIcon />
                              </ListItemIcon>
                              <ListItemText
                                primary={
                                  <Translate value="dashboard.ratePlanConfiguration" />
                                }
                              />
                            </ListItem>
                            {/* <ListItem button className={classes.nested}
                                                onClick={() => {
                                                    this.props.history.push('/contractsCreation')
               -                                 }}>
                                                <ListItemIcon>
                                                    <AppsIcon />
                                                </ListItemIcon>
                                                <ListItemText primary={<Translate value="dashboard.contracts" />} />
                                            </ListItem> 
                                            <ListItem button className={classes.nested}
                                                onClick={() => {
                                                    this.props.history.push('/contractProfileCreation')
                                                }}>
                                                <ListItemIcon>
                                                    <AppsIcon />
                                                </ListItemIcon>
                                                <ListItemText primary={<Translate value="dashboard.contractsProfiles" />} />
                                            </ListItem> */}
                          </List>
                        </Collapse>{" "}
                      </React.Fragment>
                    )}

                    <ListItem
                      button
                      onClick={() => this.props.history.push("/allReleases")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <AllInboxIcon style={{ color: "blue" }} />
                      </ListItemIcon>
                      <ListItemText primary="All Releases" />
                    </ListItem>

                    {this.props.userInfo.group &&
                      this.props.userInfo.group.includes("SuperUser") && (
                        <ListItem
                          button
                          onClick={() =>
                            this.props.history.push("/attributeConfiguration")
                          }
                        >
                          <ListItemIcon className={classes.navIcon}>
                            <BrightnessAutoIcon style={{ color: "#fc0a5b" }} />
                          </ListItemIcon>
                          <ListItemText
                            primary={
                              <Translate value="dashboard.attributeConfiguration" />
                            }
                          />
                        </ListItem>
                      )}

                    <ListItem
                      button
                      onClick={() =>
                        this.props.history.push("/ratePlanConfiguration")
                      }
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <MoneyIcon style={{ color: "#229ee6" }} />
                      </ListItemIcon>
                      <ListItemText
                        primary={
                          <Translate value="dashboard.ratePlanConfiguration" />
                        }
                      />
                    </ListItem>

                    {/* <ListItem button onClick={() => this.props.history.push('/events')}>
                                    <ListItemIcon className={classes.navIcon}>
                                        <EventAvailableIcon style={{ color: "orange" }} />
                                    </ListItemIcon>
                                    <ListItemText primary={<Translate value="dashboard.eventsConfiguration" />} />
                                </ListItem> */}

                    <ListItem
                      button
                      onClick={() => this.props.history.push("/worklist")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <WorkIcon style={{ color: "#a87f32" }} />
                      </ListItemIcon>
                      <ListItemText
                        primary={<Translate value="dashboard.workQueue" />}
                      />
                    </ListItem>

                    <ListItem
                      button
                      className={classes.nested}
                      onClick={() => this.handleClick("library")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <LibraryBooksIcon style={{ color: "#C66B00" }} />
                      </ListItemIcon>
                      <ListItemText primary="Library" />
                      {this.state.library ? (
                        <ExpandLess style={{ fontSize: "18px" }} />
                      ) : (
                        <ExpandMore style={{ fontSize: "18px" }} />
                      )}
                    </ListItem>
                    <Collapse
                      in={this.state.library}
                      timeout="auto"
                      unmountOnExit
                    >
                      <List component="div" disablePadding>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() => {
                            this.props.history.push("/libraryPlanReport");
                          }}
                        >
                          <ListItemIcon>
                            <AppsIcon />
                          </ListItemIcon>
                          <ListItemText primary={"Plan Report"} />
                        </ListItem>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() => {
                            this.props.history.push("/epcDailyReleaseReport");
                          }}
                        >
                          <ListItemIcon>
                            <AppsIcon />
                          </ListItemIcon>
                          <ListItemText primary={"Daily Release Report"} />
                        </ListItem>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() => {
                            this.props.history.push("/epcFederationReport");
                          }}
                        >
                          <ListItemIcon>
                            <AppsIcon />
                          </ListItemIcon>
                          <ListItemText primary={"Federation Report"} />
                        </ListItem>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() => {
                            this.props.history.push("/epcOfferabilityReport");
                          }}
                        >
                          <ListItemIcon>
                            <AppsIcon />
                          </ListItemIcon>
                          <ListItemText primary={"Offerability Report"} />
                        </ListItem>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() => {
                            this.props.history.push("/ratePlanReport");
                          }}
                        >
                          <ListItemIcon>
                            <AppsIcon />
                          </ListItemIcon>
                          <ListItemText primary={"Rate Plan Report"} />
                        </ListItem>
                      </List>
                    </Collapse>

                    {/* <ListItem button onClick={() => this.props.history.push('/advanceSearch')}>
                                        <ListItemIcon className={classes.navIcon}>
                                            <FindInPageIcon style={{ color: "#972ac9" }} />
                                        </ListItemIcon>
                                        <ListItemText primary={<Translate value="dashboard.advanceSearch" />} />
                                    </ListItem> */}

                    {/* <ListItem button onClick={() => this.props.history.push('/productPerformance')}>
                                        <ListItemIcon className={classes.navIcon}>
                                            <RedeemIcon style={{ color: "grey" }} />
                                        </ListItemIcon>
                                        <ListItemText primary={<Translate value="dashboard.productPerformance" />} />
                                    </ListItem> */}
                  </List>
                )}

              {this.props.userInfo.group &&
                this.props.userInfo.group.includes("Admin") && (
                  <List>
                    <ListItem button onClick={() => this.handleClick("plan")}>
                      <ListItemIcon className={classes.navIcon}>
                        <LibraryBooksIcon style={{ color: "#8175CB" }} />
                      </ListItemIcon>
                      <ListItemText primary="Package" />
                      {this.state.plan ? (
                        <ExpandLess style={{ fontSize: "18px" }} />
                      ) : (
                        <ExpandMore style={{ fontSize: "18px" }} />
                      )}
                    </ListItem>
                    <Collapse in={this.state.plan} timeout="auto" unmountOnExit>
                      <List component="div" disablePadding>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() =>
                            this.props.history.push("/adminPlanConfiguration")
                          }
                        >
                          <ListItemIcon>
                            {" "}
                            <AppsIcon />{" "}
                          </ListItemIcon>
                          <ListItemText primary="Modify Fields" />
                        </ListItem>
                      </List>
                    </Collapse>

                    <ListItem
                      button
                      onClick={() => this.handleClick("product")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <StoreIcon style={{ color: "#00ACC2" }} />
                      </ListItemIcon>
                      <ListItemText primary="Product" />
                      {this.state.product ? (
                        <ExpandLess style={{ fontSize: "18px" }} />
                      ) : (
                        <ExpandMore style={{ fontSize: "18px" }} />
                      )}
                    </ListItem>
                    <Collapse
                      in={this.state.product}
                      timeout="auto"
                      unmountOnExit
                    >
                      <List component="div" disablePadding>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() =>
                            this.props.history.push(
                              "/adminProductConfiguration"
                            )
                          }
                        >
                          <ListItemIcon>
                            {" "}
                            <AppsIcon />{" "}
                          </ListItemIcon>
                          <ListItemText primary="Modify Fields" />
                        </ListItem>
                        <ListItem
                          button
                          onClick={() => {
                            this.props.history.push("/adminCtsConfiguration");
                          }}
                        >
                          <ListItemIcon>
                            <AppsIcon />
                          </ListItemIcon>
                          <ListItemText primary="Modify CTS" />
                        </ListItem>
                      </List>
                    </Collapse>

                    <ListItem
                      button
                      onClick={() => this.handleClick("offerability")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <LocalOfferIcon style={{ color: "#EB646F" }} />
                      </ListItemIcon>
                      <ListItemText primary="Offerability" />
                      {this.state.offerability ? (
                        <ExpandLess style={{ fontSize: "18px" }} />
                      ) : (
                        <ExpandMore style={{ fontSize: "18px" }} />
                      )}
                    </ListItem>
                    <Collapse
                      in={this.state.offerability}
                      timeout="auto"
                      unmountOnExit
                    >
                      <List component="div" disablePadding>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() =>
                            this.props.history.push(
                              "/adminOfferabilityConfiguration"
                            )
                          }
                        >
                          <ListItemIcon>
                            {" "}
                            <AppsIcon />{" "}
                          </ListItemIcon>
                          <ListItemText primary="Modify Offerability" />
                        </ListItem>
                      </List>
                    </Collapse>
                    <ListItem
                      button
                      onClick={() => this.handleClick("contract")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <MenuBookIcon style={{ color: "#008E7B" }} />
                      </ListItemIcon>
                      <ListItemText primary="Contract" />
                      {this.state.contract ? (
                        <ExpandLess style={{ fontSize: "18px" }} />
                      ) : (
                        <ExpandMore style={{ fontSize: "18px" }} />
                      )}
                    </ListItem>
                    <Collapse
                      in={this.state.contract}
                      timeout="auto"
                      unmountOnExit
                    >
                      <List component="div" disablePadding>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() =>
                            this.props.history.push(
                              "/adminBundleContractConfiguration"
                            )
                          }
                        >
                          <ListItemIcon>
                            {" "}
                            <AppsIcon />{" "}
                          </ListItemIcon>
                          <ListItemText primary="Bundle Contract" />
                        </ListItem>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() =>
                            this.props.history.push(
                              "/adminContractCreationConfiguration"
                            )
                          }
                        >
                          <ListItemIcon>
                            {" "}
                            <AppsIcon />{" "}
                          </ListItemIcon>
                          <ListItemText primary="Contract Creation" />
                        </ListItem>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() =>
                            this.props.history.push(
                              "/adminContractProfileConfiguration"
                            )
                          }
                        >
                          <ListItemIcon>
                            {" "}
                            <AppsIcon />{" "}
                          </ListItemIcon>
                          <ListItemText primary="Contract Profile" />
                        </ListItem>
                      </List>
                    </Collapse>
                    {/* <ListItem button onClick={() => this.handleClick('contractProfile')}>
                                        <ListItemIcon className={classes.navIcon}>
                                            <LocalLibraryIcon style={{ color: "#D77CD8" }} />
                                        </ListItemIcon>
                                        <ListItemText primary="Contract Profile" />
                                        {this.state.contractProfile ? <ExpandLess style={{ fontSize: '18px' }} /> :
                                            <ExpandMore style={{ fontSize: "18px" }} />}
                                    </ListItem>
                                    <Collapse in={this.state.contractProfile} timeout="auto" unmountOnExit>
                                        <List component="div" disablePadding>
                                            <ListItem button className={classes.nested}
                                                onClick={() => this.props.history.push("/adminContractProfileConfiguration")} >
                                                <ListItemIcon> <AppsIcon />  </ListItemIcon>
                                                <ListItemText primary="Modify Fields" />
                                            </ListItem>
                                        </List>
                                    </Collapse> */}
                    <ListItem
                      button
                      onClick={() => this.handleClick("attribute")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <BrightnessAutoIcon style={{ color: "#F60076" }} />
                      </ListItemIcon>
                      <ListItemText primary="Attribute" />
                      {this.state.attribute ? (
                        <ExpandLess style={{ fontSize: "18px" }} />
                      ) : (
                        <ExpandMore style={{ fontSize: "18px" }} />
                      )}
                    </ListItem>
                    <Collapse
                      in={this.state.attribute}
                      timeout="auto"
                      unmountOnExit
                    >
                      <List component="div" disablePadding>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() =>
                            this.props.history.push("/adminAttrConfiguration")
                          }
                        >
                          <ListItemIcon>
                            {" "}
                            <AppsIcon />{" "}
                          </ListItemIcon>
                          <ListItemText primary="Attribute" />
                        </ListItem>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() =>
                            this.props.history.push(
                              "/adminAttrGrpConfiguration"
                            )
                          }
                        >
                          <ListItemIcon>
                            {" "}
                            <AppsIcon />{" "}
                          </ListItemIcon>
                          <ListItemText primary="Attribute Group" />
                        </ListItem>
                      </List>
                    </Collapse>
                    <ListItem
                      button
                      onClick={() => this.handleClick("ratePlan")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <MoneyIcon style={{ color: "#FFB800" }} />
                      </ListItemIcon>
                      <ListItemText primary="Rate Plan" />
                      {this.state.ratePlan ? (
                        <ExpandLess style={{ fontSize: "18px" }} />
                      ) : (
                        <ExpandMore style={{ fontSize: "18px" }} />
                      )}
                    </ListItem>
                    <Collapse
                      in={this.state.ratePlan}
                      timeout="auto"
                      unmountOnExit
                    >
                      <List component="div" disablePadding>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() =>
                            this.props.history.push(
                              "/adminRatePlanConfiguration"
                            )
                          }
                        >
                          <ListItemIcon>
                            {" "}
                            <AppsIcon />{" "}
                          </ListItemIcon>
                          <ListItemText primary="Modify Fields" />
                        </ListItem>
                      </List>
                    </Collapse>
                    <ListItem button onClick={() => this.handleClick("rental")}>
                      <ListItemIcon className={classes.navIcon}>
                        <LocalAtmIcon style={{ color: "#8D6D62" }} />
                      </ListItemIcon>
                      <ListItemText primary="Pricing" />
                      {this.state.rental ? (
                        <ExpandLess style={{ fontSize: "18px" }} />
                      ) : (
                        <ExpandMore style={{ fontSize: "18px" }} />
                      )}
                    </ListItem>
                    <Collapse
                      in={this.state.rental}
                      timeout="auto"
                      unmountOnExit
                    >
                      <List component="div" disablePadding>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() =>
                            this.props.history.push("/adminRentalConfiguration")
                          }
                        >
                          <ListItemIcon>
                            {" "}
                            <AppsIcon />{" "}
                          </ListItemIcon>
                          <ListItemText primary="Rental" />
                        </ListItem>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() =>
                            this.props.history.push(
                              "/adminDiscountConfiguration"
                            )
                          }
                        >
                          <ListItemIcon>
                            {" "}
                            <AppsIcon />{" "}
                          </ListItemIcon>
                          <ListItemText primary="Discount" />
                        </ListItem>
                      </List>
                    </Collapse>
                    <ListItem button onClick={() => this.handleClick("user")}>
                      <ListItemIcon className={classes.navIcon}>
                        <AccountCircleIcon style={{ color: "#FF6239" }} />
                      </ListItemIcon>
                      <ListItemText primary="User" />
                      {this.state.user ? (
                        <ExpandLess style={{ fontSize: "18px" }} />
                      ) : (
                        <ExpandMore style={{ fontSize: "18px" }} />
                      )}
                    </ListItem>
                    <Collapse in={this.state.user} timeout="auto" unmountOnExit>
                      <List component="div" disablePadding>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() =>
                            this.props.history.push("/adminuserConfiguration")
                          }
                        >
                          <ListItemIcon>
                            {" "}
                            <AppsIcon />{" "}
                          </ListItemIcon>
                          <ListItemText primary="User Creation" />
                        </ListItem>
                      </List>
                    </Collapse>
                    <ListItem
                      button
                      onClick={() => this.handleClick("workflow")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <WorkIcon style={{ color: "#1dad03" }} />
                      </ListItemIcon>
                      <ListItemText primary="Workflow" />
                      {this.state.workflow ? (
                        <ExpandLess style={{ fontSize: "18px" }} />
                      ) : (
                        <ExpandMore style={{ fontSize: "18px" }} />
                      )}
                    </ListItem>
                    <Collapse
                      in={this.state.workflow}
                      timeout="auto"
                      unmountOnExit
                    >
                      <List component="div" disablePadding>
                        <ListItem
                          button
                          className={classes.nested}
                          onClick={() =>
                            this.props.history.push("/adminWorklist")
                          }
                        >
                          <ListItemIcon>
                            {" "}
                            <AppsIcon />{" "}
                          </ListItemIcon>
                          <ListItemText primary="Worklist" />
                        </ListItem>
                      </List>
                    </Collapse>
                    {/* <ListItem button onClick={() => this.handleClick('discount')}>
                                        <ListItemIcon className={classes.navIcon}>
                                            <AddShoppingCartIcon style={{ color: "#FF6239" }} />
                                        </ListItemIcon>
                                        <ListItemText primary="Discount" />
                                        {this.state.discount ? <ExpandLess style={{ fontSize: '18px' }} /> :
                                            <ExpandMore style={{ fontSize: "18px" }} />}
                                    </ListItem>
                                    <Collapse in={this.state.discount} timeout="auto" unmountOnExit>
                                        <List component="div" disablePadding>
                                            <ListItem button className={classes.nested}
                                                onClick={() => this.props.history.push("/adminDiscountConfiguration")} >
                                                <ListItemIcon> <AppsIcon />  </ListItemIcon>
                                                <ListItemText primary="Modify Fields" />
                                            </ListItem>
                                        </List>
                                    </Collapse> */}
                  </List>
                )}

              {this.props.userInfo.group &&
                !this.props.userInfo.group.includes("Admin") &&
                !this.props.userInfo.group.includes("TelemediaProductManager") && (
                  <List>
                    <ListItem
                      button
                      onClick={() => this.props.history.push("/allReleases")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <AllInboxIcon style={{ color: "blue" }} />
                      </ListItemIcon>
                      <ListItemText primary="All Releases" />
                    </ListItem>

                    <ListItem
                      button
                      onClick={() => this.props.history.push("/worklist")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <WorkIcon style={{ color: "#a87f32" }} />
                      </ListItemIcon>
                      <ListItemText
                        primary={<Translate value="dashboard.workQueue" />}
                      />
                    </ListItem>
                  </List>
                )}
            </div>
          </Drawer>

          <main
            className={clsx(classes.content, {
              [classes.contentShift]: this.state.open,
            })}
          >
            <Toolbar />
            {this.props.children}
          </main>
        </div>
      </ThemeProvider>
    );
    if (!(Object.keys(this.props.userInfo).length > 0))
      layout = this.props.children;

    return layout;
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
    pkgKey: state.packageData.pkgKey,
    productKey: state.productData.productKey,
    searchItems: state.searchData.searchItems,
    searchValue: state.searchData.searchValue,
    entity: state.searchData.entity,
    packageData: state.packageData.packageData,
    productData: state.productData.productData,
    approversData: state.approverData.approversData,
    releaseData: state.releaseData.releaseData,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onLogout: () => dispatch({ type: actionTypes.LOG_OUT }),
    onPackageEnter: (packageData) =>
      dispatch({ type: actionTypes.INSIDE_PACKAGE, packageData: packageData }),
    changePackageKey: (pkgKey) =>
      dispatch({ type: actionTypes.CHANGE_PACKAGE_KEY, pkgKey: pkgKey }),
    changePackageActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
        activeStep: activeStep,
      }),
    changeProductKey: (productKey) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_KEY,
        productKey: productKey,
      }),
    onProductEnter: (productData) =>
      dispatch({ type: actionTypes.INSIDE_PRODUCT, productData: productData }),
    changeProductActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP,
        activeStep: activeStep,
      }),
    setSearchValue: (searchValue) =>
      dispatch({
        type: actionTypes.SET_SEARCH_VALUE,
        searchValue: searchValue,
      }),
    changeLocale: (locale) => dispatch(setLocale(locale)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(withRouter(Layout)));

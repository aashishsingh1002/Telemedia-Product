import React, { useState } from 'react';
import Button from '@material-ui/core/Button';
import axios from 'axios';
import MuiAlert from '@material-ui/lab/Alert';
import Snackbar from '@material-ui/core/Snackbar';
import Modal from '../UI/Modal/CloneModal';
import { TextField } from '@material-ui/core';

const btnStyle = {
  textTransform: 'capitalize',
  background: '#fff',
  border: '2px solid #e58422',
  letterSpacing: '-1px',
  fontWeight: '500',
  color: '#000',
  fontSize: '14px',
  padding: '0px',
  borderRadius: '50px',
  //padding: '6px 32px',
  position: 'absolute',
  top: '93px',
  '&:hover': {
    opacity: 0.8,
    background: '#4679da',
  },
};
function Alert(props) {
  return <MuiAlert elevation={6} variant='filled' {...props} />;
}

const CopyCloneButton = (props) => {
  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenSnack(false);
  };
  const vertical = 'top';
  const horizontal = 'center';
  const [openSnack, setOpenSnack] = useState(false);
  const [message, setMessage] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [saveClone, setSaveClone] = useState(false);
  const [genId, setGenId] = useState(null);
  const [name, setName] = useState('');

  const copyClone = (props) => {
    setModalOpen(true);
    console.log(props);
    let payload = {};
    payload.id = props.id;
    payload.buId = props.buId;
    payload.createdBy = props.createdBy;
    payload.genId = genId;
    payload.identifier = props.identifier;
    payload.name = name;
    payload.opId = props.opId;
    payload.releaseId = props.releaseId;
    console.log(payload);
    axios
      .post(process.env.REACT_APP_URL + props.url, payload, {})
      .then((response) => {
        console.log(response);
        setOpenSnack(true);
        setMessage(response.data.statusMsg);
        setGenId(null);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return (
    <>
      <Snackbar
        anchorOrigin={{ vertical, horizontal }}
        open={openSnack}
        autoHideDuration={3000}
        onClose={() => handleClose()}
      >
        <Alert onClose={() => handleClose()} severity='success'>
          {message}
        </Alert>
      </Snackbar>
      <Button
        variant='contained'
        style={btnStyle}
        onClick={() => {
          setModalOpen(true);
        }}
      >
        Clone
      </Button>
      <Modal
        show={modalOpen}
        modalClosed={() => setModalOpen(false)}
        title={'Clone'}
        onClick={() => copyClone(props)}
      >
        <span>
          {`Enter the ${
            props.identifier === 'Product' ? 'Product Name' : 'Package Name'
          } :   `}
          <TextField
            placeholder={props.identifier + 'Name'}
            style={{ fontSize: '18px' }}
            onChange={(e) => setName(e.target.value)}
          />
        </span>
        <span>
          {`Enter the ${
            props.identifier === 'Product' ? 'PartNumber' : 'Package Id'
          } :   `}
          <TextField
            placeholder={props.identifier + 'Id'}
            style={{ fontSize: '18px' }}
            onChange={(e) => setGenId(e.target.value)}
          />
        </span>
      </Modal>
    </>
  );
};

export default CopyCloneButton;

import React from 'react';
import Button from '@material-ui/core/Button';
import { saveAsExcel } from './utils';

const btnStyle = {
  textTransform: 'capitalize',
  background: '#ffcc00',
  letterSpacing: '-1px',
  fontWeight: '600',
  color: '#000',
  fontSize: '16px',
  borderRadius: '50px',
  padding: '6px 32px',
  '&:hover': {
    opacity: 0.8,
    background: '#ffcc00',
  },
};

const ExportButton = ({ schema, name, data, derived }) => {
  const onClick = () => {
    saveAsExcel({ schema, name, data, derived });
  };

  return (
    <Button variant='contained' style={btnStyle} onClick={onClick}>
      Export
    </Button>
  );
};

export default ExportButton;

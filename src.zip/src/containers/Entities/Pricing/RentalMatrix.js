import React, { Component } from 'react';
import axios from '../../../axios-epc';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import { withStyles } from '@material-ui/core/styles';
import Box from '@material-ui/core/Box';
import Collapse from '@material-ui/core/Collapse';
import IconButton from '@material-ui/core/IconButton';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import Tooltip from '@material-ui/core/Tooltip';
import AddIcon from '@material-ui/icons/Add';
import MultiSelect from '../../../UI/Input/MultiSelect';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import DeleteIcon from '@material-ui/icons/Delete';
// import Button from "@material-ui/core/Button";
import Button from '../../../UI/Button/Button';
import Modal from '../../../UI/Modal/Modal';
import moment from 'moment';
import Loader from '../../../UI/Loader/Loader';
import StyledButton from '../../../UI/Button/Button';

const useStyles = (theme) => ({
  cardHeader: {
    // background: "#546D7A",
    // height: "4.5vh",
    paddingBottom: 0,
  },
  subheader: {
    color: 'rgba(0, 0, 0, 0.87)',
    fontSize: '16px',
    fontWeight: '600',
    // color: "white",
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
});

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: '#525354',
    color: 'white',
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

let crrMatrixRowId = 1;

class RentalMatrix extends Component {
  _isMounted = false;

  state = {
    loading: true,
    attributeSchema: {},
    offerKeys: [],
    schema: {},
    refUiMap: {},
    refUiMapSwap: {},
    offerabilitySchema: {},
    matrixRows: [],
    show: false,
    modalContent: null,
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;
    this.attributeData().then(() => {
      this.offerabilityData().then(() => {
        let refUiMapSwap = {};
        let offerabilitySchema = {};
        for (let key in this.state.refUiMap) {
          refUiMapSwap[this.state.refUiMap[key]] = key;
        }

        Object.keys(this.state.schema).forEach((key) => {
          let obj = {};
          if (this.state.schema[key].type == 'MultiSelect') {
            obj.type = 'MultiSelect';
            obj.value = this.state.schema[key].value.split(',');
          } else {
            obj.type = 'TextInput';
            obj.value = '';
          }
          offerabilitySchema[key] = obj;
        });

        this.setState({
          refUiMapSwap: refUiMapSwap,
          offerabilitySchema: offerabilitySchema,
        });
        this.pricingData().then(() => {
          this.setState({
            loading: false,
          });
        });
      });
    });
  }

  pricingData() {
    if (this.props.releaseData.releaseId) {
      if (this.props.id) {
        return axios
          .get('pricing/matrix?id=' + this.props.id)
          .then((res) => {
            console.log(res.data.data);
            let matrixRows = [];
            if (Object.keys(res.data.data).length > 0) {
              Object.keys(res.data.data).forEach((key) => {
                let arr = {};
                arr.price = res.data.data[key].listPrice;
                arr.Delete = 'delete';
                arr.down = 'mdi-chevron-down';
                arr.chargeType = res.data.data[key].priceType;
                arr.frequency = res.data.data[key].rcFrequency;
                arr.attributes = Object.keys(res.data.data[key].attributes);
                let arrOffer = [];
                let objOffer = {};
                let objattr = {};
                Object.keys(res.data.data[key].offerabilities).forEach(
                  (keyoffer) => {
                    arrOffer.push(this.state.refUiMap[keyoffer]);
                    if (
                      res.data.data[key].offerabilities[keyoffer] !== null &&
                      res.data.data[key].offerabilities[keyoffer].indexOf(',') >
                        -1
                    )
                      objOffer[this.state.refUiMap[keyoffer]] =
                        res.data.data[key].offerabilities[keyoffer].split(',');
                    else
                      objOffer[this.state.refUiMap[keyoffer]] =
                        res.data.data[key].offerabilities[keyoffer];
                  }
                );
                Object.keys(res.data.data[key].attributes).forEach(
                  (keyattr) => {
                    if (
                      res.data.data[key].attributes[keyattr] !== null &&
                      res.data.data[key].attributes[keyattr].indexOf(',') > -1
                    )
                      objattr[keyattr] =
                        res.data.data[key].attributes[keyattr].split(',');
                    else
                      objattr[keyattr] = res.data.data[key].attributes[keyattr];
                  }
                );
                arr.offerability = arrOffer;
                arr.id = crrMatrixRowId++;
                arr.show = false;
                arr.selattributes = objattr;
                arr.selOfferabilities = objOffer;
                matrixRows.push(arr);
              });
            } else {
              let obj = {
                attributes: [],
                offerability: [],
                price: '',
                chargeType: '',
                frequency: '',
                Delete: 'delete',
                down: 'mdi-chevron-down',
                selattributes: {},
                selOfferabilities: {},
                id: crrMatrixRowId++,
                show: false,
              };
              matrixRows.push(obj);
            }
            this.setState({
              matrixRows: matrixRows,
            });
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      } else {
        return Promise.resolve();
      }
    } else {
      return Promise.resolve();
    }
  }

  attributeData() {
    if (this.props.releaseData.releaseId) {
      return axios
        .get(
          'attribute/basicDetails?releaseId=' +
            this.props.releaseData.releaseId,
          {
            headers: {
              opId: this.props.userInfo.opId,
            },
          }
        )
        .then((res) => {
          let attributeSchema = {};
          res.data.data.forEach((attribute) => {
            let obj = {};
            if (
              !attribute.ppmAttrType ||
              attribute.ppmAttrType.toUpperCase() == 'TEXT'
            ) {
              obj.type = 'TextInput';
              obj.value = '';
            } else {
              obj.type = 'MultiSelect';
              obj.value = attribute.ppmAttrValue
                ? attribute.ppmAttrValue.split(',')
                : [];
            }
            attributeSchema[attribute.ppmAttrName] = obj;
          });
          if (this._isMounted)
            this.setState({
              attributeSchema: attributeSchema,
            });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      return Promise.resolve();
    }
  }

  offerabilityData() {
    if (
      localStorage.getItem('offerabilityMatrix') &&
      localStorage.getItem('offerabilityKeys') &&
      localStorage.offerability_version &&
      localStorage.offerability_version == this.props.offerVersion
    ) {
      console.log('fetching from local storage');
      try {
        this.setState({
          schema: JSON.parse(localStorage.getItem('offerabilityMatrix')),
          offerKeys: JSON.parse(localStorage.getItem('offerabilityKeys')),
          refUiMap: JSON.parse(localStorage.getItem('offerabilityUiRefMap')),
        });
      } catch (e) {
        localStorage.removeItem('offerabilityMatrix');
        localStorage.removeItem('offerabilityKeys');
        localStorage.removeItem('offerabilityUiRefMap');
      }
      return Promise.resolve();
    } else {
      console.log('fetching from api');
      return axios
        .get('config?entityName=offerability', {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          },
        })
        .then((res) => {
          let schema = {};
          let offerKeys = [];
          let refUiMap = {};
          res.data.data.forEach((el) => {
            let offerabilityType = {};
            offerabilityType.value = el.refLovs ? el.refLovs : '';
            offerabilityType.type = el.refType;
            schema[el.uiName] = offerabilityType;
            offerKeys.push(el.refName);
            refUiMap[el.refName] = el.uiName;
          });

          this.setState({
            schema: schema,
            offerKeys: offerKeys,
            refUiMap: refUiMap,
          });

          localStorage.setItem('offerabilityMatrix', JSON.stringify(schema));
          localStorage.setItem('offerabilityKeys', JSON.stringify(offerKeys));
          localStorage.setItem(
            'offerabilityUiRefMap',
            JSON.stringify(refUiMap)
          );

          localStorage.offerability_version = this.props.offerVersion;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  cartesianProduct(arr) {
    return arr.reduce(
      function (a, b) {
        return a
          .map(function (x) {
            return b.map(function (y) {
              return x.concat([y]);
            });
          })
          .reduce(function (a, b) {
            return a.concat(b);
          }, []);
      },
      [[]]
    );
  }
  saveRentalMatrix = () => {
    if (this.props.id) {
      this.setState({
        loading: true,
      });
      let rowCnt = 0;
      let listofPpmPricingMatrixAud = [];
      this.state.matrixRows.map((row) => {
        let arr = [];
        arr.push(row.attributes.length === 0 ? ['ANY'] : row.attributes);
        arr.push(row.offerability);
        rowCnt += 1;
        this.cartesianProduct(arr).map((col) => {
          let obj = {};
          obj.matrixRowNbr = rowCnt;
          obj.attrName = col[0];
          if (row.selattributes[col[0]] instanceof Array)
            obj.attrValue = row.selattributes[col[0]].join();
          else obj.attrValue = row.selattributes[col[0]];

          obj.offerName = this.state.refUiMapSwap[col[1]];
          if (row.selOfferabilities[col[1]] instanceof Array)
            obj.offerValue = row.selOfferabilities[col[1]].join();
          else obj.offerValue = row.selOfferabilities[col[1]];
          obj.packageId = this.props.id;
          obj.listPrice = row.price;
          if (row.chargeType == 'RC') {
            obj.priceType = 'RC';
            obj.rcFrequency = row.frequency;
          } else if (row.chargeType == 'NRC') {
            obj.priceType = 'NRC';
            obj.rcFrequency = null;
          }
          let date = moment().format('DD-MMM-YY');
          obj.opId = this.props.userInfo.opId;
          obj.buId = this.props.userInfo.buId;
          obj.createdBy = this.props.userInfo.id;
          obj.createdDate = date;
          obj.startDate = date;
          obj.endDate = '30-Dec-30';
          obj.updatedBy = null;
          obj.updatedDate = null;

          listofPpmPricingMatrixAud.push(obj);
        });
      });
      console.log(listofPpmPricingMatrixAud);
      let payload = {};
      payload.listofPpmPricingMatrixAud = listofPpmPricingMatrixAud;
      payload.releaseId = this.props.releaseData.releaseId;
      payload.id = this.props.id;
      axios
        .post('pricing/matrix', payload)
        .then((response) => {
          console.log(response);
          window.location.reload();
          this.setState({
            loading: false,
          });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      let modalContent = (
        <Typography variant='h6'>
          {' '}
          Submit Basic {this.props.entity} Details first.{' '}
        </Typography>
      );
      this.setState({ modalContent: modalContent, show: true });
    }
  };

  errorConfirmedHandler = () => {
    this.setState({ show: false });
  };

  render() {
    console.log('schema', this.state.attributeSchema);
    const { classes } = this.props;
    let rentalMatrix = null;
    rentalMatrix = (
      <React.Fragment>
        <Modal
          show={this.state.show}
          modalClosed={this.errorConfirmedHandler}
          title={'Something Went Wrong!'}
        >
          {this.state.modalContent}
        </Modal>
        <Card style={{ marginTop: '1.75%' }} style={{ overflow: 'visible' }}>
          <CardHeader
            className={classes.cardHeader}
            classes={{
              subheader: classes.subheader,
            }}
            subheader={'Rental Matrix'}
            action={
              <LightTooltip title='Add Matrix Row' arrow>
                <AddIcon
                  onClick={() => {
                    let matrixRows = [...this.state.matrixRows];
                    let obj = {
                      attributes: [],
                      offerability: [],
                      price: '',
                      Delete: 'delete',
                      down: 'mdi-chevron-down',
                      chargeType: '',
                      frequency: '',
                      selattributes: {},
                      selOfferabilities: {},
                      id: crrMatrixRowId++,
                      show: false,
                    };
                    matrixRows.push(obj);
                    this.setState({
                      matrixRows: matrixRows,
                    });
                  }}
                  style={{
                    color: 'white',
                    marginRight: '10px',
                    cursor: 'pointer',
                  }}
                />
              </LightTooltip>
            }
          />

          <CardContent style={{ overflow: 'visible' }}>
            <TableContainer component={Paper} style={{ overflow: 'visible' }}>
              <Table aria-label='collapsible table'>
                <TableHead>
                  <TableRow>
                    <TableCell>Show</TableCell>
                    <TableCell>Attribute</TableCell>
                    <TableCell>Offerability</TableCell>
                    <TableCell>List Price</TableCell>
                    <TableCell>Charge Type</TableCell>
                    <TableCell>Delete</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {this.state.matrixRows.map((row) => (
                    <React.Fragment key={row.id}>
                      <TableRow className={classes.root}>
                        <TableCell style={{ width: '1%' }}>
                          <IconButton
                            onClick={() => {
                              let show = row.show;
                              this.setState({
                                matrixRows: this.state.matrixRows.map((el) =>
                                  el.id === row.id
                                    ? {
                                        ...el,
                                        show: !show,
                                      }
                                    : el
                                ),
                              });
                            }}
                            aria-label='expand row'
                            size='small'
                          >
                            {row.show ? (
                              <KeyboardArrowUpIcon />
                            ) : (
                              <KeyboardArrowDownIcon />
                            )}
                          </IconButton>
                        </TableCell>
                        <TableCell style={{ width: '20%' }}>
                          <MultiSelect
                            refLovs={Object.keys(
                              this.state.attributeSchema
                            ).filter((x) => x !== 'ANY')}
                            value={row['attributes']}
                            changed={(selected) => {
                              this.setState({
                                matrixRows: this.state.matrixRows.map((el) =>
                                  el.id === row.id
                                    ? {
                                        ...el,
                                        attributes: selected,
                                      }
                                    : el
                                ),
                              });
                            }}
                            placeholder={'Attributes'}
                          />
                        </TableCell>
                        <TableCell style={{ width: '20%' }}>
                          <MultiSelect
                            refLovs={Object.keys(this.state.offerabilitySchema)}
                            value={row['offerability']}
                            changed={(selected) => {
                              this.setState({
                                matrixRows: this.state.matrixRows.map((el) =>
                                  el.id === row.id
                                    ? {
                                        ...el,
                                        offerability: selected,
                                      }
                                    : el
                                ),
                              });
                            }}
                            placeholder={'Offerability'}
                          />
                        </TableCell>
                        <TableCell style={{ width: '10%' }}>
                          <TextField
                            placeholder={'List Price'}
                            type='number'
                            fullWidth
                            value={row['price']}
                            onChange={(event) => {
                              this.setState({
                                matrixRows: this.state.matrixRows.map((el) =>
                                  el.id === row.id
                                    ? {
                                        ...el,
                                        price: event.target.value,
                                      }
                                    : el
                                ),
                              });
                            }}
                          />
                        </TableCell>
                        <TableCell style={{ width: '10%' }}>
                          <FormControl style={{ minWidth: '100%' }}>
                            <Select
                              onChange={(event) => {
                                this.setState({
                                  matrixRows: this.state.matrixRows.map((el) =>
                                    el.id === row.id
                                      ? {
                                          ...el,
                                          chargeType: event.target.value,
                                        }
                                      : el
                                  ),
                                });
                              }}
                              placeholder={'Charge Type'}
                              value={row['chargeType']}
                            >
                              {['RC', 'NRC'].map((lov) => {
                                return (
                                  <MenuItem key={lov} value={lov}>
                                    {lov}
                                  </MenuItem>
                                );
                              })}
                            </Select>
                          </FormControl>

                          {row['chargeType'] == 'RC' && (
                            <FormControl style={{ minWidth: '100%' }}>
                              <Select
                                onChange={(event) => {
                                  this.setState({
                                    matrixRows: this.state.matrixRows.map(
                                      (el) =>
                                        el.id === row.id
                                          ? {
                                              ...el,
                                              frequency: event.target.value,
                                            }
                                          : el
                                    ),
                                  });
                                }}
                                placeholder={'RC Frequency'}
                                value={row['frequency']}
                              >
                                {['Monthly', 'Quaterly', 'Annually'].map(
                                  (lov) => {
                                    return (
                                      <MenuItem key={lov} value={lov}>
                                        {lov}
                                      </MenuItem>
                                    );
                                  }
                                )}
                              </Select>
                            </FormControl>
                          )}
                        </TableCell>

                        <TableCell style={{ width: '5%' }}>
                          <DeleteIcon
                            onClick={() => {
                              let matrixRows = [...this.state.matrixRows];

                              let removeIndex = matrixRows
                                .map(function (row) {
                                  return row.id;
                                })
                                .indexOf(row.id);
                              matrixRows.splice(removeIndex, 1);
                              this.setState({
                                matrixRows: matrixRows,
                              });
                            }}
                            style={{ color: 'red', cursor: 'pointer' }}
                          />
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell
                          style={{ paddingBottom: 0, paddingTop: 0 }}
                          colSpan={6}
                        >
                          <Collapse in={row.show} timeout='auto' unmountOnExit>
                            <Box
                              margin={1}
                              style={{ height: '30vh', overflow: 'auto' }}
                            >
                              {row['attributes'].length > 0 && (
                                <React.Fragment>
                                  <Typography
                                    variant='h6'
                                    gutterBottom
                                    component='div'
                                  >
                                    Attributes
                                  </Typography>
                                  <Table size='small' aria-label='purchases'>
                                    <TableHead>
                                      <TableRow>
                                        <TableCell style={{ width: '30%' }}>
                                          Attribute Name
                                        </TableCell>
                                        <TableCell style={{ width: '70%' }}>
                                          Value
                                        </TableCell>
                                      </TableRow>
                                    </TableHead>
                                    <TableBody>
                                      {row['attributes'].map((attribute) => {
                                        return (
                                          <TableRow
                                            className={classes.root}
                                            key={attribute}
                                          >
                                            <TableCell style={{ width: '30%' }}>
                                              {attribute}
                                            </TableCell>
                                            <TableCell style={{ width: '70%' }}>
                                              {this.state.attributeSchema[
                                                attribute
                                              ].type == 'MultiSelect' ? (
                                                <MultiSelect
                                                  refLovs={
                                                    this.state.attributeSchema[
                                                      attribute
                                                    ].value
                                                  }
                                                  value={
                                                    row['selattributes'][
                                                      attribute
                                                    ]
                                                  }
                                                  changed={(selected) => {
                                                    if (
                                                      !(
                                                        selected instanceof
                                                        Array
                                                      )
                                                    )
                                                      selected = [selected];

                                                    let attributes = {
                                                      ...row['selattributes'],
                                                    };
                                                    attributes[attribute] =
                                                      selected;
                                                    this.setState({
                                                      matrixRows:
                                                        this.state.matrixRows.map(
                                                          (el) =>
                                                            el.id === row.id
                                                              ? {
                                                                  ...el,
                                                                  selattributes:
                                                                    attributes,
                                                                }
                                                              : el
                                                        ),
                                                    });
                                                  }}
                                                  placeholder={attribute}
                                                />
                                              ) : (
                                                <TextField
                                                  placeholder={attribute}
                                                  fullWidth
                                                  value={
                                                    row['selattributes'][
                                                      attribute
                                                    ]
                                                  }
                                                  onChange={(event) => {
                                                    let attributes = {
                                                      ...row['selattributes'],
                                                    };
                                                    attributes[attribute] =
                                                      event.target.value;

                                                    this.setState({
                                                      matrixRows:
                                                        this.state.matrixRows.map(
                                                          (el) =>
                                                            el.id === row.id
                                                              ? {
                                                                  ...el,
                                                                  selattributes:
                                                                    attributes,
                                                                }
                                                              : el
                                                        ),
                                                    });
                                                  }}
                                                />
                                              )}
                                            </TableCell>
                                          </TableRow>
                                        );
                                      })}
                                    </TableBody>
                                  </Table>
                                </React.Fragment>
                              )}

                              {row['offerability'].length > 0 && (
                                <React.Fragment>
                                  <Typography
                                    variant='h6'
                                    gutterBottom
                                    component='div'
                                    style={{
                                      marginTop: '1%',
                                    }}
                                  >
                                    Offerability
                                  </Typography>
                                  <Table size='small' aria-label='purchases'>
                                    <TableHead>
                                      <TableRow>
                                        <TableCell style={{ width: '30%' }}>
                                          Offerability Name
                                        </TableCell>
                                        <TableCell style={{ width: '70%' }}>
                                          Value
                                        </TableCell>
                                      </TableRow>
                                    </TableHead>
                                    <TableBody>
                                      {row['offerability'].map(
                                        (offerability) => {
                                          return (
                                            <TableRow
                                              className={classes.root}
                                              key={offerability}
                                            >
                                              <TableCell
                                                style={{ width: '30%' }}
                                              >
                                                {offerability}
                                              </TableCell>
                                              <TableCell
                                                style={{ width: '70%' }}
                                              >
                                                {this.state.offerabilitySchema[
                                                  offerability
                                                ] &&
                                                this.state.offerabilitySchema[
                                                  offerability
                                                ] !== undefined &&
                                                this.state.offerabilitySchema[
                                                  offerability
                                                ].type == 'MultiSelect' ? (
                                                  <MultiSelect
                                                    refLovs={
                                                      this.state
                                                        .offerabilitySchema[
                                                        offerability
                                                      ].value
                                                    }
                                                    value={
                                                      row['selOfferabilities'][
                                                        offerability
                                                      ]
                                                    }
                                                    changed={(selected) => {
                                                      console.log(selected);
                                                      if (
                                                        !(
                                                          selected instanceof
                                                          Array
                                                        )
                                                      )
                                                        selected = [selected];

                                                      console.log(selected);

                                                      let offerabilities = {
                                                        ...row[
                                                          'selOfferabilities'
                                                        ],
                                                      };
                                                      offerabilities[
                                                        offerability
                                                      ] = selected;
                                                      this.setState({
                                                        matrixRows:
                                                          this.state.matrixRows.map(
                                                            (el) =>
                                                              el.id === row.id
                                                                ? {
                                                                    ...el,
                                                                    selOfferabilities:
                                                                      offerabilities,
                                                                  }
                                                                : el
                                                          ),
                                                      });
                                                    }}
                                                    placeholder={offerability}
                                                  />
                                                ) : (
                                                  <TextField
                                                    placeholder={offerability}
                                                    fullWidth
                                                    value={
                                                      row['selOfferabilities'][
                                                        offerability
                                                      ]
                                                    }
                                                    onChange={(event) => {
                                                      let offerabilities = {
                                                        ...row[
                                                          'selOfferabilities'
                                                        ],
                                                      };
                                                      offerabilities[
                                                        offerability
                                                      ] = event.target.value;

                                                      this.setState({
                                                        matrixRows:
                                                          this.state.matrixRows.map(
                                                            (el) =>
                                                              el.id === row.id
                                                                ? {
                                                                    ...el,
                                                                    selOfferabilities:
                                                                      offerabilities,
                                                                  }
                                                                : el
                                                          ),
                                                      });
                                                    }}
                                                  />
                                                )}
                                              </TableCell>
                                            </TableRow>
                                          );
                                        }
                                      )}
                                    </TableBody>
                                  </Table>
                                </React.Fragment>
                              )}
                            </Box>
                          </Collapse>
                        </TableCell>
                      </TableRow>
                    </React.Fragment>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>

            {this.props.releaseData.releaseId && (
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'flex-end',
                  alignItems: 'center',
                }}
              >
                <StyledButton
                  //   variant="contained"
                  onClick={this.saveRentalMatrix}
                  style={{
                    // background: "#02bfa0",
                    textTransform: 'none',
                    marginTop: '1%',
                    marginBottom: '1%',
                    background: '#5dc17f',
                  }}
                >
                  Save
                </StyledButton>
              </div>
            )}
          </CardContent>
        </Card>
      </React.Fragment>
    );
    if (this.state.loading) rentalMatrix = <Loader relative />;

    return rentalMatrix;
  }
}

export default withStyles(useStyles)(WithErrorHandler(RentalMatrix, axios));

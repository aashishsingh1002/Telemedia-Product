import React, { Component } from "react";
import WithErrorHandler from "../../../HOC/WithErrorHandler/WithErrorHandler";
import axios from "axios";
import { connect } from "react-redux";
import TextField from "@material-ui/core/TextField";
import CustomTable from "../../../UI/Table/Table";
import Loader from "../../../UI/Loader/Loader";
import Select from "react-select";
import EditIcon from "@material-ui/icons/Edit";
import IconButton from "@material-ui/core/IconButton";
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";
import { withStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import SaveIcon from "@material-ui/icons/Save";

const useStyles = (theme) => ({
  cardHeader: {
    background: "#546D7A",
    height: "4vh",
  },
  subheader: {
    color: "white",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "96%",
    flexShrink: 0,
  },
  selectMenuOuter: { top: "auto", bottom: "100%" },
});

class CtsConfiguration extends Component {
  _isMounted = false;

  state = {
    loading: true,
    columns: [
      {
        title: "Entity",
        field: "entity",
        sorting: false,
        // cellStyle: { width: '15%' }
      },
      {
        title: "UI Name",
        field: "uiName",
        sorting: false,
        render: (rowData) => (
          <TextField
            fullWidth
            value={rowData.uiName}
            onChange={(event) => {
              this.setState({
                schema: this.state.schema.map((el) =>
                  el.refId === rowData.refId
                    ? {
                        ...el,
                        uiName: event.target.value,
                      }
                    : el
                ),
              });
            }}
          />
        ),
        // cellStyle: { width: '15%' }
      },
      {
        title: "Reference Name",
        field: "refName",
        sorting: false,
        render: (rowData) => (
          <TextField
            fullWidth
            value={rowData.refName}
            onChange={(event) => {
              this.setState({
                schema: this.state.schema.map((el) =>
                  el.refId === rowData.refId
                    ? {
                        ...el,
                        refName: event.target.value,
                      }
                    : el
                ),
              });
            }}
          />
        ),
        //  cellStyle: { width: '15%' }
      },
      {
        title: "Display",
        field: "isDisplay",
        sorting: false,
        render: (rowData) => (
          <Select
            menuPortalTarget={document.body}
            styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
            onChange={(selectedOption) => {
              console.log(selectedOption);
              this.setState({
                schema: this.state.schema.map((el) =>
                  el.refId === rowData.refId
                    ? {
                        ...el,
                        isDisplay: selectedOption.value,
                      }
                    : el
                ),
              });
            }}
            options={[
              {
                value: "Y",
                label: "Y",
              },
              {
                value: "N",
                label: "N",
              },
            ]}
            value={{
              value: rowData.isDisplay,
              label: rowData.isDisplay,
            }}
            menuPortalTarget={document.body}
            styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
          />
        ),
        // , cellStyle: { width: '5%' }
      },
      {
        title: "Edit",
        field: "edit",
        render: (rowData) => (
          <IconButton
            onClick={() => {
              let payload = { ...rowData };
              payload.opId = this.props.userInfo.opId;
              payload.buId = this.props.userInfo.buId;
              this.setState({ loading: true });
              axios
                .post(process.env.REACT_APP_URL + "config", payload, {
                  headers: {
                    authUserId: this.props.userInfo.id,
                    Authorization: 'Bearer ' + this.props.userInfo.jwt
                  },
                })
                .then((response) => {
                  console.log(response);
                  this.setState({ loading: false });
                })
                .catch((error) => {
                  console.log(error);
                  if (this._isMounted) this.setState({ loading: false });
                });
            }}
          >
            <EditIcon />
          </IconButton>
        ),
        sorting: false,
      },
    ],
    schema: [],
    addField: {
      entity: "",
      refId: null,
      entityName: "",
      refName: "",
      uiName: "",
      refLovs: null,
      refType: "",
      displayOrder: null,
      isDisplay: "",
      isMandatory: "",
      uiGroup: null,
      groupName: null,
    },
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;
    console.log("moued");
    console.log(this.state.schema);
    this.uiFields().then(() => {
      this.setState({ loading: false });
    });
  }

  uiFields() {
    return axios
      .all([
        axios.get(
          process.env.REACT_APP_URL +
            "config/entity?entityName=product.categoryList",
          {
            headers: {
              opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
              authUserId: this.props.userInfo.id,
              Authorization: "Bearer " + this.props.userInfo.jwt,
            },
          }
        ),
        axios.get(
          process.env.REACT_APP_URL +
            "config/entity?entityName=product.subTypeList",
          {
            headers: {
              opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
              authUserId: this.props.userInfo.id,
             Authorization: "Bearer " + this.props.userInfo.jwt,
            },
          }
        ),
        axios.get(
          process.env.REACT_APP_URL +
            "config/entity?entityName=product.typeList",
          {
            headers: {
              opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
              authUserId: this.props.userInfo.id,
           Authorization: "Bearer " + this.props.userInfo.jwt,
            },
          }
        ),
      ])
      .then(
        axios.spread((categoryRes, subTypesRes, typesRes) => {
          let typesHelper = typesRes.data.data;
          let subTypesHelper = subTypesRes.data.data;
          let categoriesHelper = categoryRes.data.data;
          let schema = [];

          categoriesHelper.forEach(function (element) {
            element.entity = "Category";
          });
          typesHelper.forEach(function (element) {
            element.entity = "Type";
          });
          subTypesHelper.forEach(function (element) {
            element.entity = "Sub Type";
          });
          schema.push(...categoriesHelper);
          schema.push(...typesHelper);
          schema.push(...subTypesHelper);
          this.setState({
            schema: schema,
          });
        })
      )
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  render() {
    const { classes } = this.props;

    let ctsConfiguration = (
      <div>
        <div
          style={
            this.state.loading ? { display: "none" } : { display: "block" }
          }
        >
          <CustomTable
            pageSize={10}
            title="CTS Configuration"
            data={this.state.schema}
            columns={this.state.columns}
          />

          <Card style={{ overflow: "visible", marginTop: "3vh" }}>
            <CardHeader
              className={classes.cardHeader}
              classes={{
                subheader: classes.subheader,
              }}
              subheader={"Add Field"}
            />

            <CardContent>
              <TableContainer component={Paper}>
                <Table className={classes.table} size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Entity</TableCell>
                      <TableCell>Name</TableCell>
                      <TableCell>Reference Name</TableCell>
                      <TableCell>Display</TableCell>
                      <TableCell>Save</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    <TableRow>
                      <TableCell>
                        <Select
                          menuPlacement="top"
                          menuPortalTarget={document.body}
                          styles={{
                            menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                          }}
                          onChange={(selectedOption) => {
                            this.setState((prevState) => {
                              return {
                                addField: {
                                  ...prevState.addField,
                                  entity: selectedOption.value,
                                },
                              };
                            });
                          }}
                          options={[
                            {
                              value: "Category",
                              label: "Category",
                            },
                            {
                              value: "Type",
                              label: "Type",
                            },
                            {
                              value: "Sub Type",
                              label: "Sub Type",
                            },
                          ]}
                          value={{
                            value: this.state.addField.entity,
                            label: this.state.addField.entity,
                          }}
                          menuPortalTarget={document.body}
                          styles={{
                            menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <TextField
                          fullWidth
                          value={this.state.addField.uiName}
                          onChange={(event) => {
                            let val = event.target.value;
                            this.setState((prevState) => {
                              return {
                                addField: {
                                  ...prevState.addField,
                                  uiName: val,
                                },
                              };
                            });
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <TextField
                          fullWidth
                          value={this.state.addField.refName}
                          onChange={(event) => {
                            let val = event.target.value;

                            this.setState((prevState) => {
                              return {
                                addField: {
                                  ...prevState.addField,
                                  refName: val,
                                },
                              };
                            });
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <Select
                          menuPlacement="top"
                          menuPortalTarget={document.body}
                          styles={{
                            menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                          }}
                          onChange={(selectedOption) => {
                            this.setState((prevState) => {
                              return {
                                addField: {
                                  ...prevState.addField,
                                  isDisplay: selectedOption.value,
                                },
                              };
                            });
                          }}
                          options={[
                            {
                              value: "Y",
                              label: "Y",
                            },
                            {
                              value: "N",
                              label: "N",
                            },
                          ]}
                          value={{
                            value: this.state.addField.isDisplay,
                            label: this.state.addField.isDisplay,
                          }}
                          menuPortalTarget={document.body}
                          styles={{
                            menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <IconButton
                          onClick={() => {
                            let payload = { ...this.state.addField };
                            console.log(payload);

                            if (payload.entity === "Category")
                              payload.entityName = "product.categoryList";
                            else if (payload.entity === "Type")
                              payload.entityName = "product.typeList";
                            else if (payload.entity === "Sub Type")
                              payload.entityName = "product.subTypeList";

                            payload.opId = this.props.userInfo.opId;
                            payload.buId = this.props.userInfo.buId;
                            this.setState({ loading: true });
                            axios
                              .post(
                                process.env.REACT_APP_URL + "config",
                                payload,
                                {
                                  headers: {
                                    authUserId: this.props.userInfo.id,
                                    Authorization:
                                      "Bearer " + this.props.userInfo.jwt,
                                  },
                                }
                              )
                              .then((response) => {
                                let item = {
                                  refId: null,
                                  entityName: "",
                                  refName: "",
                                  uiName: "",
                                  refLovs: null,
                                  refType: "",
                                  displayOrder: null,
                                  isDisplay: "",
                                  isMandatory: "",
                                  uiGroup: null,
                                  groupName: null,
                                  entity: "",
                                };
                                console.log(response.data.data);
                                let newField = response.data.data;
                                newField.entity = payload.entity;
                                let schema = [...this.state.schema];
                                schema.push(newField);
                                this.setState({
                                  loading: false,
                                  schema: schema,
                                  addField: item,
                                });
                              })
                              .catch((error) => {
                                console.log(error);
                                if (this._isMounted)
                                  this.setState({ loading: false });
                              });
                          }}
                        >
                          <SaveIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </div>
        {this.state.loading && <Loader />}
      </div>
    );
    return ctsConfiguration;
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
  };
};

export default connect(mapStateToProps)(
  withStyles(useStyles)(WithErrorHandler(CtsConfiguration, axios))
);

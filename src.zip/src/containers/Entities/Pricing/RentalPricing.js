import React, { Component } from 'react';
import axios from '../../../axios-epc';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import Input from '../../../UI/Input/Input';
// import Button from "@material-ui/core/Button";
import Button from '../../../UI/Button/Button';
import Loader from '../../../UI/Loader/Loader';
import Modal from '../../../UI/Modal/Modal';
import Typography from '@material-ui/core/Typography';
import moment from 'moment';
import Tooltip from '@material-ui/core/Tooltip';
import AddIcon from '@material-ui/icons/Add';
import { connect } from 'react-redux';
import * as actionTypes from '../../../store/actions/actionTypes';

import StyledButton from '../../../UI/Button/Button';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';



function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
}

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: '#525354',
    color: 'white',
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

const useStyles = (theme) => ({
  cardHeader: {
    // background: "#546D7A",
    // height: "4.5vh",
    paddingBottom: 0,
  },
  subheader: {
    color: 'rgba(0, 0, 0, 0.87)',
    fontSize: '16px',
    fontWeight: '600',
    // color: "white",
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
});

class RentalPricing extends Component {
  _isMounted = false;

  state = {
    schemaRental: [],
    rentalGroups: {},
    schemaRentalRc: [],
    schemaRentalNrc: [],
    loading: true,
    show: false,
    modalContent:'',
    componentIdRental: '',
    serviceTypeId:'/service',
    currency:'INR',
    isValidated:false,

  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;
    this.rentalFields().then(() => {
      let rentalGroups = {};
      let schemaRentalNrc = [];
      let schemaRentalRc = [];
      
      this.state.schemaRental.forEach((el) => {
        if (!(el.uiGroup in rentalGroups)) {
          let arr = [];
          let lovs = [];
          
          this.state.schemaRental.forEach((elem) => {
            
            if (elem.uiGroup == el.uiGroup && elem.uiGroup != 'Price Details') {
              if (
                elem.refType == 'SelectInput' ||
                elem.refType == 'MultiSelect'
              ) {
                console.log(elem.refLovs.split(','))
                lovs = elem.refLovs.split(',');
                elem.refLovs = lovs;
              }
              arr.push(elem);
            }
          });
          rentalGroups[el.uiGroup] = arr;
        }
      });
      let arrPd = [];

      this.state.schemaRental.forEach((elem) => {
        if (elem.uiGroup == 'Price Details') {
          let lovs = [];
          if (elem.refType == 'SelectInput' || elem.refType == 'MultiSelect') {
            lovs = elem.refLovs.split(',');
            elem.refLovs = lovs;
          }
          if (elem.groupName == 'mandatory') {
            arrPd.push(elem);
          } else if (elem.groupName.includes('RCTYPE_NRC')) {
            schemaRentalRc.push(elem);
            schemaRentalNrc.push(elem);
          } else {
            if (elem.groupName.includes('RCTYPE')) {
              schemaRentalRc.push(elem);
            } else if (elem.groupName.includes('NRC')) {
              schemaRentalNrc.push(elem);
            }
          }
        }
      });
      rentalGroups['Price Details'] = arrPd;
      this.setState({
        rentalGroups: rentalGroups,
        schemaRentalNrc: schemaRentalNrc,
        schemaRentalRc: schemaRentalRc,
        loading: false,
      });
      if (this.props.rentalData && 
        Object.keys(this.props.rentalData).length > 0) {
        Object.keys(this.props.rentalData).forEach((key) => {
          this.setState({ [key]: this.props.rentalData[key] });
        });
        this.setState({
          componentIdRental: this.props.rentalData.componentName,
        });
      }
    });
  }

  rentalFields() {
    if (
      localStorage.getItem('rental') &&
      localStorage.rental_version &&
      localStorage.rental_version == this.props.rentalVersion
    ) {
      console.log('fetching RENTAL from local storage');
      try {
        this.setState({
          schemaRental: JSON.parse(localStorage.getItem('rental')),
        });
      } catch (e) {
        localStorage.removeItem('rental');
      }
      return Promise.resolve();
    } else {
      console.log('fetching RENTAL from api');
      return axios
        .get('package/config?entityName=package.rental', {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
            Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        })
        .then((res) => {
          localStorage.setItem('rental', JSON.stringify(res.data.data));
          this.schemaRental = res.data.data;
          if (this._isMounted)
            this.setState({
              schemaRental: res.data.data,
            });
          localStorage.rental_version = this.props.rentalVersion;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  checkExistingPlan = (priceType) => {
    
		return axios.get(`/pricing/onecomponent?productId=${this.props.id}`, {
			headers: {
				opId: this.props.releaseData.opId,
				buId: this.props.releaseData.buId,
       priceType,
       comp:'Rental'
				
			},
		})
	};

  errorConfirmedHandler = () => {
    this.setState({ show: false });
  };
  saveDirectRentalHandler = (event) => {
		event.preventDefault();
    
    // const response = this.checkExistingPlan(this.state.priceType);
    // console.log('RE',response);
    
    // const planValidation = this.props.allPricingComponents.findIndex(item => item.componentSubType === this.state.priceType);
    const planValidation = this.props.allPricingComponents.findIndex(item => item.componentSubType === this.state.priceType);
    if (planValidation >= 0 && !this.state.componentIdRental) {
      let modalContent = (
        <Typography variant="h6"> Rental Component for Type {this.state.priceType} Exists </Typography>
      );
      
      this.setState({ modalContent: modalContent, show: true });
     
      return;
    }

    const response = this.checkExistingPlan(this.state.priceType);
    console.log('RE',response);

		if (this.props.id){
				this.setState({ loading: true });
				let payload = {};
				let date = moment().format('DD-MMM-YY');
				let componentDetails = {};

				this.state.schemaRental.map((formElement) => {
					if (formElement.refType == 'Date')
						componentDetails[formElement.refName] = moment(
							this.state[formElement.refName]
						).format('DD-MMM-YY');
					else if (formElement.refType == 'Checkbox')
          componentDetails[formElement.refName] =
            this.state[formElement.refName] === null ||
            this.state[formElement.refName] === undefined
              ? 'N'
              : this.state[formElement.refName];
        else if (formElement.refType == 'TextInput' || 'TextArea')
          componentDetails[formElement.refName] =
            this.state[formElement.refName];
        else
          componentDetails[formElement.refName] =
            this.state[formElement.refName];
      });
      
      componentDetails.chargeCurrency = this.state.currency;
      componentDetails.chargeListPrice = this.state.listPrice;
      componentDetails.rcFrequency = this.state.chargeFrequency;
      componentDetails.createdDate = date;
      componentDetails.endDate = '30-Dec-30';
				componentDetails.startDate = date;
				componentDetails.buId = this.props.userInfo.buId;
				componentDetails.opId = this.props.userInfo.opId;
				componentDetails.createdBy = this.props.userInfo.id;
				componentDetails.customerSegmentId = 'ANY';
				componentDetails.customerMarketCode = 'ANY';
				componentDetails.customerTypeId = 'ANY';
				componentDetails.channelId = 'ANY';
				componentDetails.minimum = '0';
				componentDetails.maximum = '0';
				componentDetails.payNow = 'N';
				componentDetails.chargeType = 'PO';
				componentDetails.productId = this.props.id;
				componentDetails.componentTypeId = 'RENTAL';
				componentDetails.priceCompMethod = 'DIRECT';
				componentDetails.overridable = this.state.overridable
					? this.state.overridable === 'Yes'
						? 'Y'
						: 'N'
					: 'N';
          // this.state.radioBasicDetails === 'overridable' ? 'Y' : 'N';
				componentDetails.prorateFirst = this.state.prorateFirst
        ? this.state.prorateFirst === 'Yes'
          ? 'Y'
          : 'N'
        : 'Y';
      // this.state.radioBasicDetails === 'prorateFirst' ? 'Y' : 'N';
      payload.releaseId = this.props.releaseData.releaseId;
      payload.id = this.props.id;
      payload.componentType = this.props.entity + 'Components';
      console.log(payload);
      if (!this.state.componentIdRental) {
        console.log('post request');
        payload.componentDetails = componentDetails;

        axios
          .post('pricing/direct', payload)
          .then((response) => {
            console.log(response.data.data);
            if (this._isMounted)
              this.setState({
                loading: false,
                componentIdRental: response.data.data,
              });

            let obj = {};
            obj.componentId = this.state.componentIdRental;
            obj.componentType = 'Rental';
            obj.componentSubType = this.state.priceType;
            obj.componentValue =
              this.state.listPrice + ' ' + this.state.currency;
            obj.componentFrequency =
              obj.componentSubType == 'RC'
                ? this.state.chargeFrequency
                : null;
             
            this.props.addComponent(obj);
            window.location.reload();
            if (this._isMounted){
            this.state.listPrice = '';
            this.state.priceType = '';
            this.state.chargeFrequency = '';
            this.state.effectiveStartDuration = '';
            this.state.compTermUnits = '';
              this.state.compTerm = '';
              this.state.effectiveStartUnits = '';}
              
             
						})
						.catch((error) => {
							console.log(error);
							if (this._isMounted) this.setState({ loading: false });
						});
				} 
        else {
					console.log('put request');
					componentDetails.productComponentId = this.state.componentIdRental;
					componentDetails.productComponentRefId = this.state.componentIdRental;
					payload.componentDetails = componentDetails;

					axios
						.post('pricing/direct', payload)
						.then((response) => {
							console.log(response.data.data);
							let obj = {};
							obj.componentId = response.data.data;
							obj.componentType = 'Rental';
							obj.componentSubType = this.state.priceType;
							obj.componentValue =
								this.state.listPrice + ' ' + this.state.currency;
							obj.componentFrequency =
								obj.componentSubType == 'RC'
									? this.state.chargeFrequency
									: null;

              this.props.updateComponent(obj, this.state.componentIdRental);
              window.location.reload();
              if (this._isMounted){
                this.state.listPrice = '';
                this.state.priceType = '';
                this.state.chargeFrequency = '';
                this.state.effectiveStartDuration = '';
                this.state.compTermUnits = '';
                this.state.compTerm = '';
                this.state.effectiveStartUnits = '';}
							if (this._isMounted)
								this.setState({
									loading: false,
									componentIdRental: response.data.data,
								});
						})
						.catch((error) => {
							console.log(error);
							if (this._isMounted) this.setState({ loading: false });
						});
				}
			} else {
				let modalContent = (
					<Typography variant="h6">
						{' '}
						Submit Basic {this.props.entity} Details first.{' '}
					</Typography>
				);
				this.setState({ modalContent: modalContent, show: true });
			}
		
	};











  validateHandler = () => {
    try{
		return axios
			.get(
				`attribute/validation?packageId=${this.props.id}&releaseID=${this.props.releaseData.releaseId}`,
				{
					headers: {
						opId: this.props.userInfo.opId,
						buId: this.props.userInfo.buId,
            Authorization:'Bearer '+ this.props.userInfo.jwt
					},
				}
			)
			.then((res) => {
				if(res.data.statusMsg==="SUCCESS"){
				this.setState({
					
					isValidated: true,
					openSnack:true,
					message:"Success",
				});}
				else{
					this.setState({
					openSnack:true,
					message:"Failure",
					})
				}
			});
    }catch(err) {
      console.error(err);
    }
	};
  render() {
    const { classes } = this.props;
    const vertical = 'top';
    const horizontal = 'center';
    let pricing = (
      <>
      <Snackbar anchorOrigin={{ vertical, horizontal }}
                        open={this.state.openSnack} autoHideDuration={3000} onClose={this.handleClose}>
                        <Alert onClose={this.handleClose} severity="success">
                            {this.state.message}
                        </Alert>
                    </Snackbar>


      <Grid container alignContent='flex-start' spacing={2}>
        <Modal
          show={this.state.show}
          modalClosed={this.errorConfirmedHandler}
          title={'Something Went Wrong!'}
        >
          {this.state.modalContent}
        </Modal>
        <Grid item xs={12}>
          <form onSubmit={this.saveDirectRentalHandler}>
            {Object.keys(this.state.rentalGroups).map((key) => {
              return (
                <Card
                  key={key}
                  style={{ marginTop: '1%', overflow: 'visible' }}
                >
                  <CardHeader
                    className={classes.cardHeader}
                    classes={{
                      subheader: classes.subheader,
                    }}
                    subheader={key}
                    action={
                      key == 'Basic Details' && (
                        <LightTooltip title='New Rental Component' arrow>
                          <AddIcon
                            onClick={() => {
                              this.setState({
                                componentIdRental: '',
                              });

                              this.state.schemaRental.map((formElement) => {
                                if (formElement.refType == 'Date')
                                  this.setState({
                                    [formElement.refName]:
                                      formElement.defaultValue
                                        ? moment(
                                            formElement.defaultValue
                                          ).format('DD-MMM-YY')
                                        : moment().format('DD-MMM-YY'),
                                  });
                                else if (formElement.refType == 'Checkbox')
                                  this.setState({
                                    [formElement.refName]: 'N',
                                  });
                                else if (formElement.refType == 'MultiSelect')
                                  this.setState({
                                    [formElement.refName]: [],
                                  });
                                else
                                  this.setState({
                                    [formElement.refName]: '',
                                  });
                              });
                            }}
                            style={{
                              //   color: "white",
                              //   marginRight: "10px",
                              cursor: 'pointer',
                            }}
                          />
                        </LightTooltip>
                      )
                    }
                  />

                  <CardContent>
                    <Grid container alignItems='flex-end' spacing={2}>
                    
                      {this.state.rentalGroups[key].map((formElement) => (
                        
                        <Input
                           
                          key={formElement.refName}
                          {...formElement}
                          // value={this.state[formElement.refName]}
                          // disabled={
                          //   formElement.isDisabled == 'Y' ? true : false
                          // }
                          value={
                            formElement.refType === 'Radio'
                              ? this.state.radioBasicDetails
                        
                              : formElement.refName === 'overridable' ||
                                formElement.refName === 'prorateFirst'
                              ? this.state[formElement.refName] ??
                                formElement.defaultValue
                              : formElement.refName === "serviceTypeId" ?this.state.serviceTypeId:
                              this.state[formElement.refName]
                          }
                          disabled={
                            formElement.isDisabled === 'Y'
                              ? true
                              : formElement.refName === 'prorateFirst' &&
                                this.state.overridable === 'Yes'
                              ? true
                              : false
                          }
                          required={
                            formElement.isMandatory === 'Y' ? true : false
                          }
                          checkChanged={(event) => {
                            this.setState({
                              [formElement.refName]: event.target.checked
                                ? 'Y'
                                : 'N',
                            });
                          }}
                          changed={(event) => {
                            if (!event.target) {
                              if (formElement.refType === 'Radio') {
                                this.setState({
                                  radioBasicDetails: event,
                                });
                              } else {
                                if (formElement.refName === 'overridable') {
                                  this.setState((prev) => {
                                    return {
                                      [formElement.refName]: event,
                                      prorateFirst:
                                        event === 'Yes'
                                          ? 'No'
                                          : prev.prorateFirst ?? null,
                                    };
                                  });
                                }
                                else if (formElement.refName==='serviceTypeId'){
                                  this.setState({serviceTypeId :event })
                                
                                } else {
                                  this.setState((prev) => {
                                    return {
                                      [formElement.refName]: event,
                                    };
                                  });
                                }
                              }
                            } else {
                              // if (event.target.type !== 'checkbox')
                              if (formElement.refType === 'Radio') {
                                this.setState({
                                  radioBasicDetails: event.target.value,
                                });
                              } else {
                                this.setState({
                                  [formElement.refName]:
                                    formElement.refType === 'NumberInput' &&
                                    event.target.value < 1
                                      ? null
                                      : event.target.value,
                                });
                              }
                              // else {
                              //     console.log(event.target.checked)
                              //     this.setState({
                              //         [formElement.refName]:
                              //             event.target.checked
                              //     })
                              // }
                            }
                          }}
                        />
                      ))}
                    </Grid>
                    {this.state.priceType == 'RC' && key == 'Price Details' && (
                      <Grid
                        container
                        alignItems='flex-end'
                        spacing={2}
                        style={{
                          marginTop: '.5%',
                        }}
                      >
                        {this.state.schemaRentalRc.map((formElement) => (
                          <Input
                            key={formElement.refName}
                            {...formElement}
                            value={formElement.refName === "currency" ?this.state.currency:
                            this.state[formElement.refName]}
                            disabled={
                              formElement.isDisabled == 'Y' ? true : false
                            }
                            required={
                              formElement.isMandatory == 'Y' ? true : false
                            }
                            checkChanged={(event) => {
                              this.setState({
                                [formElement.refName]: event.target.checked
                                  ? 'Y'
                                  : 'N',
                              });
                            }}

                            keyUp={(e) => {
															if (
																e.key === '-' &&
																formElement.refType === 'NumberInput'
															) {
																this.setState({
																	[formElement.refName]: '0',
																});
															}
                            }}
                            

                            changed={(event) => {
                              if (!event.target) 
                              {
                                if (formElement.refName==='currency'){
                                this.setState({currency :event })
                              }
                              else{
                                this.setState({
                                  [formElement.refName]: event,
                                });
                              } 

                                
                              } else if(!event.target)  {
                                this.setState({
																	[formElement.refName]:
																		formElement.refType === 'NumberInput' &&
																		(event < 0 || event == '-0' || event =='+0')
																			? '0'
																			: event,
																});
                              }
                              
                              
                              
                              
                              
                              else {
                                
                                this.setState({
																	[formElement.refName]:
																		formElement.refType === 'NumberInput' &&
																		(event.target.value < 0 ||
																			event.target.value == '-0' || event =='+0')
																			? '0'
																			: event.target.value,
                                });
                              
                              }
                            }}
                          />
                        ))}
                      </Grid>
                    )}
                    {this.state.priceType == 'NRC' && key == 'Price Details' && (
                      <Grid
                        container
                        alignItems='flex-end'
                        spacing={2}
                        style={{
                          marginTop: '.5%',
                        }}
                      >
                        {this.state.schemaRentalNrc.map((formElement) => (
                          <Input
                            key={formElement.refName}
                            {...formElement}
                            value={formElement.refName === "currency" ?this.state.currency:
                            this.state[formElement.refName]}
                            disabled={
                              formElement.isDisabled == 'Y' ? true : false
                            }
                            required={
                              formElement.isMandatory == 'Y' ? true : false
                            }
                            checkChanged={(event) => {
                              this.setState({
                                [formElement.refName]: event.target.checked
                                  ? 'Y'
                                  : 'N',
                              });
                            }}
                            changed={(event) => {
                              if (!event.target) {if (formElement.refName==='currency'){
                                this.setState({currency :event })
                              }
                              else{
                                this.setState({
                                  [formElement.refName]: event,
                                });
                              } 
                              
                            } else if(!event.target)  {
                              this.setState({
                                [formElement.refName]:
                                  formElement.refType === 'NumberInput' &&
                                  (event < 0 || event == '-0') 
                                    ? '0'
                                    : event,
                              });
                            }
                                
                               else {
                              
                                this.setState({
																	[formElement.refName]:
																		formElement.refType === 'NumberInput' &&
																		(event.target.value < 0 ||
																			event.target.value == '-0')
																			? '0'
																			: event.target.value,
                                });
                           
                              }
                            }}
                          />
                        ))}
                      </Grid>
                    )}
                  </CardContent>
                </Card>
              );
            })}

            {this.props.releaseData.releaseId && (
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'flex-end',
                  alignItems: 'center',
                }}
              >
                {/* <Button
                  //   variant="contained"
                  onClick={() => {
                    if (this.props.entity === 'Package')
                      this.props.changePackageActiveStep(2);
                    else this.props.changeProductActiveStep(1);
                  }}
                  style={{
                    marginTop: '1%',
                    textTransform: 'none',
                    // border: "1px solid #ff1921",
                    background: '#fff',
                    color: '#ff1921',
                    padding: '6px 0',
                  }}
                  className={classes.btn}
                >
                  Back
                </Button>
                <Button
                  //   variant="contained"
                  onClick={() => {
                    if (this.props.entity === 'Package')
                      this.props.changePackageActiveStep(4);
                    else this.props.changeProductActiveStep(3);
                  }}
                  style={{
                    textTransform: 'none',
                    // background: "blue",
                    background: '#fff',
                    color: '#ff1921',
                    marginTop: '1%',
                    marginLeft: 'auto',
                    padding: '6px',
                  }}
                  className={classes.btn}
                >
                  Next
                </Button> */}
                <StyledButton
                  //   variant="contained"
                  onClick={() => {
										if (this.props.entity === 'Package')
											this.props.changePackageActiveStep(2);
										else this.props.changeProductActiveStep(1);
									}}
                  style={{
                    // background: "#02bfa0",
                    textTransform: 'none',
                    marginTop: '1%',
                    marginLeft: '20px',
                    background: '#5dc17f',
                  }}
                  
                  >
                 Back
                </StyledButton>
                <StyledButton
                  //   variant="contained"
                  onClick={this.validateHandler}
                  style={{
                    // background: "#02bfa0",
                    textTransform: 'none',
                    marginTop: '1%',
                    marginLeft: '20px',
                    background: '#5dc17f',
                  }}
                  disabled={!this.props.id}
                  >
                Validate
                </StyledButton>
                <StyledButton
                  //   variant="contained"
                  type='submit'
                  style={{
                    // background: "#02bfa0",
                    textTransform: 'none',
                    marginTop: '1%',
                    marginLeft: '20px',
                    background: '#5dc17f',
                  }}
                  disabled={
										this.props.releaseData.releaseStatus !== 'InProgress'
									}
                  >
                  Save
                </StyledButton>
                <StyledButton
                  //   variant="contained"
                  onClick={() => {
										if (this.props.entity === 'Package')
											this.props.changePackageActiveStep(4);
										else this.props.changeProductActiveStep(3);
									}}
                  style={{
                    // background: "#02bfa0",
                    textTransform: 'none',
                    marginTop: '1%',
                    marginLeft: '20px',
                    background: '#5dc17f',
                  }}
                  
                  >
                  Next
                </StyledButton>
              </div>
            )}
          </form>
        </Grid>
      </Grid>
      </>
    );

    if (this.state.loading) pricing = <Loader relative />;
    return pricing;
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    changePackageActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
        activeStep: activeStep,
      }),
    changeProductActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP,
        activeStep: activeStep,
      }),
  };
};

export default connect(
  null,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(RentalPricing, axios)));

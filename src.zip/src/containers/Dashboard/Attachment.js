import React, { Component } from 'react';
import Modal from '../../UI/Modal/Modal';
import { DropzoneArea } from 'material-ui-dropzone'
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Input from '@material-ui/core/Input';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import { withStyles } from '@material-ui/core/styles';
import { ThemeProvider ,Snackbar} from '@material-ui/core'
import { createMuiTheme } from '@material-ui/core/styles';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import Popover from '@material-ui/core/Popover';
import IconButton from '@material-ui/core/IconButton';
import CustomTable from '../../UI/Table/TablePadded'
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import Checkbox from '@material-ui/core/Checkbox';
import ListItemText from '@material-ui/core/ListItemText';
import { Alert } from '@material-ui/lab';
import DeleteIcon from '@material-ui/icons/Delete';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Box from '@material-ui/core/Box';
import GetAppIcon from '@material-ui/icons/GetApp';
import PublishIcon from '@material-ui/icons/Publish';
import Grid from '@material-ui/core/Grid';
import Autocomplete from '@material-ui/lab/Autocomplete';
import TextField from '@material-ui/core/TextField';
import { connect } from 'react-redux';


function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={3}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

const useStyles = (theme) => ({
    formControl: {
        margin: theme.spacing(1),
        minWidth: '100%',
    },
    center: {
        textAlign: 'center'
    },
    cardHeader: {
        background: '#546D7A',
        height: '2vh'
    },
    subheader: {
        color: 'white',
    },

});

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250,
        },
    },
};

const theme = createMuiTheme({
    typography: {
		fontFamily: 'BrighterSans',
	},
    overrides: {
        MuiTableCell: {
            root: {
                padding: '0px',
                paddingLeft: '10px'
            },
        },
        MuiDropzoneArea: {
            root: {
                height: '100%',
            },
        },
    },
});


class Attachment extends Component {
    _isMounted = false;

    constructor(props) {
        super(props);
        this.dropzoneRef = React.createRef();
        this.state = {
            activeTab: 0,
            anchorEl: null,
            fileName: null,
            originalFiles: [],
            files: [],
            key: 'app',
            show: true,
            open: false,
			invalid: null,
			invalidFileName: [],
			attachments: {},
			loading: true,
			downloadAttachments: [],
            columns: [
                {
                    title: "File", field: 'fileName', sorting: false, render: rowData =>
                        <span
                            onClick={() => this.downloadAttachmentHandler(rowData.fileName)}
                            style={{
                                cursor: 'pointer',
                                textDecoration: 'underline',
                                color: 'blue'
                            }}> {rowData.fileName}</span>, cellStyle: { width: '40%',fontFamily:'BrighterSans'  }
                },
                {
                    title: "Role", field: 'role', sorting: false, render: rowData =>
                        <span style={{
                            display: 'block',
                            width: '20vw',
                            maxHeight: '100px',
                            overflow: 'auto',
                            wordWrap: 'break-word'
                        }}> {rowData.role}</span>, cellStyle: { width: '20%',fontFamily:'BrighterSans'  }
                },
                { title: "Uploaded By", field: 'createdBy', sorting: false, cellStyle: { width: '20%',fontFamily:'BrighterSans' } },
                {
                    title: "Time", field: 'creationDate', sorting: false, cellStyle: { width: '20%',fontFamily:'BrighterSans' }
                },
                ((this.props.userInfo.group.includes("TelemediaProductManager") &&
                    this.props.releaseData.releaseStatus == "InProgress")
                    || !this.props.userInfo.group.includes("TelemediaProductManager"))
                    ? {
                        title: 'Delete',
                        field: 'delete',
                        render: rowData => {
                            return rowData.createdBy == this.props.userInfo.email && <IconButton onClick={(event) => {
                                this.setState({
                                    fileName: rowData.fileName,
                                    anchorEl: event.currentTarget
                                })
                            }} >
                                <DeleteIcon style={{ cursor: 'pointer', color: '#ff1921' }} />
                            </IconButton>
                        }
                    } : {}

            ],

        };
    }

    componentWillUnmount() {
        this._isMounted = false;
    }


    attachmentDataHandler = () => {
        let req = ''
        if (this.props.userInfo.group.includes("TelemediaProductManager")
            || this.props.userInfo.group.includes("WorkflowAdmin"))
            req = "telemediaAttach/fileNames?releaseId=" +
                this.props.releaseData.releaseId
        else
            req =
                "telemediaAttach/fileNames?releaseId=" +
                this.props.releaseData.releaseId +
                "&roleName=" +
                this.props.approversData[this.props.userInfo.group[0]]
        console.log(req)
        return axios
            .get(
                req
            )
            .then(res => {
                console.log("get files");
                console.log(res);
                if (this._isMounted) {
                    let data = [...res.data.data]
                    this.setState({ downloadAttachments: data })
                }
            })
            .catch(error => {
                console.log(error);
                if (this._isMounted) {
                    this.setState({ loading: false })
                }
            });
    }
    componentDidMount() {
        this._isMounted = true;
        this.attachmentDataHandler().then(() => {
            console.log(this.props.releaseData)
            this.setState({ loading: false })
        })

    }

    handleChange(files) {
		this.setState({
			originalFiles: files,
			invalid: null,
		});
		for (let i = 0; i < files.length - 1; i += 1) {
			if (files[i].name === files[files.length - 1].name) {
				this.dropzoneRef.current.deleteFile(
					files[files.length - 1],
					files.length - 1
				);
			}
		}
		const invalidChar = [
			'#',
			'%',
			'&',
			'$',
			'{',
			'}',
			'\\',
			'<',
			'>',
			'*',
			'?',
			'/',
			'!',
			"'",
			'"',
			':',
			'@',
			'+',
			'`',
			'|',
			'=',
            ';',
		];

		const allowedExt = [
			'gif',
			'jpeg',
			'jpg',
			'png',
			'pdf',
			'txt',
			'xls',
			'doc',
			'docx',
			'xlsx',
			'zip',
			'csv',
			'xla',
			'msg',
		];
		if (files.length) {
			const fileName = files[files.length - 1].name.split('.')[0];
			const fileExt = files[files.length - 1].name.split('.')[1];

			const invalidFileName = [];
			if (fileName) {
				invalidChar.map((char) => {
					if (fileName.includes(char)) {
						invalidFileName.push(fileName);
					}
				});
			}
			if (invalidFileName.length) {
				this.dropzoneRef.current.deleteFile(
					files[files.length - 1],
					files.length - 1
				);
				this.setState({
					invalidFileName: [...this.state.invalidFileName, ...invalidFileName],
					invalid: 'fail',
					open: true,
				});
				return;
			} else if (!allowedExt.includes(fileExt)) {
				this.dropzoneRef.current.deleteFile(
					files[files.length - 1],
					files.length - 1
				);
				this.setState({
					invalid: 'failExt',
					open: true,
				});
				return;
			} else {
				this.setState({
					invalid: this.state.invalid ?? 'success',
				});
			}
		}
		let fileNames = [];
		files = [
			...files.filter((v, i, a) => a.findIndex((t) => t.name === v.name) === i),
		];

		files = [
			...files.filter(
				(a) => !this.state.invalidFileName.includes(a.name.split('.')[0])
			),
		];

		files.forEach((file) => {
			fileNames.push(file.name);
		});
		let attachments = Object.keys(this.state.attachments);
		let difference = fileNames.filter((x) => !attachments.includes(x));

		let newAttachments = {};
		difference.forEach((file) => {
			newAttachments[file] = {
				value: 'All',
				roles: [],
				uploaded: false,
			};
		});

		this.setState((prevState) => {
			return {
				files: files,

				attachments: { ...prevState.attachments, ...newAttachments },
				open: true,
			};
		});
	}

    handleChangeRole = (value, file) => {
        this.setState((prevState) => {
            return {
                attachments: {
                    ...prevState.attachments,
                    [file]: {
                        ...prevState.attachments[file],
                        roles: value, value: 'Specific Role',
                    }
                }
            }
        });
        console.log(this.state.attachments)

    }
    handleAttachmentRoles = (event, file) => {
        this.setState((prevState) => {
            return {
                attachments: {
                    ...prevState.attachments,
                    [file]: {
                        ...prevState.attachments[file],
                        roles: [], value: event.target.value
                    }
                }
            }
        });
        console.log(this.state.attachments)
    }

    modalCloseHandler = () => {
        this.setState({ show: false })
        this.props.showAttachment()
    }

    saveAllAttachmentHandler = () => {
        console.log(this.state.files)
        console.log(this.state.attachments)
        let formData = new FormData();
        let upload = false;
        let files = []
        this.state.files.map(file => {

            if (!this.state.attachments[file.name].uploaded) {
                formData.append("file", file);

                upload = true
                files.push(file)
                if (this.state.attachments[file.name]['value'] == "All") {
                    formData.append("roleName[" + file.name + "]", "All");
                }
                else if (this.state.attachments[file.name]['roles'].length > 0) {

                    let roles = [...this.state.attachments[file.name]['roles']]
                    if (!roles.includes(this.props.approversData[this.props.userInfo.group]) &&
                        !this.props.userInfo.group.includes("WorkflowAdmin")
                        && !this.props.userInfo.group.includes("TelemediaProductManager")) {
                        roles.push(this.props.approversData[this.props.userInfo.group[0]])
                    }
                    roles = roles.filter(function (role) {
                        return role !== undefined;
                    });
                    formData.append("roleName[" + file.name + "]", roles.join());

                    console.log(roles.join())
                }
                else {
                    formData.append("roleName[" + file.name + "]", "All");

                }
            }
        })

        formData.append("releaseId", this.props.releaseData.releaseId);
        formData.append("createdBy", this.props.userInfo.email);

        if (upload) {
            this.setState({ loading: true })

            console.log("formData");
            for (var pair of formData.entries()) {
                console.log(pair[0]);
                console.log(pair[1]);
            }

            axios
                .post("telemediaAttach/uploadFile", formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId
                    }
                })
                .then(response => {
                    console.log(response)
                    this.attachmentDataHandler().then(() => {
                        let key = this.state.key.length > 10 ? 'app' : this.state.key + '1'
                        this.setState({ key: key, files: [] })
                        this.setState({ loading: false, attachments: {}, activeTab: 1 })
                    })
                    if (
						this.props.role === 'CIT_OPS' ||
						this.props.role === 'preProdTest'
					) {
						this.props.completeHandler();
					}


                })
                .catch(error => {
                    console.log(error);
                    this.setState({
                        loading: false,
                    })
                });


        }
    }


    downloadAttachmentHandler = (attachment) => {

        axios
            .get(
                "telemediaAttach/downloadFile?fileName=" +
                attachment +
                "&releaseId=" +
                this.props.releaseData.releaseId,
                { responseType: "blob" }
            )
            .then(res => {

                console.log(res);
                const fileName = res.config.url.split('fileName=')[1].split('&')[0];
                var headers = res.headers;
                var blob = new Blob([res.data], {
                    type: headers["content-type"]
                });

                var link = document.createElement("a");
                link.href = window.URL.createObjectURL(blob);
                link.download = fileName;
                link.click();
            })
            .catch(error => {
                console.log(error);

            });

    }
    handleClose = () => {
		this.setState({
			invalid: null,
			open: false,
		});
	};

    deleteAttachmentHandler = () => {
        debugger;
        console.log(this.state.downloadAttachments)
        console.log(this.state.fileName)
        this.setState({ anchorEl: null, loading: true })
        axios
            .post("telemediaAttach/deleteFile?fileName=" + this.state.fileName + "&releaseId=" +
                this.props.releaseData.releaseId)
            .then(response => {
                console.log(response);

                let downloadAttachments = this.state.downloadAttachments.filter(row => {
                    return row.fileName != this.state.fileName
                })

                console.log(downloadAttachments)
                this.setState({
                    downloadAttachments: downloadAttachments,
                    loading: false
                })

            })
            .catch(error => {
                console.log(error);
                if (this._isMounted)
                    this.setState({ 
                        loading: false });

            });
    }

    render() {
        const open = Boolean(this.state.anchorEl);
        const id = open ? 'simple-popover' : undefined;

        const { classes } = this.props;
        let attachment = <React.Fragment>
        {(this.state.files.length || this.state.invalidFileName.length) > 0 &&
            this.state.invalid && (
                <Snackbar
                    open={this.state.open}
                    autoHideDuration={2000}
                    onClose={this.handleClose}>
                    
                    {this.state.invalid === 'fail' ? (
                        <Alert
                            elevation={6}
                            variant="filled"
                            onClose={this.handleClose}
                            severity="error">
                            File name invalid. Remove special characters
                        </Alert>
                        
                    ) : this.state.invalid === 'success' ? (
                        <Alert
                            elevation={6}
                            variant="filled"
                            onClose={this.handleClose}
                            severity="success">
                            File successfully added.
                        </Alert>
                    ) : this.state.invalid === 'failExt' ? (
                        <Alert
                            elevation={6}
                            variant="filled"
                            onClose={this.handleClose}
                            severity="success">
                            Invalid file extension.
                        </Alert>
                    ) : (
                        this.state.invalid === 'delete' && (
                            <Alert
                                elevation={6}
                                variant="filled"
                                onClose={this.handleClose}
                                severity="info">
                                File deleted
                            </Alert>
                        )
                    )}
                </Snackbar>
            )}
            <Popover id={id} open={open} anchorEl={this.state.anchorEl}
                onClose={() => {
                    this.setState({
                        anchorEl: null
                    })
                }}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
                transformOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                }}
            >
                <Card >
                    <CardHeader
                        className={classes.cardHeader}
                        classes={{
                            subheader: classes.subheader,
                        }}
                        subheader={'Do you want to remove ' + this.state.fileName + ' from this release?'}
                    />
                    <CardContent style={{ padding: '4px' }} >
                        <div style={{ marginTop: '10px', display: 'flex', justifyContent: 'flex-end' }}>
                            <Button size="small" color="primary" style={{
                                textTransform: 'none'
                            }} onClick={() => {
                                this.setState({
                                    anchorEl: null
                                })
                            }}>
                                Close
                                  </Button>
                            <Button size="small" color="primary" style={{
                                textTransform: 'none'
                            }} onClick={this.deleteAttachmentHandler}>
                                Ok
                                  </Button>
                        </div>
                    </CardContent>
                </Card>
            </Popover>

            <Paper square >

                <Tabs
                    value={this.state.activeTab}
                    onChange={(event, newValue) => {
                        this.setState({
                            activeTab: newValue,
                            invalid: null,
                        })
                    }}
                    variant="fullWidth"
                    indicatorColor="white"
                    textColor="primary"
                    fontFamily='BrighterSans'                 >
                    <Tab icon={<PublishIcon />} label="Upload" />
                    <Tab icon={<GetAppIcon />} label="Download" />
                </Tabs>

                <TabPanel value={this.state.activeTab} index={0}>
                    {this.props.releaseData.releaseStatus !== "Deployed" ?
                        <React.Fragment>
                            <Grid container spacing={3} >
                                <Grid item xs={2} >
                                    <ThemeProvider theme={theme}>
                                        <DropzoneArea
                                            key={this.state.key}
                                            ref={this.dropzoneRef}
                                            showAlerts={false}
                                            onChange={this.handleChange.bind(this)}
                                            maxFileSize={30000000}
                                            filesLimit={20}
                                            dropzoneText='Upload'
                                            showPreviewsInDropzone={false}
                                            style={{ height: '100%' }}
                                            acceptedFiles={["image/gif", 'image/jpeg',
                                                'image/png', 'application/pdf', 'text/plain', 'application/vnd.ms-excel'
                                                , 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                                                'application/msword', 'application/vnd.ms-powerpoint',
                                                'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
                                                , 'application/zip','text/csv','.csv','application/csv']}
                                        />
                                    </ThemeProvider>
                                </Grid>
                                <Grid item xs={10} >

                                    <div style={{ fontWeight: 'normal', marginTop: '10px', color: 'red',fontSize:'18px' }}>
                                        <span style={{

                                            marginLeft: '5px',
                                            marginRight: '5px'
                                        }}>*</span>
                                        gif,jpeg,png,pdf,txt,xls,doc,ppt,docx,xlsx,zip,csv,jpg,xla (Accepted Files)
                                        <div>
                                        <span
												style={{
													marginLeft: '5px',
													marginRight: '5px',
												}}>
												*
											</span>
											{
												'File names should not include: #, %, &, {, }, \\, <, >, *, ?, /, $, !, \', ", :, @, +, `, |,=, ;'
											}
                                            </div>
                                        
                     <Button variant="contained"
                                            size="medium"
                                            style={{ background: '#02bfa0', textTransform: 'none',fontWeight: 'bold', float: 'right',fontFamily:'BrighterSans'  }}
                                            onClick={this.saveAllAttachmentHandler}>
                                            Upload
                        </Button>
                                    </div>

                                    <ThemeProvider theme={theme}>
                                        <TableContainer component={Paper} style={{ marginTop: '50px' }}>
                                            <Table size="small" >
                                                <TableHead>
                                                    <TableRow>
                                                        <TableCell align="left" style={{ width: '40%' }}>File Name</TableCell>
                                                        <TableCell align="left" style={{ width: '50%' }}>Visible To</TableCell>
                                                        <TableCell align="left" style={{ width: '10%' }}>Delete</TableCell>
                                                        {/* <TableCell align="left" style={{ width: '20%' }} >Status</TableCell> */}

                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    {this.state.files.map((file, index) => (
                                                        <TableRow key={file.name}>
                                                            <TableCell align="left"> {file.name}</TableCell>
                                                            <TableCell align="left">
                                                                <React.Fragment>
                                                                    <FormControl className={classes.formControl} >
                                                                        <Select
                                                                            MenuProps={MenuProps}
                                                                            displayEmpty
                                                                            value={this.state.attachments[file.name]['value']}
                                                                            onChange={(event) => this.handleAttachmentRoles(event, file.name)}
                                                                            input={<Input />}
                                                                            renderValue={(selected) => {
                                                                                if (selected) {
                                                                                    if (selected.length === 0) {
                                                                                        return <em>Visible To</em>;
                                                                                    }

                                                                                    return selected

                                                                                }
                                                                            }}
                                                                            inputProps={{ 'aria-label': 'Without label' }}
                                                                        >
                                                                            <MenuItem disabled value="">
                                                                                <em>Visible To</em>
                                                                            </MenuItem>
                                                                            {['All', 'Specific Role'].map((name) => (
                                                                                <MenuItem key={name} value={name} >
                                                                                    {name}
                                                                                </MenuItem>
                                                                            ))}
                                                                        </Select>
                                                                    </FormControl>
                                                                    
                                                                    {this.state.attachments[file.name]['value'] == 'Specific Role' ?

                                                                        <Autocomplete
                                                                            disableCloseOnSelect
                                                                            multiple
                                                                            limitTags={2}
                                                                            value={this.state.attachments[file.name]['roles']}
                                                                            onChange={(event, value) => this.handleChangeRole(value, file.name)}
                                                                            options={Object.values(this.props.approversData).filter(approver=>{
                                                                                return !["MS_TEST","NCA_UAT","Selfcare_UAT","preProdTest","Product Manager"].includes(approver);
                                                                            })}
                                                                            renderInput={(params) => (
                                                                                <TextField {...params} />
                                                                            )}
                                                                        />
                                                                        // <FormControl className={classes.formControl}>
                                                                        //     <Select
                                                                        //         multiple
                                                                        //         value={this.state.attachments[file.name]['roles']}
                                                                        //         onChange={(event) => this.handleChangeRole(event, file.name)}
                                                                        //         input={<Input />}
                                                                        //         renderValue={(selected) => {
                                                                        //             if (selected) {
                                                                        //                 if (selected.length === 0) {
                                                                        //                     return <em>Roles</em>;
                                                                        //                 }

                                                                        //                 selected = selected.filter(function (role) {
                                                                        //                     return role !== undefined;
                                                                        //                 });

                                                                        //                 return selected.join()
                                                                        //             }
                                                                        //         }}

                                                                        //         MenuProps={MenuProps}
                                                                        //     >
                                                                        //         {Object.values(this.state.approversData).map((name) => (
                                                                        //             <MenuItem key={name} value={name}>
                                                                        //                 <Checkbox style={{ color: '#ff1921' }}
                                                                        //                     checked={this.state.attachments[file.name]['roles'].indexOf(name) > -1} />
                                                                        //                 <ListItemText primary={name} />
                                                                        //             </MenuItem>
                                                                        //         ))}
                                                                        //     </Select>
                                                                        // </FormControl>

                                                                        : null}
                                                                </React.Fragment>

                                                            </TableCell>
                                                            <TableCell
                                                                align="left"
                                                            >
                                                                {!this.state.attachments[file.name]['uploaded'] ? <DeleteIcon onClick={(event) => {
                                                                    this.setState({
                                                                        invalid: 'delete',
                                                                        open: true,
                                                                    });
                                                                    let files = [...this.state.files]
                                                                    console.log(files)
                                                                    console.log(this.state.attachments)
                                                                    this.dropzoneRef.current.deleteFile(this.state.files[index], index)
                                                                }} style={{ color: 'red', cursor: 'pointer' }} /> : null}
                                                            </TableCell>
                                                            {/* <TableCell align="left">
                                                                {!this.state.attachments[file.name]['uploaded'] ? 'Not Uploaded' : 'Uploaded'}
                                                            </TableCell> */}


                                                        </TableRow>
                                                    ))}
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                    </ThemeProvider>
                                </Grid>
                            </Grid>
                        </React.Fragment>
                        :
                        <div style={{ minHeight: '30vh' }}><Typography variant="h6" className={classes.center} >
                            Upload on Deployed Release is Not Allowed.</Typography></div>}
                </TabPanel>
                <TabPanel value={this.state.activeTab} index={1}>
                    {this.state.downloadAttachments.length > 0 ?
                        <div style={{ marginBottom: '2vh' }}>
                            <CustomTable pageSize={20} title='Attachments' data={this.state.downloadAttachments}
                                columns={this.state.columns} />
                        </div> :
                        <div style={{ minHeight: '30vh' }}><Typography variant="h6" className={classes.center} >
                            No Attachments Found</Typography></div>}

                </TabPanel>
            </Paper>



        </React.Fragment>
        return <Modal show={this.state.show} modalClosed={this.modalCloseHandler}
            title={"Release Id " + this.props.releaseData.externalReleaseId}>
            <div>
                <div style={this.state.loading ? { display: 'none' } : { display: 'block' }}>
                    {attachment}
                </div>
            </div>
            {this.state.loading && <div style={{ minHeight: '30vh' }}> <Loader /> </div>}
        </Modal>
    }

}

const mapStateToProps = state => {
    return {
        approversData: state.approverData.approversData,
    };
}

export default withStyles(useStyles)(WithErrorHandler(connect(mapStateToProps)(Attachment), axios));
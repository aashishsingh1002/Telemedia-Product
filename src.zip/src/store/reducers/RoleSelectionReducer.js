import * as actionTypes from '../actions/actionTypes';

const initialState = {
	hasSelectedService: false,
	roleGroup: null,
};

const roleSelection = (state, action) => {
	return {
		...state,
		hasSelectedService: action.hasSelectedService,
	};
};
const changeRoleGroup = (state, action) => {
	
	return {
		...state,
		roleGroup: action.roleGroup,
	};
};

const reducer = (state = initialState, action) => {
	switch (action.type) {
		case actionTypes.ROLE_SELECTION:
			return roleSelection(state, action);
		case actionTypes.CHANGE_ROLE_GROUP:
			return changeRoleGroup(state, action);
		default:
			return state;
	}
};

export default reducer;

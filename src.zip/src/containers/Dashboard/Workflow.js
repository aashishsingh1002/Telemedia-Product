// import React, { Component } from "react";
// import ModalAction from "../../UI/ModalAction/ModalAction";
// import Loader from "../../UI/Loader/Loader";
// import axios from "../../axios-epc";
// import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
// import { withStyles } from "@material-ui/core/styles";
// import Accordion from "@material-ui/core/Accordion";
// import AccordionDetails from "@material-ui/core/AccordionDetails";
// import AccordionSummary from "@material-ui/core/AccordionSummary";
// import Typography from "@material-ui/core/Typography";
// import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
// import Autocomplete from "@material-ui/lab/Autocomplete";
// import TextField from "@material-ui/core/TextField";
// import Radio from "@material-ui/core/Radio";
// import RadioGroup from "@material-ui/core/RadioGroup";
// import FormControlLabel from "@material-ui/core/FormControlLabel";
// import Table from "@material-ui/core/Table";
// import TableBody from "@material-ui/core/TableBody";
// import TableCell from "@material-ui/core/TableCell";
// import TableContainer from "@material-ui/core/TableContainer";
// import TableHead from "@material-ui/core/TableHead";
// import TableRow from "@material-ui/core/TableRow";
// import Paper from "@material-ui/core/Paper";
// import FormControl from "@material-ui/core/FormControl";
// import Select from "@material-ui/core/Select";
// import MenuItem from "@material-ui/core/MenuItem";
// import Input from "@material-ui/core/Input";
// import Button from "@material-ui/core/Button";
// import InputLabel from "@material-ui/core/InputLabel";

// const useStyles = (theme) => ({
//   center: {
//     textAlign: "center",
//   },
//   root: {
//     "& .MuiPaper-root": {
//       width: "100%",
//     },
//   },
//   heading: {
//     fontSize: theme.typography.pxToRem(15),
//     flexBasis: "33.33%",
//     flexShrink: 0,
//   },
// });

// class Workflow extends Component {
//   _isMounted = false;

//   constructor(props) {
//     super(props);

//     // cellStyle: { width: '20%' }
//     this.state = {
//       approvers: [],
//       showModal: false,
//       show: true,
//       loading: true,
//       expanded: false,
//       worklowVariables: {},
//       smsNotiData: {},
//       data: [],
//       workflowType: "CVM",
//     };
//   }
//   workflowVariableChangeHandler(event, varName) {
//     let worklowVariables = {
//       ...this.state.worklowVariables,
//     };
//     worklowVariables[varName] = event.target.value;
//     this.setState({ worklowVariables: worklowVariables });
//   }

//   modalCloseHandler = () => {
//     this.setState({ show: false });
//     this.props.showWorkflow();
//   };

//   approversDataHandler(id) {
//     return axios
//       .get(process.env.REACT_APP_URL + "SelectApprovers/approver", {
//         headers: {
//           opId: this.props.userInfo.opId,
//           buId: this.props.userInfo.buId,
//           lob: "Postpaid",
//           circle: id.toUpperCase(),
//         },
//       })
//       .then((res) => {
//         console.log(res);
//         if (res) {
//           let workflow = {};
//           let smsNotiData = {};

//           Object.keys(res.data.data).forEach((key) => {
//             res.data.data[key].filter((el) => {
//               smsNotiData[el["grpName"]] = {
//                 primarymail: el["primarysignatory"][0]
//                   ? el["primarysignatory"][0]
//                   : null,
//                 secondarymail: el["primarysignatory"][1]
//                   ? el["primarysignatory"][1]
//                   : null,
//               };
//               if (el["disabled"] == "true")
//                 workflow[el["varName"]] = "Mandatory";
//               else workflow[el["varName"]] = "FYI";
//             });
//           });
//           this.setState({
//             approvers: { ...res.data.data },
//             worklowVariables: workflow,
//             smsNotiData,
//           });
//         }
//       })
//       .catch((error) => {
//         console.log(error);
//         if (this._isMounted) this.setState({ loading: false });
//       });
//   }

//   componentWillUnmount() {
//     this._isMounted = false;
//   }
//   componentDidMount = () => {
//     this._isMounted = true;
//     this.setState({ loading: true });

//     this.approversDataHandler("CVM").then(() => {
//       this.setState({ loading: false });
//     });
//   };
//   changeHandler = (panel) => (event, isExpanded) => {
//     this.setState({ expanded: isExpanded ? panel : false });
//   };
//   initiateApprovalHandler = () => {
//     console.log(this.props.releaseData.pendingWith);
//     if (this.props.releaseData.pendingWith == "WorkFlow Not Initiated") {
//       if (this.state.workflowType) {
//         this.setState({ loading: true });
//         let variables = {};
//         variables.releaseCreatedBy = {
//           value: this.props.releaseData.createdBy,
//           type: "String",
//         };
//         variables.releaseId = {
//           value: this.props.releaseData.releaseId,
//           type: "String",
//         };
//         variables.releaseObjective = {
//           value: this.props.releaseData.remarks,
//           type: "String",
//         };
//         variables.releaseCreationDate = {
//           value: this.props.releaseData.createdOn,
//           type: "String",
//         };
//         variables.releaseStatus = {
//           value: this.props.releaseData.releaseStatus,
//           type: "String",
//         };
//         let worklowVariables = {};
//         Object.keys(this.state.worklowVariables).filter((key) => {
//           if (this.state.worklowVariables[key] == "Mandatory")
//             worklowVariables[key] = {
//               value: true,
//             };
//           else
//             worklowVariables[key] = {
//               value: false,
//             };
//         });
//         let smsNotiPayload = {};
//         let roles = [];
//         Object.keys(this.state.approvers).map((role) => {
//           this.state.approvers[role].map((approver) => {
//             let obj = {};
//             obj.taskname = approver.grpName;
//             obj.primarymail =
//               this.state.smsNotiData[approver.grpName].primarymail;
//             obj.secondarymail =
//               this.state.smsNotiData[approver.grpName].secondarymail;
//             obj.varname = approver.varName;
//             obj.value =
//               this.state.worklowVariables[approver.varName].toLowerCase();
//             roles.push(obj);
//           });
//         });
//         smsNotiPayload.roles = roles;
//         console.log(smsNotiPayload);
//         let payloadVar = {};
//         payloadVar.variables = worklowVariables;
//         let payloadWorkflowStart = {};
//         payloadWorkflowStart.variables = variables;
//         payloadWorkflowStart.businessKey = "myBusinessKey";
//         payloadWorkflowStart.withVariablesInReturn = true;
//         let url = "rest/process-definition/key/cvmflow/start";
//         if (this.state.workflowType === "Device")
//           url = "rest/process-definition/key/devflow/start";
//         else if (this.state.workflowType === "Online")
//           url = "rest/process-definition/key/Onflow/start";
//         console.log(url);
//         console.log("url hit");
//         console.log("opid" + this.props.userInfo.opId);
//         console.log(payloadWorkflowStart);
//         axios
//           .post(url, payloadWorkflowStart)
//           .then((response) => {
//             axios
//               .get("custom/taskId?executionId=" + response.data.id)
//               .then((res) => {
//                 console.log(res);
//                 console.log(res.data.data.taskId);
//                 axios
//                   .post(
//                     "rest/task/" + res.data.data.taskId + "/complete",
//                     payloadVar,
//                     {
//                       headers: {
//                         "Content-Type": "application/json",
//                       },
//                     }
//                   )
//                   .then((response) => {
//                     console.log(response);
//                     this.setState({ loading: false });
//                     this.modalCloseHandler();
//                     window.location.reload();

//                     // axios
//                     //     .post(
//                     //         "SmsNotificationService/sendsms/" +
//                     //         this.props.releaseData.releaseId,
//                     //         smsNotiPayload,
//                     //         {
//                     //             headers: {
//                     //                 opId: this.props.userInfo.opId,
//                     //                 buId: this.props.userInfo.buId,
//                     //                 lob: "Postpaid",
//                     //                 initiateapproval: true
//                     //             }
//                     //         }
//                     //     )
//                     //     .then(response => {
//                     //         console.log(response);
//                     //         // this.setState({ loading: false })
//                     //         this.modalCloseHandler();
//                     //         window.location.reload();

//                     //     })
//                     //     .catch(error => {
//                     //         console.log(error);
//                     //         this.setState({ loading: false })

//                     //     });
//                   })
//                   .catch((error) => {
//                     console.log(error);
//                     this.setState({ loading: false });
//                   });
//               })
//               .catch((error) => {
//                 console.log(error);
//                 this.setState({ loading: false });
//               });
//           })
//           .catch((error) => {
//             console.log(error);
//             this.setState({ loading: false });
//           });
//       }
//     } else this.setState({ showModal: true });
//   };
//   render() {
//     const { classes } = this.props;
//     let panels = [];

//     Object.keys(this.state.approvers).forEach((key) => {
//       let panel = null;
//       panel = (
//         <Accordion
//           key={key}
//           expanded={this.state.expanded === key}
//           onChange={this.changeHandler(key)}
//         >
//           <AccordionSummary
//             expandIcon={<ExpandMoreIcon />}
//             aria-controls="panel1bh-content"
//             id="panel1bh-header"
//           >
//             <Typography className={classes.heading}>{key}</Typography>
//           </AccordionSummary>
//           <AccordionDetails style={{ display: "block" }}>
//             <TableContainer component={Paper} style={{ overflow: "visible" }}>
//               <Table aria-label="collapsible table">
//                 <TableHead>
//                   <TableRow>
//                     <TableCell>Group</TableCell>
//                     <TableCell>Primary Signatory</TableCell>
//                     <TableCell>Secondary Signatory</TableCell>
//                     <TableCell>Mandatory/FYI/NA</TableCell>
//                   </TableRow>
//                 </TableHead>
//                 <TableBody>
//                   {this.state.approvers[key].map((row) => {
//                     return (
//                       <TableRow className={classes.root} key={row.grpName}>
//                         <TableCell style={{ width: "15%" }}>
//                           {row.grpName}
//                         </TableCell>

//                         <TableCell style={{ width: "25%" }}>
//                           <Autocomplete
//                             disableClearable
//                             value={
//                               this.state.smsNotiData[row.grpName].primarymail
//                             }
//                             options={row.primarysignatory}
//                             onChange={(event, selected) => {
//                               let smsNotiData = {
//                                 ...this.state.smsNotiData,
//                               };
//                               let approveData = {
//                                 ...smsNotiData[[row.grpName]],
//                               };
//                               approveData.primarymail = selected;
//                               smsNotiData[row.grpName] = approveData;
//                               this.setState({ smsNotiData: smsNotiData });
//                             }}
//                             renderInput={(params) => (
//                               <TextField {...params} margin="normal" />
//                             )}
//                           />
//                         </TableCell>

//                         <TableCell style={{ width: "25%" }}>
//                           <Autocomplete
//                             disableClearable
//                             onChange={(event, selected) => {
//                               let smsNotiData = {
//                                 ...this.state.smsNotiData,
//                               };
//                               let approveData = {
//                                 ...smsNotiData[[row.grpName]],
//                               };
//                               approveData.secondarymail = selected;
//                               smsNotiData[row.grpName] = approveData;
//                               this.setState({ smsNotiData: smsNotiData });
//                             }}
//                             value={
//                               this.state.smsNotiData[row.grpName].secondarymail
//                             }
//                             options={row.primarysignatory}
//                             renderInput={(params) => (
//                               <TextField {...params} margin="normal" />
//                             )}
//                           />
//                         </TableCell>

//                         <TableCell style={{ width: "35%" }}>
//                           <RadioGroup
//                             row
//                             aria-label="position"
//                             name="position"
//                             onChange={(event) =>
//                               this.workflowVariableChangeHandler(
//                                 event,
//                                 row["varName"]
//                               )
//                             }
//                             value={this.state.worklowVariables[row["varName"]]}
//                           >
//                             <FormControlLabel
//                               value={"Mandatory"}
//                               control={<Radio style={{ color: "#3f74c5" }} />}
//                               label="Mandatory"
//                               disabled={row.disabled == "true" ? true : false}
//                             />
//                             <FormControlLabel
//                               value="FYI"
//                               control={<Radio style={{ color: "#3f74c5" }} />}
//                               label="FYI"
//                               disabled={row.disabled == "true" ? true : false}
//                             />
//                             <FormControlLabel
//                               disabled={row.disabled == "true" ? true : false}
//                               value="NA"
//                               control={<Radio style={{ color: "#3f74c5" }} />}
//                               label="NA"
//                             />
//                           </RadioGroup>
//                         </TableCell>
//                       </TableRow>
//                     );
//                   })}
//                 </TableBody>
//               </Table>
//             </TableContainer>
//           </AccordionDetails>
//         </Accordion>
//       );
//       panels.push(panel);
//     });
//     let modalChild = panels;
//     if (this.state.showModal)
//       modalChild = (
//         <Typography variant="h5" className={classes.center}>
//           {" "}
//           WorkFlow Already Initiated
//         </Typography>
//       );
//     else if (this.state.loading) modalChild = <Loader />;

//     let workflow = (
//       <ModalAction
//         show={this.state.show}
//         modalClosed={this.modalCloseHandler}
//         data={this.props.releaseData}
//         actionText={"Initiate Approval"}
//         title={"Release Id " + this.props.releaseData.releaseId}
//         action={this.initiateApprovalHandler}
//       >
//         <div className={classes.root} style={{ minHeight: "30vh" }}>
//           {!this.state.loading && (
//             <div style={{ marginBottom: "20px" }}>
//               <FormControl
//                 style={{
//                   minWidth: "300px",
//                 }}
//               >
//                 <InputLabel>WorkFlow</InputLabel>
//                 <Select
//                   value={this.state.workflowType}
//                   onChange={(event) => {
//                     this.setState({
//                       loading: true,
//                     });
//                     this.approversDataHandler(event.target.value).then(() => {
//                       this.setState({ loading: false });
//                       this.setState({
//                         workflowType: event.target.value,
//                       });
//                     });
//                   }}
//                   input={<Input />}
//                   renderValue={(selected) => {
//                     if (selected) {
//                       if (selected.length === 0) {
//                         return <em>WorkFlow</em>;
//                       }
//                       return selected;
//                     }
//                   }}
//                   inputProps={{ "aria-label": "Without label" }}
//                 >
//                   <MenuItem disabled value="">
//                     <em>WorkFlow</em>
//                   </MenuItem>
//                   {["Device", "CVM", "Online"].map((name) => (
//                     <MenuItem key={name} value={name}>
//                       {name}
//                     </MenuItem>
//                   ))}
//                 </Select>
//               </FormControl>
//             </div>
//           )}
//           {modalChild}
//         </div>
//       </ModalAction>
//     );

//     return workflow;
//   }
// }

// export default withStyles(useStyles)(WithErrorHandler(Workflow, axios));

import React, { Component } from "react";
import { connect } from 'react-redux';
import ModalAction from "../../UI/ModalAction/ModalAction";
import Loader from "../../UI/Loader/Loader";
import axios from "../../axios-epc";
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import { withStyles } from "@material-ui/core/styles";
import Accordion from "@material-ui/core/Accordion";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import Autocomplete from "@material-ui/lab/Autocomplete";
import TextField from "@material-ui/core/TextField";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";

const useStyles = (theme) => ({
  center: {
    textAlign: "center",
  },
  root: {
    "& .MuiPaper-root": {
      width: "100%",
    },
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "33.33%",
    flexShrink: 0,
  },
});

class Workflow extends Component {
  _isMounted = false;

  constructor(props) {
    super(props);
    let workflow = {};
    let smsNotiData = {};
    Object.keys(props.approvers).forEach((key) => {
      props.approvers[key].filter((el) => {
        smsNotiData[el["grpName"]] = {
          primarymail: el["primarysignatory"][0]
            ? el["primarysignatory"][0]
            : null,
          secondarymail: el["primarysignatory"][1]
            ? el["primarysignatory"][1]
            : null,
        };
        if (el["disabled"] == "true") workflow[el["varName"]] = "Mandatory";
        else workflow[el["varName"]] = "FYI";
      });
    });
    // cellStyle: { width: '20%' }
    this.state = {
      showModal: false,
      approvers: [],
      show: true,
      loading: true,
      expanded: false,
      worklowVariables: { ...workflow },
      smsNotiData: { ...smsNotiData },
      data: [],
    };
  }
  workflowVariableChangeHandler(event, varName) {
    let worklowVariables = {
      ...this.state.worklowVariables,
    };
    worklowVariables[varName] = event.target.value;
    this.setState({ worklowVariables: worklowVariables });
  }

  modalCloseHandler = () => {
    this.setState({ show: false });
    this.props.showWorkflow();
  };

  componentWillUnmount() {
    this._isMounted = false;
  }
  componentDidMount = () => {
    this._isMounted = true;
    if (this._isMounted) this.setState({ loading: false });
    console.log("mounted" + this.props.releaseData.releaseId);
    console.log(this.props.approvers);
    
    this.approversDataHandler().then(() => {
      this.setState({ loading: false });
    });
  };

  

  changeHandler = (panel) => (event, isExpanded) => {
    this.setState({ expanded: isExpanded ? panel : false });
  };

  approversDataHandler(id) {
    const opId = this.props?.userInfo?.opId ?? this.userInfo.opId;
		const buId = this.props?.userInfo?.buId ?? this.userInfo.buId;
		const authUserId = this.props?.userInfo?.id ?? this.userInfo.id;
		const Authorization = this.props?.userInfo?.jwt ?? this.userInfo.jwt;
    const role=this.props?.roleGroup?? this.roleGroup;
    return axios
      .get(process.env.REACT_APP_URL + 'TeleAuthentication/approver', {
        headers: {
          opId: opId,
          buId:buId,
          role: this.props.roleGroup,
          lob: 'Postpaid',
          role:role,
          // circle: 'Hobs',
          authUserId:authUserId,
					Authorization:'Bearer '+ Authorization,
          
        },
      })
      .then((res) => {
        console.log(res);
        if (res) {
          let workflow = {};
          let smsNotiData = {};

          Object.keys(res.data.data).forEach((key) => {
            res.data.data[key].filter((el) => {
              smsNotiData[el['grpName']] = {
                primarymail: el['primarysignatory'][0]
                  ? el['primarysignatory'][0]
                  : null,
                secondarymail: el['primarysignatory'][1]
                  ? el['primarysignatory'][1]
                  : null,
              };
              if (el['disabled'] == 'true')
                workflow[el['varName']] = 'Mandatory';
              else workflow[el['varName']] = 'FYI';
            });
          });
          this.setState({
            approvers: { ...res.data.data },
            worklowVariables: workflow,
            smsNotiData,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  

  initiateApprovalHandler = () => {
    console.log(this.props.releaseData.pendingWith);
    console.log(this.props.selectedType);

    if (this.props.releaseData.pendingWith == "WorkFlow Not Initiated") {
      this.setState({ loading: true });
      let variables = {};
      variables.releaseCreatedBy = {
        value: this.props.releaseData.createdBy,
        type: "String",
      };
      variables.releaseId = {
        value: this.props.releaseData.releaseId,
        type: "String",
      };
      variables.releaseObjective = {
        value: this.props.releaseData.remarks,
        type: "String",
      };
      variables.releaseCreationDate = {
        value: this.props.releaseData.createdOn,
        type: "String",
      };
      variables.releaseExternalId = {
        value: this.props.releaseData.externalReleaseId,
        type: "String",
      };
      variables.releaseStatus = {
        //value: this.props.releaseData.releaseStatus,
        value:'Approval In Progress',
        type: "String",
      };
      variables.releaseReplicationStatus = {
				value: this.props.releaseData.replicationStatus,
				type: 'String',
			};
      let worklowVariables = {};
      Object.keys(this.state.worklowVariables).filter((key) => {
        if (this.state.worklowVariables[key] == "Mandatory")
          worklowVariables[key] = {
            value: true,
          };
        else
          worklowVariables[key] = {
            value: false,
          };
      });
      let smsNotiPayload = {};
      let roles = [];
      console.log(this.state.approvers);

      Object.keys(this.state.approvers).map((role) => {
        this.state.approvers[role].map((approver) => {
          let obj = {};
          obj.taskName = approver.grpName;
          obj.primaryMail =
            this.state.smsNotiData[approver.grpName].primarymail;
          obj.secondaryMail =
            this.state.smsNotiData[approver.grpName].secondarymail;
          obj.varName = approver.varName;
          obj.value =
            // this.state.worklowVariables[approver.varName].toLowerCase();
            this.state.worklowVariables[approver.varName];
            obj.medium = 'sms';
					obj.group = 'radB2c';
          roles.push(obj);
        });
      });
      smsNotiPayload.roleDetailList = roles;
      console.log(smsNotiPayload);
      let payloadVar = {};
      payloadVar.variables = worklowVariables;
      let payloadWorkflowStart = {};
      payloadWorkflowStart.variables = variables;
      payloadWorkflowStart.businessKey = "myBusinessKey";
      payloadWorkflowStart.withVariablesInReturn = true;
      //  let url = "rest/process-definition/key/swf/start"
      // let url = "rest/process-definition/key/cvmflow/start";
      let groupWf = this.props.roleGroup.toUpperCase();
      let url = `Telerest/process-definition/key/telemedia${groupWf}/start`;

      // let url = 'Telerest/process-definition/key/telemedia'+this.props.roleGroup+'/start';




      // let groupWf = this.props.roleGroup.toUpperCase();
      // url = `Telerest/process-definition/key/telemedia${groupWf}/start`;
      // https://10.5.198.129/Telerest/process-definition/key/telemediaB2BMANUAL/start



      // if (this.props.userInfo.opId == "Airtel_Telemedia")
      //     url = 'rest/process-definition/key/telemediawf/start'
      // if (this.state.workflowType === "Device")
      //   url = "rest/process-definition/key/devflow/start";
      // else if (this.state.workflowType === "Online")
      //   url = "rest/process-definition/key/Onflow/start";
      console.log(url);
      console.log("url hit");
      console.log("opid" + this.props.userInfo.opId);
      axios
        .post(url, payloadWorkflowStart)
        .then((response) => {
          axios
            .get("Telecustom/taskId?executionId=" + response.data.id)
            .then((res) => {
              console.log(res);
              console.log(res.data.data.taskId);
              this.modalCloseHandler();
              // window.location.reload();
              axios
                .post(
                  "Telerest/task/" + res.data.data.taskId + "/complete",
                  payloadVar,
                  {
                    headers: {
                      "Content-Type": "application/json",
                    },
                  }
                )
                .then((response) => {
                  console.log(response);
                  this.setState({ loading: false });
                  this.modalCloseHandler();
                
                  // axios
                  //     .post(
                  //         "TeleSmsNotificationService/sendsms?releaseId=" +
                  //         this.props.releaseData.releaseId,
                  //         smsNotiPayload,
                  //         {
                  //             headers: {
                  //                 opId: this.props.userInfo.opId,
                  //                 buId: this.props.userInfo.buId,
                  //                 lob: "Postpaid",
                  //                 initiateapproval: true
                  //             }
                  //         }
                  //     )
                  //     .then(response => {
                  //         console.log(response);
                  //         this.setState({ loading: false })
                  //         this.modalCloseHandler();
                  //         window.location.reload();
                  //     })
                  //     .catch(error => {
                  //         console.log(error);
                  //         this.setState({ loading: false })

                  //     });
                  axios
                  .post(
                    'TeleSelectApprovers/send/notification/initiate-approval?releaseId=' +
                      this.props.releaseData.releaseId,
                    smsNotiPayload,
                    {
                      headers: {
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId,
                        lob: 'Postpaid',
                        initiateapproval: true,
                        group: this.props.userInfo.group[0],
                        authUserId: this.props.userInfo.id,
                      },
                    }
                  )
                  .then((response) => {
                    console.log(response);
                    this.setState({ loading: false });
                    this.modalCloseHandler();
                    localStorage.removeItem(`${this.props.roleGroup}Data`);
                    window.location.reload();
                  })
                  .catch((error) => {
                    console.log(error);
                    this.setState({ loading: false });
                  });
                })
                .catch((error) => {
                  console.log(error);
                  this.setState({ loading: false });
                });
              this.props.history.push('/');
            })
            .catch((error) => {
              console.log(error);
              this.setState({ loading: false });
            });
        })
        .catch((error) => {
          console.log(error);
          this.setState({ loading: false });
        });
    } else this.setState({ showModal: true });
  };


  render() {
    const { classes } = this.props;
    let panels = [];

    Object.keys(this.state.approvers).forEach((key) => {
      let panel = null;
      panel = (
        <Accordion
          key={key}
          expanded={this.state.expanded === key}
          onChange={this.changeHandler(key)}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1bh-content"
            id="panel1bh-header"
          >
            <Typography className={classes.heading}>{key}</Typography>
          </AccordionSummary>
          <AccordionDetails style={{ display: "block" }}>
            <TableContainer component={Paper} style={{ overflow: "visible" }}>
              <Table aria-label="collapssible table">
                <TableHead>
                  <TableRow>
                    <TableCell>Group</TableCell>
                    <TableCell>Primary Signatory</TableCell>
                    <TableCell>Secondary Signatory</TableCell>
                    <TableCell>Mandatory/FYI/NA</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {this.state.approvers[key].map((row) => {
                    return (
                      <TableRow className={classes.root} key={row.grpName}>
                        <TableCell style={{ width: "15%" }}>
                          {row.grpName}
                        </TableCell>

                        <TableCell style={{ width: "25%" }}>
                          <Autocomplete
                            disableClearable
                            value={
                              this.state.smsNotiData[row.grpName].primarymail
                            }
                            options={row.primarysignatory}
                            onChange={(event, selected) => {
                              let smsNotiData = {
                                ...this.state.smsNotiData,
                              };
                              let approveData = {
                                ...smsNotiData[[row.grpName]],
                              };
                              approveData.primarymail = selected;
                              smsNotiData[row.grpName] = approveData;
                              this.setState({ smsNotiData: smsNotiData });
                            }}
                            renderInput={(params) => (
                              <TextField {...params} margin="normal" />
                            )}
                            />
                        </TableCell>

                        <TableCell style={{ width: "25%" }}>
                          <Autocomplete
                            disableClearable
                            onChange={(event, selected) => {
                              let smsNotiData = {
                                ...this.state.smsNotiData,
                              };
                              let approveData = {
                                ...smsNotiData[[row.grpName]],
                              };
                              approveData.secondarymail = selected;
                              smsNotiData[row.grpName] = approveData;
                              this.setState({ smsNotiData: smsNotiData });
                            }}
                            value={
                              this.state.smsNotiData[row.grpName].secondarymail
                            }
                            options={row.primarysignatory}
                            renderInput={(params) => (
                              <TextField {...params} margin="normal" />
                            )}
                            />
                        </TableCell>

                        <TableCell style={{ width: "35%" }}>
                          <RadioGroup
                            row
                            aria-label="position"
                            name="position"
                            onChange={(event) =>
                              this.workflowVariableChangeHandler(
                                event,
                                row["varName"]
                              )
                            }
                            value={this.state.worklowVariables[row["varName"]]}
                          >
                            <FormControlLabel
                              value={"Mandatory"}
                              control={<Radio style={{ color: "#ff1921" }} />}
                              label="Mandatory"
                              disabled={row.disabled == "true" ? true : false}
                            />
                            <FormControlLabel
                              value="FYI"
                              control={<Radio style={{ color: "#ff1921" }} />}
                              label="FYI"
                              disabled={row.disabled == "true" ? true : false}
                            />
                            <FormControlLabel
                              disabled={row.disabled == "true" ? true : false}
                              value="NA"
                              control={<Radio style={{ color: "#ff1921" }} />}
                              label="NA"
                            />
                          </RadioGroup>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          </AccordionDetails>
        </Accordion>
      );
      panels.push(panel);
    });
    let modalChild = panels;
    if (this.state.showModal)
      modalChild = (
        <Typography variant="h5" className={classes.center}>
          {" "}
          WorkFlow Already Initiated
        </Typography>
      );
    else if (this.state.loading)
      modalChild = (
        <div style={{ minHeight: "25vh" }}>
          {" "}
          <Loader />{" "}
        </div>
      );

    let workflow = (
      <ModalAction
        show={this.state.show}
        modalClosed={this.modalCloseHandler}
        data={this.props.releaseData}
        actionText={"Initiate Approval"}
        title={"Release Id " + this.props.releaseData.externalReleaseId}
        action={this.initiateApprovalHandler}
      >
        <div className={classes.root} style={{ minHeight: "25vh" }}>
          {modalChild}
        </div>
      </ModalAction>
    );
 
    return workflow;
  }
}
const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
    roleGroup: state.roleSelected.roleGroup,


  };
};

export default connect(mapStateToProps)(withStyles(useStyles)(WithErrorHandler(Workflow, axios)));

// import React, { Component } from 'react';
// import ModalAction from '../../UI/ModalAction/ModalAction';
// import Loader from '../../UI/Loader/Loader';
// import axios from '../../axios-epc';
// import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
// import { withStyles } from '@material-ui/core/styles';
// import Accordion from '@material-ui/core/Accordion';
// import AccordionDetails from '@material-ui/core/AccordionDetails';
// import AccordionSummary from '@material-ui/core/AccordionSummary';
// import Typography from '@material-ui/core/Typography';
// import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
// import Autocomplete from '@material-ui/lab/Autocomplete';
// import TextField from '@material-ui/core/TextField';
// import Radio from '@material-ui/core/Radio';
// import RadioGroup from '@material-ui/core/RadioGroup';
// import FormControlLabel from '@material-ui/core/FormControlLabel';
// import Table from '@material-ui/core/Table';
// import TableBody from '@material-ui/core/TableBody';
// import TableCell from '@material-ui/core/TableCell';
// import TableContainer from '@material-ui/core/TableContainer';
// import TableHead from '@material-ui/core/TableHead';
// import TableRow from '@material-ui/core/TableRow';
// import Paper from '@material-ui/core/Paper';
// import FormControl from '@material-ui/core/FormControl';
// import Select from '@material-ui/core/Select';
// import MenuItem from '@material-ui/core/MenuItem';
// import Input from '@material-ui/core/Input';
// import Button from '@material-ui/core/Button';
// import InputLabel from '@material-ui/core/InputLabel';

// const useStyles = (theme) => ({
//     center: {
//         textAlign: 'center'
//     },
//     root: {
//         "& .MuiPaper-root": {
//             width: '100%'
//         },
//     },
//     heading: {
//         fontSize: theme.typography.pxToRem(15),
//         flexBasis: '33.33%',
//         flexShrink: 0,
//     },
// });

// class Workflow extends Component {
//     _isMounted = false;

//     constructor(props) {
//         super(props);

//         // cellStyle: { width: '20%' }
//         this.state = {
//             approvers: [],
//             showModal: false,
//             show: true,
//             loading: true,
//             expanded: false,
//             worklowVariables: {},
//             smsNotiData: {},
//             data: [],
//             workflowType: 'CVM',
//         }
//     }
//     workflowVariableChangeHandler(event, varName) {
//         let worklowVariables = {
//             ...this.state.worklowVariables
//         }
//         worklowVariables[varName] = event.target.value
//         this.setState({ worklowVariables: worklowVariables })
//     }

//     modalCloseHandler = () => {
//         this.setState({ show: false })
//         this.props.showWorkflow()
//     }

//     approversDataHandler(id) {

//         return axios
//             .get(process.env.REACT_APP_URL + "SelectApprovers/approver", {
//                 headers: {
//                     opId: this.props.userInfo.opId,
//                     buId: this.props.userInfo.buId,
//                     lob: "Postpaid",
//                     circle: id.toUpperCase()
//                 }
//             })
//             .then(res => {
//                 console.log(res)
//                 if (res) {
//                     let workflow = {}
//                     let smsNotiData = {}

//                     Object.keys(res.data.data).forEach(key => {
//                         res.data.data[key].filter(el => {
//                             smsNotiData[el['grpName']] = {
//                                 primarymail: el['primarysignatory'][0] ? el['primarysignatory'][0] : null,
//                                 secondarymail: el['primarysignatory'][1] ? el['primarysignatory'][1] : null
//                             }
//                             if (el['disabled'] == 'true')
//                                 workflow[el['varName']] = 'Mandatory'
//                             else
//                                 workflow[el['varName']] = 'FYI'
//                         })
//                     })
//                     this.setState({
//                         approvers: { ...res.data.data }
//                         , worklowVariables: workflow,
//                         smsNotiData
//                     })
//                 }
//             })
//             .catch(error => {
//                 console.log(error)
//                 if (this._isMounted)
//                     this.setState({ loading: false })
//             });
//     }

//     componentWillUnmount() {
//         this._isMounted = false;
//     }
//     componentDidMount = () => {
//         this._isMounted = true;
//         this.setState({ loading: true })

//         this.approversDataHandler('CVM').then(() => {
//             this.setState({ loading: false })
//         })

//     }
//     changeHandler = (panel) => (event, isExpanded) => {
//         this.setState({ expanded: isExpanded ? panel : false });
//     };
//     initiateApprovalHandler = () => {
//         console.log(this.props.releaseData.pendingWith)
//         if (
//             this.props.releaseData.pendingWith == "WorkFlow Not Initiated"

//         ) {
//             if (this.state.workflowType) {
//                 this.setState({ loading: true })
//                 let variables = {};
//                 variables.releaseCreatedBy = {
//                     value: this.props.releaseData.createdBy,
//                     type: "String"
//                 };
//                 variables.releaseId = {
//                     value: this.props.releaseData.releaseId,
//                     type: "String"
//                 };
//                 variables.releaseObjective = {
//                     value: this.props.releaseData.remarks,
//                     type: "String"
//                 };
//                 variables.releaseCreationDate = {
//                     value: this.props.releaseData.createdOn,
//                     type: "String"
//                 };
//                 variables.releaseStatus = {
//                     value: this.props.releaseData.releaseStatus,
//                     type: "String"
//                 };
//                 let worklowVariables = {}
//                 Object.keys(this.state.worklowVariables).filter(key => {
//                     if (this.state.worklowVariables[key] == "Mandatory")
//                         worklowVariables[key] = {
//                             value: true
//                         }
//                     else worklowVariables[key] = {
//                         value: false
//                     }
//                 });
//                 let smsNotiPayload = {}
//                 let roles = []
//                 Object.keys(this.state.approvers).map(role => {
//                     this.state.approvers[role].map(approver => {
//                         let obj = {}
//                         obj.taskname = approver.grpName
//                         obj.primarymail = this.state.smsNotiData[approver.grpName].primarymail
//                         obj.secondarymail = this.state.smsNotiData[approver.grpName].secondarymail
//                         obj.varname = approver.varName
//                         obj.value = this.state.worklowVariables[approver.varName].toLowerCase()
//                         roles.push(obj)
//                     })
//                 })
//                 smsNotiPayload.roles = roles
//                 console.log(smsNotiPayload)
//                 let payloadVar = {};
//                 payloadVar.variables = worklowVariables;
//                 let payloadWorkflowStart = {}
//                 payloadWorkflowStart.variables = variables
//                 payloadWorkflowStart.businessKey = "myBusinessKey"
//                 payloadWorkflowStart.withVariablesInReturn = true
//                 let url = "rest/process-definition/key/cvmflow/start"
//                 if (this.state.workflowType === 'Device')
//                     url = "rest/process-definition/key/devflow/start"
//                 else if (this.state.workflowType === 'Online')
//                     url = "rest/process-definition/key/Onflow/start"
//                 console.log(url)
//                 console.log('url hit')
//                 console.log('opid' + this.props.userInfo.opId)
//                 console.log(payloadWorkflowStart)
//                 axios
//                     .post(
//                         url,
//                         payloadWorkflowStart
//                     )
//                     .then(response => {
//                         axios
//                             .get(
//                                 "custom/taskId?executionId=" +
//                                 response.data.id
//                             )
//                             .then(res => {
//                                 console.log(res);
//                                 console.log(res.data.data.taskId);
//                                 axios
//                                     .post(
//                                         "rest/task/" +
//                                         res.data.data.taskId +
//                                         "/complete",
//                                         payloadVar,
//                                         {
//                                             headers: {
//                                                 "Content-Type": "application/json"
//                                             }
//                                         }
//                                     )
//                                     .then(response => {
//                                         console.log(response);
//                                         this.setState({ loading: false })
//                                         this.modalCloseHandler();
//                                         window.location.reload();

//                                         // axios
//                                         //     .post(
//                                         //         "SmsNotificationService/sendsms/" +
//                                         //         this.props.releaseData.releaseId,
//                                         //         smsNotiPayload,
//                                         //         {
//                                         //             headers: {
//                                         //                 opId: this.props.userInfo.opId,
//                                         //                 buId: this.props.userInfo.buId,
//                                         //                 lob: "Postpaid",
//                                         //                 initiateapproval: true
//                                         //             }
//                                         //         }
//                                         //     )
//                                         //     .then(response => {
//                                         //         console.log(response);
//                                         //         // this.setState({ loading: false })
//                                         //         this.modalCloseHandler();
//                                         //         window.location.reload();

//                                         //     })
//                                         //     .catch(error => {
//                                         //         console.log(error);
//                                         //         this.setState({ loading: false })

//                                         //     });
//                                     })
//                                     .catch(error => {
//                                         console.log(error);
//                                         this.setState({ loading: false })

//                                     });
//                             })
//                             .catch(error => {
//                                 console.log(error);
//                                 this.setState({ loading: false })

//                             });
//                     })
//                     .catch(error => {
//                         console.log(error);
//                         this.setState({ loading: false })

//                     });
//             }
//         }
//         else
//             this.setState({ showModal: true })
//     }
//     render() {
//         const { classes } = this.props;
//         let panels = [];

//         Object.keys(this.state.approvers).forEach(key => {
//             let panel = null;
//             panel = <Accordion key={key} expanded={this.state.expanded === key} onChange={this.changeHandler(key)}>
//                 <AccordionSummary
//                     expandIcon={<ExpandMoreIcon />}
//                     aria-controls="panel1bh-content"
//                     id="panel1bh-header"
//                 >
//                     <Typography className={classes.heading}>{key}</Typography>
//                 </AccordionSummary>
//                 <AccordionDetails style={{ display: 'block' }} >
//                     <TableContainer component={Paper} style={{ overflow: 'visible' }}>
//                         <Table aria-label="collapsible table" >
//                             <TableHead>
//                                 <TableRow>
//                                     <TableCell >Group</TableCell>
//                                     <TableCell >Primary Signatory</TableCell>
//                                     <TableCell >Secondary Signatory</TableCell>
//                                     <TableCell >Mandatory/FYI/NA</TableCell>
//                                 </TableRow>
//                             </TableHead>
//                             <TableBody >
//                                 {this.state.approvers[key].map((row) => {
//                                     return <TableRow className={classes.root}
//                                         key={row.grpName}>
//                                         <TableCell style={{ width: '15%' }} >
//                                             {row.grpName}
//                                         </TableCell>

//                                         <TableCell style={{ width: '25%' }}>
//                                             <Autocomplete
//                                                 disableClearable
//                                                 value={this.state.smsNotiData[row.grpName].primarymail}
//                                                 options={row.primarysignatory}
//                                                 onChange={(event, selected) => {
//                                                     let smsNotiData = {
//                                                         ...this.state.smsNotiData
//                                                     }
//                                                     let approveData = { ...smsNotiData[[row.grpName]] }
//                                                     approveData.primarymail = selected
//                                                     smsNotiData[row.grpName] = approveData
//                                                     this.setState({ smsNotiData: smsNotiData })

//                                                 }}
//                                                 renderInput={(params) => <TextField {...params} margin="normal" />}
//                                             />
//                                         </TableCell>

//                                         <TableCell style={{ width: '25%' }}>
//                                             <Autocomplete
//                                                 disableClearable
//                                                 onChange={(event, selected) => {
//                                                     let smsNotiData = {
//                                                         ...this.state.smsNotiData
//                                                     }
//                                                     let approveData = { ...smsNotiData[[row.grpName]] }
//                                                     approveData.secondarymail = selected
//                                                     smsNotiData[row.grpName] = approveData
//                                                     this.setState({ smsNotiData: smsNotiData })

//                                                 }}
//                                                 value={this.state.smsNotiData[row.grpName].secondarymail}

//                                                 options={row.primarysignatory}
//                                                 renderInput={(params) => <TextField {...params} margin="normal" />}
//                                             />
//                                         </TableCell>

//                                         <TableCell style={{ width: '35%' }}>
//                                             <RadioGroup row aria-label="position" name="position"
//                                                 onChange={(event) => this.workflowVariableChangeHandler(event, row['varName'])}
//                                                 value={this.state.worklowVariables[row['varName']]}
//                                             >
//                                                 <FormControlLabel
//                                                     value={'Mandatory'}
//                                                     control={<Radio style={{ color: '#3f74c5' }} />}
//                                                     label="Mandatory"
//                                                     disabled={row.disabled == 'true' ? true : false} />
//                                                 <FormControlLabel
//                                                     value="FYI"
//                                                     control={<Radio style={{ color: '#3f74c5' }} />}
//                                                     label="FYI"
//                                                     disabled={row.disabled == 'true' ? true : false} />
//                                                 <FormControlLabel disabled={row.disabled == 'true' ? true : false} value="NA" control={<Radio style={{ color: '#3f74c5' }} />} label="NA" />
//                                             </RadioGroup>
//                                         </TableCell>
//                                     </TableRow>
//                                 })
//                                 }
//                             </TableBody>
//                         </Table>
//                     </TableContainer>
//                 </AccordionDetails>
//             </Accordion>
//             panels.push(panel)
//         })
//         let modalChild = panels
//         if (this.state.showModal)
//             modalChild = < Typography variant="h5" className={classes.center} > WorkFlow Already Initiated</Typography >
//         else if (this.state.loading)
//             modalChild = <Loader />

//         let workflow = <ModalAction show={this.state.show} modalClosed={this.modalCloseHandler}
//             data={this.props.releaseData} actionText={'Initiate Approval'}
//             title={"Release Id " + this.props.releaseData.releaseId} action={this.initiateApprovalHandler} >

//             <div className={classes.root} style={{ minHeight: '30vh' }}>
//                 {!this.state.loading && <div style={{ marginBottom: '20px' }}>< FormControl style={{
//                     minWidth: '300px',
//                 }}>
//                     <InputLabel >WorkFlow</InputLabel>
//                     <Select
//                         value={this.state.workflowType}
//                         onChange={(event) => {
//                             this.setState({
//                                 loading: true
//                             })
//                             this.approversDataHandler(event.target.value).then(() => {
//                                 this.setState({ loading: false })
//                                 this.setState({
//                                     workflowType: event.target.value
//                                 })
//                             })

//                         }}
//                         input={<Input />}
//                         renderValue={(selected) => {
//                             if (selected) {
//                                 if (selected.length === 0) {
//                                     return <em>WorkFlow</em>;
//                                 }
//                                 return selected
//                             }
//                         }}
//                         inputProps={{ 'aria-label': 'Without label' }}
//                     >
//                         <MenuItem disabled value="">
//                             <em>WorkFlow</em>
//                         </MenuItem>
//                         {['Device', 'CVM', 'Online'].map((name) => (
//                             <MenuItem key={name} value={name} >
//                                 {name}
//                             </MenuItem>
//                         ))}
//                     </Select>
//                 </FormControl></div>}
//                 {modalChild}
//             </div>
//         </ModalAction>

//         return workflow
//     }

// }

// export default withStyles(useStyles)(WithErrorHandler(Workflow, axios));

// import React, { Component } from "react";
// import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
// import axios from "../../axios-epc";
// import Card from "@material-ui/core/Card";
// import CardHeader from "@material-ui/core/CardHeader";
// import CardContent from "@material-ui/core/CardContent";
// import { withStyles } from "@material-ui/core/styles";
// import LastPageIcon from "@material-ui/icons/LastPage";
// import { connect } from "react-redux";
// import Loader from "../../UI/Loader/Loader";
// import Input from "../../UI/Input/Input";
// //import ButtonNew from "../../UI/Button/Button";
// import Grid from "@material-ui/core/Grid";
// import Button from "@material-ui/core/Button";
// import moment from "moment";
// import Tooltip from "@material-ui/core/Tooltip";
// import MultiSelect from "../../UI/Input/MultiSelect";
// import Box from "@material-ui/core/Box";
// import CreatableSelect from "react-select/creatable";
// import Radio from "@material-ui/core/Radio";
// import RadioGroup from "@material-ui/core/RadioGroup";
// import FormControlLabel from "@material-ui/core/FormControlLabel";
// import Typography from "@material-ui/core/Typography";
// import Divider from "@material-ui/core/Divider";
// import Select from "react-select";
// import MaterialTable from "material-table";
// import { forwardRef } from "react";
// import AddBox from "@material-ui/icons/AddBox";
// import ArrowDownward from "@material-ui/icons/ArrowDownward";
// import Check from "@material-ui/icons/Check";
// import ChevronLeft from "@material-ui/icons/ChevronLeft";
// import ChevronRight from "@material-ui/icons/ChevronRight";
// import Clear from "@material-ui/icons/Clear";
// import DeleteOutline from "@material-ui/icons/DeleteOutline";
// import Edit from "@material-ui/icons/Edit";
// import FilterList from "@material-ui/icons/FilterList";
// import FirstPage from "@material-ui/icons/FirstPage";
// import LastPage from "@material-ui/icons/LastPage";
// import Remove from "@material-ui/icons/Remove";
// import SaveAlt from "@material-ui/icons/SaveAlt";
// import Search from "@material-ui/icons/Search";
// import ViewColumn from "@material-ui/icons/ViewColumn";
// import { ThemeProvider } from "@material-ui/core";
// import { createMuiTheme } from "@material-ui/core/styles";
// import * as actionTypes from "../../store/actions/actionTypes";

// const tableIcons = {
//   Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
//   Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
//   Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
//   Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
//   DetailPanel: forwardRef((props, ref) => (
//     <ChevronRight {...props} ref={ref} />
//   )),
//   Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
//   Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
//   Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
//   FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
//   LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
//   NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
//   PreviousPage: forwardRef((props, ref) => (
//     <ChevronLeft {...props} ref={ref} />
//   )),
//   ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
//   Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
//   SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
//   ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
//   ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
// };

// const theme = createMuiTheme({
//   overrides: {
//     MuiTable: {
//       root: {
//         tableLayout: "fixed",
//       },
//     },
//     MuiTableCell: {
//       root: {
//         padding: "10px",
//         paddingLeft: "10px",
//       },
//     },
//     MuiPaper: {
//       width: "100%",
//     },
//   },
// });

// const LightTooltip = withStyles((theme) => ({
//   tooltip: {
//     backgroundColor: "#525354",
//     color: "white",
//     boxShadow: theme.shadows[1],
//     fontSize: 14,
//   },
// }))(Tooltip);

// const useStyles = (theme) => ({
//   cardHeader: {
//     background: "#546D7A",
//     height: "4.5vh",
//   },
//   subheader: {
//     color: "white",
//     // fontWeight: 'bold'
//   },
//   boldText: {
//     // fontWeight: 'bold'
//   },
//   center: {
//     display: "flex",
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   heading: {
//     fontSize: theme.typography.pxToRem(15),
//     flexBasis: "96%",
//     flexShrink: 0,
//   },
// });

// class AdvanceSearch extends Component {
//   _isMounted = false;

//   state = {
//     SearchType: "",
//     loading: true,
//     searchCriteria: [],
//     schema: [],
//     searchData: {},
//     searchEntites: [],
//     selSearchCriteria: [],
//     searchDataInput: {},
//     data: [],
//     columns: [
//       {
//         title: "Entity Id",
//         field: "responseId",
//         sorting: true,
//         cellStyle: { width: "13%" },
//       },

//       {
//         title: "Entity Name",
//         field: "responseName",
//         sorting: true,
//         cellStyle: { width: "8%" },
//       },
//     ],
//   };

//   componentWillUnmount() {
//     this._isMounted = false;
//   }

//   componentDidUpdate(prevProps, prevState) {
//     if (prevState["SearchType"] !== this.state["SearchType"]) {
//       if (this.state.SearchType) {
//         this.state.selSearchCriteria.map((el) => {
//           this.setState({ [el]: [] });
//         });
//         this.setState({ loading: true });
//         axios
//           .post("dashboard/AdvSearch/select", {
//             searchIn: this.state.SearchType,
//             opId: this.props.userInfo.opId,
//             buId: this.props.userInfo.buId,
//           })
//           .then((res) => {
//             console.log(res);
//             let searchDataInput = {};
//             Object.keys(res.data.data).map((key) => {
//               searchDataInput = {
//                 ...searchDataInput,
//                 ...res.data.data[key],
//               };
//             });
//             console.log(searchDataInput);
//             this.setState({
//               loading: false,
//               searchData: res.data.data,
//               searchEntites: [],
//               selSearchCriteria: [],
//               searchCriteria: [],
//               searchDataInput: searchDataInput,
//               data: [],
//             });
//           })
//           .catch((error) => {
//             console.log(error);
//             if (this._isMounted) this.setState({ loading: false });
//           });
//       }
//     }
//   }

//   componentDidMount() {
//     this._isMounted = true;
//     this.setState({
//       loading: false,
//     });
//     this.setState({ SearchType: "Package" });
//   }

//   backToRelease = () => {
//     this.props.history.push("/editRelease");
//   };

//   attributeGrpData() {
//     return axios
//       .get("package/attrGrp?releaseId=" + this.props.releaseData.releaseId, {
//         headers: {
//           opId: this.props.userInfo.opId,
//         },
//       })
//       .then((res) => {
//         console.log(res);
//         let attrGrps = [];
//         res.data.data.map((attributeGrp) => {
//           attrGrps.push(attributeGrp.attrGrpName);
//         });
//         let searchData = { ...this.state.searchData };
//         console.log(searchData);

//         Object.keys(this.state.searchData).map((entity) => {
//           Object.keys(this.state.searchData[entity]).map((field) => {
//             searchData[entity][field] = {
//               ...this.state.searchDataInput[field],
//             };
//           });
//         });
//         searchData["Attribute"] = {
//           ...this.state.searchData["Attribute"],
//           Attribute: {
//             constraint: attrGrps.join(),
//             type: "MultiSelect",
//           },
//         };
//         console.log(searchData);

//         let searchDataInput = {};
//         Object.keys(searchData).map((key) => {
//           searchDataInput = {
//             ...searchDataInput,
//             ...searchData[key],
//           };
//         });
//         console.log(searchDataInput);

//         this.setState({
//           searchData: searchData,
//           searchDataInput: searchDataInput,
//         });
//       });
//   }

//   inputHelper(value, name) {
//     let formElement = {
//       ...value,
//       uiName: name,
//     };
//     if (formElement.type == "MultiSelect") {
//       return (
//         <Grid item xs={12} sm={10} key={formElement.uiName}>
//           <Box>
//             <span style={{}}>{formElement.uiName}</span>
//           </Box>
//           <Box mt={2}>
//             {/* < MultiSelect
//                         refLovs={formElement.constraint ? formElement.constraint.split(',') : []}
//                         value={this.state[formElement.uiName]}
//                         changed={(selected) => {
//                             console.log(selected)
//                             if (!(selected instanceof Array))
//                                 selected = [selected]

//                             this.setState({
//                                 [formElement.uiName]:
//                                     selected
//                             })
//                         }
//                         }
//                     /> */}

//             <Select
//               menuPlacement="top"
//               menuPortalTarget={document.body}
//               styles={{
//                 menuPortal: (base) => ({ ...base, zIndex: 9999 }),
//                 option: (base, state) => ({
//                   ...base,
//                   fontSize: "12px",
//                 }),
//               }}
//               isMulti
//               closeMenuOnSelect={false}
//               onChange={(selectedOptions) => {
//                 console.log(selectedOptions);
//                 let lovs = [];
//                 if (selectedOptions) {
//                   selectedOptions.map((lov) => {
//                     lovs.push(lov.value);
//                   });
//                 }
//                 this.setState({
//                   [formElement.uiName]: lovs,
//                 });
//               }}
//               value={
//                 this.state[formElement.uiName]
//                   ? this.state[formElement.uiName].map((lov) => {
//                       return {
//                         value: lov,
//                         label: lov,
//                       };
//                     })
//                   : []
//               }
//               options={
//                 formElement.constraint
//                   ? formElement.constraint.split(",").map((lov) => {
//                       return {
//                         value: lov,
//                         label: lov,
//                       };
//                     })
//                   : []
//               }
//             />
//           </Box>
//         </Grid>
//       );
//     } else if (formElement.type == "Creatable") {
//       return (
//         <Grid item xs={12} sm={10} key={formElement.uiName}>
//           <Box>
//             <span style={{}}>{formElement.uiName}</span>
//           </Box>
//           <Box mt={2}>
//             <CreatableSelect
//               isMulti
//               onChange={(selectedOptions) => {
//                 console.log(selectedOptions);
//                 let lovs = [];
//                 if (selectedOptions) {
//                   selectedOptions.map((lov) => {
//                     lovs.push(lov.value);
//                   });
//                 }
//                 this.setState({
//                   [formElement.uiName]: lovs,
//                 });
//               }}
//               value={
//                 this.state[formElement.uiName]
//                   ? this.state[formElement.uiName].map((lov) => {
//                       return {
//                         value: lov,
//                         label: lov,
//                       };
//                     })
//                   : []
//               }
//               options={
//                 formElement.constraint
//                   ? formElement.constraint.split(",").map((lov) => {
//                       return {
//                         value: lov,
//                         label: lov,
//                       };
//                     })
//                   : []
//               }
//             />
//           </Box>
//         </Grid>
//       );
//     } else
//       return (
//         <Input
//           resize
//           key={formElement.uiName}
//           value={this.state[formElement.uiName]}
//           // disabled={formElement.isDisabled == 'Y' ? true : false}
//           // required={formElement.isMandatory == 'Y' ? true : false}
//           changed={(event) => {
//             if (!event.target) {
//               this.setState({
//                 [formElement.uiName]: event,
//               });
//             } else {
//               if (event.target.type !== "checkbox")
//                 this.setState({
//                   [formElement.uiName]: event.target.value,
//                 });
//               else {
//                 console.log(event.target.checked);
//                 this.setState({
//                   [formElement.uiName]: event.target.checked,
//                 });
//               }
//             }
//           }}
//         />
//       );
//   }

//   searchHandler = () => {
//     let payload = { ...this.state.searchData };
//     Object.keys(payload).map((entity) => {
//       Object.keys(payload[entity]).map((field) => {
//         payload[entity][field] = this.state[field] ? this.state[field] : [];
//       });
//     });
//     let searchPayload = {
//       searchIn: this.state.SearchType,
//       opId: this.props.userInfo.opId,
//       buId: this.props.userInfo.buId,
//       search: [payload],
//     };
//     console.log(searchPayload);

//     this.setState({ loading: true });
//     axios
//       .post("dashboard/AdvSearch/search", searchPayload)
//       .then((res) => {
//         console.log(res);
//         this.setState({
//           loading: false,
//           data: res.data.data,
//         });
//       })
//       .catch((error) => {
//         console.log(error);
//         if (this._isMounted) this.setState({ loading: false });
//       });
//   };

//   render() {
//     const { classes } = this.props;

//     let advanceSearch = (
//       <div>
//         <div style={{ padding: "20px 0", fontSize: "24px", fontWeight: "600" }}>
//           Advance Search
//         </div>
//         <Card style={{ minHeight: "60vh" }}>
//           <CardContent>
//             <Typography
//               style={{ fontSize: "18px", fontWeight: "600" }}
//               gutterBottom
//             >
//               Search inside release {this.props.releaseData.releaseId}
//             </Typography>
//             <div>
//               <Grid container spacing={1}>
//                 <Grid item xs={3}>
//                   <RadioGroup
//                     // row
//                     aria-label="position"
//                     name="position"
//                     defaultValue="top"
//                     value={this.state.SearchType}
//                     onChange={(event) => {
//                       this.setState({
//                         SearchType: event.target.value,
//                       });
//                     }}
//                   >
//                     <FormControlLabel
//                       value={"Package"}
//                       control={
//                         <Radio
//                           style={{ color: "#ffcc00", padding: "4px 9px" }}
//                         />
//                       }
//                       label="Package"
//                     />
//                     <FormControlLabel
//                       value="Product"
//                       control={
//                         <Radio
//                           style={{ color: "#ffcc00", padding: "4px 9px" }}
//                         />
//                       }
//                       label="Product"
//                     />
//                   </RadioGroup>
//                 </Grid>
//                 <Grid item xs={3} style={{ display: "flex" }}>
//                   <div style={{ width: "100%", marginTop: "auto" }}>
//                     <span style={{ fontWeight: "600", fontSize: "14px" }}>
//                       Entities
//                     </span>
//                     <MultiSelect
//                       refLovs={Object.keys(this.state.searchData)}
//                       value={this.state.searchEntites}
//                       changed={(selected) => {
//                         let searchCriteria = [];
//                         let removeInput = [];
//                         let selSearchCriteria = [
//                           ...this.state.selSearchCriteria,
//                         ];
//                         let diff = this.state.searchEntites.filter(
//                           (x) => !selected.includes(x)
//                         );
//                         diff.map((entity) => {
//                           removeInput.push(
//                             ...Object.keys(this.state.searchData[entity])
//                           );
//                         });
//                         selected.map((entity) => {
//                           searchCriteria.push(
//                             ...Object.keys(this.state.searchData[entity])
//                           );
//                         });
//                         console.log(removeInput);
//                         console.log(searchCriteria);

//                         removeInput.map((el) => {
//                           this.setState({ [el]: [] });
//                           if (selSearchCriteria.includes(el))
//                             selSearchCriteria.splice(
//                               selSearchCriteria.indexOf(el),
//                               1
//                             );
//                         });
//                         // selSearchCriteria = selSearchCriteria.
//                         //     filter((el) => {
//                         //         this.setState({ [el]: [] })
//                         //         return !removeInput.includes(el)
//                         //     }
//                         //     );

//                         this.setState({
//                           searchEntites: selected,
//                           searchCriteria: searchCriteria,
//                           selSearchCriteria: selSearchCriteria,
//                         });
//                       }}
//                     />
//                   </div>
//                 </Grid>
//                 <Grid item xs={3} style={{ display: "flex" }}>
//                   <div style={{ width: "100%", marginTop: "auto" }}>
//                     {" "}
//                     <span style={{ fontWeight: "600", fontSize: "14px" }}>
//                       Search Criteria
//                     </span>
//                     <MultiSelect
//                       refLovs={this.state.searchCriteria}
//                       value={this.state.selSearchCriteria}
//                       changed={(selected) => {
//                         if (
//                           !this.state.selSearchCriteria.includes("Attribute") &&
//                           selected.includes("Attribute")
//                         ) {
//                           console.log("Attribute");
//                           //   this.setState({ loading: true });
//                           //   this.attributeGrpData().then(() => {
//                           //     this.setState({ loading: false });
//                           //   });
//                         }
//                         let diff = this.state.selSearchCriteria.filter(
//                           (x) => !selected.includes(x)
//                         );
//                         diff.map((el) => {
//                           this.setState({
//                             [el]: [],
//                           });
//                         });
//                         this.setState({
//                           selSearchCriteria: selected,
//                         });
//                       }}
//                     />
//                   </div>
//                 </Grid>
//                 <Grid item xs={12} style={{ display: "flex" }}>
//                   <Button
//                     style={{
//                       padding: "6px 50px",
//                       marginTop: "10px",
//                       marginLeft: "auto",
//                     }}
//                     // disabled={
//                     //   this.state.selSearchCriteria &&
//                     //   this.state.selSearchCriteria.length > 0
//                     // }
//                     onClick={this.searchHandler}
//                   >
//                     Search
//                   </Button>
//                 </Grid>
//               </Grid>
//             </div>
//             <Divider style={{ margin: "20px 0" }} />
//             {this.state.data.length > 0 ? (
//               <MaterialTable
//                 tableRef={this.selectTable}
//                 icons={tableIcons}
//                 title={"Search Results"}
//                 columns={this.state.columns}
//                 data={this.state.data}
//                 onRowClick={
//                   this.props.releaseData.releaseId
//                     ? (event, rowData) => {
//                         console.log(rowData.responseId);
//                         if (this.state.SearchType === "Package") {
//                           this.props.changePackageActiveStep(0);
//                           let pkgData = {};
//                           pkgData["packageId"] = rowData.responseId;
//                           this.props.onPackageEnter(pkgData);
//                           this.props.changePackageKey(this.props.pkgKey + "1");
//                           this.props.history.push("/planConfiguration");
//                         } else if (this.state.SearchType === "Product") {
//                           this.props.changeProductActiveStep(0);
//                           let proData = {};
//                           proData["productId"] = rowData.responseId;
//                           this.props.onProductEnter(proData);
//                           this.props.changeProductKey(
//                             this.props.productKey + "1"
//                           );
//                           this.props.history.push("/productConfiguration");
//                         }
//                       }
//                     : null
//                 }
//                 options={{
//                   pageSize: 10,
//                   pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
//                   toolbar: true,
//                   paging: true,
//                   rowStyle: {
//                     fontSize: "14px",
//                     // fontWeight: "600"
//                   },
//                   headerStyle: {
//                     fontWeight: "bold",
//                   },
//                 }}
//               />
//             ) : (
//               <div
//                 style={{
//                   padding: "20px",
//                   fontSize: "16px",
//                   background: "rgba(0, 0, 0, 0.04)",
//                   borderRadius: "5px",
//                 }}
//               >
//                 No results found
//               </div>
//             )}
//           </CardContent>
//         </Card>
//       </div>
//     );

//     let advanceSearch2 = (
//       <Card style={{ overflow: "visible", minHeight: "90vh" }}>
//         <CardHeader
//           className={classes.cardHeader}
//           classes={{
//             subheader: classes.subheader,
//           }}
//           action={
//             this.props.releaseData.releaseId && (
//               <React.Fragment>
//                 <div>
//                   <LightTooltip title="Back To Release" arrow>
//                     <LastPageIcon
//                       onClick={this.backToRelease}
//                       style={{ color: "white", cursor: "pointer" }}
//                     />
//                   </LightTooltip>
//                 </div>
//               </React.Fragment>
//             )
//           }
//           subheader={
//             this.props.releaseData.releaseId
//               ? "Advance Search You are inside release " +
//                 this.props.releaseData.releaseId
//               : "Advance Search"
//           }
//         />

//         <CardContent style={{ marginBottom: "2%" }}>
//           <Grid
//             container
//             alignContent="flex-start"
//             spacing={2}
//             style={{ overflow: "visible", marginBottom: "1vh" }}
//           >
//             <Grid
//               item
//               xs={4}
//               sm={4}
//               md={2}
//               style={{
//                 display: "flex",
//                 alignItems: "center",
//               }}
//             >
//               <Typography variant="subtitle1"> Search</Typography>
//             </Grid>
//             <Grid item xs={8} sm={8} md={10}>
//               <RadioGroup
//                 row
//                 aria-label="position"
//                 name="position"
//                 defaultValue="top"
//                 value={this.state.SearchType}
//                 onChange={(event) => {
//                   this.setState({
//                     SearchType: event.target.value,
//                   });
//                 }}
//               >
//                 <FormControlLabel
//                   value={"Package"}
//                   control={<Radio style={{ color: "#3f74c5" }} />}
//                   label="Package"
//                 />
//                 <FormControlLabel
//                   value="Product"
//                   control={<Radio style={{ color: "#3f74c5" }} />}
//                   label="Product"
//                 />
//               </RadioGroup>
//             </Grid>
//           </Grid>
//           <Grid container alignContent="flex-start" spacing={2}>
//             <Grid item xs={12} sm={4}>
//               <Grid container alignContent="flex-start" spacing={2}>
//                 <Grid item xs={12} sm={6}>
//                   <Box>
//                     <span>Entities</span>
//                   </Box>
//                   <Box mt={2}>
//                     <MultiSelect
//                       refLovs={Object.keys(this.state.searchData)}
//                       value={this.state.searchEntites}
//                       changed={(selected) => {
//                         let searchCriteria = [];
//                         let removeInput = [];
//                         let selSearchCriteria = [
//                           ...this.state.selSearchCriteria,
//                         ];
//                         let diff = this.state.searchEntites.filter(
//                           (x) => !selected.includes(x)
//                         );
//                         diff.map((entity) => {
//                           removeInput.push(
//                             ...Object.keys(this.state.searchData[entity])
//                           );
//                         });
//                         selected.map((entity) => {
//                           searchCriteria.push(
//                             ...Object.keys(this.state.searchData[entity])
//                           );
//                         });
//                         console.log(removeInput);
//                         console.log(searchCriteria);

//                         removeInput.map((el) => {
//                           this.setState({ [el]: [] });
//                           if (selSearchCriteria.includes(el))
//                             selSearchCriteria.splice(
//                               selSearchCriteria.indexOf(el),
//                               1
//                             );
//                         });
//                         // selSearchCriteria = selSearchCriteria.
//                         //     filter((el) => {
//                         //         this.setState({ [el]: [] })
//                         //         return !removeInput.includes(el)
//                         //     }
//                         //     );

//                         this.setState({
//                           searchEntites: selected,
//                           searchCriteria: searchCriteria,
//                           selSearchCriteria: selSearchCriteria,
//                         });
//                       }}
//                     />
//                   </Box>
//                 </Grid>
//                 <Grid item xs={12} sm={6}>
//                   <Box>
//                     <span>Search Criteria</span>
//                   </Box>
//                   <Box mt={2}>
//                     <MultiSelect
//                       refLovs={this.state.searchCriteria}
//                       value={this.state.selSearchCriteria}
//                       changed={(selected) => {
//                         if (
//                           !this.state.selSearchCriteria.includes("Attribute") &&
//                           selected.includes("Attribute")
//                         ) {
//                           console.log("Attribute");
//                           this.setState({ loading: true });
//                           this.attributeGrpData().then(() => {
//                             this.setState({ loading: false });
//                           });
//                         }
//                         let diff = this.state.selSearchCriteria.filter(
//                           (x) => !selected.includes(x)
//                         );
//                         diff.map((el) => {
//                           this.setState({
//                             [el]: [],
//                           });
//                         });
//                         this.setState({
//                           selSearchCriteria: selected,
//                         });
//                       }}
//                     />
//                   </Box>
//                 </Grid>
//               </Grid>
//               <Divider
//                 style={{
//                   background: "grey",
//                   marginTop: "2vh",
//                   marginBottom: "2vh",
//                 }}
//               />

//               <div style={{ maxHeight: "65vh", overflow: "auto" }}>
//                 {this.state.selSearchCriteria.map((formElement) => {
//                   return (
//                     <div style={{ marginBottom: "2vh" }}>
//                       {this.inputHelper(
//                         this.state.searchDataInput[formElement],
//                         formElement
//                       )}
//                     </div>
//                   );
//                 })}
//               </div>
//               {this.state.selSearchCriteria &&
//                 this.state.selSearchCriteria.length > 0 && (
//                   <div className={classes.center}>
//                     <Button
//                       variant="contained"
//                       style={{
//                         background: "#02bfa0",
//                         marginTop: "3%",
//                         textTransform: "none",
//                       }}
//                       onClick={this.searchHandler}
//                     >
//                       Search
//                     </Button>
//                   </div>
//                 )}
//             </Grid>

//             <Grid item xs={12} sm={8}>
//               <ThemeProvider theme={theme}>
//                 <MaterialTable
//                   tableRef={this.selectTable}
//                   icons={tableIcons}
//                   title={"Search Results"}
//                   columns={this.state.columns}
//                   data={this.state.data}
//                   onRowClick={
//                     this.props.releaseData.releaseId
//                       ? (event, rowData) => {
//                           console.log(rowData.responseId);
//                           if (this.state.SearchType == "Package") {
//                             this.props.changePackageActiveStep(0);
//                             let pkgData = {};
//                             pkgData["packageId"] = rowData.responseId;
//                             this.props.onPackageEnter(pkgData);
//                             this.props.changePackageKey(
//                               this.props.pkgKey + "1"
//                             );
//                             this.props.history.push("/planConfiguration");
//                           } else if (this.state.SearchType == "Product") {
//                             this.props.changeProductActiveStep(0);
//                             let proData = {};
//                             proData["productId"] = rowData.responseId;
//                             this.props.onProductEnter(proData);
//                             this.props.changeProductKey(
//                               this.props.productKey + "1"
//                             );
//                             this.props.history.push("/productConfiguration");
//                           }
//                         }
//                       : null
//                   }
//                   options={{
//                     pageSize: 10,
//                     pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
//                     toolbar: true,
//                     paging: true,
//                     rowStyle: {
//                       fontSize: "14px",
//                       // fontWeight: "600"
//                     },
//                     headerStyle: {
//                       fontWeight: "bold",
//                     },
//                   }}
//                 />
//               </ThemeProvider>
//             </Grid>
//           </Grid>
//         </CardContent>
//       </Card>
//     );

//     if (this.state.loading) advanceSearch = <Loader />;

//     return advanceSearch;
//   }
// }

// const mapStateToProps = (state) => {
//   return {
//     releaseData: state.releaseData.releaseData,
//     userInfo: state.login.loggedInUserInfo,
//     pkgKey: state.packageData.pkgKey,
//     productKey: state.productData.productKey,
//   };
// };

// const mapDispatchToProps = (dispatch) => {
//   return {
//     onPackageEnter: (packageData) =>
//       dispatch({ type: actionTypes.INSIDE_PACKAGE, packageData: packageData }),
//     changePackageKey: (pkgKey) =>
//       dispatch({ type: actionTypes.CHANGE_PACKAGE_KEY, pkgKey: pkgKey }),
//     changePackageActiveStep: (activeStep) =>
//       dispatch({
//         type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
//         activeStep: activeStep,
//       }),
//     changeProductKey: (productKey) =>
//       dispatch({
//         type: actionTypes.CHANGE_PRODUCT_KEY,
//         productKey: productKey,
//       }),
//     onProductEnter: (productData) =>
//       dispatch({ type: actionTypes.INSIDE_PRODUCT, productData: productData }),
//     changeProductActiveStep: (activeStep) =>
//       dispatch({
//         type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP,
//         activeStep: activeStep,
//       }),
//   };
// };

// export default connect(
//   mapStateToProps,
//   mapDispatchToProps
// )(withStyles(useStyles)(WithErrorHandler(AdvanceSearch, axios)));

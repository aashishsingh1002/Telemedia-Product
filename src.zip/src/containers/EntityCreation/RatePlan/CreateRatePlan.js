import React, { Component } from 'react';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import axios from 'axios';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import AddIcon from '@material-ui/icons/Add';
import Tooltip from '@material-ui/core/Tooltip';
import Loader from '../../../UI/Loader/Loader';
import Input from '../../../UI/Input/Input';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box';
import MultiSelect from '../../../UI/Input/MultiSelect';
import InputNumber from '../../../UI/Input/InputNumber';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import moment from 'moment';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import Divider from '@material-ui/core/Divider';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import DeleteIcon from '@material-ui/icons/Delete';
import VisibilityIcon from '@material-ui/icons/Visibility';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import EditIcon from '@material-ui/icons/Edit';
import { Prompt } from 'react-router';
import { connect } from 'react-redux';

const LightTooltip = withStyles((theme) => ({
	tooltip: {
    backgroundColor: "#525354",
    color: "white",
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

const useStyles = (theme) => ({
	AccordionSummary:{
		PointerEvent:'none'
	},
  cardHeader: {
    // background: "#546D7A",
    // height: "4.5vh",
  },
  subheader: {
    fontSize: "20px",
    color: "#393939",
    // color: "white",
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    margin: "0 auto 0 0",
  },
  formControl: {
    marginLeft: 15,
    minWidth: 200,
  },
});

class CreateRatePlan extends Component {
	_isMounted = false;

	state = {
		ratePlanUoms: [],
		ratePlanUsageGroupOrg: {},
		ratePlanDataVersion: '',
		ratePlanVersion: '',
		discountUsageGroupVersion: '',
		ratePlanUsageGroup: {},
		loading: true,
		ratePlanGroups: {},
		ratePlanGroupsOrg: {},
		schema: [],
		country: [],
		zones: [],
		jurisdiction: [],
		selJurisdiction: [],
		tapCodes: [],
		seltapCodes: [],
		countryCodes: [],
		usageGrps: {},
		ratesObj: {},
		show: false,
		modalContent: null,
		expanded: false,
		serviceTypeWatch: true,
		serviceSubTypeWatch: true,
		zoneWatch: true,
		countryWatch: true,
		countryCodesWatch: true,
		serviceSubSubTypeWatch: true,
		editing: false,
		ccmidUpdate: '',
		disableRp: false,
		fillRates: '',
		onDeploy: false,
	};

	changeHandler = (panel) => (event, isExpanded) => {
		this.setState({ expanded: isExpanded ? panel : false });
	};

	componentWillUnmount() {
		this._isMounted = false;
	}

	
	componentDidUpdate(prevProps, prevState) {
		if (
			prevState['icmRateplanCategory'] !== this.state['icmRateplanCategory']
		) {
			if (!this.state.serviceTypeWatch) {
				this.setState({
					serviceTypeWatch: true,
				});
				return;
			} else {
				if (this.state['icmRateplanCategory']) {
					if (this.state['icmRateplanCategory'] === 'ISD') {
						let ratePlanGroups = { ...this.state.ratePlanGroupsOrg };
						ratePlanGroups['Rates Details'] = ratePlanGroups[
							'Rates Details'
						].filter((el) => el.refName != 'icmUom');
						this.setState({
							ratePlanGroups,
						});
					} else {
						let ratePlanGroups = { ...this.state.ratePlanGroupsOrg };
						this.setState({
							ratePlanGroups,
						});
					}
					let serviceSubTypes = [];
					let schema = [...this.state.schema];
					serviceSubTypes = Object.keys(
						this.state.ratePlanUsageGroup[this.state.icmRateplanCategory]
					);
					schema.map((el) => {
						if (el.refName == 'icmSubCategory') {
							el.refLovs = [];
							el.refLovs = serviceSubTypes;
						}
						if (el.refName == 'ugcSubType2') {
							el.refLovs = [];
						}
					});
					this.setState({
						schema: schema,
						icmSubCategory: null,
						ugcSubType2: [],
						usageType: null,
						icmUom: null,
					});
				}
			}
		} else if (prevProps['getLatestData'] !== this.props['getLatestData']) {
			this.props.sendLatestData([this.state.usageGrps, this.state.disableRp]);
		}

		// else if (prevState['usageType'] !== this.state['usageType']) {
		//     if (this.state['usageType']) {
		//         if (this.state['usageType'] === 'Custom Pulse') {
		//             let ratePlanGroups = { ...this.state.ratePlanGroupsOrg }
		//             this.setState({
		//                 ratePlanGroups
		//             })
		//         }
		//         else {
		//             let ratePlanGroups = { ...this.state.ratePlanGroupsOrg }
		//             ratePlanGroups['Rates Details'] = ratePlanGroups['Rates Details'].filter(el => el.refName != 'icmUom')
		//             this.setState({
		//                 ratePlanGroups
		//             })
		//         }
		//     }
		// }
		else if (prevState['icmSubCategory'] !== this.state['icmSubCategory']) {
			if (!this.state.serviceSubTypeWatch) {
				this.setState({
					serviceSubTypeWatch: true,
				});
				return;
			} else {
				if (this.state['icmSubCategory']) {
					let serviceSubSubType = [];
					let schema = [...this.state.schema];
					serviceSubSubType = Object.keys(
						this.state.ratePlanUsageGroup[this.state.icmRateplanCategory][
							this.state.icmSubCategory
						]
					);
					schema.map((el) => {
						if (el.refName == 'ugcSubType2') {
							el.refLovs = [];
							el.refLovs = serviceSubSubType;
						}
					});

					this.setState({
						ugcSubType2: [],
						schema: schema,
						icmUom: null,
					});
				}
			}
		} else if (prevState['ugcSubType2'] !== this.state['ugcSubType2']) {
			if (!this.state.serviceSubSubTypeWatch) {
				this.setState({
					serviceSubSubTypeWatch: true,
				});
				return;
			}
		} else if (
			prevProps.editRpData !== this.props.editRpData &&
			prevProps.typeRatePlan === 'edit' &&
			this.props.typeRatePlan === 'create'
		) {
			if (Object.keys(prevProps.editRpData).length > 0) {
				console.log(prevProps.editRpData);
				Object.keys(prevProps.editRpData['basic']).forEach((key) => {
					this.setState({
						[key]: '',
					});
				});
				this.setState({
					usageGrps: {},
					ratesObj: {},
					editing: false,
					ccmidUpdate: '',
				});
			}
		}
	}

	componentDidMount() {
		this._isMounted = true;
		this.versions().then(() => {
			this.uiFields().then(() => {
				this.state.schema.map((formElement) => {
					if (formElement.refType == 'Date')
						this.setState({
							[formElement.refName]: formElement.defaultValue
								? moment(formElement.defaultValue).format('DD-MMM-YY')
								: moment().format('DD-MMM-YY'),
						});
					else if (formElement.refType == 'TextInput' || 'TextArea')
						this.setState({
							[formElement.refName]: formElement.defaultValue,
						});
				});
				this.discountUsageGroupLovsData().then(() => {
					this.discountedItemsDataLovsData().then(() => {
						this.state.schema.map((uiField) => {
							if (uiField.refName == 'icmUom') {
								this.setState({
									ratePlanUoms: uiField.refLovs,
								});
							}
						});
						let ratePlanGroups = {};
						this.state.schema.map((el) => {
							// if (el.refType == "MultiSelect")
							//     this.$set(this.formData, el.refName, []);
							// else this.$set(this.formData, el.refName, "");
							if (!(el.uiGroup in ratePlanGroups)) {
								let arr = [];
								this.state.schema.map((elem) => {
									if (elem.uiGroup == el.uiGroup) {
										arr.push(elem);
									}
								});
								ratePlanGroups[el.uiGroup] = arr;
							}
						});
						console.log(ratePlanGroups);
						this.setState({
							loading: false,
							ratePlanGroups: ratePlanGroups,
							ratePlanGroupsOrg: { ...ratePlanGroups },
							onDeploy:
								this.props.editRpData?.basic?.releaseMasterCheck.toLowerCase() ===
								'deployed',
						});

						if (Object.keys(this.props.editRpData).length > 0) {
							console.log(this.props.editRpData);
							Object.keys(this.props.editRpData['basic']).forEach((key) => {
								if (
									key === 'icmDesc' &&
									this.props.editRpData?.basic?.releaseMasterCheck ===
										'Deployed'
								) {
									this.setState({
										[key]: '',
									});
								} else {
									this.setState({
										[key]: this.props.editRpData['basic'][key],
									});
								}
							});
							this.setState({
								usageGrps: this.props.editRpData['usageGrps'],
								ratesObj: this.props.editRpData['ratesObj'],
								editing: true,
								ccmidUpdate: this.props.editRpData['basic'].ccmId,
							});
						}
					});
				});
			});
		});
	}

	versions() {
		return axios
			.all([
				axios.get(
					process.env.REACT_APP_URL +
						'package/config/version?entityName=ratePlan',
					{
						headers: {
							opId: this.props.userInfo.opId,
							buId: this.props.userInfo.buId,
							authUserId: this.props.userInfo.id,
							Authorization: 'Bearer ' + this.props.userInfo.jwt,
						},
					}
				),
				axios.get(
					process.env.REACT_APP_URL +
						'package/config/version?entityName=ratePlanUsageGroup',
					{
						headers: {
							opId: this.props.userInfo.opId,
							buId: this.props.userInfo.buId,
							authUserId: this.props.userInfo.id,
							Authorization: 'Bearer ' + this.props.userInfo.jwt,
						},
					}
				),
				axios.get(
					process.env.REACT_APP_URL +
						'package/config/version?entityName=ratePlanItemsData',
					{
						headers: {
							opId: this.props.userInfo.opId,
							buId: this.props.userInfo.buId,
							authUserId: this.props.userInfo.id,
							Authorization: 'Bearer ' + this.props.userInfo.jwt,
						},
					}
				),
			])
			.then(
				axios.spread(
					(
						ratePlanVersion,
						discountUsageGroupVersion,
						ratePlanItemsDataVersion
					) => {
						this.setState({
							ratePlanVersion: ratePlanVersion.data.data.version,
							discountUsageGroupVersion:
								discountUsageGroupVersion.data.data.version,
							ratePlanDataVersion: ratePlanItemsDataVersion.data.data.version,
						});
					}
				)
			)
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	}

	uiFields() {
		if (
			localStorage.getItem('ratePlan') &&
			localStorage.ratePlan_version &&
			localStorage.ratePlan_version == this.state.ratePlanVersion
		) {
			console.log('fetching from local storage');
			try {
				this.setState({ schema: JSON.parse(localStorage.getItem('ratePlan')) });
			} catch (e) {
				localStorage.removeItem('ratePlan');
			}
			return Promise.resolve();
		} else {
			console.log('fetching from api');
			return axios
				.get(
					process.env.REACT_APP_URL + '/package/config?entityName=ratePlan',
					{
						headers: {
							opId: this.props.userInfo.opId,
							buId: this.props.userInfo.buId,
							authUserId: this.props.userInfo.id,
							Authorization: 'Bearer ' + this.props.userInfo.jwt,
						},
					}
				)
				.then((res) => {
					let schema = [];
					schema = res.data.data.map(function (el) {
						if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
							if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
							else if (el.refLovs == null) el.refLovs = [];
						}
						return el;
					});
					if (this._isMounted) this.setState({ schema: schema });
					localStorage.setItem('ratePlan', JSON.stringify(schema));
					localStorage.ratePlan_version = this.state.ratePlanVersion;
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		}
	} 



	discountedItemsDataLovsData() {
		if (
			localStorage.getItem('ratePlanItemsData') &&
			localStorage.ratePlanItemsData_version &&
			localStorage.ratePlanItemsData_version == this.state.ratePlanDataVersion
		) {
			console.log('fetching ratePlanItemsData from local storage');
			try {
				this.setState({
					ratePlanItemsData: JSON.parse(
						localStorage.getItem('ratePlanItemsData')
					),
				});
			} catch (e) {
				localStorage.removeItem('ratePlanItemsData');
			}
			return Promise.resolve();
		} else {
			console.log('fetching ratePlanItemsData from api');
			return axios
				.get(process.env.REACT_APP_URL + 'ratePlan/slabrate', {
					headers: {
						authUserId: this.props.userInfo.id,
						Authorization: 'Bearer ' + this.props.userInfo.jwt,
					},
				})
				.then((res) => {
					console.log(res);
					localStorage.setItem(
						'ratePlanItemsData',
						JSON.stringify(res.data.data)
					);
					this.setState({
						ratePlanItemsData: res.data.data,
					});
					localStorage.ratePlanItemsData_version =
						this.state.ratePlanDataVersion;
				})
				.catch((error) => {
					console.log(error);
					this.setState({ loading: false });
				});
		}
	}

	discountUsageGroupLovsData() {
		if (
			localStorage.getItem('ratePlanUsageGroup') &&
			localStorage.discountUsageGroup_version &&
			localStorage.discountUsageGroup_version ==
				this.state.discountUsageGroupVersion
		) {
			console.log('fetching ratePlanUsageGroup from local storage');
			try {
				let ratePlanUsageGroupOrg = JSON.parse(
					localStorage.getItem('ratePlanUsageGroup')
				);
				console.log(ratePlanUsageGroupOrg);
				let ratePlanUsageGroup = JSON.parse(
					localStorage.getItem('ratePlanUsageGroup')
				);
				if (ratePlanUsageGroup['HOME'] && ratePlanUsageGroup['HOME']['VOICE']) {
					Object.keys(ratePlanUsageGroup['HOME']['VOICE']).map((subSubType) => {
						ratePlanUsageGroup['HOME']['VOICE'][subSubType] =
							ratePlanUsageGroup['HOME']['VOICE'][subSubType].filter(
								(subSubType) => !subSubType.includes('EPC')
							);
					});
				}
				this.setState({
					ratePlanUsageGroup: ratePlanUsageGroup,
					ratePlanUsageGroupOrg: ratePlanUsageGroupOrg,
				});
			} catch (e) {
				localStorage.removeItem('ratePlanUsageGroup');
			}
			return Promise.resolve();
		} else {
			console.log('fetching ratePlanUsageGroup from api');
			return axios
				.get(process.env.REACT_APP_URL + 'ratePlan/usageGrps', {
					headers: {
						opId: this.props.userInfo.opId,
						authUserId: this.props.userInfo.id,
						Authorization: 'Bearer ' + this.props.userInfo.jwt,
					},
				})
				.then((res) => {
					console.log(res.data.data);
					localStorage.setItem(
						'ratePlanUsageGroup',
						JSON.stringify(res.data.data)
					);
					let ratePlanUsageGroup = { ...res.data.data };
					if (
						ratePlanUsageGroup['HOME'] &&
						ratePlanUsageGroup['HOME']['VOICE']
					) {
						Object.keys(ratePlanUsageGroup['HOME']['VOICE']).map(
							(subSubType) => {
								ratePlanUsageGroup['HOME']['VOICE'][subSubType] =
									ratePlanUsageGroup['HOME']['VOICE'][subSubType].filter(
										(subSubType) => !subSubType.includes('EPC')
									);
							}
						);
					}

					this.setState({
						ratePlanUsageGroup: ratePlanUsageGroup,
					});
					localStorage.discountUsageGroup_version =
						this.state.discountUsageGroupVersion;
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		}
	}

	inputHelper(formElement) {
		if (formElement.refType == 'MultiSelect')
			return (
				<Grid item xs={12} sm={4} md={3} key={formElement.refName}>
					<Box>
						<span style={{}}>{formElement.uiName}</span>
					</Box>
					<Box mt={2}>
						<MultiSelect
							refLovs={formElement.refLovs}
							value={this.state[formElement.refName]}
							{...formElement}
							changed={(selected) => {
								console.log(selected);
								if (!(selected instanceof Array)) selected = [selected];

								this.setState({
									[formElement.refName]: selected,
								});
							}}
							// placeholder={offerability}
						/>
					</Box>
				</Grid>
			);
		else
			return (
				<Input
					key={formElement.refName}
					{...formElement}
					value={this.state[formElement.refName]}
					disabled={formElement.isDisabled == 'Y' ? true : false}
					required={formElement.isMandatory == 'Y' ? true : false}
					changed={(event) => {
						if (!event.target) {
							this.setState({
								[formElement.refName]: event,
							});
						} else {
							if (event.target.type !== 'checkbox')
								this.setState({
									[formElement.refName]: event.target.value,
								});
							else {
								console.log(event.target.checked);
								this.setState({
									[formElement.refName]: event.target.checked,
								});
							}
						}
					}}
				/>
			);
	}

	saveRpNormalFlow = (uom) => {
		if (this.state.icmUom) {
			let usageGrps = { ...this.state.usageGrps };
			let ratesObj = { ...this.state.ratesObj };
			console.log('jk',ratesObj)
			this.state['ugcSubType2'].map((el) => {
				if (
					!(
						this.state['icmRateplanCategory'] +
							'-' +
							this.state['icmSubCategory'] +
							'-' +
							el in
						this.state.usageGrps
					)
				) {
					let newProp =
						this.state['icmRateplanCategory'] +
						'-' +
						this.state['icmSubCategory'] +
						'-' +
						el;
					usageGrps[newProp] = null;
					let filteredUsageGrps = Array.from(
						new Set(
							this.state.ratePlanUsageGroup[this.state['icmRateplanCategory']][
								this.state['icmSubCategory']
							][el]
						)
					);

					usageGrps[newProp] = [...filteredUsageGrps];
					ratesObj[newProp] = {};
					ratesObj[newProp]['icmUom'] = this.state.icmUom;
					filteredUsageGrps.map((usageGrp) => {
						ratesObj[newProp][usageGrp + '_pulse'] = this.state.icmUom;
					});
				}
			});
			console.log(ratesObj);
			this.setState({
				usageGrps: usageGrps,
				ratesObj: ratesObj,
			});
			console.log('jkusg',usageGrps);
			console.log(ratesObj);
		}
	};

	saveRatesIsdHelper(uom) {
		let usageGrps = { ...this.state.usageGrps };
		let ratesObj = { ...this.state.ratesObj };

		this.state.ugcSubType2.map((el) => {
			let newProp =
				this.state['icmRateplanCategory'] +
				'-' +
				this.state['icmSubCategory'] +
				'-' +
				el;

			if (!(newProp in this.state.usageGrps)) {
				let filteredUsageGrps = Object.keys(this.state.ratePlanItemsData);
				usageGrps[newProp] = [...filteredUsageGrps];
				ratesObj[newProp] = {};
				ratesObj[newProp]['icmUom'] = uom;
				ratesObj[newProp]['usageType'] = this.state.usageType;
				filteredUsageGrps.map((usageGrp) => {
					if (this.state.usageType == 'Standard Min') {
						ratesObj[newProp][usageGrp] =
							this.state.ratePlanItemsData[usageGrp].RATE_PER_MIN;
						ratesObj[newProp][usageGrp + '_pulse'] = uom;
					} else if (this.state.usageType == 'Standard Pulse') {
						ratesObj[newProp][usageGrp] =
							this.state.ratePlanItemsData[usageGrp].PRICE_IN_RS_PER_PULSE;
						ratesObj[newProp][usageGrp + '_pulse'] =
							this.state.ratePlanItemsData[usageGrp].PULSE_IN_SEC;
					} else if (this.state.usageType == 'Custom Min') {
						ratesObj[newProp][usageGrp] =
							this.state.ratePlanItemsData[usageGrp].RATE_PER_MIN;
						ratesObj[newProp][usageGrp + '_pulse'] = uom;
					} else if (this.state.usageType == 'Custom Pulse') {
						ratesObj[newProp][usageGrp] =
							this.state.ratePlanItemsData[usageGrp].PRICE_IN_RS_PER_PULSE;
						ratesObj[newProp][usageGrp + '_pulse'] =
							this.state.ratePlanItemsData[usageGrp].PULSE_IN_SEC;
					}
				});
			}
		});
		console.log(ratesObj);

		this.setState({
			usageGrps: usageGrps,
			ratesObj: ratesObj,
		});
	}

	saveRatesIsd() {
		if (this.state.usageType) {
			// if (this.state.usageType === 'Custom Pulse') {
			//     if (this.state.icmUom)
			//         this.saveRatesIsdHelper(this.state.icmUom)
			// }
			// else
			this.saveRatesIsdHelper('60 Second');
		}
	}

	createCloneRatePlan = () => {
		return console.log('this is deployed');
	};

	submitChanges = (id, payload, flag) => {
		return axios
			.post(
				`/ratePlan/EditCrp?releaseId=${this.props.releaseData.releaseId}&ccmId=${id}&flag=${flag}`,
				payload,
				{
					headers: {
						opId: this.props.userInfo.opId,
						authUserId: this.props.userInfo.id,
						Authorization: 'Bearer ' + this.props.userInfo.jwt,
					},
				}
			)
			.then((res) => {
				console.log(`${flag} rate plan`, res.data.data);
				this.setState({ loading: false });
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	};

	saveRatePlans = (event) => {
		debugger;
		event.preventDefault();

		console.log(this.state.ratePlanUsageGroupOrg);
		let ratePlanUsageGroupOrg = JSON.parse(
			localStorage.getItem('ratePlanUsageGroup')
		);
		console.log(ratePlanUsageGroupOrg);

		this.setState({ expanded: true });
		this.setState({ loading: true });
		let ratesObj = { ...this.state.ratesObj };
		console.log(ratesObj);

		Object.keys(ratesObj).map((ratePlanType) => {
			if (ratePlanType.includes('HOME-VOICE')) {
				let subSubTye = ratePlanType.split('-')[2];
				console.log(subSubTye);

				ratePlanUsageGroupOrg['HOME']['VOICE'][subSubTye].forEach(
					(usageType) => {
						if (usageType.includes('EPC')) {
							console.log(usageType);
							ratesObj[ratePlanType][usageType] = usageType;
						}
					}
				);
			}
		});

		console.log(ratesObj);

		let payload = {};
		let listOfratePlanInput = [];
		let date = moment().format('YYYY-MM-DD');
		let categories = [];
		Object.keys(ratesObj).forEach((key) => {
			let obj = {};
			if (!this.state.editing) obj.icmId = null;
			else {
				// if ('newRP' in ratesObj[key] && !ratesObj[key].newRP) {
				//     obj.icmId = ratesObj[key].icmId
				// }
				// else
				//     obj.icmId = null
				if (ratesObj[key].icmId) {
					obj.icmId = ratesObj[key].icmId;
				} else obj.icmId = null;
			}
			obj.rateClass = 'Standard';
			obj.timeband = '24 hours';
			obj.pulse = ratesObj[key]['icmUom'];
			obj.ccmOpId = this.props.userInfo.opId;
			obj.ccmBuId = this.props.userInfo.buId;
			obj.icmDesc = this.state.icmDesc;
			obj.icmEndDate = moment(this.state.icmEndDate).format('YYYY-MM-DD');
			obj.icmStartDate = moment(this.state.icmStartDate).format('YYYY-MM-DD');
			obj.icmCreatedBy = this.props.userInfo.id;
			obj.icmCreationDate = date;
			obj.icmModifiedBy = this.props.userInfo.id;
			obj.icmModifiedDate = date;

			obj.icmUom = ratesObj[key]['icmUom'];
			let rp = key.split('-');
			obj.icmRateplanCategory = rp[0];
			obj.icmSubCategory = rp[1];
			categories.push(obj.icmSubCategory);
			obj.ugcSubType2 = rp[2];
			let cgdRates = [];
			if (obj.icmRateplanCategory == 'ISD') {
				let helperCgd = { ...ratesObj[key] };
				obj.minutesOrPulse = helperCgd['usageType'];
				let helperGridPulse = {};
				delete helperCgd['icmId'];
				delete helperCgd['newRP'];

				delete helperCgd['icmUom'];
				delete helperCgd['usageType'];

				Object.keys(helperCgd).forEach((usageGrp) => {
					if (usageGrp.includes('_pulse')) {
						helperGridPulse[usageGrp] = helperCgd[usageGrp];
						delete helperCgd[usageGrp];
					}
				});
				Object.keys(helperCgd).forEach((usageGrp) => {
					let rateObj = {};
					rateObj.usageGroup = usageGrp;
					rateObj.rates =
						helperCgd[usageGrp] + '/' + helperGridPulse[usageGrp + '_pulse'];
					cgdRates.push(rateObj);
				});
			} else {
				let helperCgdrates = { ...ratesObj[key] };
				console.log(ratesObj[key]);
				delete helperCgdrates['icmUom'];
				delete helperCgdrates['icmId'];
				delete helperCgdrates['newRP'];

				console.log(helperCgdrates);
				let helperGridPulseHome = {};
				Object.keys(helperCgdrates).forEach((usageGrp) => {
					if (usageGrp.includes('_pulse')) {
						helperGridPulseHome[usageGrp] = helperCgdrates[usageGrp];
						delete helperCgdrates[usageGrp];
					}
				});

				Object.keys(helperCgdrates).forEach((usageGrp) => {
					let rateObj = {};
					rateObj.usageGroup = usageGrp;
					if (usageGrp.includes('EPC'))
						rateObj.rates = usageGrp + '/' + usageGrp;
					else
						rateObj.rates =
							helperCgdrates[usageGrp] +
							'/' +
							helperGridPulseHome[usageGrp + '_pulse'];
					cgdRates.push(rateObj);
				});
			}
			obj.cgdRates = cgdRates;
			listOfratePlanInput.push(obj);
		});
		payload.listOfratePlanInput = listOfratePlanInput;
		payload.releaseId = this.props.releaseData.releaseId;
		payload.ccmSubcateg = Array.from(new Set(categories)).join();
		payload.pkgBrand = this.state.pkgBrand;
		console.log(payload);

		if (
			Object.keys(this.props.editRpData).length !== 0 &&
			!this.state.onDeploy
		) {
			// ratesObj.filter((item) => !item.icmId.includes('undefined'));
			ratesObj = Object.fromEntries(
				Object.entries(ratesObj).filter(
					([key]) => !ratesObj[key].icmId.toString().includes('undefined')
				)
			);
			this.setState({ ratesObj });
			return this.submitChanges(
				this.props.editRpData.basic.ccmId,
				payload,
				'UPDATE'
			).then(()=> this.props.changeToActive());
		} else {
			let url = 'ratePlan/createRatePlan';

			axios
				.post(process.env.REACT_APP_URL + url, payload, {
					headers: {
						opId: this.props.userInfo.opId,
						authUserId: this.props.userInfo.id,
						Authorization: 'Bearer ' + this.props.userInfo.jwt,
					},
				})
				.then((response) => {
					console.log(response);
					this.setState({ loading: false });
					if (response){
						this.setState({
							disableRp: true,
						});
						this.props.changeToActive();
					}
					// this.clearRP()
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		}
	};

	disableWatchers() {
		this.setState({
			serviceTypeWatch: false,
			serviceSubTypeWatch: false,
			zoneWatch: false,
			countryWatch: false,
			countryCodesWatch: false,
			serviceSubSubTypeWatch: false,
		});
	}

	enableWatchers() {
		this.setState({
			serviceTypeWatch: true,
			serviceSubTypeWatch: true,
			zoneWatch: true,
			countryWatch: true,
			countryCodesWatch: true,
			serviceSubSubTypeWatch: true,
		});
	}

	viewRatePlan(name) {
		this.disableWatchers();
		// this.clearView();
		let rp = name.split('-');

		let arr = [];
		let uom = this.state.ratesObj[name]['icmUom'];
		arr.push(rp[2]);

		this.setState({
			['icmRateplanCategory']: rp[0],
			['icmSubCategory']: rp[1],
			['icmUom']: uom,
			['ugcSubType2']: arr,
		});

		let schema = [...this.state.schema];

		schema.map((el) => {
			if (el.refName == 'icmSubCategory') {
				el.refLovs = [];
				el.refLovs = Object.keys(this.state.ratePlanUsageGroup[rp[0]]);
			} else if (el.refName == 'ugcSubType2') {
				el.refLovs = [];
				el.refLovs = Object.keys(this.state.ratePlanUsageGroup[rp[0]][rp[1]]);
			}
		});

		if (rp[0] == 'ISD') {
			this.setState({
				usageType: this.state.ratesObj[name]['usageType'],
			});

			let ratePlanGroups = { ...this.state.ratePlanGroupsOrg };
			ratePlanGroups['Rates Details'] = ratePlanGroups['Rates Details'].filter(
				(el) => el.refName != 'icmUom'
			);
			this.setState({
				ratePlanGroups,
			});
		} else {
			let ratePlanGroups = { ...this.state.ratePlanGroupsOrg };
			this.setState({
				ratePlanGroups,
			});
		}
		this.setState(
			{
				schema: schema,
			},
			() => {
				this.enableWatchers();
			}
		);
	}

	clearRP = () => {
		let schema = [...this.state.schema];
		schema.map((el) => {
			if (el.refName == 'icmSubCategory') {
				el.refLovs = [];
			}
			if (el.refName == 'ugcSubType2') {
				el.refLovs = [];
			}
		});
		this.setState({
			schema: schema,
			usageGrps: {},
			ratesObj: {},
			editing: false,
			disableRp: false,
			ccmidUpdate: '',
			usageType: '',
		});

		this.state.schema.map((formElement) => {
			if (formElement.refType == 'Date')
				this.setState({
					[formElement.refName]: formElement.defaultValue
						? moment(formElement.defaultValue).format('DD-MMM-YY')
						: moment().format('DD-MMM-YY'),
				});
			else if (formElement.refType == 'Checkbox')
				this.setState({
					[formElement.refName]: 'N',
				});
			else if (formElement.refType == 'MultiSelect')
				this.setState({
					[formElement.refName]: [],
				});
			else
				this.setState({
					[formElement.refName]: '',
				});
		});
	};



	// handleMoneyChange=(e)=>{
	// 	const { value } = e.target;
	// 	if(e.key !== "Backspace"){
	// 		if(value.includes('.')){
	// 			if(value.split('.')[1].length >= 2){
	// 				return 
	// 			}
	// 		}
	// 	}
	// }

	render() {
		const { classes } = this.props;

		let usageType = this.inputHelper({
			refName: 'usageType',
			uiName: 'Usage Type',
			refLovs: ['Custom Min', 'Custom Pulse', 'Standard Min', 'Standard Pulse'],
			refType: 'SelectInput',
			uiGroup: 'Rates Details',
		});

		let createRatePlan = (
			<Grid container alignContent="flex-start" spacing={2}>
				<Prompt
					when={
						Object.keys(this.state.usageGrps).length > 0 &&
						!this.state.disableRp
					}
					message={'You have not saved your changes.Do you want to navigate?'}
				/>
				<Grid item xs={12}>
					<form onSubmit={this.saveRatePlans}>
						{' '}
						{Object.keys(this.state.ratePlanGroups)
							.sort()
							.map((key, i) => {
								return (
									<Card
										key={key}
										style={{ marginTop: '1%', overflow: 'visible' }}>
										<CardHeader
											className={classes.cardHeader}
											classes={{
												subheader: classes.subheader,
											}}
											subheader={key}
											action={
												i == 0 && (
													<LightTooltip title="New Rate Plan" arrow>
														<AddIcon
															onClick={this.clearRP}
															style={{
																color: 'white',
																marginRight: '10px',
																cursor: 'pointer',
															}}
														/>
													</LightTooltip>
												)
											}
										/>
										<CardContent>
											<Grid container alignItems="flex-start" spacing={2}>
												{this.state.ratePlanGroups[key].map((formElement) =>
													this.inputHelper(formElement)
												)}
												{key == 'Rates Details' &&
													this.state.icmRateplanCategory &&
													this.state.icmRateplanCategory == 'ISD' &&
													usageType}
											</Grid>

											{key === 'Rates Details' && (
												
												<React.Fragment>
												
													<div
													
														style={{
															width: '100%',
														}}
														className={classes.center}>
														<Button
															onClick={() => {
																
																if (
																	this.state['icmRateplanCategory'] == 'ISD'
																) {
																	this.saveRatesIsd();
																} else this.saveRpNormalFlow();
															}}
															variant="contained"
															color="secondary"
															style={{
																background: '#0273bf',
																textTransform: 'none',
																marginTop: '1.5%',
															}}>
															Create
														</Button>
													</div>
												</React.Fragment>
											)}
										</CardContent>
									</Card>
								);
							})}
							
						{Object.keys(this.state.usageGrps).length > 0 && (
							<Card style={{ marginTop: '1%', overflow: 'visible' }}>
								<CardHeader
									className={classes.cardHeader}
									classes={{
										subheader: classes.subheader,
									}}
									subheader={'Rate Plans'}
								/>
								<CardContent>
									{Object.keys(this.state.usageGrps)
										.sort()
										.filter((item) => {
											if (this.state.ratesObj[item].icmId) {
												return !this.state.ratesObj[item].icmId.includes(
													'DELETED'
												);
											} else {
												return true;
											}
										})
										.map((usageGrp) => {
											return (
												<Accordion
													expanded={
														this.state.expanded === usageGrp ||
														this.state.expanded === true
													}
													onChange={this.changeHandler(usageGrp)}
													key={usageGrp}
													>
													<AccordionSummary
													
														aria-controls="panel1bh-content"
														id="panel1bh-header"
														pointer-events>
														<ExpandMoreIcon onClick={(e) => {
															
															this.setState({
																expanded: false,
															});
														}}/>
														<Typography className={classes.heading}>
															{usageGrp}
														</Typography>

														{this.state.editing &&
															'newRP' in this.state.ratesObj[usageGrp] &&
															!this.state.ratesObj[usageGrp].newRP && (
																<>
																	<EditIcon
																		style={{
																			color: 'green',
																			marginLeft: '-10px',
																			marginRight: '20px',
																		}}
																		onClick={(event) => {
																			event.stopPropagation();
																			let ratesObj = { ...this.state.ratesObj };
																			let usageData = {
																				...this.state.ratesObj[usageGrp],
																			};
																			usageData.newRP = true;
																			ratesObj[usageGrp] = usageData;
																			this.setState({
																				ratesObj,
																			});
																		}}
																	/>
																</>
															)}
														{(!(this.state.editing &&
															'newRP' in this.state.ratesObj[usageGrp] &&
															!this.state.ratesObj[usageGrp].newRP) ||
															(this.props.typeRatePlan === 'create')) && (

																!this.state.ratesObj[usageGrp].usageType
																? true
																: this.state.ratesObj[usageGrp].usageType !==
																		"Standard Min" &&
																  this.state.ratesObj[usageGrp].usageType !==
																		"Standard Pulse") && (
																<>
																	<InputNumber 
																	decimal={true}
																		style={{
																			margin: '-20px 0 0 5rem',
																			minWidth: '15%',
																		}}
																		placeholder="Fill All Rates"
																		// value={this.state.fillRates.indexOf(".")>=0? this.state.fillRates.substr(0,this.state.fillRates.indexOf("."))+this.state.fillRates.substr(this.state.fillRates.indexOf("."),3): this.state.fillRates}
                                                                             value={this.state.fillRates}
																			 onClick={(e) => {
																				e.stopPropagation();
																				
																			}}
																		onChange={(e) => {
																			
																			this.setState({fillRates: e.target.value});
																			
																		}}
																		disabled={this.props.releaseData.releaseStatus !== 'InProgress'}
																		required={false}
																	/>
																	<Button
																	
																		variant="outlined"
																		size="small"
																		style={{ margin: '0 2rem 0 1rem' }}
																		// disabled={this.state.minutesOrPulse=="Standard Min"}
																		onClick={(e) => {
																			e.stopPropagation();
																			console.log(this);
																			let ratesObj = this.state.ratesObj;
																			this.state.usageGrps[usageGrp].forEach(
																				(item) =>
																					(ratesObj[usageGrp] = {
																						...ratesObj[usageGrp],
																						[item]: this.state.fillRates,
																					})
																			);
																			this.setState({
																				ratesObj,
																			});
																		}}
																		disabled={this.props.releaseData.releaseStatus !== 'InProgress'}
																		>
																		Apply
																	</Button>
																</>
															)}
														<VisibilityIcon
															style={{
																color: '3f74c5',
																marginLeft: '-10px',
																marginRight: '10px',
															}}
															onClick={(event) => {
																event.stopPropagation();
																this.viewRatePlan(usageGrp);
															}}
														/>

														<DeleteIcon
															style={{ color: 'red', marginRight: '10px' }}
															onClick={(event) => {
																event.stopPropagation();
																
																let ratesObj = { ...this.state.ratesObj };
																ratesObj[
																	usageGrp
																].icmId = `${ratesObj[usageGrp].icmId}_DELETED`;
																this.setState({
																	ratesObj,
																});
																console.log('KK',ratesObj)
																console.log('KKI',{...this.state.ratesObj})
															}}
														/>
													</AccordionSummary>
													<AccordionDetails>
														<List
															component="nav"
															aria-labelledby="nested-list-subheader"
															style={{
																width: '100%',
																maxHeight: '30vh',
																overflow: 'auto',
															}}>
															{this.state.usageGrps[usageGrp].map(
																(usageGrpRates, index) => {
																	if(this.state.ratesObj[usageGrp][usageGrpRates]!==undefined)
																		if(this.state.ratesObj[usageGrp][usageGrpRates].includes('.')){
																			if(this.state.ratesObj[usageGrp][usageGrpRates].split('.')[1].length >= 2){
																						let lenval=this.state.ratesObj[usageGrp][usageGrpRates].split('.')[1].length;
																				var num = parseFloat(this.state.ratesObj[usageGrp][usageGrpRates].substr(0,this.state.ratesObj[usageGrp][usageGrpRates].length-lenval+2));
																				var cleanNum = num.toFixed(2);
																				this.state.ratesObj[usageGrp][usageGrpRates] = cleanNum;
																				
																			}
																		}

																	let input = (
																		<TextField
																		
																			style={{ minWidth: '15%' }}
																			InputLabelProps={{
																				shrink: true,
																			}}
																			label={
																				this.state.ratesObj[usageGrp]
																					.usageType &&
																				this.state.ratesObj[
																					usageGrp
																				].usageType.includes('Standard')
																					? 'Standard Rate'
																					: 'Rate (Rs)'
																			}
																			disabled={
																				(this.state.editing &&
																					'newRP' in
																						this.state.ratesObj[usageGrp] &&
																					!this.state.ratesObj[usageGrp]
																						.newRP) ||
																				(this.state.ratesObj[usageGrp]
																					.usageType &&
																					this.state.ratesObj[
																						usageGrp
																					].usageType.includes('Standard'))
																			}
																			value={
																				this.state.ratesObj[usageGrp][
																					usageGrpRates]
																			}
																			// onKeyDown={(e)=> {
																			// 	this.handleMoneyChange(e)
																			// }}
																			
																			style={{ marginRight: 10 }}
																			onChange={(event) => {
																				if (
																					!isNaN(event.target.value) &&
																					event.target.value >= 0
																				) {
																					let rates = {
																						...this.state.ratesObj,
																					};
																					let usageGrpData = {
																						...this.state.ratesObj[usageGrp],
																					};
																					usageGrpData[usageGrpRates] =
																						event.target.value;
																					rates[usageGrp] = usageGrpData;
																					this.setState({
																						ratesObj: rates,
																					});
																				} else {
																					let rates = {
																						...this.state.ratesObj,
																					};
																					let usageGrpData = {
																						...this.state.ratesObj[usageGrp],
																					};
																					if (usageGrpData[usageGrpRates])
																						usageGrpData[usageGrpRates] =
																							usageGrpData[usageGrpRates];
																					else usageGrpData[usageGrpRates] = '';
																					rates[usageGrp] = usageGrpData;
																					this.setState({
																						ratesObj: rates,
																					});
																				}
																			}}
																			required={true}
																		/>
																	);
																	let inputCustom = usageGrp.startsWith(
																		'ISD'
																	) &&
																		this.state.ratesObj[
																			usageGrp
																		].usageType.includes('Custom') && (
																			<TextField
																			// decimal={true}
																				style={{ minWidth: '15%' }}
																				label={'Standard Rate'}
																				disabled={true}
																				value={
																					usageGrp.startsWith('ISD') &&
																					this.state.ratesObj[usageGrp]
																						.usageType == 'Custom Pulse'
																						? this.state.ratePlanItemsData[
																								usageGrpRates
																						  ].PRICE_IN_RS_PER_PULSE
																						: this.state.ratePlanItemsData[
																								usageGrpRates
																						  ].RATE_PER_MIN
																				}
																			/>
																		);
																	let inputPulse = (
																		<TextField
																		// decimal={true}
																			style={{ minWidth: '15%' }}
																			label={'Standard Pulse'}
																			disabled={true}
																			value={
																				this.state.ratesObj[usageGrp][
																					usageGrpRates + '_pulse'
																				]
																			}
																		/>
																	);

																	let inputPulseHome = (
																		<FormControl
																			className={classes.formControl}>
																			<InputLabel>{'Pulse *'}</InputLabel>
																			<Select
																				required
																				disabled={
																					(this.state.editing &&
																						'newRP' in
																							this.state.ratesObj[usageGrp] &&
																						!this.state.ratesObj[usageGrp]
																							.newRP) ||
																					(this.state.ratesObj[usageGrp]
																						.usageType &&
																						this.state.ratesObj[
																							usageGrp
																						].usageType.includes('Standard'))
																				}
																				value={
																					this.state.ratesObj[usageGrp][
																						usageGrpRates + '_pulse'
																					]
																				}
																				onChange={(event) => {
																					let rates = {
																						...this.state.ratesObj,
																					};
																					let usageGrpData = {
																						...this.state.ratesObj[usageGrp],
																					};
																					usageGrpData[
																						usageGrpRates + '_pulse'
																					] = event.target.value;
																					rates[usageGrp] = usageGrpData;
																					this.setState({
																						ratesObj: rates,
																					});
																				}}>
																				{this.state.ratePlanUoms.map((uom) => {
																					return (
																						<MenuItem value={uom}>
																							{uom}
																						</MenuItem>
																					);
																				})}
																			</Select>
																		</FormControl>
																	);

																	return (
																		<React.Fragment key={usageGrpRates + index}>
																			<ListItem>
																				<ListItemText primary={usageGrpRates} />

																				{usageGrp.startsWith('ISD') &&
																				this.state.ratesObj[usageGrp]
																					.usageType == 'Custom Pulse' ? (
																					<React.Fragment>
																						{usageGrp.startsWith('ISD') &&
																							this.state.ratesObj[
																								usageGrp
																							].usageType.includes('Custom') &&
																							inputCustom}
																						{this.state.ratesObj[usageGrp]
																							.usageType &&
																							this.state.ratesObj[
																								usageGrp
																							].usageType.includes('Pulse') &&
																							inputPulse}
																						{input}
																					</React.Fragment>
																				) : (
																					<React.Fragment>
																						{usageGrp.startsWith('ISD') &&
																							this.state.ratesObj[
																								usageGrp
																							].usageType.includes('Custom') &&
																							inputCustom}
																						{input}
																						{usageGrp.startsWith('HOME') &&
																							inputPulseHome}
																						{this.state.ratesObj[usageGrp]
																							.usageType &&
																							this.state.ratesObj[
																								usageGrp
																							].usageType.includes('Pulse') &&
																							inputPulse}
																					</React.Fragment>
																				)}
																			</ListItem>
																			<Divider />
																		</React.Fragment>
																	);
																}
															)}
														</List>
													</AccordionDetails>
												</Accordion>
											);
										})}
										{this.props.releaseData.releaseId && (
											<div
												style={{
													display: 'flex',
													justifyContent: 'center',
													alignItems: 'center',
												}}>
												<Button
													disabled={this.state.disableRp}
													onClick={() => {
														this.setState({
															expanded: true,
														});
													}}
													variant="contained"
													type="submit"
													style={{
														background: '#02bfa0',
														textTransform: 'none',
														marginTop: '1%',
													}}>
													{this.props.editRpData?.basic?.releaseMasterCheck &&
													this.props.editRpData?.basic?.releaseMasterCheck ===
														'Deployed'
														? 'Clone'
														: 'Save'}
												</Button>
											</div>
										)}
								</CardContent>
							</Card>
						)}
						{/* 
						{this.props.releaseData.releaseId && (
							<div
								style={{
									display: 'flex',
									justifyContent: 'center',
									alignItems: 'center',
								}}>
								<Button
									disabled={this.state.disableRp}
									onClick={() => {
										this.setState({
											expanded: true,
										});
									}}
									variant="contained"
									type="submit"
									style={{
										background: '#02bfa0',
										textTransform: 'none',
										marginTop: '1%',
									}}>
									{this.props.editRpData?.basic?.releaseMasterCheck &&
									this.props.editRpData?.basic?.releaseMasterCheck ===
										'Deployed'
										? 'Clone'
										: 'Save'}
								</Button>
							</div>
						)} */}
					</form>
				</Grid>
			</Grid>
		);

		if (this.state.loading) createRatePlan = <Loader relative />;
		return createRatePlan;
	}
}

const mapStateToProps = (state) => {
	return {
		releaseData: state.releaseData.releaseData,
		userInfo: state.login.loggedInUserInfo,
	};
};

export default connect(mapStateToProps)(
	withStyles(useStyles)(WithErrorHandler(CreateRatePlan, axios))
);

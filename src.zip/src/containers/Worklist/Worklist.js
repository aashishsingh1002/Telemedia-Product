import LibraryBooksOutlinedIcon from '@material-ui/icons/LibraryBooksOutlined';
import LibraryBooksIcon from '@material-ui/icons/LibraryBooks';
import React, { Component } from 'react';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Title from '../../UI/Typography/Title';
import Tooltip from '@material-ui/core/Tooltip';
import IconButton from '@material-ui/core/IconButton';
import AttachmentIcon from '@material-ui/icons/Attachment';
import { withStyles } from '@material-ui/core/styles';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import { connect } from 'react-redux';
import SaveIcon from '@material-ui/icons/Save';
import PublicIcon from '@material-ui/icons/Public';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
import TextField from '@material-ui/core/TextField';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import Attachment from '../Dashboard/Attachment';
import Modal from '../../UI/Modal/Modal';
import Typography from '@material-ui/core/Typography';
import SettingsSystemDaydreamIcon from '@material-ui/icons/SettingsSystemDaydream';
import Federation from './Federation';
import AuditLogs from '../Dashboard/AuditLogs';
import BookIcon from '@material-ui/icons/Book';
import Backdrop from '@material-ui/core/Backdrop';
import MaterialTable from 'material-table';
import { forwardRef } from 'react';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import Toolbar from '@material-ui/core/Toolbar';
import CloseIcon from '@material-ui/icons/Close';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import * as actionTypes from '../../store/actions/actionTypes';
import InputLabel from '@material-ui/core/InputLabel';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Literature from "../Dashboard/Literature";
const tableIcons = {
	Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
	Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
	Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
	Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
	DetailPanel: forwardRef((props, ref) => (
		<ChevronRight {...props} ref={ref} />
	)),
	Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
	Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
	Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
	FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
	LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
	NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
	PreviousPage: forwardRef((props, ref) => (
		<ChevronLeft {...props} ref={ref} />
	)),
	ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
	Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
	SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
	ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
	ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};

const drawerWidth = '35vw';

const useStyles = (theme) => ({
	drawer: {
		width: drawerWidth,
		flexShrink: 0,
},
	drawerPaper: {
		width: drawerWidth,
		height: window.screen.height + 0.2 * window.screen.height,
		zIndex: 1000000,
	},
	backdrop: {
		zIndex: theme.zIndex.drawer + 1,
		height: window.screen.height + 0.2 * window.screen.height,
		color: '#fff',
	},
});
const theme = createMuiTheme({
	overrides: {
		MuiTable: {
			root: {
				tableLayout: 'fixed',
			},
		},
		MuiTableCell: {
			root: {
				padding: '0px',
				paddingLeft: '10px',
			},
		},
		MuiPaper: {
			width: '100%',
		},
	},
});
const ITEM_HEIGHT = 34;
const ITEM_PADDING_TOP = 6;
const MenuProps = {
	PaperProps: {
		style: {
			maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
			width: 120,
			top:'247px'
		},
	},
};
const CustomSelect = withStyles((theme) => ({
	fontFamily: 'BrighterSans',
}))(Select);

const LightTooltip = withStyles((theme) => ({
	tooltip: {
		backgroundColor: '#525354',
		color: 'white',
		boxShadow: theme.shadows[1],
		fontSize: 14,
	},
}))(Tooltip);

const getColor = {
	Deployed: '#1565c0',
	InProgress: '#528548',
	Cancelled: '#fc0a5b',
	'Approval In Progress': '#f26933',
	'Design InProgress': '#528548',
	Approved: '#1565c0',
};

class Worklist extends Component {
	_isMounted = false;

	state = {
		relWorkFlowAction: '',
		relWorkRemarks: '',
		releaseEditData: {},
		loadingEdit: false,
		openDrawer: false,
		federate: false,
		actionsMyItems: ['Approve', 'RFI', 'RFC'],

		approversData: {},
		approverDataRev: {},
		userGroups: [],
		selGrp: null,
		userRole: this.props.roleGroup ?? this.props.userInfo.group[0],
		roleSelected: null,

		show: false,
		modalContent: null,
		relData: {},
		failDeploy: false,
		attachment: false,
		auditLogs: false,
		loading: true,
		dataTeamItems: [],
		dataMyItems: [],
		open: false,
		literature: false,
		columnsMyItemsPm: [
			{
				title: 'Release No.',
				field: 'externalReleaseId',
			},
			{
				title: 'Release Objective',
				field: 'releaseObjective',
				sorting: false,
				render: (rowData) => (
					<Tooltip
						interactive
						title={
							<pre
								style={{
									fontSize: '12px',
									overflow: 'auto',
									maxHeight: '40vh',
									maxWidth: '60vw',
								}}>
								{rowData.releaseObjective}
							</pre>
						}>
						<span>
							{' '}
							{rowData.releaseObjective
								? rowData.releaseObjective.length > 25
									? rowData.releaseObjective.substring(0, 25) + '...'
									: rowData.releaseObjective
								: ''}
						</span>
					</Tooltip>
				),
			},
			{ title: 'Creation Date', field: 'releaseCreationDate' },

			{ title: 'Release Status', field: 'releaseStatus' },
			{ title: 'Resubmit To', field: 'resubmitName' },
			{ title: 'Action', field: 'actionType' },

			{
				title: 'Attachment',
				field: 'attachment',
				filtering: false,
				render: (rowData) => (
					<IconButton
						onClick={(event) => {
							event.stopPropagation();
							this.attachmentHandler(rowData);
						}}>
						<AttachmentIcon />
					</IconButton>
				),
				sorting: false,
				cellStyle: { width: '10%' },
			},
			{
				title: 'Audit Logs',
				field: 'logs',
				filtering: false,
				render: (rowData) => (
					<IconButton
						onClick={(event) => {
							event.stopPropagation();
							this.setState({ relData: { ...rowData } });
							this.setState({ auditLogs: true });
						}}>
						<BookIcon />
					</IconButton>
				),
				sorting: false,
				cellStyle: { width: '10%' },
			},
		],
		columnsTeamItems: [
			{
				title: 'Self Assign',
				field: 'selfAssign',
				render: (rowData) => (
					<IconButton onClick={() => this.selfAssignHandler(rowData)}>
						<KeyboardArrowUpIcon />
					</IconButton>
				),
				filtering: false,
			},
			{ title: 'Release No.', field: 'externalReleaseId' },
			{
				title: 'Release Objective',
				field: 'releaseObjective',
				sorting: false,
				render: (rowData) => (
					<LightTooltip title={rowData.releaseObjective} arrow>
						<span>
							{' '}
							{rowData.releaseObjective
								? rowData.releaseObjective.length > 10
									? rowData.releaseObjective.substring(0, 10) + '...'
									: rowData.releaseObjective
								: ''}
						</span>
					</LightTooltip>
				),
			},
			{ title: 'Creation Date', field: 'releaseCreationDate' },
			{ title: 'Release Status', field: 'releaseStatus' },
			// {
			//     title: 'Status',
			//     field: 'releaseStatus',
			//     render: rowData => < Chip label={rowData.releaseStatus} style={{ background: getColor[rowData.releaseStatus], color: 'white' }} />
			//     , sorting: false
			// },

			{
				title: 'Attachment',
				field: 'attachment',
				render: (rowData) => (
					<IconButton onClick={(event) => {
						event.stopPropagation();
						this.attachmentHandler(rowData)}}>
						<AttachmentIcon />
					</IconButton>
				),
				sorting: false,
				filtering: false,
			},
			{
				title: 'Literature',
				field: 'literature',
				render: (rowData) => (
					<LibraryBooksIcon
						style={{ color: 'black', marginRight: '10px' }}
						onClick={(event) => {
							event.stopPropagation();
							this.literatureHandler(rowData);
						}}
					/>
				),
				sorting: false,
				filtering: false,
			},


		],
		columnsMyItems: [

			{
				title: 'Un Assign',
				filtering: false,
				field: 'unAssign',
				render: (rowData) => (
					<IconButton
						onClick={(event) => {
							event.stopPropagation();
							this.unAssignHandler(rowData);
						}}>
						<ExpandMoreIcon />
					</IconButton>
				),
				sorting: false,
				cellStyle: { width: '10%' },
			},
			{
				title: 'Release No.',
				field: 'externalReleaseId',
			},
			{
				title: 'Release Objective',
				field: 'releaseObjective',
				sorting: false,
				render: (rowData) => (
					<LightTooltip title={rowData.releaseObjective} arrow>
						<span>
							{' '}
							{rowData.releaseObjective
								? rowData.releaseObjective.length > 10
									? rowData.releaseObjective.substring(0, 10) + '...'
									: rowData.releaseObjective
								: ''}
						</span>
					</LightTooltip>
				),
			},
			{ title: 'Creation Date', field: 'releaseCreationDate' },
			{ title: 'Release Status', field: 'releaseStatus' },
			// {
			//     title: 'Status',
			//     field: 'releaseStatus',
			//     render: rowData => < Chip label={rowData.releaseStatus} style={{ background: getColor[rowData.releaseStatus], color: 'white' }} />
			//     , sorting: false
			// },

			{
				title: 'Attachment',
				field: 'attachment',
				render: (rowData) => (
					
					<IconButton 
					disabled={rowData.releaseStatus === 'Federation failed'}
					onClick={(event) =>{event.stopPropagation(); this.attachmentHandler(rowData)}}>
						<AttachmentIcon />
					</IconButton>
				),
				sorting: false,
				filtering: false,
			},
			{
				title: 'Literature',
				field: 'literature',
				render: (rowData) => (
					<LibraryBooksIcon
						style={{ color: 'black', marginRight: '10px' }}
						onClick={(event) => {
							event.stopPropagation();
							this.literatureHandler(rowData);
						}}
					/>
				),
				sorting: false,
				filtering: false,
			},

			{
				title: 'Audit Logs',
				field: 'attachment',
				filtering: false,
				render: (rowData) => (
					<IconButton onClick={(event) =>{event.stopPropagation(); this.auditLogsHandler(rowData)}}>
						<LibraryBooksOutlinedIcon />
					</IconButton>
				),
				sorting: false,
				cellStyle: { width: '2%' },
			},
			{/*
			{
				title: 'Action',
				field: 'action',
				filtering: false,
				render: (rowData) => (
					<FormControl style={{ minWidth: 100 }}>
						<Select
							name='action'
							MenuProps={MenuProps}
							displayEmpty
							value={this.state['releaseAction' + rowData.releaseId]}
							onChange={(event) =>
								this.setState({
									['releaseAction' + rowData.releaseId]: event.target.value,
								})
							}
							
							input={<Input required={true} id={rowData.releaseId + 'ip'}  />}
							renderValue={(selected) => {
								if (selected) {
									if (selected.length === 0) {
										return <em>Action</em>;
									}

									return selected;
								}
							}}
							inputProps={{ 'aria-label': 'Without label' }}
						>
							<MenuItem disabled value='' style={{width:10}}>
								
							</MenuItem>
							{['Approve ', 'RFI', 'RFC'].map((name) => (
								<MenuItem key={name} value={name}>
									{name}
								</MenuItem>
							))}
						</Select>
					</FormControl>
				),
				sorting: false,
				cellStyle: { width: '15%' },
			},
			{
				title: 'Remarks',
				field: 'remarks',
				filtering: false,

				render: (rowData) => (
					<TextField
						placeholder='remarks'
						name='remarks'
						fullWidth
						value={this.state['release' + rowData.releaseId]}
						onChange={(event) =>
							this.setState({
								['release' + rowData.releaseId]: event.target.value,
							})
						}
					/>
				),
				sorting: false,
				cellStyle: { width: '25%' },
			},  ,
			{
				title: 'Save',
				field: 'save',
				filtering: false,

				render: (rowData) => (
					<IconButton
						style={{ marginLeft: '10' }}
						onClick={() => this.actionHandler(rowData)}
					>
						<SaveIcon />
					</IconButton>
				),
				sorting: false,
				cellStyle: { width: '7%' },
			},
			*/}
		],
		columnsTeamItemsCit: [
			{
				title: 'Self Assign',
				field: 'selfAssign',
				render: (rowData) => (
					<IconButton
						onClick={(event) => {
							event.stopPropagation();
							this.selfAssignHandler(rowData);
						}}>
						<KeyboardArrowUpIcon />
					</IconButton>
				),
				cellStyle: { width: '10%' },
				filtering: false,
			},
			{ title: 'Release No.', field: 'externalReleaseId' },
			{
				title: 'Release Objective',
				field: 'releaseObjective',
				sorting: false,
				render: (rowData) => (
					<Tooltip
						interactive
						title={
							<pre
								style={{
									fontSize: '12px',
									overflow: 'auto',
									maxHeight: '20vh',
									maxWidth: '60vw',
								}}>
								{rowData.releaseObjective}
							</pre>
						}>
						<span>
							{' '}
							{rowData.releaseObjective
								? rowData.releaseObjective.length > 10
									? rowData.releaseObjective.substring(0, 10) + '...'
									: rowData.releaseObjective
								: ''}
						</span>
					</Tooltip>
				),
			},
			{ title: 'Creation Date', field: 'releaseCreationDate' },

			{ title: 'Release Status', field: 'releaseStatus' },

			{
				title: 'Audit Logs',
				field: 'logs',
				filtering: false,
				render: (rowData) => (
					<IconButton
						onClick={(event) => {
							console.log(rowData);
							event.stopPropagation();
							this.setState({ relData: { ...rowData } });
							this.setState({ auditLogs: true });
						}}>
						<BookIcon />
					</IconButton>
				),
				sorting: false,
				cellStyle: { width: '10%' },
			},
		],

	};
	showLiteratureHandler = () => {
		this.setState({ literature: false });
	  };
	  literatureHandler = (relData) => {
		this.setState({ relData: { ...relData } });
		this.setState({ literature: true });
	  };
	componentWillUnmount() {
		this._isMounted = false;
	}
	unAssignHandler = (rowData) => {
		console.log(rowData);
		if (this._isMounted) {
			this.setState({ loading: true });
		}

		if (rowData.releaseStatus === 'Assigned For Federation') {
			const groupIndex = this.state.userGroups.indexOf('radB2c');
			axios
				.get(
					`/Telecustom/UnasignUserTaskList?groupId=${this.state.userGroups[groupIndex]}&userId=${this.props.userInfo.id}`,
					{
						headers: {
							opId: this.props.userInfo.opId,
							buId: this.props.userInfo.buId,
							extrnRelId: rowData.externalReleaseId,
						},
					}
				)
				.then((response) => {
					console.log(response);
					if (response) {
						let myItems = [...this.state.dataMyItems];
						var removeIndex = this.state.dataMyItems
							.map(function (item) {
								return item.releaseId;
							})
							.indexOf(rowData.releaseId);

						myItems.splice(removeIndex, 1);
						let newMyitem = {};
						newMyitem = { ...rowData };
						newMyitem.save = '';
						newMyitem.action = '';
						newMyitem.remarks = '';
						newMyitem.releaseStatus = 'Ready To Federate';
						this.setState((prevState) => {
							return {
								loading: false,
								dataMyItems: myItems,
								dataTeamItems: [newMyitem].concat(prevState.dataTeamItems),
							};
						});
					} else {
						this.setState({ loading: false });
					}
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		} else
			axios
				.post(
					'Telerest/task/' + rowData.taskId + '/unclaim',
					{ userId: this.props.userInfo.id },
					{
						headers: {
							'Content-Type': 'application/json',
						},
					}
				)
				.then((response) => {
					console.log(response);
					if (response) {
						let myItems = [...this.state.dataMyItems];
						var removeIndex = this.state.dataMyItems
							.map(function (item) {
								return item.releaseId;
							})
							.indexOf(rowData.releaseId);

						myItems.splice(removeIndex, 1);
						let newMyitem = {};
						newMyitem = { ...rowData };
						newMyitem.save = '';
						newMyitem.action = '';
						newMyitem.remarks = '';
						this.setState((prevState) => {
							return {
								loading: false,
								dataMyItems: myItems,
								dataTeamItems: [newMyitem].concat(prevState.dataTeamItems),
							};
						});
					} else {
						this.setState({ loading: false });
					}
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
	};
	actionHandlerPM = (event) => {
		// event.preventDefault();

		this.setState({ loadingEdit: true });

		if (this.state.relWorkFlowAction === 'Resubmit') {
			axios
				.post(
					'TeleSelectApprovers/resubmit/' +
					this.state.releaseEditData.releaseId +
					'/' +
					this.props.userInfo.id,
					{
						remarks: this.state.relWorkRemarks,
					},

					{
						headers: {
							group: this.state.selGrp
								? this.state.approverDataRev[this.state.selGrp]
								: null,
							rfiPerson: this.state.releaseEditData.resubmitName,
							action: this.state.releaseEditData.actionType,
						},
					}
				)
				.then((response) => {
					console.log(response);
				})
				.catch((error) => {
					console.log(error);
				});
			let myItems = [...this.state.dataMyItems];

			let removeIndex = this.state.dataMyItems.findIndex(
				(item) =>
					item.releaseId === this.state.releaseEditData.releaseId &&
					item.resubmitName === this.state.releaseEditData.resubmitName
			);

			myItems.splice(removeIndex, 1);
			this.setState({
				dataMyItems: myItems,
				loadingEdit: false,
				openDrawer: false,
				relWorkFlowAction: '',
				relWorkRemarks: '',
			});
		}
	};



	cancelTask = () => {
		return axios.get('Telecustom/cancelTask', {
			headers: {
				taskId: this.state.releaseEditData.taskId,
				group: this.props.userInfo.group[0],
			},
		});
	};
	actionHandler = async (event) => {
		if (event) {
			event.preventDefault();
		}
		console.log(this.state.relWorkFlowAction);
		console.log(this.state.relWorkRemarks);
		console.log(this.state.releaseEditData.releaseId);
		let variables = {};
		let payload = {};
		this.setState({ loadingEdit: true });
		if (
			this.state.relWorkFlowAction === 'Approve' ||
			this.state.relWorkFlowAction === 'Validate' ||
			this.state.relWorkFlowAction === 'Not Validate' ||
			!event
		) {
			variables.approve = {
				value:
					this.state.relWorkFlowAction === 'Approve' ||
					this.state.relWorkFlowAction === 'Validate' ||
					this.state.relWorkFlowAction === 'Pass' ||
					this.state.relData.releaseStatus === 'Pre-prod Dump Upload' ||
					this.state.relData.releaseStatus === 'Prod Dump Upload' ||
					this.state.userGroups.indexOf('CIT_OPS') !== -1,
			};
			variables.remarks = {
				value:
					this.state.relWorkRemarks !== ''
						? this.state.relWorkRemarks
						: 'Dump Uploaded Successfully',
			};
			payload.variables = variables;
			console.log('payload');
			const url =
				this.state.userGroups.includes('CIT_OPS') ||
					this.state.userGroups.includes('preProdTest')
					? 'Telerest/task/' + this.state.relData.taskId + '/complete'
					: 'Telerest/task/' + this.state.releaseEditData.taskId + '/complete';
			console.log(payload);
			if (
				this.state.releaseEditData?.releaseStatus === 'Prod Test Dump Upload'
			) {
				await this.cancelTask().then(console.log);
			}
			axios
				.post(url, payload, {
					headers: {
						'Content-Type': 'application/json',
					},
				})
				.then((response) => {
					console.log(response);
					if (
						this.state.releaseEditData?.releaseStatus === 'Prod Dump Upload' ||
						this.state.relData?.releaseStatus === 'Prod Dump Upload' ||
						this.state.releaseEditData?.releaseStatus === 'Prod Test Failed' ||
						this.state.relData?.releaseStatus === 'Prod Test Failed'
					) {
						let myItems = [...this.state.dataMyItems];
						let removeIndex = this.state.dataMyItems
							.map(function (item) {
								return item.releaseId;
							})
							.indexOf(this.state.releaseEditData.releaseId);

						myItems.splice(removeIndex, 1);
						axios
							.get('Telecustom/updateForProdTestUpload', {
								headers: {
									releaseId:
										this.state.relData?.releaseId ??
										this.state.releaseEditData?.releaseId,

									opId: this.props.userInfo.opId,
									buId: this.props.userInfo.buId,
								},
							})
							.then((res) => {
								console.log(res);
								this.setState({
									dataMyItems: myItems,
									loadingEdit: false,
									openDrawer: false,
									relWorkFlowAction: '',
									relWorkRemarks: '',
								});
								window.location.reload();
							});
					} else {
						let myItems = [...this.state.dataMyItems];
						let removeIndex = this.state.dataMyItems
							.map(function (item) {
								return item.releaseId;
							})
							.indexOf(this.state.releaseEditData.releaseId);

						myItems.splice(removeIndex, 1);

						// if (!this.state.userGroups.includes('CIT_OPS')) {
						let smsNotiPayload = {};
						let roles = [];

						const approver = JSON.parse(
							localStorage.getItem('approversDataUser')
						);

						// let obj = {};
						// obj.taskName = approver.grpName;

						// obj.primaryMail = approver.primarysignatory[0] ?? null;
						// obj.secondaryMail = approver.primarysignatory[1] ?? null;
						// obj.varName = approver.varName;
						// obj.value = approver.disabled === 'true' ? 'mandatory' : 'fyi';
						// obj.medium = 'sms';
						// obj.group = this.state.userRole;
						// roles.push(obj);
						// smsNotiPayload.roleDetailList = roles;
						// console.log(smsNotiPayload);

						axios
							.post(
								'TeleSelectApprovers/send/notification/initiate-approval?releaseId=' +
								(this.state.releaseEditData.releaseId ??
									this.state.relData.releaseId),
								{
									roleDetailList: smsNotiPayload.roleDetailList,
								},

								{
									headers: {
										opId: this.props.userInfo.opId,
										buId: this.props.userInfo.buId,
										lob: 'Postpaid',
										initiateapproval: false,
										group: this.state.userRole ?? this.props.userInfo.group[0],
										authUserId: this.props?.userInfo?.id ?? this.userInfo.id,
									},
								}
							)
							.then((response) => {
								console.log(response);
								if (
									(this.state.userGroups.includes('ceoB2c') ||
										this.state.userGroups.includes('ceoB2b')) &&
									!(
										this.state.releaseEditData.releaseReplicationStatus ===
										'b2bmanual' ||
										this.state.releaseEditData.releaseReplicationStatus ===
										'b2cmanual' ||
										this.state.releaseEditData.releaseReplicationStatus ===
										'primanual'
									)
								) {
									axios
										.get('Telecustom/updateForRad', {
											headers: {
												releaseId: this.state.releaseEditData.releaseId,
												opId: this.props.userInfo.opId,
												buId: this.props.userInfo.buId,
											},
										})
										.then((res) => {
											console.log(res);
											this.setState({
												dataMyItems: myItems,
												loadingEdit: false,
												openDrawer: false,

												relWorkFlowAction: '',
												relWorkRemarks: '',
											});
											window.location.reload();
										});
								} else if (
									(this.state.userGroups.includes('radB2b') ||
										this.state.userGroups.includes('radB2c')) &&
									this.state.releaseEditData.releaseStatus === 'RAD Validation'
								) {
									axios
										.get('Telecustom/updateAfterRAD', {
											headers: {
												releaseId: this.state.releaseEditData.releaseId,
												opId: this.props.userInfo.opId,
												buId: this.props.userInfo.buId,
												approve: this.state.relWorkFlowAction === 'Validate',
											},
										})
										.then((res) => {
											console.log(res);
											this.setState({
												dataMyItems: myItems,
												loadingEdit: false,
												openDrawer: false,
												relWorkFlowAction: '',
												relWorkRemarks: '',
											});
											window.location.reload();
										});
								} else if (
									this.state.releaseEditData.releaseStatus ===
									'Prod Test Dump Upload'
								) {
									axios
										.get('Telecustom/updateAfterProdTest', {
											headers: {
												releaseId: this.state.releaseEditData.releaseId,
												opId: this.props.userInfo.opId,
												buId: this.props.userInfo.buId,
												approve: this.state.relWorkFlowAction === 'Validate',
											},
										})
										.then((res) => {
											console.log(res);
											this.setState({
												dataMyItems: myItems,
												loadingEdit: false,
												openDrawer: false,
												relWorkFlowAction: '',
												relWorkRemarks: '',
											});
											window.location.reload();
										});
								} else if (
									(this.state.relData.releaseStatus ===
									'Pre-prod Dump Upload' || this.state.relData.releaseStatus ===
										'Validation Failed')
										 &&
									(this.state.selGrp === 'CIT_OPS' ||
									this.state.selGrp === 'preProdTest')) {
									axios
										.get('Telecustom/updateForRADValid', {
											headers: {
												releaseId: this.state.relData.releaseId,
												opId: this.props.userInfo.opId,
												buId: this.props.userInfo.buId,
											},
										})
										.then((res) => {
											console.log(res);
											this.setState({
												dataMyItems: myItems,
												loadingEdit: false,
												openDrawer: false,
												relWorkFlowAction: '',
												relWorkRemarks: '',
											});
											window.location.reload();
										});
								} else if (
									this.state.releaseEditData.releaseStatus ===
									'Ready to Go Live'
								) {
									axios
										.get('Telecustom/updateAfterProdRAD', {
											headers: {
												releaseId: this.state.releaseEditData.releaseId,
												opId: this.props.userInfo.opId,
												buId: this.props.userInfo.buId,
											},
										})
										.then((res) => {
											console.log(res);
											this.setState({
												dataMyItems: myItems,
												loadingEdit: false,
												openDrawer: false,
												relWorkFlowAction: '',
												relWorkRemarks: '',
											});
											window.location.reload();
										});
								} else {
									this.setState({
										dataMyItems: myItems,
										loadingEdit: false,
										openDrawer: false,
										relWorkFlowAction: '',
										relWorkRemarks: '',
									});
								}
							})
							.catch((error) => {
								console.log(error);
							});
						// }
					}
					
				})
				.catch((error) => {
					console.log(error);
					this.setState({
						loadingEdit: false,
						openDrawer: false,
						relWorkFlowAction: '',
						relWorkRemarks: '',
					});
				});
		} else {
			axios
				.post(
					'TeleSelectApprovers/' +
					this.state.relWorkFlowAction.toLowerCase() +
					'/ui/' +
					this.state.releaseEditData.releaseId +
					'/' +
					this.props.userInfo.id,
					{
						remarks: this.state.relWorkRemarks,
					},
					{
						headers: {
							group: this.state.userRole,
						},
					}
				)
				.then((response) => {
					console.log(response);
					debugger;
					if (this.state.relWorkFlowAction.toLowerCase() === 'rfc') {
						axios
							.get(
								`/Telecustom/statusForRFC?releaseId=${this.state.releaseEditData.releaseId}`,
								{
									headers: {
										opId: this.props.userInfo.opId,
										buId: this.props.userInfo.buId,

										lob: this.state.releaseEditData.releaseReplicationStatus,
									},
								}
							)
							.then((response) => {
								console.log(response);
								let myItems = [...this.state.dataMyItems];
								let removeIndex = this.state.dataMyItems
									.map(function (item) {
										return item.releaseId;
									})
									.indexOf(this.state.releaseEditData.releaseId);

								myItems.splice(removeIndex, 1);
								this.setState({
									dataMyItems: myItems,
									loadingEdit: false,
									openDrawer: false,
									relWorkFlowAction: '',
									relWorkRemarks: '',
								});
							})
							.catch((error) => {
								console.log(error);
								if (this._isMounted) this.setState({ loading: false });
							});
					} else {
						let myItems = [...this.state.dataMyItems];
						let removeIndex = this.state.dataMyItems
							.map(function (item) {
								return item.releaseId;
							})
							.indexOf(this.state.releaseEditData.releaseId);

						myItems.splice(removeIndex, 1);
						this.setState({
							dataMyItems: myItems,
							loadingEdit: false,
							openDrawer: false,
							relWorkFlowAction: '',
							relWorkRemarks: '',
						});
					}
				})
				.catch((error) => {
					console.log(error);
				});
		}

	};

	errorConfirmedHandler = () => {
		this.setState({ show: false });
	};

	selfAssignHandler = async (rowData) => {
		console.log(rowData);
		if (this._isMounted) this.setState({ loading: true });

		if (rowData.releaseStatus === 'Ready To Federate') {
			const groupIndex = this.state.userGroups.indexOf('radB2c');
			axios
				.get(
					`/Telecustom/asignUserTaskList?groupId=${this.state.userGroups[groupIndex]}&userId=${this.props.userInfo.id}`,
					{
						headers: {
							opId: this.props.userInfo.opId,
							buId: this.props.userInfo.buId,
							extrnRelId: rowData.externalReleaseId,
						},
					}
				)
				.then((response) => {
					console.log(response);
					let teamItems = [...this.state.dataTeamItems];
					var removeIndex = this.state.dataTeamItems
						.map(function (item) {
							return item.releaseId;
						})
						.indexOf(rowData.releaseId);

					teamItems.splice(removeIndex, 1);
					let newMyitem = {};
					newMyitem = { ...rowData };
					newMyitem.save = '';
					newMyitem.action = '';
					newMyitem.remarks = '';
					newMyitem.releaseStatus = 'Assigned For Federation';
					if (this._isMounted) {
						this.setState((prevState) => {
							return {
								loading: false,
								dataTeamItems: teamItems,
								dataMyItems: [newMyitem].concat(prevState.dataMyItems),
							};
						});
					}
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		} else {
			if (rowData.releaseStatus === 'Validation Failed') {
				const validationFailed = await axios.get(
					'/Telecustom/updateAfterCitClaim',
					{
						headers: {
							releaseId: this.state.releaseEditData.releaseId,
							opId: this.props.userInfo.opId,
							buId: this.props.userInfo.buId,
						},
					}
				);
				console.log(validationFailed);
			}
			axios
				.post(
					// "rest/task/" + rowData.taskId + "/claim",
					'Telerest/task/' + rowData.taskId + '/claim',
					{ userId: this.props.userInfo.id },
					{
						headers: {
							'Content-Type': 'application/json',
						},
					}
				)
				.then((response) => {
					console.log(response);
					let teamItems = [...this.state.dataTeamItems];
					var removeIndex = this.state.dataTeamItems
						.map(function (item) {
							return item.releaseId;
						})
						.indexOf(rowData.releaseId);

					teamItems.splice(removeIndex, 1);
					let newMyitem = {};
					newMyitem = { ...rowData };
					newMyitem.save = '';
					newMyitem.action = '';
					newMyitem.remarks = '';
					if (this._isMounted) {
						this.setState((prevState) => {
							return {
								loading: false,
								dataTeamItems: teamItems,
								dataMyItems: [newMyitem].concat(prevState.dataMyItems),
							};
						});
					}
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		}
	};

	myItemsHandler(roleSelected) {

		const userRole =
			roleSelected ?? (this.props.userInfo.group.length === 1
				? this.props.userInfo.group[0]
				: this.props.roleGroup);

		let url =
			'Telecustom/userTaskList?groupId=' +
			userRole +
			'&userId=' +
			this.props.userInfo.id;
		if (this.props.userInfo.group.includes('TelemediaProductManager')) {
			url =
				'Telecustom/pmtasklist?groupId=TelemediaProductManager&userId=' +
				this.props.userInfo.id;
		}
		return axios
			.get(url, {
				headers: {
					opId: this.props.userInfo.opId,
					buId: this.props.userInfo.buId,

					// userRole: JSON.stringify(localStorage.getItem('isB2c')) === 'true' ? 'b2c' : 'b2b',
					userRole: this.state.userRole
				},
			})
			.then((res) => {
				console.log('my items');
				console.log(res);
				console.log(res.data.data);
				let myItems = [];
				res.data.data.filter((el) => {
					if (el.releaseDetails.length > 0) {
						let obj = {};
						obj.taskId = el.taskId;
						el.releaseDetails.filter((element) => {
							if (element.varName === 'releaseCreationDate') {
								obj.releaseCreationDate = element.varValue;
							} else if (element.varName === 'releaseId') {
								obj.releaseId = element.varValue;
							} else if (element.varName === 'releaseStatus') {
								obj.releaseStatus = element.varValue;
							} else if (element.varName === 'releaseObjective') {
								obj.releaseObjective = element.varValue;
							} else if (element.varName === 'releaseCreatedBy') {
								obj.createdBy = element.varValue;
							} else if (element.varName === 'releaseExternalId') {
								obj.externalReleaseId = element.varValue;
								// } else if (element.varName === 'approve') {
								// 	obj.actionType = element.varValue;
							} else if (element.varName === 'releaseReplicationStatus') {
								obj.releaseReplicationStatus = element.varValue;
							}
						});
						obj.actionType = el.action;

						obj.resubmitName = el.taskName;

						obj.action = '';
						obj.remarks = '';
						obj.save = '';

						myItems.push(obj);
					}
				});
				if (this._isMounted) this.setState({ dataMyItems: myItems });
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	}



	teamItemsHandler(roleSelected) {
		const userRole =
			roleSelected ?? (this.props.userInfo.group.length === 1
				? this.props.userInfo.group[0]
				: this.props.roleGroup);

		if (!this.props.userInfo.group.includes('TelemediaProductManager')) {
			return axios
				.get(
					'Telecustom/taskList?groupId=' + userRole,

					{
						headers: {
							opId: this.props.userInfo.opId,
							buId: this.props.userInfo.buId,
						},
					}
				)
				.then((res) => {
					console.log('team ');
					console.log(res.data.data);
					let teamItems = [];

					if (res.data.data) {
						res.data.data.filter((el) => {
							let obj = {};
							obj.taskId = el.taskId;
							el.releaseDetails.filter((element) => {
								if (element.varName === 'releaseCreationDate') {
									obj.releaseCreationDate = element.varValue;
								} else if (element.varName === 'releaseId') {
									obj.releaseId = element.varValue;
								} else if (element.varName === 'releaseStatus') {
									obj.releaseStatus = element.varValue;
								} else if (element.varName === 'releaseObjective') {
									obj.releaseObjective = element.varValue;
								} else if (element.varName === 'releaseCreatedBy') {
									obj.createdBy = element.varValue;
								} else if (element.varName === 'releaseExternalId') {
									obj.externalReleaseId = element.varValue;
								} else if (element.varName === 'releaseReplicationStatus') {
									obj.releaseReplicationStatus = element.varValue;
								}
							});
							obj.selfAssign = '';
							teamItems.push(obj);
						});
					}

					if (this._isMounted) {
						this.setState({ dataTeamItems: teamItems });
					}

					if (
						this.state.userGroups.includes('radB2c') ||
						this.state.userGroups.includes('radB2b') ||
						this.state.userGroups.includes('preProdTest')
					) {
						const groupIndex = this.state.userGroups.indexOf(this.state.selGrp);
						axios
							.get(
								`/Telecustom/fedUserTaskList?groupId=${this.state.userGroups[groupIndex]}&userId=${this.props.userInfo.id}`,
								{
									headers: {
										opId: this.props.userInfo.opId,
										buId: this.props.userInfo.buId,
										lob:JSON.stringify(localStorage.getItem('isB2c')),
									},
								}
							)
							.then((res) => {
								console.log('RAD specific items');
								console.log(res.data.data);
								let teamItems = [];
								res.data.data.map((element) => {
									const obj = {};
									obj.releaseCreationDate = element.createdOn;
									obj.releaseId = element.releaseid;
									obj.releaseStatus = element.releaseStatus;
									obj.releaseObjective = element.remarks;
									obj.createdBy = '';
									obj.externalReleaseId = element.extrnReleaseId;
									obj.selfAssign = '';
									teamItems.push(obj);
								});
								if (this._isMounted) {
									this.setState({
										dataTeamItems: [...this.state.dataTeamItems, ...teamItems],
									});
								}
							});
					}
					// else if (this.state.userGroups.includes("CIT_OPS")) {
					// 	axios
					// 		.get("/Telecustom/CitTaskList", {
					// 			headers: {
					// 				opId: this.props.userInfo.opId,
					// 				buId: this.props.userInfo.buId,
					// 				groupId: "CIT_OPS",
					// 			},
					// 		})
					// 		.then((res) => {
					// 			console.log("CIT_OPS specific items");
					// 			console.log(res.data.data);
					// 			let teamItems = [];
					// 			res.data.data.map((element) => {
					// 				const obj = {};
					// 				obj.releaseCreationDate = element.createdOn;
					// 				obj.releaseId = element.releaseid;
					// 				obj.releaseStatus = element.releaseStatus;
					// 				obj.releaseObjective = element.remarks;
					// 				obj.createdBy = "";
					// 				obj.externalReleaseId = element.extrnReleaseId;
					// 				obj.selfAssign = "";
					// 				teamItems.push(obj);
					// 			});
					// 			if (this._isMounted) {
					// 				this.setState({
					// 					dataTeamItems: [...this.state.dataTeamItems, ...teamItems],
					// 				});
					// 			}
					// 		});
					// }
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		} else return Promise.resolve();
	}
	myItemsFederateHandler(userRole) {
		userRole = userRole ?? this.state.userGroups[0];

		const groupIndex = this.state.userGroups.indexOf(userRole);
		if (groupIndex !== -1) {
			return axios
				.get(
					`/Telecustom/assignFedUserTaskList?groupId=${this.state.userGroups[groupIndex]}&userId=${this.props.userInfo.id}`,
					{
						headers: {
							opId: this.props.userInfo.opId,
							buId: this.props.userInfo.buId,
							lob: JSON.stringify(localStorage.getItem('isB2c')),
						},
					}
				)
				.then((res) => {
					const myItems = [];
					res.data.data.map((element) => {
						const obj = {};
						obj.releaseCreationDate = element.createdOn;
						obj.releaseId = element.releaseid;
						obj.releaseStatus = element.releaseStatus;
						obj.releaseObjective = element.remarks;
						obj.createdBy = '';
						obj.externalReleaseId = element.extrnReleaseId;
						obj.selfAssign = '';
						myItems.push(obj);
					});
					if (this._isMounted) {
						this.setState({
							dataMyItems: [...this.state.dataMyItems, ...myItems],
						});
					}
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		} else return Promise.resolve();
	}
	async componentDidMount() {
		this._isMounted = true;

		await this.approversDataHandler();
		axios
			.get('TeleAuthentication/roleuimapping', {
				headers: {
					opId: this.props.userInfo.opId,
					buId: this.props.userInfo.buId,
					lob: 'Postpaid',
					Authorization: 'Bearer ' + this.props.userInfo.jwt,
				},
			})
			.then((res) => {
				console.log(res);
				let approverData = res.data.data;
				approverData = {
					...approverData,
					['TelemediaProductManager']: 'Product Manager',
				};
				debugger;
				let approverDataRev = {};

				Object.keys(approverData).map((key) => {
					approverDataRev[approverData[key]] = key;
				});
				this.setState(
					{
						approverDataRev: approverDataRev,
						approversData: approverData,
						userGroups: this.props.userInfo.group,
						selGrp: approverData[this.props.userInfo.group[0]]
							? approverData[this.props.userInfo.group[0]]
							: this.props.userInfo.group[0],
					},
					() => {
						this.props.onReleaseExit();
						if (this.props.userInfo.group.length === 1) {
							this.teamItemsHandler().then(() => {
								this.myItemsHandler().then(() => {
									this.myItemsFederateHandler().then(() => {
										if (
											this.props.userInfo.group &&
											(this.props.userInfo.group.includes('rad') ||
												this.props.userInfo.group.includes('radB2c') ||
												this.props.userInfo.group.includes('radB2b') ||
												this.props.userInfo.group.includes('CIT_OPS'))
										) {
											let newCol = {
												title: this.props.userInfo.group.includes('CIT_OPS')
													? 'Re-Federate'
													: 'Federate',
												field: this.props.userInfo.group.includes('CIT_OPS')
													? 'refederate'
													: 'federate',
												filtering: false,

												render: (rowData) => (
													<IconButton
														disabled={
															rowData.releaseStatus === 'InProgress' ||
															rowData.releaseStatus ===
															'Pre-prod Dump Upload' ||
															rowData.releaseStatus === 'RAD Validation' ||
															rowData.releaseStatus === 'Prod Dump Upload' ||
															rowData.releaseStatus === 'Prod Test Failed' ||
															rowData.releaseStatus === 'Ready to Go Live' ||
															rowData.releaseStatus === 'Go Live' ||
															rowData.releaseStatus === 'Validation Failed'
														}
														style={{ marginLeft: '10' }}
														onClick={(event) => {
															event.stopPropagation();
															this.setState({ relData: { ...rowData } });
															this.setState({ federate: true });
														}}>
														<SettingsSystemDaydreamIcon />
													</IconButton>
												),
												sorting: false,
												cellStyle: { width: '7%' },
											};
											let columnsMyItems = [...this.state.columnsMyItems];
											columnsMyItems.push(newCol);

											if (this.props.userInfo.group.includes('CIT_OPS')) {
												const deployCol = {
													title: 'Deploy',
													field: 'deploy',
													filtering: false,

													render: (rowData) => (
														<IconButton
															disabled={rowData.releaseStatus !== 'Go Live'}
															style={{ marginLeft: '10' }}
															onClick={(event) => {
																event.stopPropagation();
																this.setState({ relData: { ...rowData } });
																this.deployHandler(rowData.releaseId).then(
																	(res) => {
																		if (res.data.statusMsg === 'SUCCESS') {
																			this.actionHandler().then(console.log());
																		} else {
																			this.setState({
																				failDeploy: true,
																			});
																		}
																	}
																);
															}}>
															<PublicIcon />
														</IconButton>
													),
													sorting: false,
													cellStyle: { width: '7%' },
												};
												columnsMyItems.push(deployCol);
											}

											this.setState({
												columnsMyItems: columnsMyItems,
												actionsMyItems:
													this.state.relData.releaseStatus ===
														'RAD Validation' ||
														this.props.userInfo.group.includes('MS_TEST') ||
														this.props.userInfo.group.includes('NCA_UAT') ||
														this.props.userInfo.group.includes('Selfcare_UAT')
														? ['Validate', 'Not Validate']
														: this.state.relData.releaseStatus ===
															'Ready to Go Live'
															? ['Approve']
															: [('Approve', 'RFI', 'RFC')],
											});
										}
									});
								});
							});
						} else if (
							this.props.userInfo.group &&
							(this.props.userInfo.group.includes('rad') ||
								this.props.userInfo.group.includes('radB2c') ||
								this.props.userInfo.group.includes('radB2b') ||
								this.props.userInfo.group.includes('CIT_OPS'))
						) {
							this.teamItemsHandler().then(() => {
								this.myItemsHandler().then(() => {
									this.myItemsFederateHandler().then(() => {
										let newCol = {
											title:
												this.state.selGrp === 'CIT_OPS'
													? 'Re-Federate'
													: 'Federate',
											field:
												this.state.selGrp === 'CIT_OPS'
													? 'refederate'
													: 'federate',
											filtering: false,

											render: (rowData) => (
												<IconButton
													disabled={
														rowData.releaseStatus === 'InProgress' ||
														rowData.releaseStatus === 'Approval In Progress' ||
														rowData.releaseStatus === 'Pre-prod Dump Upload' ||
														rowData.releaseStatus === 'RAD Validation' ||
														rowData.releaseStatus === 'Prod Dump Upload' ||
														rowData.releaseStatus === 'Ready to Go Live' ||
														rowData.releaseStatus === 'Go Live' ||
														rowData.releaseStatus === 'Validation Failed'
													}
													style={{ marginLeft: '10' }}
													onClick={(event) => {
														event.stopPropagation();
														this.setState({ relData: { ...rowData } });
														this.setState({ federate: true });
													}}>
													<SettingsSystemDaydreamIcon />
												</IconButton>
											),
											sorting: false,
											cellStyle: { width: '7%' },
										};
										let columnsMyItems = [...this.state.columnsMyItems];
										columnsMyItems.push(newCol);

										if (this.props.userInfo.group.includes('CIT_OPS')) {
											const deployCol = {
												title: 'Deploy',
												field: 'deploy',
												filtering: false,

												render: (rowData) => (
													<IconButton
														disabled={rowData.releaseStatus !== 'Go Live'}
														style={{ marginLeft: '10' }}
														onClick={(event) => {
															event.stopPropagation();
															this.setState({ relData: { ...rowData } });
															this.deployHandler(rowData.releaseId).then(
																(res) => {
																	if (res.data.statusMsg === 'SUCCESS') {
																		this.actionHandler().then(console.log());
																	} else {
																		this.setState({
																			failDeploy: true,
																		});
																	}
																}
															);
														}}>
														<PublicIcon />
													</IconButton>
												),
												sorting: false,
												cellStyle: { width: '7%' },
											};
											columnsMyItems.push(deployCol);
										}

										this.setState({
											columnsMyItems: columnsMyItems,
											actionsMyItems:
												this.state.relData.releaseStatus === 'RAD Validation' ||
													this.props.userInfo.group.includes('MS_TEST') ||
													this.props.userInfo.group.includes('NCA_UAT') ||
													this.props.userInfo.group.includes('Selfcare_UAT')
													? ['Validate', 'Not Validate']
													: this.state.relData.releaseStatus ===
														'Ready to Go Live'
														? ['Approve']
														: [('Approve', 'RFI', 'RFC')],
										});
									});
								});
							});
						} else {
							this.teamItemsHandler().then(() => {
								this.myItemsHandler().then(() => {
									this.myItemsFederateHandler()
								})
							})
						}
						this.setState({ loading: false });
					}
				);
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	}

	attachmentHandler = (rowData) => {
		console.log(rowData);
		this.setState({ relData: { ...rowData } });
		this.setState({ attachment: true });
	};

	auditLogsHandler = (rowData) => {
		console.log(rowData);
		this.setState({ relData: { ...rowData } });
		this.setState({ auditLogs: true });
	};

	showAttachmentHandler = () => {
		this.setState({ attachment: false });
	};
	showAuditLogsHandler = () => {
		this.setState({ auditLogs: false });
	};

	showFederationHandler = () => {
		this.setState({ federate: false });
	};
	userRoleHandler = async (event) => {
		const value = event.target?.value ?? event;
		this.props.changeRoleGroup(value);
		this.setState({
			loading: true,
		});
		await this.approversDataHandler();
		this.myItemsHandler(value).then(() => {
			this.teamItemsHandler(value).then(() => {
				this.myItemsFederateHandler(value).then(() => {
					this.setState({
						userRole: value,
						loading: false,
					});
				});
			});
		});
	};
	deployHandler(releaseId) {
		return axios.post(
			'telemediaDeploy/release?releaseId=' + releaseId,
			{},
			{
				headers: {
					updatedBy: this.props.userInfo.id,
					'Content-Type': 'application/json',
					Accept: 'application/json,text/plan,*/*',
				},
			}
		);
	}
	approversDataHandler() {
		console.log('fetching approvers for worklist from api');
		const opId = this.props?.userInfo?.opId ?? this.userInfo.opId;
		const buId = this.props?.userInfo?.buId ?? this.userInfo.buId;
		const authUserId = this.props?.userInfo?.id ?? this.userInfo.id;
		const Authorization = this.props?.userInfo?.jwt ?? this.userInfo.jwt;
		const role = this.state.userRole.slice(
			this.state.userRole.length - 3,
			this.state.userRole.length
		);

		return axios
			.get(process.env.REACT_APP_URL + 'TeleAuthentication/approverUser', { 
				headers: {
					opId,
					buId,
					role,
					lob: 'Postpaid',
					authUserId: authUserId,
					Authorization: 'Bearer ' + Authorization,
					user: this.state.userRole,
				},
			})
			.then((res) => {
				Object.keys(res.data.data).map(
					(str) => {
						res.data.data[str].map(
							(role) => {
								localStorage.setItem('approversDataUser', JSON.stringify(role));
							},
							[this]
						);
					},
					[this]
				);
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	}
	render() {
		const { classes } = this.props;
		let worklist = (
			<React.Fragment>
				{this.props.userInfo.group.length > 1 &&
					!this.props.hasSelectedService &&
					(!sessionStorage.getItem('hasSelectedService') ||
						sessionStorage.getItem('hasSelectedService') === 'false') ? (
					<Card>
						<CardContent>
							<div style={{ textAlign: 'center' }}>
								<h2>Select a Product Type From below :</h2>
								<RadioGroup
									style={{ justifyContent: 'center' }}
									row
									onChange={(event) => {
										this.setState({
											roleSelected: event.currentTarget.value,
										});
										// this.props.changeRoleGroup(event.currentTarget.value);
									}}>
									{this.props.userInfo.group.map((role) => {
										return (
											<FormControlLabel
												style={{
													marginInlineStart: '2rem',
													marginInlineEnd: '2rem',
												}}
												value={role}
												control={<Radio style={{ color: '#ff1921' }} />}
												label={role
													.slice(role.length - 3, role.length)
													.toUpperCase()}
												labelPlacement="end"
											/>
										);
									})}
								</RadioGroup>
								<Button
									onClick={async () => {
										await this.userRoleHandler(this.state.roleSelected);
										this.props.onRoleSelected(true);
										sessionStorage.setItem('hasSelectedService', true);
									}}
									variant="contained"
									disabled={!this.state.roleSelected}
									style={{
										marginTop: '20px',
										background: '#546D7A',
										color: 'white',
										textTransform: 'none',
									}}>
									Submit
								</Button>
							</div>
						</CardContent>
					</Card>
				) : null}
				{this.props.userInfo.group.length === 1 ||
					this.props.hasSelectedService ||
					sessionStorage.getItem('hasSelectedService') === 'true' ? (
					<div>
						{this.props.userInfo.group.includes('TelemediaProductManager') ||
							this.props.userInfo.group.length < 2 ? null : (
								
							<span
								style={{
									display: 'block',
									textAlign: 'end',
									marginBottom: '1rem',
									marginRight: '1rem',
								}}>


								{/* <div style={{ padding: '5px 0', fontSize: '24px', fontWeight: '600'}}>
									My Work Queue */}
									
								<FormControl style={{ width: '8rem', textAlign: 'start'}}>
									<InputLabel>Role</InputLabel>
									<Select
										value={this.state.userRole}
										onChange={this.userRoleHandler}>
										{this.props.userInfo.group.map((role) => {
											return (
												<MenuItem value={role} key={role}>
													{role.toUpperCase()}
												</MenuItem>
											);
										})}
									</Select>
								</FormControl>
							
							</span>


						)}

						<Modal
							show={this.state.show}
							modalClosed={this.errorConfirmedHandler}
							title={'Something Went Wrong!'}>
							{this.state.modalContent}
						</Modal>
						<form
												onSubmit={
													this.props.userInfo.group.includes(
														'TelemediaProductManager'
													)
														? this.actionHandlerPM
														: this.actionHandler
												}
												id="workFlowForm">
												
						</form>

						<Backdrop className={classes.backdrop} open={this.state.openDrawer}>
							<Drawer
								className={classes.drawer}
								variant="persistent"
								anchor="right"
								open={this.state.openDrawer}
								classes={{
									paper: classes.drawerPaper,
								}}>
								<Toolbar>
									<IconButton
										edge="start"
										style={{
											position: 'absolute',
											right: '0',
											marginRight: '2vw',
										}}
										onClick={() => {
											this.setState({
												openDrawer: false,
												relWorkFlowAction: '',
												relWorkRemarks: '',
											});
										}}>
										<CloseIcon />
									</IconButton>
								</Toolbar>
								{this.state.loadingEdit ? (
									<Loader />
								) : (
									<div style={{ marginLeft: '15px', marginRight: '2vw' }}>
										<div
											style={{
												width: '100%',
												height: '103vh',
												overflowY: 'auto',
												overflowX: 'hidden',
											}}>
											<Typography
												style={{
													marginTop: '10px',
													fontWeight: '600',
													fontSize: '18px',
													color: '#393939',
												}}>
												{this.state.releaseEditData.externalReleaseId}
											</Typography>
											<Typography
												style={{
													fontWeight: '600',
													fontSize: '12px',
													color: '#696969',
												}}>
												created on:
												{this.state.releaseEditData.releaseCreationDate}
											</Typography>

											<Typography
												style={{
													fontWeight: '550',
													fontSize: '16px',
													color: '#393939',
													marginTop: '15px',
												}}>
												Release Objective
											</Typography>
											<div
												style={{
													fontWeight: '600',
													fontSize: '14px',
													color: '#696969',
													marginTop: '5px',
													maxHeight: '15vh',
													overflow: 'auto',
												}}>
												{this.state.releaseEditData.releaseObjective}
											</div>

											<form
												onSubmit={
													this.props.userInfo.group.includes(
														'TelemediaProductManager'
													)
														? this.actionHandlerPM
														: this.actionHandler
												}
												id="workFlowForm">
												<Grid
													container
													spacing={3}
													style={{ marginTop: '20px', display: 'inline-flex' }}>
													<Grid item xs={12}>
														<Box>
															<span
																style={{
																	fontWeight: '600',
																	fontSize: '14px',
																	color: '#696969',
																}}>
																Action
															</span>
															<span
																style={{
																	color: 'red',
																	marginLeft: '5px',
																}}>
																*
															</span>
														</Box>
														<Box mt={2}>
															<FormControl style={{ minWidth: '100%' }}>
																<Select
																	name="action"
																	MenuProps={MenuProps}
																	displayEmpty
																	value={this.state.relWorkFlowAction}
																	onChange={(event) =>
																		this.setState({
																			relWorkFlowAction: event.target.value,
																		})
																	}
																	input={<Input required={true} />}
																	renderValue={(selected) => {
																		if (selected) {
																			if (selected.length === 0) {
																				return <em>Action</em>;
																			}
																			return selected;
																		}
																	}}
																	inputProps={{
																		'aria-label': 'Without label',
																	}}>
																	<MenuItem disabled value="">
																		<em>Action</em>
																	</MenuItem>
																	{this.props.userInfo.group.includes(
																		'TelemediaProductManager'
																	)
																		? ['Resubmit'].map((name) => (
																			<MenuItem key={name} value={name}>
																				{name}
																			</MenuItem>
																		))
																		: this.state.releaseEditData
																			.releaseStatus === 'RAD Validation' ||
																			this.props.userInfo.group.includes(
																				'MS_TEST'
																			) ||
																			this.props.userInfo.group.includes(
																				'NCA_UAT'
																			) ||
																			this.props.userInfo.group.includes(
																				'Selfcare_UAT'
																			)
																			? ['Validate', 'Not Validate'].map(
																				(name) => (
																					<MenuItem key={name} value={name}>
																						{name}
																					</MenuItem>
																				)
																			)
																			: this.state.actionsMyItems.map((name) => (
																				<MenuItem key={name} value={name}>
																					{name}
																				</MenuItem>
																			))}
																</Select>
															</FormControl>
														</Box>
													</Grid>

													<Grid item xs={12}>
														<Box>
															<span
																style={{
																	fontWeight: '600',
																	fontSize: '14px',
																	color: '#696969',
																}}>
																Remarks
															</span>
															<span
																style={{
																	color: 'red',
																	marginLeft: '5px',
																}}>
																* Max Length 255 Characters
															</span>
														</Box>
														<Box mt={2}>
															<TextField
																inputProps={{
																	maxLength: 255,
																}}
																placeholder="Remarks"
																onChange={(event) => {
																	this.setState({
																		relWorkRemarks: event.target.value,
																	});
																}}
																fullWidth
																value={this.state.relWorkRemarks}
																rows={2}
																rowsMax={5}
																multiline
																required={true}
																variant="outlined"
															/>
														</Box>
														
													</Grid>
												</Grid>
											</form>
										</div>
									</div>
								)}
								{!this.state.loadingEdit && (
									<div
										style={{
											height: '17vh',
											width: '100%',
											background: '#FFFFFF',
											boxShadow: '0px 0px 4px rgba(0, 0, 0, 0.137156)',
											textAlign: 'center',
										}}>
										<Button
											form="workFlowForm"
											type="submit"
											// onClick={"history.go(0)"}
											
											style={{
												color: '#0079FF',
												border: '1px solid #0079FF',
												marginTop: '-60vh',
											}} 
											color="info"
											variant="outlined">
											Submit
										</Button>
									</div>
								)}
							</Drawer>
										</Backdrop> 
										
						{this.props.userInfo.group.includes('TelemediaProductManager') ? (
							<ThemeProvider theme={theme}>
								<MaterialTable
									icons={tableIcons}
									title={'My Work Queue'}
									columns={this.state.columnsMyItemsPm}
									data={this.state.dataMyItems}
									onRowClick={(event, rowData) => {
										console.log(rowData);
										if (
											rowData.releaseStatus !== 'Assigned For Federation' &&
											rowData.releaseStatus !== 'Federate to Production' &&
											rowData.releaseStatus !== 'Prod Dump Upload' &&
											rowData.releaseStatus !== 'Validation Failed'
										) {
											this.setState({
												openDrawer: true,
												releaseEditData: rowData,
											});
										}
									}}
									options={{
										filtering: true,
										pageSize: 10,
										pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
										toolbar: true,
										paging: true,
										rowStyle: {
											fontSize: '14px',
											// fontWeight: "600"
										},
										headerStyle: {
											fontWeight: 'bold',
											fontSize: '13px',
										},
									}}
								/>
							</ThemeProvider>
						) : (
							<ThemeProvider theme={theme}>
								<MaterialTable
									icons={tableIcons}
									title={'My Work Queue'}
									columns={this.state.columnsMyItems}
									data={this.state.dataMyItems}
									onRowClick={(event, rowData) => {
										console.log(rowData);
										if (
											rowData.releaseStatus === 'Pre-prod Dump Upload' ||
											rowData.releaseStatus === 'Federation failed' ||
											rowData.releaseStatus === 'Federate to Production' ||
											rowData.releaseStatus === 'Prod Dump Upload' ||
											rowData.releaseStatus === 'Assigned For Federation' ||
											rowData.releaseStatus === 'Prod Test Failed' ||
											rowData.releaseStatus === 'Go Live' ||
											rowData.releaseStatus === 'Validation Failed'
										) {
											return;
										} else if (
											rowData.releaseStatus === 'RAD Validation' ||
											this.props.userInfo.group.includes('MS_TEST') ||
											this.props.userInfo.group.includes('NCA_UAT') ||
											this.props.userInfo.group.includes('Selfcare_UAT')
										) {
											this.setState({
												openDrawer: true,
												releaseEditData: rowData,
												actionsMyItems: ['Validate', 'Not Validate'],
											});
										} else if (rowData.releaseStatus === 'Ready to Go Live') {
											this.setState({
												openDrawer: true,
												releaseEditData: rowData,
												actionsMyItems: ['Approve'],
											});
										} else {
											this.setState({
												openDrawer: true,
												releaseEditData: rowData,
												actionsMyItems: ['Approve', 'RFI', 'RFC'],
											});
										}
									}}
									options={{
										filtering: true,
										pageSize: 5,
										pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
										toolbar: true,
										paging: true,
										rowStyle: {
											fontSize: '14px',
											// fontWeight: "600"
										},
										headerStyle: {
											fontWeight: 'bold',
											fontSize: '13px',
										},
									}}
								/>
							</ThemeProvider>
						)}

						{!this.props.userInfo.group.includes('TelemediaProductManager') ? (
							<div style={{ marginTop: '30px' }}>
								<ThemeProvider theme={theme}>
									<MaterialTable
										icons={tableIcons}
										title="Team Items"
										data={this.state.dataTeamItems}
										columns={
											this.state.userGroups.includes('preProdTest') ||
												this.state.userGroups.includes('CIT_OPS')
												? this.state.columnsTeamItemsCit
												: this.state.columnsTeamItems
										}
										options={{
											filtering: true,
											pageSize: 5,
											pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
											toolbar: true,
											paging: true,
											rowStyle: {
												fontSize: '14px',
												// fontWeight: "600"
											},
											headerStyle: {
												fontWeight: 'bold',
												fontSize: '13px',
											},
										}}
									/>
								</ThemeProvider>
							</div>
						) : null}
						{this.state.attachment ? (
							<Attachment
								userInfo={this.props.userInfo}
								showAttachment={this.showAttachmentHandler}
								releaseData={this.state.relData}
								role={this.state.userGroups[0]}
								completeHandler={this.actionHandler}
							/>
						) : null}

						{this.state.auditLogs ? (
							<AuditLogs
								userInfo={this.props.userInfo}
								showAuditLogs={this.showAuditLogsHandler}
								releaseData={this.state.relData}
							/>
						) : null}

						{this.state.federate ? (
							<Federation
								userInfo={this.props.userInfo}
								showFederation={this.showFederationHandler}
								releaseData={this.state.relData}
								selGrp={this.state.selGrp}
							/>
						) : null}
						{
          this.state.literature ? (
            <Literature
              userInfo={this.props.userInfo}
              showLiterature={this.showLiteratureHandler}
              releaseData={this.state.relData}
            />
          ) : null}
					</div>
				) : null}
			</React.Fragment>
		);
		if (this.state.loading) worklist = <Loader />;
		return worklist;
	}
}

const mapStateToProps = (state) => {
	return {
		userInfo: state.login.loggedInUserInfo,
		hasSelectedService: state.roleSelected.hasSelectedService,
		roleGroup: state.roleSelected.roleGroup,
	};
};
const mapDispatchToProps = (dispatch) => {
	return {
		onReleaseExit: () =>
			dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: {} }),
		onRoleSelected: (hasSelectedService) =>
			dispatch({
				type: actionTypes.ROLE_SELECTION,
				hasSelectedService,
			}),
		changeRoleGroup: (roleGroup) =>
			dispatch({ type: actionTypes.CHANGE_ROLE_GROUP, roleGroup })
	};
};

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(WithErrorHandler(withStyles(useStyles)(Worklist), axios));

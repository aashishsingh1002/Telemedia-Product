import React, { Component } from 'react';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../../axios-epc';
import { connect } from 'react-redux';
import TextField from '@material-ui/core/TextField';
import Loader from '../../../UI/Loader/Loader';
import Select from 'react-select';
import Grid from '@material-ui/core/Grid';
import Avatar from '@material-ui/core/Avatar';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import InputLabel from '@material-ui/core/InputLabel';
import InputAdornment from '@material-ui/core/InputAdornment';
import FormControl from '@material-ui/core/FormControl';
import Paper from '@material-ui/core/Paper';
import IconButton from '@material-ui/core/IconButton';
import Input from '@material-ui/core/Input';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import Button from '@material-ui/core/Button';
import moment from "moment";

class UserConfiguration extends Component {

    _isMounted = false;

    state = {
        userName: null,
        password: null,
        showPassword: false,
        loading: false,
        firstName: null,
        lastName: null,
        dob: null,
        mobileNo: null,
        email: null,
        role: null,
        approversData: {},
        selRole: null
    }

    valueChangeHandler = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    componentDidMount() {
        this._isMounted = true;
        console.log('moued')
        this.approversDataHandler().then(() => {

            this.setState({ loading: false })
            console.log(this.state.approversData)
        })
    }

    clickShowPasswordHandler = () => {
        this.setState((prevState) => {
            return { showPassword: !prevState.showPassword };
        });
    };

    mouseDownPasswordHandler = (event) => {
        event.preventDefault();
    };

    approversDataHandler() {

        return axios
            // .get("TeleSelectApprovers/roleuimapping", {
            //     headers: {
            //         opId: this.props.userInfo.opId,
            //         buId: this.props.userInfo.buId,
            //         lob: "Postpaid"
            //     }
            // })
            .get("TeleSelectApprovers/roleuimapping", {
                headers: {
                    opId: this.props.userInfo.opId,
                    buId: this.props.userInfo.buId,
                    lob: "Postpaid"
                }
            })
            .then(res => {
                let approvalData = {};
                Object.keys(res.data.data).map(approver => {
                    approvalData[res.data.data[approver]] = approver
                })
                if (this._isMounted)
                    this.setState({ approversData: { ...approvalData } })
            })
            .catch(error => {
                console.log(error)
                if (this._isMounted)
                    this.setState({ loading: false })
            });

    }


    saveUser = () => {
        this.setState({ loading: true })
        let payload = {};
        let ssoUser = {};
        ssoUser.login = this.state.userName
        ssoUser.password = this.state.password
        ssoUser.firstName = this.state.firstName
        ssoUser.lastName = this.state.lastName
        ssoUser.dob = moment(this.state.dob).format("DD-MMM-YY");
        // ssoUser.country = this.country;
        ssoUser.primaryContactNumber = this.state.mobileNo;
        ssoUser.email = this.state.email
        ssoUser.opId = "HOB";
        ssoUser.buId = "DEFAULT";
        payload.ssoUser = ssoUser;
        console.log(payload);
        axios
            .post("TeleAuthentication/userCreate", payload, {
                headers: {
                    "Content-Type": "application/json"
                }
            })
            .then(res => {
                console.log("user creation");
                console.log(res);
                let role = "";
                if (this.state.role == "TelemediaProductManager") role = "TelemediaProductManager";
                else role = this.state.approversData[this.state.selRole];
                console.log(role)
                axios
                    .put(
                        "Telerest/group/" +
                        role +
                        "/members/" +
                        this.state.userName
                    )
                    .then(res => {
                        console.log(res);
                        this.setState({
                            userName: '',
                            password: '',
                            firstName: '',
                            lastName: '',
                            dob: '',
                            mobileNo: '',
                            email: '',
                            role: '',
                            selRole: '',
                            loading: false
                        })

                    })
                    .catch(error => {
                        console.log(error)
                        if (this._isMounted)
                            this.setState({ loading: false })
                    });
            })
            .catch(error => {
                console.log(error)
                if (this._isMounted)
                    this.setState({ loading: false })
            });

    }
    render() {

        const { classes } = this.props;

        let userConfiguration =
            <div>
                <div style={this.state.loading ? { display: 'none' } : { display: 'block' }}>
                    <Grid container >
                        <Grid item xs={3}></Grid>

                        <Grid item xs={6} >
                            <Paper >

                                <div style={{
                                    width: '100%',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    marginBottom: '2vh'
                                }}>
                                    <Avatar style={{
                                        color: '#fff',
                                        backgroundColor: '#546D7A',
                                        width: '100px',
                                        height: '100px'
                                    }}>
                                        <AccountCircleIcon style={{
                                            width: '100px',
                                            height: '100px'
                                        }} />
                                    </Avatar>
                                </div>
                                <div style={{
                                    width: '100%',
                                    marginBottom: '2vh', padding: '10px'
                                }}
                                >

                                    <TextField label="User Name" name='userName'
                                        value={this.state.userName}
                                        onChange={this.valueChangeHandler} fullWidth
                                    />

                                    <FormControl style={{ width: '100%', marginTop: '10px' }}>
                                        <InputLabel htmlFor="standard-adornment-password">Password</InputLabel>
                                        <Input
                                            type={this.state.showPassword ? 'text' : 'password'}
                                            value={this.state.password}
                                            onChange={this.valueChangeHandler}
                                            name='password'
                                            endAdornment={
                                                <InputAdornment position="end">
                                                    <IconButton
                                                        aria-label="toggle password visibility"
                                                        onClick={this.clickShowPasswordHandler}
                                                        onMouseDown={this.mouseDownPasswordHandler}
                                                    >
                                                        {this.state.showPassword ? <Visibility /> : <VisibilityOff />}
                                                    </IconButton>
                                                </InputAdornment>
                                            }
                                        />
                                    </FormControl>
                                    <TextField label="First Name" name='firstName'
                                        value={this.state.firstName}
                                        onChange={this.valueChangeHandler} fullWidth
                                        style={{ marginTop: '10px' }}
                                    /> <TextField label="Last Name" name='lastName'
                                        value={this.state.lastName}
                                        onChange={this.valueChangeHandler} fullWidth
                                        style={{ marginTop: '10px' }}

                                    />
                                    <TextField
                                        label="Date Of Birth"
                                        fullWidth
                                        type="date"
                                        name='dob'
                                        value={this.state.dob}
                                        onChange={this.valueChangeHandler}
                                        style={{ marginTop: '10px' }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />
                                    <TextField
                                        label="Mobile No"
                                        fullWidth
                                        type="number"
                                        name='mobileNo'
                                        value={this.state.mobileNo}
                                        onChange={this.valueChangeHandler}
                                        style={{ marginTop: '10px' }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />

                                    <TextField
                                        label="Email"
                                        fullWidth
                                        type="email"
                                        name='email'
                                        value={this.state.email}
                                        onChange={this.valueChangeHandler}
                                        style={{ marginTop: '10px' }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />
                                    <div style={{ marginTop: '10px' }}>
                                        <Select
                                            menuPortalTarget={document.body}
                                            placeholder='Role'
                                            styles={{
                                                menuPortal:
                                                    base => ({
                                                        ...base, zIndex: 9999,

                                                    })
                                            }}
                                            onChange={(selectedOption) => {
                                                console.log(selectedOption)
                                                this.setState({
                                                    role: selectedOption.value
                                                });
                                            }}
                                            options={[{
                                                "value": 'TelemediaProductManager',
                                                "label": 'TelemediaProductManager'
                                            }, {
                                                "value": 'Approver',
                                                "label": 'Approver'
                                            }]}
                                            value={this.state.role ? {
                                                "value": this.state.role,
                                                "label": this.state.role
                                            } : null}
                                            menuPortalTarget={document.body}
                                            styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                        />
                                    </div>

                                    {this.state.role &&
                                        this.state.role == 'Approver' && <div style={{ marginTop: '10px' }}>

                                            <Select
                                                menuPlacement="top"
                                                menuPortalTarget={document.body}
                                                placeholder='Approvers'
                                                styles={{
                                                    menuPortal:
                                                        base => ({
                                                            ...base, zIndex: 9999,

                                                        })
                                                }}
                                                onChange={(selectedOption) => {
                                                    console.log(selectedOption)
                                                    this.setState({
                                                        selRole: selectedOption.value
                                                    });
                                                }}
                                                options={
                                                    Object.keys(this.state.approversData).length > 0
                                                        ? Object.keys(this.state.approversData).map(lov => {
                                                            return {
                                                                "value": lov,
                                                                "label": lov
                                                            }
                                                        }) : []}
                                                value={this.state.selRole ? {
                                                    "value": this.state.selRole,
                                                    "label": this.state.selRole
                                                } : null}
                                                menuPortalTarget={document.body}
                                                styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                            />
                                        </div>}

                                </div>
                                <div style={{
                                    width: '100%',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                }}>
                                    <Button variant="contained"
                                        style={{
                                            background: '#02bfa0',
                                            textTransform: 'none',
                                            marginBottom: '2vh'
                                        }}
                                        onClick={this.saveUser}
                                    >
                                        Create User
                        </Button>
                                </div>
                            </Paper>

                        </Grid>

                        <Grid item xs={3}></Grid>

                    </Grid>
                </div>
                {this.state.loading && <Loader />}

            </div>
        return userConfiguration;
    }


}


const mapStateToProps = state => {
    return {
        userInfo: state.login.loggedInUserInfo,
    };
}


export default connect(mapStateToProps)(WithErrorHandler(UserConfiguration, axios));



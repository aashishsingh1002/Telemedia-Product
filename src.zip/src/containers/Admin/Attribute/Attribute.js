import React, { Component } from 'react';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Grid from '@material-ui/core/Grid';
import CardActions from '@material-ui/core/CardActions';
import KeyboardArrowRightIcon from '@material-ui/icons/KeyboardArrowRight';
import KeyboardArrowLeftIcon from '@material-ui/icons/KeyboardArrowLeft';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import ListSubheader from '@material-ui/core/ListSubheader';
import AppsIcon from '@material-ui/icons/Apps';
import { withRouter } from 'react-router-dom';
import BrightnessAutoIcon from '@material-ui/icons/BrightnessAuto';


class Attribute extends Component {

    state = {
        attribute: true
    }
    render() {
        return <Grid item xs={12} sm={6} md={4}
            style={{ height: '30vh' }}>
            <Card key="b" style={{ background: '#F60076', height: '100%' }}>

                <CardContent style={{ height: '75%' }}>
                    {this.state.attribute ? <span style={{ color: 'white' }}>
                        <BrightnessAutoIcon
                            style={{ marginRight: '20px', fontSize: '60px' }} />
                        <span style={{ marginRight: '10px', fontSize: '40px' }}>Attribute</span>
                    </span> :
                        <List component="div" disablePadding style={{ color: 'white' }}>
                            <ListSubheader style={{ color: 'white' }}>Attribute</ListSubheader>
                            <ListItem button
                                onClick={() => {
                                    this.props.history.push("/adminAttrConfiguration")
                                }}>
                                <ListItemIcon>
                                    <AppsIcon style={{ color: 'white' }} />
                                </ListItemIcon>
                                <ListItemText primary="Attribute" />
                            </ListItem>
                            <ListItem button
                                onClick={() => {
                                    this.props.history.push("/adminAttrGrpConfiguration")
                                }}>
                                <ListItemIcon>
                                    <AppsIcon style={{ color: 'white' }} />
                                </ListItemIcon>
                                <ListItemText primary="Attribute Group" />
                            </ListItem>
                        </List>}
                </CardContent>
                <CardActions style={this.state.attribute ? {
                    height: '25%', display: 'flex', justifyContent: 'flex-end'
                } :
                    { height: '25%', display: 'flex' }}>
                    {this.state.attribute ? <KeyboardArrowRightIcon onClick={() => this.setState((prevState) => {
                        return { attribute: !prevState.attribute };
                    })}
                        style={{ color: 'white', cursor: 'pointer' }} /> :
                        <KeyboardArrowLeftIcon onClick={() => this.setState((prevState) => {
                            return { attribute: !prevState.attribute };
                        })}
                            style={{ color: 'white', cursor: 'pointer' }} />}
                </CardActions>
            </Card>
        </Grid>
    }
}

export default withRouter(Attribute);
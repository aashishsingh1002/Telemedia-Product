import React, { Component } from "react";
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import axios from "axios";
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";
import { withStyles } from "@material-ui/core/styles";
import AddIcon from "@material-ui/icons/Add";
import LastPageIcon from "@material-ui/icons/LastPage";
import { connect } from "react-redux";
import Tooltip from "@material-ui/core/Tooltip";
import Loader from "../../UI/Loader/Loader";
import Input from "../../UI/Input/Input";
import Grid from "@material-ui/core/Grid";
import Button from "@material-ui/core/Button";
import moment from "moment";
import CustomInput from "../../UI/Input/Input";
import Box from "@material-ui/core/Box";
import Modal from "../../UI/Modal/Modal";
import Typography from "@material-ui/core/Typography";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import DeleteIcon from "@material-ui/icons/Delete";
import Title from "../../UI/Typography/Title";

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: "#525354",
    color: "white",
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

const useStyles = (theme) => ({
  cardHeader: {
    // background: "#546D7A",
    // height: "4.5vh",
  },
  subheader: {
    fontSize: "20px",
    color: "#393939",
    // color: "white",
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    marginTop: "3%",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "96%",
    flexShrink: 0,
  },
});

class Attribute extends Component {
  _isMounted = false;

  state = {
    attributeVersion: "",
    attributeGrpVersion: "",
    loading: true,
    schemaAttribute: [],
    schemaAttributeGroup: [],
    attributes: {},
    attributeGrps: {},
    selAttribute: null,
    ppmAttrNbr: "",
    show: false,
    modalContent: null,
    selAttributeGrp: null,
    attrGrpData: {},
    listOfPpmAttributes: [],
    addAttribute: null,
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;
    this.versionsHandler().then(() => {
      this.attributeFields().then(() => {
        this.attributeGroupFields().then(() => {
          this.attributeData().then(() => {
            this.attributeGrpData().then(() => {
              this.state.schemaAttributeGroup.map((formElement) => {
                if (formElement.refType == "Date")
                  this.setState({
                    [formElement.refName]: formElement.defaultValue
                      ? moment(formElement.defaultValue).format("DD-MMM-YY")
                      : moment().format("DD-MMM-YY"),
                  });
                else if (formElement.refType == "TextInput" || "TextArea")
                  this.setState({
                    [formElement.refName]: formElement.defaultValue,
                  });
              });
              this.setState({ loading: false });
              if (
                this.props.location.state &&
                this.props.location.state.attrName
              ) {
                let attrName = this.props.location.state.attrName;
                this.setState({
                  selAttribute: attrName,
                });
                Object.keys(this.state.attributes[attrName]).forEach((key) => {
                  this.setState({
                    [key]: this.state.attributes[attrName][key],
                  });
                });
                let ppmAttrNbr = this.state.attributes[attrName].ppmAttrNbr;
                this.setState({
                  ppmAttrNbr: ppmAttrNbr,
                });
              } else if (
                this.props.location.state &&
                this.props.location.state.attrGrpName
              ) {
                let attrGrpName = this.props.location.state.attrGrpName;
                console.log(attrGrpName);
                this.setState({
                  selAttributeGrp: attrGrpName,
                });
                this.attrGrpChange(attrGrpName);
              }
            });
          });
        });
      });
    });
  }

  backToRelease = () => {
    this.props.history.push("/editRelease");
  };

  attributeGrpData() {
    if (this.props.releaseData.releaseId) {
      return axios
        .get(
          process.env.REACT_APP_URL +
            "attributeGrp/basicDetails?relId=" +
            this.props.releaseData.releaseId,
          {
            headers: {
              opId: this.props.userInfo.opId,
              authUserId: this.props.userInfo.id,
              Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        )
        .then((res) => {
          console.log("attrgrp");
          console.log(res.data.data);
          let attributeGrps = {};
          res.data.data.forEach((attributeGrp) => {
            attributeGrps[attributeGrp.attrGrpName] = attributeGrp.attrGrpId;
          });
          if (this._isMounted) this.setState({ attributeGrps: attributeGrps });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      return Promise.resolve();
    }
  }
  attributeData() {
    if (this.props.releaseData.releaseId) {
      return axios
        .get(
          process.env.REACT_APP_URL +
            "attribute/basicDetails?releaseId=" +
            this.props.releaseData.releaseId,
          {
            headers: {
              opId: this.props.userInfo.opId,
              authUserId: this.props.userInfo.id,
              Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        )
        .then((res) => {
          console.log("attr");
          console.log(res);
          let attributes = {};
          res.data.data.forEach((attribute) => {
            attributes[attribute.ppmAttrName] = attribute;
          });
          if (this._isMounted)
            this.setState({
              attributes: attributes,
            });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      return Promise.resolve();
    }
  }
  versionsHandler() {
    return axios
      .all([
        axios.get(
          process.env.REACT_APP_URL + "config/version?entityName=attribute",
          {
            headers: {
              opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
              authUserId: this.props.userInfo.id,
               Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        ),
        axios.get(
          process.env.REACT_APP_URL +
            "package/config/version?entityName=attributeGroup",
          {
            headers: {
              opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
              authUserId: this.props.userInfo.id,
               Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        ),
      ])
      .then(
        axios.spread((attributeVersion, attributeGrpVersion) => {
          if (this._isMounted)
            this.setState({
              attributeVersion: attributeVersion.data.data.version,
              attributeGrpVersion: attributeGrpVersion.data.data.version,
            });
        })
      )
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  attributeGroupFields() {
    if (
      localStorage.getItem("attributeGroup") &&
      localStorage.attributeGroup_version &&
      localStorage.attributeGroup_version == this.state.attributeGrpVersion
    ) {
      console.log("fetching from local storage");
      try {
        this.setState({
          schemaAttributeGroup: JSON.parse(
            localStorage.getItem("attributeGroup")
          ),
        });
      } catch (e) {
        localStorage.removeItem("attributeGroup");
      }
      return Promise.resolve();
    } else {
      console.log("fetching from api");
      return axios
        .get(process.env.REACT_APP_URL + "config?entityName=attributeGroup", {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
            authUserId: this.props.userInfo.id,
             Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        })
        .then((res) => {
          let schema = [];
          schema = res.data.data.map(function (el) {
            if (el.refType == "SelectInput" || el.refType == "MultiSelect") {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(",");
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });
          if (this._isMounted) this.setState({ schemaAttributeGroup: schema });
          localStorage.setItem("attributeGroup", JSON.stringify(schema));
          localStorage.attributeGroup_version = this.state.attributeGrpVersion;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }
  attributeFields() {
    if (
      localStorage.getItem("attribute") &&
      localStorage.attribute_version &&
      localStorage.attribute_version == this.state.attributeVersion
    ) {
      console.log("fetching from local storage");
      try {
        this.setState({
          schemaAttribute: JSON.parse(localStorage.getItem("attribute")),
        });
      } catch (e) {
        localStorage.removeItem("attribute");
      }
      return Promise.resolve();
    } else {
      console.log("fetching from api");
      return axios
        .get(process.env.REACT_APP_URL + "config?entityName=attribute", {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
            authUserId: this.props.userInfo.id,
            Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        })
        .then((res) => {
          let schema = [];
          schema = res.data.data.map(function (el) {
            if (el.refType == "SelectInput" || el.refType == "MultiSelect") {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(",");
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });
          if (this._isMounted) this.setState({ schemaAttribute: schema });
          localStorage.setItem("attribute", JSON.stringify(schema));
          localStorage.attribute_version = this.state.attributeVersion;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }
  saveAttrGrpHandler = (event) => {
    event.preventDefault();
    let payload = {};
    this.setState({ loading: true });
    let date = moment().format("YYYY-MM-DD");
    let ppmAtrributeGroupsAud = {};
    let attrObj = {};
    if (Object.keys(this.state.attrGrpData).length > 0)
      attrObj = this.state.attrGrpData ? { ...this.state.attrGrpData } : {};
    console.log(attrObj);
    this.state.schemaAttributeGroup.map((formElement) => {
      if (formElement.refType == "Date")
        attrObj[formElement.refName] = moment(
          this.state[formElement.refName]
        ).format("YYYY-MM-DD");
      else if (formElement.refType == "Checkbox")
        attrObj[formElement.refName] = this.state[formElement.refName]
          ? "Y"
          : "N";
      else if (formElement.refType == "TextInput" || "TextArea")
        attrObj[formElement.refName] = this.state[formElement.refName];
      else attrObj[formElement.refName] = this.state[formElement.refName];
    });

    attrObj.buId = this.props.userInfo.buId;
    attrObj.opId = this.props.userInfo.opId;
    attrObj.createdBy = this.props.userInfo.id;
    attrObj.createdDate = date;
    attrObj.updatedBy = this.props.userInfo.id;
    attrObj.attrGrpDescription = this.state.attrGrpName;
    attrObj.updatedDate = date;

    if (Object.keys(this.state.attrGrpData).length > 0) {
      ppmAtrributeGroupsAud = attrObj;
      payload.ppmAtrributeGroupsAud = ppmAtrributeGroupsAud;
      payload.releaseId = this.props.releaseData.releaseId;
      console.log("put");
      console.log(payload);

      axios
        .post(process.env.REACT_APP_URL + "attributeGrp/update", payload, {
          headers: {
            authUserId: this.props.userInfo.id,
            Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        })
        .then((response) => {
          let attrGrpMapPayload = {};
          attrGrpMapPayload.releaseId = this.props.releaseData.releaseId;
          attrGrpMapPayload.attrGrpId = this.state.attrGrpData.attrGrpId;
          let listOfPpmAttrGroupDefnAud = [];
          this.state.listOfPpmAttributes.forEach((attribute) => {
            console.log(attribute);
            let obj = {};
            obj.attrGrpId = this.state.attrGrpData.attrGrpId;
            obj.buId = this.props.userInfo.buId;
            obj.catalogId = "DEF_CATALOG";
            obj.createdBy = this.props.userInfo.id;
            obj.createdDate = date;
            obj.datasetId = "PPM_ATTR_SET01";
            obj.endDate = "2030-12-30";
            obj.opId = this.props.userInfo.opId;
            obj.ppmAttrGroupDefnId = "GRP_MAP_1";
            obj.ppmAttrId = attribute.ppmAttrId;
            obj.startDate = date;
            listOfPpmAttrGroupDefnAud.push(obj);
          });
          attrGrpMapPayload.listOfPpmAttrGroupDefnAud =
            listOfPpmAttrGroupDefnAud;
          console.log(attrGrpMapPayload);

          axios
            .post(
              process.env.REACT_APP_URL + "attrGrpMapping/create",
              attrGrpMapPayload,
              {
                headers: {
                  authUserId: this.props.userInfo.id,
                  Authorization: 'Bearer ' + this.props.userInfo.jwt
                },
              }
            )
            .then((response) => {
              console.log("mapping");
              console.log(response);
              this.setState({ loading: false });
            });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      if (this.state.attrGrpName in this.state.attributeGrps) {
        let modalContent = (
          <Typography variant="h6">
            Attribute Group with this name exists.
          </Typography>
        );
        this.setState({
          modalContent: modalContent,
          show: true,
          loading: false,
        });
      } else {
        // attrObj.attrGrpAllocateValue = "PRODUCT";
        attrObj.catalogId = "DEF_CATALOG";
        attrObj.datasetId = "PPM_ATTR_SET01";
        attrObj.uiEnabled = "Y";
        attrObj.changeLog = null;
        ppmAtrributeGroupsAud = attrObj;
        payload.ppmAtrributeGroupsAud = ppmAtrributeGroupsAud;
        payload.releaseId = this.props.releaseData.releaseId;
        console.log("post");
        console.log(payload);

        axios
          .post(process.env.REACT_APP_URL + "attributeGrp/create", payload, {
            headers: {
              authUserId: this.props.userInfo.id,
               Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          })
          .then((response) => {
            console.log(response);
            let attributeGrps = { ...this.state.attributeGrps };
            attributeGrps[this.state.attrGrpName] =
              response.data.data.attrGrpId;
            this.setState({
              attributeGrps: attributeGrps,
            });
            let attrGrpMapPayload = {};
            attrGrpMapPayload.releaseId = this.props.releaseData.releaseId;
            attrGrpMapPayload.attrGrpId = response.data.data.attrGrpId;
            let listOfPpmAttrGroupDefnAud = [];
            this.state.listOfPpmAttributes.forEach((attribute) => {
              let obj = {};
              obj.attrGrpId = response.data.data.attrGrpId;
              obj.buId = this.props.userInfo.buId;
              obj.catalogId = "DEF_CATALOG";
              obj.createdBy = this.props.userInfo.id;
              obj.createdDate = date;
              obj.datasetId = "PPM_ATTR_SET01";
              obj.endDate = "2030-12-30";
              obj.opId = this.props.userInfo.opId;
              obj.ppmAttrGroupDefnId = "GRP_MAP_1";
              obj.ppmAttrId = attribute.ppmAttrId;
              obj.startDate = date;
              listOfPpmAttrGroupDefnAud.push(obj);
            });

            attrGrpMapPayload.listOfPpmAttrGroupDefnAud =
              listOfPpmAttrGroupDefnAud;
            console.log(attrGrpMapPayload);

            axios
              .post(
                process.env.REACT_APP_URL + "attrGrpMapping/create",
                attrGrpMapPayload,
                {
                  headers: {
                    authUserId: this.props.userInfo.id,
                    Authorization: 'Bearer ' + this.props.userInfo.jwt
                  },
                }
              )
              .then((response) => {
                console.log(response);
                this.setState({ loading: false });
              });
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      }
    }
  };
  saveAttrDetailsHandler = (event) => {
    event.preventDefault();
    this.setState({ loading: true });
    let payload = {};
    let date = moment().format("YYYY-MM-DD");
    let tcarePpmAttributesAud = {};
    let attrObj = {};
    if (this.state.ppmAttrNbr)
      attrObj = this.state.attributes[this.state.ppmAttrName]
        ? { ...this.state.attributes[this.state.ppmAttrName] }
        : {};

    console.log(attrObj);
    this.state.schemaAttribute.map((formElement) => {
      if (formElement.refType == "Date")
        attrObj[formElement.refName] = moment(
          this.state[formElement.refName]
        ).format("DD-MMM-YY");
      else if (formElement.refType == "Checkbox")
        attrObj[formElement.refName] = this.state[formElement.refName]
          ? "Y"
          : "N";
      else if (formElement.refType == "TextInput" || "TextArea")
        attrObj[formElement.refName] = this.state[formElement.refName];
      else attrObj[formElement.refName] = this.state[formElement.refName];
    });

    attrObj.buId = this.props.userInfo.buId;
    attrObj.opId = this.props.userInfo.opId;
    attrObj.createdBy = this.props.userInfo.id;
    attrObj.createdDate = date;
    attrObj.updatedBy = this.props.userInfo.id;
    attrObj.updatedDate = date;
    attrObj.ppmAttrKey = this.state.ppmAttrName;
    attrObj.ppmAttrDescription = this.state.ppmAttrName;
    attrObj.ppmAttrValueType = this.state.ppmAttrType;
    if (this.state.ppmAttrNbr) {
      tcarePpmAttributesAud = attrObj;
      payload.tcarePpmAttributesAud = tcarePpmAttributesAud;
      payload.releaseId = this.props.releaseData.releaseId;
      axios
        .post(process.env.REACT_APP_URL + "attribute/update", payload, {
          headers: {
            authUserId: this.props.userInfo.id,
             Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        })
        .then((response) => {
          console.log(response);
          let attributes = { ...this.state.attributes };
          attributes[this.state.ppmAttrName] = attrObj;
          this.setState({
            loading: false,
            attributes: attributes,
          });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
      console.log("put");

      console.log(payload);
    } else {
      if (this.state.ppmAttrName in this.state.attributes) {
        let modalContent = (
          <Typography variant="h6">Attribute with this name exists.</Typography>
        );
        this.setState({
          modalContent: modalContent,
          show: true,
          loading: false,
        });
      } else {
        attrObj.catalogId = "DEF_CATALOG";
        attrObj.datasetId = "PPM_ATTR_SET01";
        attrObj.hasChildAttrs = "N";
        attrObj.displayOrder = 0;
        payload.tcarePpmAttributesAud = attrObj;
        payload.releaseId = this.props.releaseData.releaseId;
        attrObj.startDate = date;
        attrObj.endDate = "2030-12-30";

        console.log("post");

        console.log(payload);
        axios
          .post(process.env.REACT_APP_URL + "attribute/create", payload, {
            headers: {
              authUserId: this.props.userInfo.id,
              Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          })
          .then((response) => {
            console.log(response.data.data);
            let attributes = { ...this.state.attributes };
            attributes[this.state.ppmAttrName] = response.data.data;
            this.setState({
              loading: false,
              attributes: attributes,
              ppmAttrNbr: response.data.data.ppmAttrNbr,
            });
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      }
    }
  };

  deleteAttrGrpHandler = () => {
    let payload = {};
    let ppmAtrributeGroupsAud = {};
    let attrObj = {};
    attrObj.ppmAttrGroupNbr = this.state.attrGrpData.ppmAttrGroupNbr;
    ppmAtrributeGroupsAud = attrObj;
    payload.ppmAtrributeGroupsAud = ppmAtrributeGroupsAud;
    payload.releaseId = this.props.releaseData.releaseId;
    console.log(payload);
    this.setState({ loading: true });

    axios
      .delete(process.env.REACT_APP_URL + "attributeGrp/delete", {
        data: payload,
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          authUserId: this.props.userInfo.id,
           Authorization: 'Bearer ' + this.props.userInfo.jwt
        },
      })
      .then((res) => {
        console.log(res);
        let attributeGrps = { ...this.state.attributeGrps };
        delete attributeGrps[this.state.selAttributeGrp];
        this.setState({
          loading: false,
          attributeGrps: attributeGrps,
        });
        this.clearAttrGrpHandler();
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  deleteAttrHandler = () => {
    let payload = {};
    let tcarePpmAttributesAud = {};
    let attrObj = {};
    attrObj.ppmAttrNbr = this.state.ppmAttrNbr;
    tcarePpmAttributesAud = attrObj;
    payload.tcarePpmAttributesAud = tcarePpmAttributesAud;
    payload.releaseId = this.props.releaseData.releaseId;
    this.setState({ loading: true });
    axios
      .delete(process.env.REACT_APP_URL + "attribute/delete", {
        data: payload,
        headers: {
          "Content-Type": "application/json",
          authUserId: this.props.userInfo.id,
           Authorization: 'Bearer ' + this.props.userInfo.jwt
        },
      })
      .then((res) => {
        console.log(res);
        let attributes = { ...this.state.attributes };
        delete attributes[this.state.selAttribute];
        this.setState({
          loading: false,
          attributes: attributes,
          ppmAttrNbr: "",
          selAttribute: null,
        });
        this.clearAttrHandler();
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };
  errorConfirmedHandler = () => {
    this.setState({ show: false });
  };

  attrGrpChange = (value) => {
    if (value) {
      this.setState({
        selAttributeGrp: value,
        loading: true,
        addAttribute: null,
        attrGrpData: {},
        listOfPpmAttributes: [],
      });

      axios
        .get(
          process.env.REACT_APP_URL +
            "attrGrpMapping/basicDetails?releaseId=" +
            this.props.releaseData.releaseId +
            "&attrGrpId=" +
            this.state.attributeGrps[value],
          {
            headers: {
              opId: this.props.userInfo.opId,
              authUserId: this.props.userInfo.id,
              Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        )
        .then((res) => {
          console.log(res.data.data);
          let attrGrpData = { ...res.data.data.attrGrp };
          let listOfPpmAttributes = [...res.data.data.listOfPpmAttributes];
          this.setState({
            attrGrpData: attrGrpData,
            listOfPpmAttributes: listOfPpmAttributes,
            loading: false,
          });

          Object.keys(res.data.data.attrGrp).forEach((key) => {
            this.setState({ [key]: res.data.data.attrGrp[key] });
          });
        });
    }
  };
  clearAttrHandler = () => {
    this.setState({
      ppmAttrNbr: "",
      selAttribute: null,
    });

    this.state.schemaAttribute.map((formElement) => {
      if (formElement.refType == "Date")
        this.setState({
          [formElement.refName]: formElement.defaultValue
            ? moment(formElement.defaultValue).format("DD-MMM-YY")
            : moment().format("DD-MMM-YY"),
        });
      else if (formElement.refType == "Checkbox")
        this.setState({
          [formElement.refName]: "N",
        });
      else if (formElement.refType == "MultiSelect")
        this.setState({
          [formElement.refName]: [],
        });
      else
        this.setState({
          [formElement.refName]: "",
        });
    });
  };

  clearAttrGrpHandler = () => {
    this.setState({
      attrGrpData: {},
      listOfPpmAttributes: [],
      selAttributeGrp: null,
      addAttribute: null,
    });

    this.state.schemaAttributeGroup.map((formElement) => {
      if (formElement.refType == "Date")
        this.setState({
          [formElement.refName]: formElement.defaultValue
            ? moment(formElement.defaultValue).format("DD-MMM-YY")
            : moment().format("DD-MMM-YY"),
        });
      else if (formElement.refType == "Checkbox")
        this.setState({
          [formElement.refName]: "N",
        });
      else if (formElement.refType == "MultiSelect")
        this.setState({
          [formElement.refName]: [],
        });
      else
        this.setState({
          [formElement.refName]: "",
        });
    });
  };

  render() {
    const { classes } = this.props;

    let attribute = (
      <React.Fragment>
        <Modal
          show={this.state.show}
          modalClosed={this.errorConfirmedHandler}
          title={"Something Went Wrong!"}
        >
          {this.state.modalContent}
        </Modal>

        <div>
          <Title>Attribute</Title>
        </div>
        <Card style={{ marginBottom: "2%", overflow: "visible" }}>
          <CardHeader
            className={classes.cardHeader}
            classes={{
              subheader: classes.subheader,
            }}
            action={
              this.props.releaseData.releaseId && (
                <React.Fragment>
                  <div>
                    <LightTooltip title="New Attribue" arrow>
                      <AddIcon
                        onClick={this.clearAttrHandler}
                        style={{
                          color: "white",
                          marginRight: "10px",
                          cursor: "pointer",
                        }}
                      />
                    </LightTooltip>

                    <LightTooltip title="Back To Release" arrow>
                      <LastPageIcon
                        onClick={this.backToRelease}
                        style={{ color: "white", cursor: "pointer" }}
                      />
                    </LightTooltip>
                  </div>
                </React.Fragment>
              )
            }
            subheader={
              this.props.releaseData.releaseId
                ? "Attribute Definition You are inside release " +
                  this.props.releaseData.externalReleaseId
                : "Attribute Definition"
            }
          />

          <CardContent style={{ marginTop: "1%" }}>
            <Grid
              container
              alignContent="flex-start"
              spacing={2}
              style={{ display: !this.state.loading ? "block" : "none" }}
            >
              <Grid item xs={12} sm={6}>
                <Box>
                  <span style={{}}>Available Attributes</span>
                </Box>
                <Box my={1} style={{ marginBottom: "20px" }}>
                  <CustomInput
                    resize
                    refType="SelectInput"
                    value={this.state.selAttribute}
                    changed={(value) => {
                      if (value) {
                        this.setState({
                          selAttribute: value,
                        });
                        Object.keys(this.state.attributes[value]).forEach(
                          (key) => {
                            this.setState({
                              [key]: this.state.attributes[value][key],
                            });
                          }
                        );
                        console.log(this.state.attributes[value]);
                        let ppmAttrNbr =
                          this.state.attributes[value].ppmAttrNbr;
                        this.setState({
                          ppmAttrNbr: ppmAttrNbr,
                        });
                      }
                    }}
                    refLovs={Object.keys(this.state.attributes)}
                  />
                </Box>
              </Grid>
            </Grid>
            <form onSubmit={this.saveAttrDetailsHandler}>
              <Grid container alignContent="flex-start" spacing={4}>
                {this.state.schemaAttribute.map((formElement) => (
                  <Input
                    key={formElement.refName}
                    {...formElement}
                    disabled={formElement.isDisabled == "Y" ? true : false}
                    required={formElement.isMandatory == "Y" ? true : false}
                    value={this.state[formElement.refName]}
                    changed={(event) => {
                      if (!event.target) {
                        this.setState({
                          [formElement.refName]: event,
                        });
                      } else {
                        if (event.target.type !== "checkbox")
                          this.setState({
                            [formElement.refName]: event.target.value,
                          });
                        else
                          this.setState({
                            [formElement.refName]: event.target.checked,
                          });
                      }
                    }}
                  />
                ))}
              </Grid>
              {this.props.releaseData.releaseId && (
                <div className={classes.center}>
                  <Button
                    variant="contained"
                    style={{
                      background: "#02bfa0",
                      textTransform: "none",
                      marginRight: "1%",
                    }}
                    type="submit"
                  >
                    Save
                  </Button>
                  {this.state.selAttribute && (
                    <Button
                      variant="contained"
                      color="secondary"
                      onClick={this.deleteAttrHandler}
                      style={{
                        background: "#0273bf",
                        textTransform: "none",
                      }}
                    >
                      Delete
                    </Button>
                  )}
                </div>
              )}
            </form>
          </CardContent>
        </Card>
        <Card style={{ overflow: "visible" }}>
          <CardHeader
            className={classes.cardHeader}
            classes={{
              subheader: classes.subheader,
            }}
            action={
              this.props.releaseData.releaseId && (
                <React.Fragment>
                  <div>
                    <LightTooltip title="New Attribute Group" arrow>
                      <AddIcon
                        onClick={this.clearAttrGrpHandler}
                        style={{
                          color: "white",
                          marginRight: "10px",
                          cursor: "pointer",
                        }}
                      />
                    </LightTooltip>
                  </div>
                </React.Fragment>
              )
            }
            subheader={"Attribute Group Definition"}
          />

          <CardContent style={{ marginTop: "1%" }}>
            <form
              onSubmit={this.saveAttrGrpHandler}
              style={{ marginTop: "1%" }}
            >
              <Grid container alignContent="flex-start" spacing={2}>
                <Grid item xs={12} sm={6}>
                  <Grid item xs={12}>
                    <Box>
                      <span style={{}}>Available Attributes Groups</span>
                    </Box>
                    <Box my={1}>
                      <CustomInput
                        resize
                        refType="SelectInput"
                        value={this.state.selAttributeGrp}
                        changed={this.attrGrpChange}
                        refLovs={Object.keys(this.state.attributeGrps)}
                      />
                    </Box>
                  </Grid>
                  <Grid container alignContent="flex-start" spacing={2}>
                    {this.state.schemaAttributeGroup.map((formElement) => (
                      <Input
                        resize={true}
                        key={formElement.refName}
                        {...formElement}
                        disabled={formElement.isDisabled == "Y" ? true : false}
                        required={formElement.isMandatory == "Y" ? true : false}
                        value={this.state[formElement.refName]}
                        changed={(event) => {
                          if (!event.target) {
                            this.setState({
                              [formElement.refName]: event,
                            });
                          } else {
                            if (event.target.type !== "checkbox")
                              this.setState({
                                [formElement.refName]: event.target.value,
                              });
                            else
                              this.setState({
                                [formElement.refName]: event.target.checked,
                              });
                          }
                        }}
                      />
                    ))}
                  </Grid>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Grid item xs={12} sm={6}>
                    <Box>
                      <span style={{}}>Add Attributes</span>
                    </Box>
                    <Box my={1}>
                      <CustomInput
                        resize
                        refType="SelectInput"
                        value={this.state.addAttribute}
                        changed={(value) => {
                          if (value) {
                            if (
                              !this.state.listOfPpmAttributes.some(
                                (attr) => attr.ppmAttrName === value
                              )
                            ) {
                              let listOfPpmAttributes = [
                                ...this.state.listOfPpmAttributes,
                              ].concat([this.state.attributes[value]]);
                              this.setState({
                                addAttribute: value,
                                listOfPpmAttributes: listOfPpmAttributes,
                              });
                            }
                          }
                        }}
                        refLovs={Object.keys(this.state.attributes)}
                      />
                    </Box>
                  </Grid>
                  <TableContainer component={Paper} style={{ height: "30vh" }}>
                    <Table className={classes.table} size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell>Attribute Name</TableCell>
                          <TableCell>Type</TableCell>
                          <TableCell>Delete</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {this.state.listOfPpmAttributes
                          ? this.state.listOfPpmAttributes.map((attribute) => {
                              return (
                                <TableRow key={attribute.ppmAttrName}>
                                  <TableCell
                                    style={{
                                      cursor: "pointer",
                                      textDecoration: "underline",
                                      color: "#ff1921",
                                    }}
                                    onClick={() => {
                                      this.setState({
                                        selAttribute: attribute.ppmAttrName,
                                      });
                                      Object.keys(
                                        this.state.attributes[
                                          attribute.ppmAttrName
                                        ]
                                      ).forEach((key) => {
                                        this.setState({
                                          [key]:
                                            this.state.attributes[
                                              attribute.ppmAttrName
                                            ][key],
                                        });
                                      });
                                      let ppmAttrNbr =
                                        this.state.attributes[
                                          attribute.ppmAttrName
                                        ].ppmAttrNbr;
                                      this.setState({
                                        ppmAttrNbr: ppmAttrNbr,
                                      });
                                    }}
                                  >
                                    {" "}
                                    {attribute.ppmAttrName}
                                  </TableCell>
                                  <TableCell>
                                    {" "}
                                    {attribute.ppmAttrType}
                                  </TableCell>
                                  <TableCell>
                                    <DeleteIcon
                                      onClick={(event) => {
                                        let listOfPpmAttributes =
                                          this.state.listOfPpmAttributes.filter(
                                            (attr) =>
                                              attr.ppmAttrName !==
                                              attribute.ppmAttrName
                                          );
                                        this.setState({
                                          listOfPpmAttributes:
                                            listOfPpmAttributes,
                                        });
                                      }}
                                      style={{
                                        color: "red",
                                        cursor: "pointer",
                                      }}
                                    />
                                  </TableCell>
                                </TableRow>
                              );
                            })
                          : null}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Grid>
              </Grid>
              {this.props.releaseData.releaseId && (
                <div className={classes.center}>
                  <Button
                    variant="contained"
                    style={{
                      background: "#02bfa0",
                      textTransform: "none",
                      marginRight: "1%",
                    }}
                    type="submit"
                  >
                    Save
                  </Button>
                  {this.state.selAttributeGrp && (
                    <Button
                      variant="contained"
                      color="secondary"
                      onClick={this.deleteAttrGrpHandler}
                      style={{
                        background: "#0273bf",
                        textTransform: "none",
                      }}
                    >
                      Delete
                    </Button>
                  )}
                </div>
              )}
            </form>
          </CardContent>
        </Card>
      </React.Fragment>
    );
    if (this.state.loading) attribute = <Loader />;

    return attribute;
  }
}

const mapStateToProps = (state) => {
  return {
    releaseData: state.releaseData.releaseData,
    userInfo: state.login.loggedInUserInfo,
  };
};

export default connect(mapStateToProps)(
  withStyles(useStyles)(WithErrorHandler(Attribute, axios))
);

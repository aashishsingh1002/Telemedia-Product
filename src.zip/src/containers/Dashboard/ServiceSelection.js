import React, { useState} from 'react'
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Button from '@material-ui/core/Button';
// import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import {  useDispatch } from "react-redux";
// import {useNavigate } from 'react-router-dom';
// import axios from "axios";
import * as actionTypes from '../../store/actions/actionTypes';






const ServiceSelection = (props ) =>{
    const [role, setRole] = useState('')
    const dispatch = useDispatch();

  const PageRef=()=>{
    window.location.reload()

  }
    
    return (
      <>
        <React.Fragment>
          <Card>
            <CardContent>
              <div style={{ textAlign: "center" }}>
                <h2>Select a Product type from below :</h2>
                <RadioGroup
                  style={{
                    justifyContent: "center",
                    display: "grid",
                    gridTemplateColumns: "auto auto",
                  }}
                  row
                  onChange={(event) => {
                    setRole(event.target.value)
                  }}
                >
                  <FormControlLabel
                    style={{
                      marginInlineStart: "2rem",
                      marginInlineEnd: "2rem",
                    }}
                    value="b2c"
                    control={<Radio style={{ color: "#ff1921" }} />}
                    label="B2C Product Configuration"
                    labelPlacement="end"
                  />
                  <FormControlLabel
                    style={{
                      marginInlineStart: "2rem",
                      marginInlineEnd: "2rem",
                    }}
                    value="b2cmanual"
                    control={<Radio style={{ color: "#ff1921" }} />}
                    label="Manual B2C Product Configuration"
                    labelPlacement="end"
                  />
                  <FormControlLabel
                    style={{
                      marginInlineStart: "2rem",
                      marginInlineEnd: "2rem",
                    }}
                    value="b2b"
                    control={<Radio style={{ color: "#ff1921" }} />}
                    label="B2B Product Configuration"
                    labelPlacement="end"
                  />
                  <FormControlLabel
                    style={{
                      marginInlineStart: "2rem",
                      marginInlineEnd: "2rem",
                    }}
                    value="b2bmanual"
                    control={<Radio style={{ color: "#ff1921" }} />}
                    label="Manual B2B Product Configuration"
                    labelPlacement="end"
                  />
                  <FormControlLabel
                    style={{
                      marginInlineStart: "2rem",
                      marginInlineEnd: "2rem",
                    }}
                    value="b2bpri"
                    control={<Radio style={{ color: "#ff1921" }} />}
                    label="PRI Product Configuration"
                    labelPlacement="end"
                  />

                  <FormControlLabel
                    style={{
                      marginInlineStart: "2rem",
                      marginInlineEnd: "2rem",
                    }}
                    value="primanual"
                    control={<Radio style={{ color: "#ff1921" }} />}
                    label="Manual PRI Product Configuration"
                    labelPlacement="end"
                  />
                </RadioGroup>
                <Button
            onClick={()=> dispatch({ type: actionTypes.CHANGE_ROLE_GROUP, roleGroup: role })}
            style={{
              marginTop: "20px",
    
              background: "#546D7A",
              color: "white",
              textTransform: "none",
              borderBottom:''
            }}
          >
            Submit
          </Button>
              </div>
            </CardContent>
            
          </Card>

          
        </React.Fragment>
      </>
    );
    
        
}

export default ServiceSelection;
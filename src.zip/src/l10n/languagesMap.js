const languagesMap = {
    en: 'English',
    es: 'Spanish'
};
export default languagesMap;
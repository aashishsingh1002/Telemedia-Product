import React, { Component } from 'react';
import MaterialTable, { MTableToolbar } from 'material-table';
import Tooltip from '@material-ui/core/Tooltip';
import LibraryBooksIcon from '@material-ui/icons/LibraryBooks';
import Literature from "../Dashboard/Literature";

import Chip from '@material-ui/core/Chip';
import IconButton from '@material-ui/core/IconButton';
import AttachmentIcon from '@material-ui/icons/Attachment';
import { withStyles } from '@material-ui/core/styles';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import { connect } from 'react-redux';
import SaveIcon from '@material-ui/icons/Save';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
import TextField from '@material-ui/core/TextField';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import Attachment from '../Dashboard/Attachment';
import Modal from '../../UI/Modal/Modal';
import Typography from '@material-ui/core/Typography';
import Table from '../../UI/Table/Table1';
import Button from '@material-ui/core/Button';
import MuiAlert from '@material-ui/lab/Alert';
import Snackbar from '@material-ui/core/Snackbar';
import StyledButton from '../../UI/Button/Button';

const Alert = (props) => {
  return <MuiAlert elevation={6} variant='filled' {...props} />;
};
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: '#525354',
    color: 'white',
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

const getColor = {
  Deployed: '#1565c0',
  InProgress: '#528548',
  Cancelled: '#fc0a5b',
  'Approval In Progress': '#f26933',
  'Design InProgress': '#528548',
  Approved: '#1565c0',
};

class Worklist extends Component {
  _isMounted = false;

  state = {
    show: false,
    modalContent: null,
    relData: {},
    literature: false,

    attachment: false,
    loading: true,
    dataTeamItems: [],
    dataMyItems: [],
    open: false,
    openSnack: false,
    columnsMyItemsPm: [
      {
        title: 'Release No.',
        field: 'releaseId',
      },
      {
        title: 'Release Objective',
        field: 'releaseObjective',
        sorting: false,
        render: (rowData) => (
          <LightTooltip title={rowData.releaseObjective} arrow>
            <span>
              {' '}
              {rowData.releaseObjective
                ? rowData.releaseObjective.length > 25
                  ? rowData.releaseObjective.substring(0, 25) + '...'
                  : rowData.releaseObjective
                : ''}
            </span>
          </LightTooltip>
        ),
      },
      { title: 'Creation Date', field: 'releaseCreationDate' },
      // {
      //     title: 'Status',
      //     field: 'releaseStatus',
      //     render: rowData => < Chip label={rowData.releaseStatus} style={{ background: getColor[rowData.releaseStatus], color: 'white' }} />
      //     , sorting: false
      // },

      {
        title: 'Attachment',
        field: 'attachment',
        filtering: false,
        render: (rowData) => (
          <IconButton onClick={() => this.attachmentHandler(rowData)}>
            <AttachmentIcon />
          </IconButton>
        ),
        sorting: false,
      },
      {
        title: 'Literature',
        field: 'literature',
        render: (rowData) => (
          <LibraryBooksIcon
          style={{ color: 'black' , marginRight: '10px'}}
          onClick={(event) => {
            event.stopPropagation();
            this.literatureHandler(rowData);
          }}
        />
        ),
        sorting: false,
      },

      // {
      //   title: 'AuditLogs',
      //   field: 'auditLogs',
      //   filtering: false,
      //   render: (rowData) => (
      //     <IconButton
      //       onClick={(event) => {
      //         this.props.auditLogs(rowData.releaseId);
      //       }}
      //     >
      //       <AttachmentIcon />
      //     </IconButton>
      //   ),
      //   sorting: false,
      // },
      {
        title: 'Action',
        field: 'save',
        filtering: false,
        render: (rowData) => (
          <FormControl style={{ minWidth: 200 }}>
            <Select
              name='action'
              MenuProps={MenuProps}
              displayEmpty
              value={this.state['releaseAction' + rowData.releaseId]}
              onChange={(event) =>
                this.setState({
                  ['releaseAction' + rowData.releaseId]: event.target.value,
                })
              }
              input={<Input required={true} id={rowData.releaseId + 'ip'} />}
              renderValue={(selected) => {
                if (selected) {
                  if (selected.length === 0) {
                    return <em>Action</em>;
                  }

                  return selected;
                }
              }}
              inputProps={{ 'aria-label': 'Without label' }}
            >
              <MenuItem disabled value=''>
                <em>Action</em>
              </MenuItem>
              {['Resubmit'].map((name) => (
                <MenuItem key={name} value={name}>
                  {name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        ),
        sorting: false,
        cellStyle: { width: '15%' },
      },
      {
        title: 'Remarks',
        field: 'remarks',
        filtering: false,
        render: (rowData) => (
          <TextField
            placeholder='remarks'
            name='remarks'
            fullWidth
            value={this.state['release' + rowData.releaseId]}
            onChange={(event) =>
              this.setState({
                ['release' + rowData.releaseId]: event.target.value,
              })
            }
          />
        ),
        sorting: false,
        cellStyle: { width: '25%' },
      },
      {
        title: 'Save',
        field: 'save',
        filtering: false,
        render: (rowData) => (
          // <IconButton
          //   style={{ marginLeft: "10" }}
          //   onClick={() => this.actionHandlerPM(rowData)}
          // >
          //   <SaveIcon />
          // </IconButton>
          <StyledButton
            // style={{
            //   textTransform: 'capitalize',
            //   background: '#ff1921',
            //   letterSpacing: '-1px',
            //   fontWeight: '600',
            //   color: '#fff',
            //   fontSize: '16px',
            //   borderRadius: '50px',
            //   padding: '6px 44px',
            //   '&:hover': {
            //     opacity: 0.8,
            //     background: '#ffcc00',
            //   },
            // }}
            style={{
              padding: '6px 16px',
              background: '#5dc17f',
            }}
            onClick={() => this.actionHandlerPM(rowData)}
          >
            Save
          </StyledButton>
        ),
        sorting: false,
        cellStyle: { width: '7%' },
      },
    ],
    columnsTeamItems: [
      {
        title: 'Self Assign',
        field: 'selfAssign',
        render: (rowData) => (
          <IconButton onClick={() => this.selfAssignHandler(rowData)}>
            <KeyboardArrowUpIcon />
          </IconButton>
        ),
        filtering: false,
      },
      { title: 'Release No.', field: 'releaseId' },
      {
        title: 'Release Objective',
        field: 'releaseObjective',
        sorting: false,
        render: (rowData) => (
          <LightTooltip title={rowData.releaseObjective} arrow>
            <span>
              {' '}
              {rowData.releaseObjective
                ? rowData.releaseObjective.length > 25
                  ? rowData.releaseObjective.substring(0, 25) + '...'
                  : rowData.releaseObjective
                : ''}
            </span>
          </LightTooltip>
        ),
      },
      { title: 'Creation Date', field: 'releaseCreationDate' },
      // {
      //     title: 'Status',
      //     field: 'releaseStatus',
      //     render: rowData => < Chip label={rowData.releaseStatus} style={{ background: getColor[rowData.releaseStatus], color: 'white' }} />
      //     , sorting: false
      // },

      {
        title: 'Attachment',
        field: 'attachment',
        render: (rowData) => (
          <IconButton onClick={() => this.attachmentHandler(rowData)}>
            <AttachmentIcon />
          </IconButton>
        ),
        sorting: false,
        filtering: false,
      },
    ],
    columnsMyItems: [
      {
        title: 'Release No.',
        field: 'releaseId',
      },
      {
        title: 'Release Objective',
        field: 'releaseObjective',
        sorting: false,
        render: (rowData) => (
          <LightTooltip title={rowData.releaseObjective} arrow>
            <span>
              {' '}
              {rowData.releaseObjective
                ? rowData.releaseObjective.length > 25
                  ? rowData.releaseObjective.substring(0, 25) + '...'
                  : rowData.releaseObjective
                : ''}
            </span>
          </LightTooltip>
        ),
      },
      { title: 'Creation Date', field: 'releaseCreationDate' },
      // {
      //     title: 'Status',
      //     field: 'releaseStatus',
      //     render: rowData => < Chip label={rowData.releaseStatus} style={{ background: getColor[rowData.releaseStatus], color: 'white' }} />
      //     , sorting: false
      // },

      {
        title: 'Attachment',
        field: 'attachment',
        render: (rowData) => (
          <IconButton onClick={() => this.attachmentHandler(rowData)}>
            <AttachmentIcon />
          </IconButton>
        ),
        sorting: false,
        filtering: false,
      },
      {
        title: 'Action',
        field: 'action',
        filtering: false,
        render: (rowData) => (
          <FormControl style={{ minWidth: 200 }}>
            <Select
              name='action'
              MenuProps={MenuProps}
              displayEmpty
              value={this.state['releaseAction' + rowData.releaseId]}
              onChange={(event) =>
                this.setState({
                  ['releaseAction' + rowData.releaseId]: event.target.value,
                })
              }
              input={<Input required={true} id={rowData.releaseId + 'ip'} />}
              renderValue={(selected) => {
                if (selected) {
                  if (selected.length === 0) {
                    return <em>Action</em>;
                  }

                  return selected;
                }
              }}
              inputProps={{ 'aria-label': 'Without label' }}
            >
              <MenuItem disabled value=''>
                <em>Action</em>
              </MenuItem>
              {['Approve Workflow', 'RFI', 'RFC'].map((name) => (
                <MenuItem key={name} value={name}>
                  {name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        ),
        sorting: false,
        cellStyle: { width: '15%' },
      },
      {
        title: 'Remarks',
        field: 'remarks',
        filtering: false,

        render: (rowData) => (
          <TextField
            placeholder='remarks'
            name='remarks'
            fullWidth
            value={this.state['release' + rowData.releaseId]}
            onChange={(event) =>
              this.setState({
                ['release' + rowData.releaseId]: event.target.value,
              })
            }
          />
        ),
        sorting: false,
        cellStyle: { width: '25%' },
      },
      {
        title: 'Save',
        field: 'save',
        filtering: false,

        render: (rowData) => (
          <IconButton
            style={{ marginLeft: '10' }}
            onClick={() => this.actionHandler(rowData)}
          >
            <SaveIcon />
          </IconButton>
        ),
        sorting: false,
        cellStyle: { width: '7%' },
      },
    ],
  };
  componentWillUnmount() {
    this._isMounted = false;
  }
  showLiteratureHandler = () => {
    this.setState({ literature: false });
  };
  literatureHandler = (relData) => {
    this.setState({ relData: { ...relData } });
    this.setState({ literature: true });
  };


  actionHandlerPM = (rowData) => {
    if (document.getElementById(rowData.releaseId + 'ip').validity.valid) {
      let variables = {};
      let payload = {};
      this.setState({ loading: true });

      if (
        this.state['releaseAction' + rowData.releaseId] == 'Approve Workflow'
      ) {
        variables.approve = { value: true };
        variables.remarks = {
          value: this.state['release' + rowData.releaseId],
        };
        payload.variables = variables;
        console.log('payload');

        console.log(payload);
        axios
          .post('Telerest/task/' + rowData.taskId + '/complete', payload, {
            headers: {
              'Content-Type': 'application/json',
            },
          })
          .then((response) => {
            console.log(response);
            // this.setState({ loading: false })
            let myItems = [...this.state.dataMyItems];
            let removeIndex = this.state.dataMyItems
              .map(function (item) {
                return item.releaseId;
              })
              .indexOf(rowData.releaseId);

            myItems.splice(removeIndex, 1);
            if (this._isMounted)
              this.setState({ loading: false, dataMyItems: myItems });
            let url =
              'dashboard/notifyApprovers?approvedBy=' +
              this.props.userInfo.id +
              '&releaseId=' +
              rowData.releaseId +
              '&opId=' +
              this.props.userInfo.opId +
              '&buId=' +
              this.props.userInfo.buId;

            axios
              .get(url, {})
              .then((response) => {
                console.log(response);
                // this.setState({ loading: false })
                // let myItems = [...this.state.dataMyItems];
                // let removeIndex = this.state.dataMyItems
                //   .map(function (item) {
                //     return item.releaseId;
                //   })
                //   .indexOf(rowData.releaseId);

                // myItems.splice(removeIndex, 1);
                // if (this._isMounted)
                //   this.setState({ loading: false, dataMyItems: myItems });
              })
              .catch((error) => {
                console.log(error);
                this.setState({ loading: false });
              });

            // axios
            //     .post(
            //         "SmsNotificationService/sendsms/" +
            //         rowData.releaseId,
            //         {
            //             "roles": []
            //         },
            //         {
            //             headers: {
            //                 opId: this.props.userInfo.opId,
            //                 buId: this.props.userInfo.buId,
            //                 lob: "Postpaid",
            //                 initiateapproval: false
            //             }
            //         }
            //     )
            //     .then(response => {
            //         console.log(response);
            //         // this.setState({ loading: false })
            //         let myItems = [...this.state.dataMyItems]
            //         let removeIndex = this.state.dataMyItems
            //             .map(function (item) {
            //                 return item.releaseId;
            //             })
            //             .indexOf(rowData.releaseId);

            //         myItems.splice(removeIndex, 1);
            //         if (this._isMounted)
            //             this.setState({ loading: false, dataMyItems: myItems }
            //             );

            //     })
            //     .catch(error => {
            //         console.log(error);
            //         this.setState({ loading: false })
            //     });
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      } else if (
        this.state['releaseAction' + rowData.releaseId] != 'Approve Workflow'
      ) {
        axios
          .post(
            'SelectApprovers/resubmit/' +
              rowData.releaseId +
              '/' +
              this.props.userInfo.id,
            {
              remarks: this.state['release' + rowData.releaseId]
                ? this.state['release' + rowData.releaseId]
                : '',
            }
          )
          .then((response) => {
            console.log(response);
            let myItems = [...this.state.dataMyItems];
            let removeIndex = this.state.dataMyItems
              .map(function (item) {
                return item.releaseId;
              })
              .indexOf(rowData.releaseId);

            myItems.splice(removeIndex, 1);
            if (this._isMounted)
              this.setState({
                loading: false,
                dataMyItems: myItems,
                openSnack: true,
              });
            window.location.reload();
          })
          .catch((error) => {
            console.log(error);
            this.setState({ loading: false });
          });
        //Ankit
        // axios
        //   .get(
        //     'dashboard/notifyResubmit?releaseId=' +
        //       rowData.releaseId +
        //       '&Initiator=' +
        //       this.props.userInfo.id +
        //       '&opId=' +
        //       this.props.userInfo.opId +
        //       '&buId=' +
        //       this.props.userInfo.buId,
        //     {}
        //   )
        // .then((response) => {
        //   console.log(response);
        //   let url =
        //     'custom/resubmit/' +
        //     rowData.releaseId +
        //     '/' +
        //     this.props.userInfo.id;
        // if (this.props.userInfo.opId === 'PLM') {
        //   url =
        //     'custom/resubmit/' +
        //     rowData.releaseId +
        //     '/' +
        //     this.props.userInfo.id;
        // }
        //  })
        // .catch((error) => {
        //   console.log(error);
        //   this.setState({ loading: false });
        // });
      }
    } else {
      let modalContent = (
        <Typography variant='h6'>Action is required.</Typography>
      );
      this.setState({ modalContent: modalContent, show: true });
    }
  };

  actionHandler = (rowData) => {
    if (document.getElementById(rowData.releaseId + 'ip').validity.valid) {
      let variables = {};
      let payload = {};
      this.setState({ loading: true });

      if (
        this.state['releaseAction' + rowData.releaseId] == 'Approve Workflow'
      ) {
        variables.approve = { value: true };
        variables.remarks = {
          value: this.state['release' + rowData.releaseId],
        };
        payload.variables = variables;
        console.log('payload');

        console.log(payload);
        axios
          .post('Telerest/task/' + rowData.taskId + '/complete', payload, {
            headers: {
              'Content-Type': 'application/json',
            },
          })
          .then((response) => {
            console.log(response);
            // this.setState({ loading: false })
            let myItems = [...this.state.dataMyItems];
            let removeIndex = this.state.dataMyItems
              .map(function (item) {
                return item.releaseId;
              })
              .indexOf(rowData.releaseId);

            myItems.splice(removeIndex, 1);
            if (this._isMounted)
              this.setState({ loading: false, dataMyItems: myItems });

            //Ankit
            axios
              .get(
                'dashboard/notifyApprovers?approvedBy=' +
                  this.props.userInfo.id +
                  '&releaseId=' +
                  rowData.releaseId +
                  '&opId=' +
                  this.props.userInfo.opId +
                  '&buId=' +
                  this.props.userInfo.buId,
                {}
              )
              .then((response) => {
                console.log(response);
              })
              .catch((error) => {
                console.log(error);
                this.setState({ loading: false });
              });

            // axios
            //     .post(
            //         "SmsNotificationService/sendsms/" +
            //         rowData.releaseId,
            //         {
            //             "roles": []
            //         },
            //         {
            //             headers: {
            //                 opId: this.props.userInfo.opId,
            //                 buId: this.props.userInfo.buId,
            //                 lob: "Postpaid",
            //                 initiateapproval: false
            //             }
            //         }
            //     )
            //     .then(response => {
            //         console.log(response);
            //         // this.setState({ loading: false })
            //         let myItems = [...this.state.dataMyItems]
            //         let removeIndex = this.state.dataMyItems
            //             .map(function (item) {
            //                 return item.releaseId;
            //             })
            //             .indexOf(rowData.releaseId);

            //         myItems.splice(removeIndex, 1);
            //         if (this._isMounted)
            //             this.setState({ loading: false, dataMyItems: myItems }
            //             );

            //     })
            //     .catch(error => {
            //         console.log(error);
            //         this.setState({ loading: false })
            //     });
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      } else if (
        this.state['releaseAction' + rowData.releaseId] != 'Approve Workflow'
      ) {
        let url =
          'Telecustom/' +
          this.state['releaseAction' + rowData.releaseId].toLowerCase() +
          '/' +
          rowData.releaseId +
          '/' +
          this.props.userInfo.id;
        // if (this.props.userInfo.opId === 'PLM') {
        //   url =
        //     'custom/' +
        //     this.state['releaseAction' + rowData.releaseId].toLowerCase() +
        //     '/' +
        //     rowData.releaseId +
        //     '/' +
        //     this.props.userInfo.id;
        // }

        axios
          .post(url, {
            remarks: this.state['release' + rowData.releaseId]
              ? this.state['release' + rowData.releaseId]
              : '',
          })
          .then((response) => {
            console.log(response);
            let myItems = [...this.state.dataMyItems];
            let removeIndex = this.state.dataMyItems
              .map(function (item) {
                return item.releaseId;
              })
              .indexOf(rowData.releaseId);

            myItems.splice(removeIndex, 1);
            if (this._isMounted)
              this.setState({ loading: false, dataMyItems: myItems });
            let url =
              'dashboard/notifyRfi?raisedBy=' +
              this.props.userInfo.id +
              '&releaseId=' +
              rowData.releaseId +
              '&opId=' +
              this.props.userInfo.opId +
              '&buId=' +
              this.props.userInfo.buId;

            axios.get(url, {}).then((response) => {
              console.log(response);
            });
          })
          .catch((error) => {
            console.log(error);
            this.setState({ loading: false });
          });
      }
    } else {
      let modalContent = (
        <Typography variant='h6'>Action is required.</Typography>
      );
      this.setState({ modalContent: modalContent, show: true });
    }
  };
  errorConfirmedHandler = () => {
    this.setState({ show: false });
  };

  selfAssignHandler = (rowData) => {
    console.log(rowData);
    if (this._isMounted) this.setState({ loading: true });
    axios
      .post(
        'Telerest/task/' + rowData.taskId + '/claim',
        { userId: this.props.userInfo.id },
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      )
      .then((response) => {
        console.log(response);
        let teamItems = [...this.state.dataTeamItems];
        var removeIndex = this.state.dataTeamItems
          .map(function (item) {
            return item.releaseId;
          })
          .indexOf(rowData.releaseId);

        teamItems.splice(removeIndex, 1);
        let newMyitem = {};
        newMyitem = { ...rowData };
        newMyitem.save = '';
        newMyitem.action = '';
        newMyitem.remarks = '';
        if (this._isMounted)
          this.setState((prevState) => {
            return {
              loading: false,
              dataTeamItems: teamItems,
              dataMyItems: [newMyitem].concat(prevState.dataMyItems),
            };
          });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  myItemsHandler() {
    let url =
      'Telecustom/userTaskList?groupId=' +
      this.props.userInfo.group[1] +
      '&userId=' +
      this.props.userInfo.id;
    if (this.props.userInfo.opId === 'HOB') {
      let groupId = this.props.userInfo.group[0];

      url =
        'Telecustom/pmtasklist?groupId=' +
        groupId +
        '&userId=' +
        this.props.userInfo.id;
    }
    return axios
      .get(url, {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {
        console.log('my items');
        console.log(res);
        console.log(res.data.data);
        let myItems = [];
        res.data.data.filter((el) => {
          if (el.releaseDetails.length > 0) {
            let obj = {};
            obj.taskId = el.taskId;
            el.releaseDetails.filter((element) => {
              if (element.varName == 'releaseCreationDate') {
                obj.releaseCreationDate = element.varValue;
              } else if (element.varName == 'releaseId') {
                obj.releaseId = element.varValue;
              } else if (element.varName == 'releaseStatus') {
                obj.releaseStatus = element.varValue;
              } else if (element.varName == 'releaseObjective') {
                obj.releaseObjective = element.varValue;
              } else if (element.varName == 'releaseCreatedBy') {
                obj.createdBy = element.varValue;
              } else if (element.varName == 'releaseExternalId') {
                obj.externalReleaseId = element.varValue;
              }
            });
            obj.action = '';
            obj.remarks = '';
            obj.save = '';

            myItems.push(obj);
          }
        });
        if (this._isMounted) this.setState({ dataMyItems: myItems });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }
  teamItemsHandler() {
    if (
      this.props.userInfo.group.includes('PricingAnalyst') ||
      this.props.userInfo.group.includes('Sv') ||
      this.props.userInfo.group.includes('Siebel') ||
      this.props.userInfo.group.includes('Siebel') ||
      this.props.userInfo.group.includes('BusinessFinanceTeam') ||
      this.props.userInfo.group.includes('TestingApproval') ||
      this.props.userInfo.group.includes('BusinessApproval') ||
      this.props.userInfo.group.includes('PricingAnalyst')
      // !this.props.userInfo.group.includes("PricingAnalyst")
    ) {
      let groupId = this.props.userInfo.group
        .filter((x) => x !== 'EBU')
        .filter((x) => x !== 'PricingAnalyst')
        .filter((x) => x !== 'CBU');

      return axios
        .get('Telecustom/taskList?groupId=' + groupId[0], {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          },
        })
        .then((res) => {
          console.log('team ');
          console.log(res.data.data);
          let teamItems = [];
          res.data.data.filter((el) => {
            let obj = {};
            obj.taskId = el.taskId;
            el.releaseDetails.filter((element) => {
              if (element.varName == 'releaseCreationDate') {
                obj.releaseCreationDate = element.varValue;
              } else if (element.varName == 'releaseId') {
                obj.releaseId = element.varValue;
              } else if (element.varName == 'releaseStatus') {
                obj.releaseStatus = element.varValue;
              } else if (element.varName == 'releaseObjective') {
                obj.releaseObjective = element.varValue;
              } else if (element.varName == 'releaseCreatedBy') {
                obj.createdBy = element.varValue;
              } else if (element.varName == 'releaseExternalId') {
                obj.externalReleaseId = element.varValue;
              }
            });
            obj.selfAssign = '';
            teamItems.push(obj);
          });
          if (this._isMounted) this.setState({ dataTeamItems: teamItems });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else return Promise.resolve();
  }
  componentDidMount() {
    this._isMounted = true;
    this.teamItemsHandler().then(() => {
      this.myItemsHandler().then(() => {
        if (this._isMounted) this.setState({ loading: false });
      });
    });
  }
  handleClose = (event, reason) => {
    this.setState({ openSnack: false });
  };
  attachmentHandler = (rowData) => {
    console.log(rowData);
    this.setState({ relData: { ...rowData } });
    this.setState({ attachment: true });
  };
  showAttachmentHandler = () => {
    this.setState({ attachment: false });
  };

  render() {
    let worklist = (
      <React.Fragment>
        <Snackbar
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
          open={this.state.openSnack}
          autoHideDuration={1500}
          onClose={this.handleClose}
        >
          <Alert onClose={this.handleClose} severity='success'>
            Workflow Resubmited Successfully
          </Alert>
        </Snackbar>
        <Modal
          show={this.state.show}
          modalClosed={this.errorConfirmedHandler}
          title={'Something Went Wrong!'}
        >
          {this.state.modalContent}
        </Modal>
        <div style={{ padding: '20px 0', fontSize: '24px', fontWeight: '600' }}>
          RFI-RFC Work Queue
        </div>
        <Table
          title='My Items'
          data={this.state.dataMyItems}
          columns={
            //   this.state.columnsMyItems
            this.state.columnsMyItemsPm
            // this.props.userInfo.group.includes('PricingAnalyst') &&
            // (this.props.userInfo.group.includes('Sv') ||
            //   this.props.userInfo.group.includes('Siebel'))
            //   ? this.state.columnsMyItems
            //   : this.props.userInfo.group.includes('PricingAnalyst')
            //   ? this.state.columnsMyItemsPm
            //   : this.state.columnsMyItems
          }
          pageSize={5}
          fontSize={'14px'}
        />
        {/* {(this.props.userInfo.group.includes("PricingAnalyst") &&
          (this.props.userInfo.group.includes("Sv") ||
            this.props.userInfo.group.includes("Siebel"))) ||
        !this.props.userInfo.group.includes("PricingAnalyst") ? ( */}
        {/* Ankit-30-11-2021 */}
        {/* <div style={{ marginTop: '30px' }}>
          <Table
            title='Team Items'
            data={this.state.dataTeamItems}
            columns={this.state.columnsTeamItems}
            pageSize={5}
            fontSize={'14px'}
          />
        </div> */}
        {/* ) : null} */}
        {this.state.attachment ? (
          <Attachment
            userInfo={this.props.userInfo}
            showAttachment={this.showAttachmentHandler}
            releaseData={this.state.relData}
          />
        ) : null}
        {
          this.state.literature ? (
            <Literature
              userInfo={this.props.userInfo}
              showLiterature={this.showLiteratureHandler}
              releaseData={this.state.relData}
            />
          ) : null}
  


      </React.Fragment>
    );
    if (this.state.loading) worklist = <Loader />;
    return worklist;
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
  };
};

export default connect(mapStateToProps)(WithErrorHandler(Worklist, axios));

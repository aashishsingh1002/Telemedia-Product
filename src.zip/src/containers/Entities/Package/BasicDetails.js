import React, { Component } from 'react';
import axios from '../../../axios-epc';
import Input from '../../../UI/Input/Input';
import Grid from '@material-ui/core/Grid';
import Snackbar from '@material-ui/core/Snackbar';
// import Button from "@material-ui/core/Button";
import { withStyles } from '@material-ui/core/styles';
import Loader from '../../../UI/Loader/Loader';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import moment from 'moment';
import { connect } from 'react-redux';
import * as actionTypes from '../../../store/actions/actionTypes';
import Button from '../../../UI/Button/Button';
import StyledButton from '../../../UI/Button/Button';
import CopyCloneButton from '../../../common/CopyCloneButton_bkp';
import Modal from '../../../UI/Modal/Modal'
import ModalAction from '../../../UI/ModalAction/ModalAction';
import MuiAlert from '@material-ui/lab/Alert';



function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
}


const useStyles = () => ({
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alignRight: {
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  btn: {
    textTransform: 'unset !important',
  },
});

class BasicDetails extends Component {
  _isMounted = false;

  state = {
    basicDetailsFieldsOriginal: [],
    basicDetailsFields: [],
    planLovs: {},
    version: '',
    loading: true,
    postRequest: true,
    // isDisabled: false,
    invalid: {
      minChannel: false,
      bundledChannelMinRate: false,
      bundledChannelFcvValueMin: false,
      bundles: false,
      fcvChannel: false,
      packageName: null,
      packageId: null,
    },
    isValidated:false,
    showModal: false,
    modalContent: '',
    fallBackLovs:[],
    releaseDetails:{},
    packages: [],
  };

  componentWillUnmount() {
    this._isMounted = false;
  }
  componentDidMount() {
    this._isMounted = true;
    this.versions().then(() => {
      this.uiFields().then(() => {
			
					this.packagelovData().then(() => {
						console.log(this.state.basicDetailsFields);
						this.state.basicDetailsFields.map((formElement) => {
							if (formElement.refType == 'Date')
								this.setState({
									[formElement.refName]: formElement.defaultValue
										? moment(formElement.defaultValue).format('DD-MMM-YY')
										: moment().format('DD-MMM-YY'),
								});
							else if (formElement.refType == 'TextInput' || 'TextArea')
								this.setState({
									[formElement.refName]: formElement.defaultValue,
								});
						});
						this.packageData().then(() => {
              this.fallBackData(true).then(() => {
								this.setState({ loading: false });
							});
					});
          this.releaseDataHandler();
				});
			});
    });
  }

  releaseDataHandler = () => {
    debugger;
    return axios
      .get('ratePlan/edit?releaseId=' + this.props.releaseData.releaseId, {
        headers: {
          Accept: 'application/json,text/plan,*/*',
          buId: this.props.userInfo.buId,
          channelId: 'CSA',
          language: 'ENG',
          opId: this.props.userInfo.opId,
        },
      })
      .then((res) => {
        console.log('KK',res.data.data);
        if (res) {
          let getCurrentReleaseData = res.data.data;
          if (getCurrentReleaseData.genericProducts == null)
            getCurrentReleaseData.genericProducts = [];
          else {
            let genericProducts = [];
            let products = [];
            getCurrentReleaseData.genericProducts.map((pro) => {
              if (pro.alaCarte == 'Y') genericProducts.push(pro);
              else products.push(pro);
            });

            getCurrentReleaseData.genericProducts = genericProducts;
            getCurrentReleaseData.otherentities = {
              ...getCurrentReleaseData.otherentities,
              products: products,
            };
          }
          if (getCurrentReleaseData.packages == null)
            getCurrentReleaseData.packages = [];

          if (this._isMounted)
            this.setState({
              loading: false,
              releaseDetails: getCurrentReleaseData,
              packages: [...getCurrentReleaseData.packages],
              genericProducts: [...getCurrentReleaseData.genericProducts],
            });
          console.log('mounted');
          console.log(getCurrentReleaseData);
        } else this.setState({ loading: false, error: true });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  lovsChangeHelper = (basicDetailsFields) => {
    this.setState({
      packageCategoryId: '',
    });
    console.log(basicDetailsFields);
    let changedBasicDetailsFields = [...basicDetailsFields];
    changedBasicDetailsFields.map((field) => {
      if (field.refName === 'packageCategoryId') {
        if (
          this.state['catalogId'] &&
          this.state.planLovs[this.state['catalogId']]
        )
          field.refLovs = [...this.state.planLovs[this.state['catalogId']]];
        else field.refLovs = [];
      }
    });
    console.log(changedBasicDetailsFields);

    return changedBasicDetailsFields;
  };

  componentDidUpdate(prevProps, prevState) {

    if (
			prevState["catalogId"] !== this.state["catalogId"] ||
			prevState["packageCategoryId"] !== this.state["packageCategoryId"]
		) {
			this.setState({
				userfield1: null,
				userfield2: null,
			});
    }
    


    if (prevState['catalogId'] !== this.state['catalogId']) {
      if (this.state['catalogId']) {
        if (
          this.state['catalogId'] == 'DSL' ||
          this.state['catalogId'] == 'Voice and DSL'
        ) {
          let basicDetailsFields = this.state.basicDetailsFieldsOriginal.filter(
            (field) =>
            field.refName != 'fcvTypeValue' &&
              field.refName != 'fcvChannel' &&
              field.refName != 'bundles' &&
              field.refName != 'minChannel' &&
              field.refName != 'serviceType' &&
              field.refName != 'facilityType' &&
              field.refName != 'bundledChannelMinRate' &&
              field.refName != 'bundledChannelFcvValueMin' &&
              field.refName != 'minChanneltdm'
          );
          if (
						!(prevState["userfield1"] || prevState["userfield1"] === "N") &&
						this.state["userfield1"] === "Y" &&
						!basicDetailsFields.find((item) => item["userfield2"])
					) {
						// basicDetailsFields = basicDetailsFields.filter(
						// 	(field) =>
						const userField2 = this.state.basicDetailsFieldsOriginal.find(
							(item) => item["userfield2"]
						);
						basicDetailsFields.push(userField2);
					} else if (
						prevState["userfield1"] === "Y" &&
						this.state["userfield1"] === "N"
					) {
						basicDetailsFields = basicDetailsFields.filter(
							(field) => field.refName !== "userfield2"
						);
          }
          


          basicDetailsFields = this.lovsChangeHelper(basicDetailsFields);
          console.log(basicDetailsFields);
          this.setState({
            basicDetailsFields: basicDetailsFields,
            throttleSpeed: '',
            dslPlanType: '',
            planSpeed: '',
            fcvTypeValue:'',
          });
        } else if (
          this.state['catalogId'] == 'SIP PRI Static' ||
          this.state['catalogId'] == 'SIP PRI Dynamic'
        ) {
          let basicDetailsFields = this.state.basicDetailsFieldsOriginal.filter(
            (field) =>
              field.refName != 'throttleSpeed' &&
              field.refName != 'dslPlanType' &&
              field.refName != 'planSpeed' &&
              field.refName != 'bundledChannelMinRate' &&
              field.refName != 'bundledChannelFcvValueMin' &&
              field.refName != 'minChanneltdm'
          );
          console.log(basicDetailsFields);
          basicDetailsFields = this.lovsChangeHelper(basicDetailsFields);

          this.setState({
            basicDetailsFields: basicDetailsFields,
            fcvChannel: ['', ''],
            bundles: ['', ''],
            minChannel: '',
            serviceType: basicDetailsFields[
              basicDetailsFields.findIndex(
                (item) => item.refName === 'serviceType'
              )
            ]?.defaultValue ?? '',
            facilityType: basicDetailsFields[
              basicDetailsFields.findIndex(
                (item) => item.refName === 'facilityType'
              )
            ]?.defaultValue ?? '',

            fcvTypeValue:'',

          });
        
        }else if (
          this.state['catalogId'] == 'Voice'
        ) {
          let basicDetailsFields = this.state.basicDetailsFieldsOriginal.filter(
            (field) =>
            field.refName != 'fcvTypeValue' &&
              field.refName != 'throttleSpeed' &&
              field.refName != 'dslPlanType' &&
              field.refName != 'planSpeed' &&
              field.refName != 'bundledChannelMinRate' &&
              field.refName != 'bundledChannelFcvValueMin' &&
              field.refName != 'minChanneltdm' &&
              field.refName != 'fcvChannel' &&
              field.refName != 'bundles' &&
              field.refName != 'minChannel' &&
              field.refName != 'serviceType' &&
              field.refName != 'facilityType' &&
              field.refName != 'bundledChannelMinRate' &&
              field.refName != 'bundledChannelFcvValueMin' &&
              field.refName != 'minChanneltdm'
          );
          console.log(basicDetailsFields);
          basicDetailsFields = this.lovsChangeHelper(basicDetailsFields);

          this.setState({
            basicDetailsFields: basicDetailsFields,
            
          });
        }

         else if (this.state['catalogId'] === 'TDM PRI') {
          let basicDetailsFields = this.state.basicDetailsFieldsOriginal.filter(
            (field) =>

              field.refName !== 'fcvChannel' &&
              field.refName !== 'bundles' &&
              field.refName !== 'minChanneltdm' &&
              field.refName !== 'throttleSpeed' &&
              field.refName !== 'dslPlanType' &&
              field.refName !== 'planSpeed'
          );
          console.log(basicDetailsFields);
          basicDetailsFields = this.lovsChangeHelper(basicDetailsFields);

          this.setState({
            basicDetailsFields: basicDetailsFields,
            bundledChannelMinRate: '',
            bundledChannelFcvValueMin: '',
            minChannel: '',
            serviceType: basicDetailsFields[
              basicDetailsFields.findIndex(
                (item) => item.refName === 'serviceType'
              )
            ]?.defaultValue ?? '',
            facilityType: basicDetailsFields[
              basicDetailsFields.findIndex(
                (item) => item.refName === 'facilityType'
              )
            ]?.defaultValue ?? '',

            fcvTypeValue:'',
          });
        } else {
          this.planTypeHelper();
        }
      } else {
        this.planTypeHelper();
      }
    }
  }

  planTypeHelper = () => {
    let basicDetailsFields = this.state.basicDetailsFieldsOriginal.filter(
      (field) =>
        field.refName != 'fcvChannel' &&
        field.refName != 'bundles' &&
        field.refName != 'minChannel' &&
        field.refName != 'serviceType' &&
        field.refName != 'facilityType' &&
        field.refName != 'throttleSpeed' &&
        field.refName != 'dslPlanType' &&
        field.refName != 'planSpeed' &&
        field.refName != 'bundledChannelMinRate' &&
        field.refName != 'bundledChannelFcvValueMin' &&
        field.refName != 'minChanneltdm'&&
        field.refName != 'fcvTypeValue'

    );
    basicDetailsFields = this.lovsChangeHelper(basicDetailsFields);

    this.setState({
      basicDetailsFields: basicDetailsFields,
      throttleSpeed: '',
      dslPlanType: '',
      planSpeed: '',
      fcvChannel: ['', ''],
      bundles: ['', ''],
      minChannel: '',
      serviceType: basicDetailsFields[
        basicDetailsFields.findIndex(
          (item) => item.refName === 'serviceType'
        )
      ]?.defaultValue ?? '',
      facilityType: basicDetailsFields[
        basicDetailsFields.findIndex(
          (item) => item.refName === 'facilityType'
        )
      ]?.defaultValue ?? '',

      fcvTypeValue:''
    });
  };

  packagelovData() {
    return axios
      .get('ratePlan/dependentLovs?param=package.basicDetails', {
        headers: {
          // opId: this.props.userInfo.opId,
          opId: 'Airtel_Telemedia',
        },
      })
      .then((res) => {
        console.log(res);
        this.setState({
          planLovs: res.data.data,
        });
      })
      .catch((error) => {
        console.log(error);
        this.setState({ loading: false });
      });
  }

  fallBackData(checked) {
    
		if (
			this.props.roleGroup !== "b2bpri" &&
			this.props.roleGroup !== "primanual" &&
      checked
		) {
			return axios
				.get(
					`package/basicDetails/fallbackPlans?brand=${this.state["packageCategoryId"]}&catalogId=${this.state["catalogId"]}`,
					{
						headers: {
							opId: this.props.userInfo.opId,
						},
					}
				)
				.then((res) => {
					let basicDetailsFieldsOriginal =
						this.state.basicDetailsFieldsOriginal;
					const fallbackIndex = basicDetailsFieldsOriginal.findIndex(
						(item) => item.refName === "userfield2"
					);
					basicDetailsFieldsOriginal[fallbackIndex].refLovs =res?.data?.data ?? [];
					this.setState({ basicDetailsFieldsOriginal });
				});
		} else {
      this.setState({userfield2:null})
			return Promise.resolve();
		}
	}


  packageData() {
    debugger;
    if (this.props.packageData.packageId) {
      return axios
        .get(
          'package/basicDetails?packageId=' +
            this.props.packageData.packageId +
            '&releaseID=' +
            this.props.releaseData.releaseId,
          {
            headers: {
              createdBy: this.props.userInfo.id,
              opId: this.props.userInfo.opId,
            },
          }
        )
        .then((res) => {
          console.log('inside package');
          console.log(res);
          this.setState({
            packageId: res.data.data.packageId,
            packageName: res.data.data.packageDesc,
          });
          Object.keys(res.data.data).forEach((key) => {
            this.setState({ [key]: res.data.data[key] });
          });
          this.setState({ postRequest: false });
          this.props.onPackageEnter(res.data.data);
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      return Promise.resolve();
    }
  }
  versions() {
    return axios
      .get('package/config/version?entityName=package.basicDetails', {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {
        if (this._isMounted) this.setState({ version: res.data.data.version });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  uiFields = () => {
    if (
      localStorage.getItem('packageBundle') &&
      localStorage.packageBundle_version &&
      localStorage.packageBundle_version == this.state.version
    ) {
      console.log('fetching from local storage');
      try {
        this.setState({
          basicDetailsFields: JSON.parse(localStorage.getItem('packageBundle')),
          basicDetailsFieldsOriginal: JSON.parse(
            localStorage.getItem('packageBundle')
          ),
        });
      } catch (e) {
        localStorage.removeItem('packageBundle');
      }
      return Promise.resolve();
    } else {
      console.log('fetching from api');

      return axios
        .get(`package/config?entityName=package.basicDetails${
          this.props.roleGroup === 'b2bpri' ||
          this.props.roleGroup === 'primanual'
            ? '.b2bpri'
            : ''
        }`
         ,{
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
            Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        })
        .then((res) => {
          let basicDetailsFields = [];
          basicDetailsFields = res.data.data.map(function (el) {
            if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });
          if (this._isMounted)
            this.setState({
              basicDetailsFields: basicDetailsFields,
              basicDetailsFieldsOriginal: [...basicDetailsFields],
            });
          localStorage.setItem(
            'packageBundle',
            JSON.stringify(basicDetailsFields)
          );
          localStorage.packageBundle_version = this.state.version;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  };
  onSavePackage = (event) => {
		event.preventDefault();
		if (
			this.state.catalogId !== 'Voice and DSL' &&
			this.state.catalogId !== 'Voice'
		) {
			this.setState(
				{
					show:
						this.state.catalogId === 'TDM PRI'
							? Number(this.state.bundledChannelFcvValueMin) >
							  Number(this.state.bundledChannelMinRate)
							: Number(this.state.fcvChannel[0]) >
							  Number(this.state.bundles[0]),
				},
				() => {
					if (
						!(
							(this.state.catalogId === 'TDM PRI' &&
								Number(this.state.bundledChannelFcvValueMin) >
									Number(this.state.bundledChannelMinRate)) ||
							(this.state.catalogId !== 'TDM PRI' &&
								Number(this.state.fcvChannel[0]) >
									Number(this.state.bundles[0]))
						)
					) {
						this.savePkgDetailsHandler();
					}
				}
			);
		} else {
			this.savePkgDetailsHandler();
		}
	};
  savePkgDetailsHandler = (event) => {
    debugger;
		if (event) event.preventDefault();

		this.setState({ loading: true, show: false });
		let payload = {};
		let date = moment().format('DD-MMM-YY');
		let tcarePpmPackageAud = {
			throttleSpeed: '',
			dslPlanType: '',
			planSpeed: '',
			bundles: null,
			fcvChannel: null,
			minChannel: '',
			serviceType: '',
			facilityType: '',
			minChanneltdm: '',
			bundledChannelMinRate: '',
			bundledChannelFcvValueMin: '',
			fcvTypeValue: '',
			planShortCode: '',
		};
		if (this.props.packageData.packageNbr) {
			tcarePpmPackageAud = { ...this.props.packageData };
			tcarePpmPackageAud.throttleSpeed = '';
			tcarePpmPackageAud.dslPlanType = '';
			tcarePpmPackageAud.planSpeed = '';
			tcarePpmPackageAud.fcvChannel = null;
			tcarePpmPackageAud.bundles = null;
			tcarePpmPackageAud.minChannel = '';
			tcarePpmPackageAud.fcvTypeValue = '';
			tcarePpmPackageAud.serviceType = '';
			tcarePpmPackageAud.facilityType = '';
			tcarePpmPackageAud.minChanneltdm = '';
			tcarePpmPackageAud.bundledChannelMinRate = '';
			tcarePpmPackageAud.bundledChannelFcvValueMin = '';

			tcarePpmPackageAud.planShortCode = '';
		}
		this.state.basicDetailsFields.map((formElement) => {
			if (formElement.refType == 'Date')
				tcarePpmPackageAud[formElement.refName] = moment(
					this.state[formElement.refName]
        ).format('DD-MMM-YY');
        else if (formElement.refType == "Checkbox") {
          tcarePpmPackageAud[formElement.refName] =
            this.state[formElement.refName] === null ||
            this.state[formElement.refName] === undefined
              ? "N"
              : this.state[formElement.refName];
			// else if (formElement.refType == 'Checkbox')
			// 	tcarePpmPackageAud[formElement.refName] = this.state[
			// 		formElement.refName
			// 	]
			// 		? 'Y'
			// 		: 'N';
        }


        // else if (formElement.refType == 'TextInput' || 'TextArea')
				// tcarePpmPackageAud[formElement.refName] =
					// this.state[formElement.refName];

          
          else if (formElement.refType == 'TextInput' || 'TextArea')
      if(formElement.refName =='packageDesc' || formElement.refName =='description' ){
        tcarePpmPackageAud[formElement.refName] =
        this.state[formElement.refName].replace(/\s{2,}/g,' ').trim();
      }
      else{
        tcarePpmPackageAud[formElement.refName] =
        this.state[formElement.refName];
      }
			else
				tcarePpmPackageAud[formElement.refName] =
					this.state[formElement.refName];
		});
		tcarePpmPackageAud.buId = this.props.userInfo.buId;
		tcarePpmPackageAud.opId = this.props.userInfo.opId;
		tcarePpmPackageAud.createdBy = this.props.userInfo.id;
		tcarePpmPackageAud.createdDate = date;
		if (
			tcarePpmPackageAud.catalogId === 'SIP PRI Static' ||
			tcarePpmPackageAud.catalogId === 'SIP PRI Dynamic'
		) {
			tcarePpmPackageAud.bundles = [
				tcarePpmPackageAud.bundles[0],
				tcarePpmPackageAud.bundles[0],
			];
			tcarePpmPackageAud.fcvChannel = [
				tcarePpmPackageAud.fcvChannel[0],
				tcarePpmPackageAud.fcvChannel[0],
			];
		}
		if (this.state.postRequest) {
			tcarePpmPackageAud.version = '1.0';
			payload.tcarePpmPackageAud = tcarePpmPackageAud;
			payload.releaseId = this.props.releaseData.releaseId;
			console.log('post');
			console.log(payload);
			axios
				.post('package/basicDetails', payload)
				.then((response) => {
					console.log('pkgcreated');
					let pkgDetails = { ...response.data.data };
					this.props.onPackageEnter(pkgDetails);
					let searchItems = [
						response.data.data.packageId + '/' + response.data.data.packageDesc,
					].concat(this.props.searchItems);

					this.props.setSearchItems(searchItems);

					this.state.basicDetailsFields.map((formElement) => {
						this.setState({
							[formElement.refName]:
								formElement.refName === 'planSpeed' ||
								formElement.refName === 'throttleSpeed'
									? Number(response.data.data[formElement.refName]) < 1000
										? `${response.data.data[formElement.refName]} KBPs`
										: Number(response.data.data[formElement.refName]) < 1000000
										? `${
												Number(response.data.data[formElement.refName]) / 1024
										  } MBPs`
										: `${
												Number(response.data.data[formElement.refName]) /
												(1024 * 1024)
										  } GBPs`
									: response.data.data[formElement.refName],
						});
					});
					this.setState({ postRequest: false, loading: false });
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		} else {
			tcarePpmPackageAud.updatedDate = date;
			tcarePpmPackageAud.updatedBy = this.props.userInfo.id;
			tcarePpmPackageAud.packageNbr = this.props.packageData.packageNbr;
			payload.tcarePpmPackageAud = tcarePpmPackageAud;
			payload.releaseId = this.props.releaseData.releaseId;

			console.log(payload);
			axios
				.post('package/basicDetails/update', payload)
				.then((response) => {
					console.log(response);
					let pkgDetails = { ...response.data.data };
					this.setState({ loading: false });
					this.props.onPackageEnter(pkgDetails);
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		}
	};
  validationCheck = (data, name) => {
    this.setState({
      invalid: {
        ...this.state.invalid,
        [name]: data,
      },
    });
  };

  disableButton = () => {
		const invalidObj = this.state.invalid;
		for (let item in invalidObj) {
			if (
				(invalidObj.hasOwnProperty(item) && invalidObj[item]) ||
				this.props.releaseData.releaseStatus !== 'InProgress'
			)
				return true;
		}
	};
  handleClose = (event, reason) => {
		if (reason === 'clickaway') {
						return;
					}
		this.setState({ openSnack: false })
	};

  validateHandler = () => {
    try{
		return axios
			.get(
				`attribute/validation?packageId=${this.props.packageData.packageId}&releaseID=${this.props.releaseData.releaseId}`,
				{
					headers: {
						opId: this.props.userInfo.opId,
						buId: this.props.userInfo.buId,
            Authorization:'Bearer ' + this.props.userInfo.jwt
					},
				}
			)
			.then((res) => {
				if(res.data.statusMsg==="SUCCESS"){
				this.setState({
					
					isValidated: true,
					openSnack:true,
					message:"Success",
				});}
				else{
					this.setState({
					openSnack:true,
					message:"Failure",
					})
				}
			});
    } catch(err) {
      console.error(err);
    }
	};


  render() {
    const { classes } = this.props;
    const vertical = 'top';
    const horizontal = 'center';
    let basicDetails = (
			<>
      <Snackbar anchorOrigin={{ vertical, horizontal }}
      open={this.state.openSnack} autoHideDuration={3000} onClose={this.handleClose}>
      <Alert onClose={this.handleClose} severity="success">
          {this.state.message}
      </Alert>
      </Snackbar>
					<div
						style={{
							marginBottom: '1em',
							display: 'flex',
							justifyContent: 'flex-end',
						}}>
						{/* <UploadButton
        uploadUrl={
          '/dashboard/productUpload?releaseId=' +
          this.props.releaseData.releaseId +
          '&createdBy=' +
          this.props.userInfo.id
        }
        headers={{
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        }}
        excelTabName={'product'}
        schema={this.state.schema.filter((x) => x.refName !== 'productId')}
        uploadName={'Product BulkUpload'}
        title='Product Upload'
        //   onSuccess={() => getData()}
      /> */}
{/* 
{this.props.releaseData.releaseStatus ==="InProgress" && ( */}


				 		{this.props.releaseData.releaseId && this.props.releaseData.releaseStatus ==="InProgress" && this.state.packages.length < 5 && (
							<CopyCloneButton
								id={this.state.packageId}
								name={this.state.packageName} 
								genId={null}
								url={'telemediaDeploy/copyClone'}
								releaseId={this.props.releaseData.releaseId}
								opId={this.props.userInfo.opId}
								buId={this.props.userInfo.buId}
								createdBy={this.props.userInfo.id}
								identifier={'Package'}
                packageslen={this.state.packages.length}
                jwt={this.props.userInfo.jwt}
                

							/>
						)}
            
					</div>
					<form
						onSubmit={this.onSavePackage}
						style={{ overflow: 'visible' }}>
              <ModalAction
					show={this.state.show}
					modalClosed={() =>
						this.setState({
							show: false,
						})
					}
					actionText={'Continue'}
					title={'Warning: New Package Validation'}
					action={this.savePkgDetailsHandler}
					size={'md'}>
					<h3>
						Bundled Channel FCV Rate is greater than Bundled Channel Rate. Do
						wish to continue?
					</h3>

					{/* <TextareaAutosize
                    rowsMin={10} placeholder="Release Objective"
                    style={{ width: '100%' }}
                    name='remarks' value={this.state.remarks} onChange={this.valueChangeHandler} />; */}
				</ModalAction>
						<Grid
							container
							alignContent="flex-start"
							spacing={4}
							style={{ overflow: 'visible' }}>
							{this.state.basicDetailsFields.map((formElement) =>
								formElement.refName !== 'userfield2' ||
								this.state['userfield1'] === 'Y' ? (
									<Input
										key={formElement.refName}
										{...formElement}
										catalogId={this.state.catalogId}
										colSize={
											['fcvChannel', 'bundles'].includes(formElement.refName)
												? 3
												: 2
										}
										disabled={
											formElement.isDisabled === 'Y'
												? true
												// : formElement.refName === 'userfield1' &&
												//   (!this.state['catalogId'] ||
												// 		!this.state['packageCategoryId'])
												// ? true
												: false
										}
										required={formElement.isMandatory == 'Y' ? true : false}
                    error={
                      this.state.minDid &&
                      this.state.maxDid &&
                      (formElement.refName === 'minDid' ||
                        formElement.refName === 'maxDid') &&
                      Number(this.state.minDid) >Number( this.state.maxDid)
                    }
                    helperText={
                      this.state.minDid &&
                      this.state.maxDid &&
                      (formElement.refName === 'minDid' ||
                        formElement.refName === 'maxDid') &&
                      Number(this.state.minDid) > Number( this.state.maxDid)
                        ? 'Min DID should not exceed Max DID'
                        : null
                    }
    
										value={this.state[formElement.refName]}
										// setDisabled= {(disabled)=>this.setState({isDisabled: disabled})}
										onValidationCheck={this.validationCheck}
										checkChanged={(event) => {
											this.fallBackData(event.target.checked);
											this.setState({
												[formElement.refName]: event.target.checked ? 'Y' : 'N',
                        
											});
										}}
										changed={(event) => {
											if (!event.target) {
												this.setState({
													[formElement.refName]: event,
												});
											} else {
												if (event.target.type !== 'checkbox'

                        )
													this.setState({
														[formElement.refName]: event.target.value,
                            invalid: {
                              ...this.state.invalid,
                              ...(
                              ((formElement.refName === 'minDid' && Number(event.target.value) > Number(this.state.maxDid)) ||
                                (formElement.refName === 'maxDid' && Number(this.state.minDid) > Number(event.target.value)) )
                              
                                ? {
                                    minDid: true,
                                    maxDid: true,
                                  }
                                : {minDid: false,
                                  maxDid: false,}),
                            },
    
													});
												else
													this.setState({
														[formElement.refName]: event.target.checked,
													});
											}
										}}
										sliderChange={(event, minMax) => {
											console.log(minMax);
											console.log(event.target.value);
											console.log(event.key);

											let value = [...this.state[formElement.refName]];

											if (minMax === 'min') {
												if (!event.target.value) {
													console.log('hi');
													value[0] = '';
												} else {
													console.log('hello');

													value[0] = event.target.value;
												}
											} else if (minMax === 'max')
												value[1] = event.target.value;

											this.setState({
												[formElement.refName]: value,
											});
										}}
									/>
								) : null
							)}
						</Grid>
						<br></br>
						<div>
							<span
								style={{
									color: 'red',
									marginLeft: '5px',
									fontWeight: 'bold',
								}}>
								*
							</span>{' '}
							<span style={{ fontSize: '13px' }}>Mandatory Fields</span>
						</div>

						{this.props.releaseData.releaseId && (
							<div className={classes.alignRight}>
								{/* <Button
              //   variant="contained"
              onClick={() => {
                this.props.changePackageActiveStep(1);
              }}
              style={{
                background: '#fff',
                marginTop: '3%',
                color: '#ff1921',
                marginRight: '20px',
              }}
              className={classes.btn}
            >
              Next
            </Button> */}
								<StyledButton
									//   variant="contained"
									// disabled= {this.state.isDisabled || this.state.invalid}
									style={{
										//   background: "#02bfa0",
										marginTop: '3%',
										background: '#5dc17f',
									}}
									// disabled={this.state.invalid.minChannel || this.state.invalid.bundledChannelMinRate ||
									//     this.state.invalid.bundledChannelFcvValueMin}
									
                  className={classes.btn}
                  onClick={this.validateHandler} 
                  disabled={!this.props.packageData.packageId}>
									Validate
								</StyledButton>

								<StyledButton
									//   variant="contained"
									// disabled= {this.state.isDisabled || this.state.invalid}
									style={{
										//   background: "#02bfa0",

										background: '#5dc17f',
										margin: '3% 1rem 0',
									}}
									type='submit'
              
              
              disabled={this.disableButton()}
              className={classes.btn}>
									Save
								</StyledButton>

								<StyledButton
									//   variant="contained"
									// disabled= {this.state.isDisabled || this.state.invalid}
									style={{
										//   background: "#02bfa0",
										marginTop: '3%',
										background: '#5dc17f',
									}}
									// disabled={this.state.invalid.minChannel || this.state.invalid.bundledChannelMinRate ||
									//     this.state.invalid.bundledChannelFcvValueMin}
									className={classes.btn}
            onClick={()=>this.props.changePackageActiveStep(1)}>
									Next
								</StyledButton>
							</div>
						)}
					</form>
			
			</>
		);

    if (this.state.loading) basicDetails = <Loader relative />;
    return basicDetails;
  }
}

const mapStateToProps = (state) => {
  return {
    searchItems: state.searchData.searchItems,
    roleGroup: state.roleSelected.roleGroup,
    userInfo: state.login.loggedInUserInfo,

  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onPackageEnter: (packageData) =>
      dispatch({ type: actionTypes.INSIDE_PACKAGE, packageData: packageData }),
    setSearchItems: (searchItems) =>
      dispatch({
        type: actionTypes.SET_SEARCH_ITEMS,
        searchItems: searchItems,
        entity: 'PACKAGE',
      }),
    changePackageActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
        activeStep: activeStep,
      }),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(BasicDetails, axios)));

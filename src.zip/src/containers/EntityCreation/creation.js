import React, { Component } from 'react';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../axios-epc';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import AddIcon from '@material-ui/icons/Add';
import LastPageIcon from '@material-ui/icons/LastPage';
import { connect } from 'react-redux';
import Tooltip from '@material-ui/core/Tooltip';
import Loader from '../../UI/Loader/Loader';
import Input from '../../UI/Input/Input';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import moment from "moment";



const LightTooltip = withStyles((theme) => ({
    tooltip: {
        backgroundColor: '#525354',
        color: 'white',
        boxShadow: theme.shadows[1],
        fontSize: 14,
    },
}))(Tooltip);


const useStyles = (theme) => ({
    cardHeader: {
        background: '#546D7A',
        height: '4.5vh'
    },
    subheader: {
        color: 'white',
        // fontWeight: 'bold'
    },
    boldText: {
        // fontWeight: 'bold'
    },
    center: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        flexBasis: '96%',
        flexShrink: 0,
    },

});

class Contract extends Component {

    _isMounted = false;

    state = {
        version: '',
        loading: true,
        schema: []
    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    componentDidMount() {
        this._isMounted = true;
        this.versions().then(() => {
            this.uiFields().then(() => {
                this.setState({ loading: false })
            })
        })
    }

    backToRelease = () => {
        this.props.history.push('/editRelease')
    }

    versions() {
        return axios
            .get(
                "config/version?entityName=contract",
                {
                    headers: {
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId
                    }
                }
            )
            .then(res => {
                if (this._isMounted)
                    this.setState({ version: res.data.data.version })

            })
            .catch(error => {
                console.log(error)
                if (this._isMounted)
                    this.setState({ loading: false })
            });
    }

    uiFields() {
        if (
            localStorage.getItem("contracts") &&
            localStorage.contracts_version &&
            localStorage.contracts_version == this.state.version
        ) {
            console.log("fetching from local storage");
            try {
                this.setState({ schema: JSON.parse(localStorage.getItem("contracts")) })

            } catch (e) {
                localStorage.removeItem("contracts");
            }
            return Promise.resolve();
        } else {
            console.log("fetching from api");
            return axios
                .get("config?entityName=contract", {
                    headers: {
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId
                    }
                })
                .then(res => {

                    let schema = []
                    schema = res.data.data.map(function (el) {
                        if (el.refType == "SelectInput" || el.refType == "MultiSelect") {
                            if (el.refLovs != null) el.refLovs = el.refLovs.split(",");
                            else if (el.refLovs == null) el.refLovs = [];
                        }
                        return el;
                    });
                    if (this._isMounted)
                        this.setState({ schema: schema })
                    localStorage.setItem("contracts", JSON.stringify(schema));
                    localStorage.contracts_version = this.state.version;
                })
                .catch(error => {
                    console.log(error)
                    if (this._isMounted)
                        this.setState({ loading: false })
                });
        }
    }

    render() {
        const { classes } = this.props;

        let contract = <Card >
            <CardHeader
                className={classes.cardHeader}
                classes={{
                    subheader: classes.subheader,
                }}
                action={
                    this.props.releaseData.releaseId &&
                    <React.Fragment>
                        <div>
                            <LightTooltip title='New Contract' arrow>
                                <AddIcon onClick={() => {
                                }}
                                    style={{ color: 'white', marginRight: '10px', cursor: 'pointer' }} />
                            </LightTooltip>

                            <LightTooltip title='Back To Release' arrow>

                                <LastPageIcon onClick={this.backToRelease}
                                    style={{ color: 'white', cursor: 'pointer' }} />
                            </LightTooltip>

                        </div>
                    </React.Fragment>
                }
                subheader={this.props.releaseData.releaseId ? "Contracts You are inside release " + this.props.releaseData.releaseId : 'Contracts'} />

            <CardContent style={{ marginTop: '2%', marginBottom: '2%' }}>
                <form onSubmit={this.savePkgDetailsHandler}>
                    <Grid container alignItems="flex-end" spacing={2}>
                        {this.state.schema.map(formElement => (
                            <Input
                                key={formElement.refName}
                                {...formElement}
                                disabled={formElement.isDisabled == 'Y' ? true : false}
                                required={formElement.isMandatory == 'Y' ? true : false}
                                value={this.state[formElement.refName]}
                                changed={(event) => {
                                    if (!event.target) {
                                        this.setState({
                                            [formElement.refName]:
                                                event
                                        })
                                    } else {
                                        if (event.target.type !== 'checkbox')
                                            this.setState({
                                                [formElement.refName]:
                                                    event.target.value
                                            })
                                        else this.setState({
                                            [formElement.refName]:
                                                event.target.checked
                                        })
                                    }
                                }}
                            />
                        ))}
                    </Grid>
                    {this.props.releaseData.releaseId && <div className={classes.center}>
                        <Button variant="outlined"
                            style={{
                                color: 'green', border: '1px solid green'
                                , marginTop: '3%'
                            }}
                            type='submit'
                        >
                            Save
                        </Button>
                    </div>}
                </form>
            </CardContent>
        </Card>

        if (this.state.loading)
            contract = <Loader />

        return contract;
    }


}


const mapStateToProps = state => {
    return {
        releaseData: state.releaseData.releaseData,
        userInfo: state.login.loggedInUserInfo,
    };
}



export default connect(mapStateToProps)(withStyles(useStyles)(WithErrorHandler(Contract, axios)));



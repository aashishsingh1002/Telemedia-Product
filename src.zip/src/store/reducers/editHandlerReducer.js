import * as actionTypes from '../actions/actionTypes';

const initialState = {
    editing:false
};



const changeEditing = (state, action) => {
    return {
        ...state,
        editing: action.editing,
    }
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.CHANGE_EDITING: return changeEditing(state, action);
        default:
            return state;
    }
};

export default reducer;

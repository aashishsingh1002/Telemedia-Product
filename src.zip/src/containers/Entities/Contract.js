import React, { Component } from 'react';
import axios from '../../axios-epc';
import Input from '../../UI/Input/Input';
import Grid from '@material-ui/core/Grid';
// import Button from "@material-ui/core/Button";
import Button from '../../UI/Button/Button';
import { withStyles } from '@material-ui/core/styles';
import Loader from '../../UI/Loader/Loader';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import moment from 'moment';
import Modal from '../../UI/Modal/Modal';
import Typography from '@material-ui/core/Typography';
import StyledButton from '../../UI/Button/Button';

const useStyles = () => ({
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alignRight: {
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
});

class Contract extends Component {
  _isMounted = false;

  state = {
    schema: [],
    version: '',
    loading: true,
    contractMap: {},
    contractProfilesMap: {},
    postRequest: true,
    show: false,
    modalContent: null,
    packageContractMapNbr: '',
    contractWatch: false,
    cntrctData: {},
  };

  componentWillUnmount() {
    this._isMounted = false;
  }
  componentDidMount() {
    this._isMounted = true;
    this.versions().then(() => {
      this.uiFields().then(() => {
        this.contractData().then(() => {
          this.state.schema.map((formElement) => {
            if (formElement.refType == 'Date')
              this.setState({
                [formElement.refName]: formElement.defaultValue
                  ? moment(formElement.defaultValue).format('DD-MMM-YY')
                  : moment().format('DD-MMM-YY'),
              });
            else if (formElement.refType == 'TextInput' || 'TextArea')
              this.setState({
                [formElement.refName]: formElement.defaultValue,
              });
          });
          this.packageData().then(() => {
            this.setState({ loading: false });
          });
        });
      });
    });
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState['contractProfileId'] !== this.state['contractProfileId']) {
      if (!this.state.contractWatch) {
        this.setState({ contractWatch: true });
      } else {
        let val = this.state['contractProfileId'];

        if (this.state.contractProfilesMap[val]) {
          let signUpFee = this.state.contractProfilesMap[val]['signUpFee'];
          let monthlyPenaltyFee =
            this.state.contractProfilesMap[val]['monthlyPenaltyFee'];
          let penaltyFixFee =
            this.state.contractProfilesMap[val]['penaltyFixFee'];
          console.log(signUpFee + monthlyPenaltyFee + penaltyFixFee + val);

          this.setState({
            signUpFee: signUpFee,
            monthlyPenaltyFee: monthlyPenaltyFee,
            penaltyFixFee: penaltyFixFee,
          });
        }
      }
    }
  }

  versions() {
    return axios
      .get('config/version?entityName=contractBundle', {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {
        if (this._isMounted) this.setState({ version: res.data.data.version });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  uiFields = () => {
    if (
      localStorage.getItem('contractBundle') &&
      localStorage.contractBundle_version &&
      localStorage.contractBundle_version == this.state.version
    ) {
      console.log('fetching from local storage');
      try {
        this.setState({
          schema: JSON.parse(localStorage.getItem('contractBundle')),
        });
      } catch (e) {
        localStorage.removeItem('contractBundle');
      }
      return Promise.resolve();
    } else {
      console.log('fetching from api');
      return axios
        .get('config?entityName=contractBundle', {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          },
        })
        .then((res) => {
          let schema = res.data.data;
          schema = schema.filter(function (el) {
            if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });
          if (this._isMounted) this.setState({ schema: schema });

          localStorage.setItem('contractBundle', JSON.stringify(schema));
          localStorage.contractBundle_version = this.state.version;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  };

  contractData() {
    if (this.props.releaseData.releaseId) {
      return axios
        .get('package/contract?releaseId=' + this.props.releaseData.releaseId, {
          headers: {
            opId: this.props.userInfo.opId,
          },
        })
        .then((res) => {
          console.log(res);

          let schema = [...this.state.schema];
          schema.map((el) => {
            if (el.refName == 'contractId') {
              el.refLovs = Object.keys(res.data.data.contractMap);
            }
            if (el.refName == 'contractProfileId') {
              el.refLovs = Object.keys(res.data.data.contractProfilesMap);
            }
          });
          this.setState({
            contractMap: res.data.data.contractMap,
            contractProfilesMap: res.data.data.contractProfilesMap,
            schema: schema,
          });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      return Promise.resolve();
    }
  }
  errorConfirmedHandler = () => {
    this.setState({ show: false });
  };

  savePkgContractDetailsHandler = (event) => {
    event.preventDefault();
    if (this.props.id) {
      this.setState({ loading: true });

      let payload = {};
      let date = moment().format('DD-MMM-YY');
      let ppmPkgContractMapAud = {};
      if (this.state.packageContractMapNbr) {
        ppmPkgContractMapAud = { ...this.state.cntrctData };
      }
      this.state.schema.map((formElement) => {
        if (formElement.refType == 'Date')
          ppmPkgContractMapAud[formElement.refName] = moment(
            this.state[formElement.refName]
          ).format('DD-MMM-YY');
        else if (formElement.refType == 'Checkbox')
          ppmPkgContractMapAud[formElement.refName] = this.state[
            formElement.refName
          ]
            ? 'Y'
            : 'N';
        else if (formElement.refType == 'TextInput' || 'TextArea')
          ppmPkgContractMapAud[formElement.refName] =
            this.state[formElement.refName];
        else
          ppmPkgContractMapAud[formElement.refName] =
            this.state[formElement.refName];
      });
      ppmPkgContractMapAud.packageContractMapId =
        this.props.id + '-' + this.state.contractId;
      ppmPkgContractMapAud.packageId = this.props.id;
      ppmPkgContractMapAud.contractDesc = this.state.contractId;
      ppmPkgContractMapAud.contractDuration =
        this.state.contractMap[this.state.contractId].contractDuration;
      ppmPkgContractMapAud.contractUnits =
        this.state.contractMap[this.state.contractId].contractUnits;
      ppmPkgContractMapAud.updatedBy = this.props.userInfo.id;
      ppmPkgContractMapAud.updatedDate = date;
      ppmPkgContractMapAud.buId = this.props.userInfo.buId;
      ppmPkgContractMapAud.opId = this.props.userInfo.opId;
      ppmPkgContractMapAud.createdBy = this.props.userInfo.id;
      ppmPkgContractMapAud.createdDate = date;
      payload.releaseId = this.props.releaseData.releaseId;
      console.log(payload);
      if (!this.state.packageContractMapNbr) {
        console.log('post');
        ppmPkgContractMapAud.version = '1.0';
        payload.ppmPkgContractMapAud = ppmPkgContractMapAud;

        axios
          .post('package/contract/id', payload)
          .then((response) => {
            console.log(response);
            if (this._isMounted)
              this.setState({
                loading: false,
                cntrctData: response.data.data,
                packageContractMapNbr: response.data.data.packageContractMapNbr,
              });
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      } else {
        console.log('put request');
        ppmPkgContractMapAud.packageContractMapNbr =
          this.state.packageContractMapNbr;
        payload.ppmPkgContractMapAud = ppmPkgContractMapAud;
        axios
          .post('package/contract/id/update', payload)
          .then((response) => {
            console.log(response);
            if (this._isMounted)
              this.setState({
                loading: false,
                packageContractMapNbr: response.data.data.packageContractMapNbr,
                cntrctData: response.data.data,
              });
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      }
    } else {
      let modalContent = (
        <Typography variant='h6'>
          {' '}
          Submit Basic {this.props.entity} Details first.{' '}
        </Typography>
      );
      this.setState({ modalContent: modalContent, show: true });
    }
  };

  packageData() {
    if (this.props.releaseData.releaseId) {
      if (this.props.id) {
        return axios
          .get(
            'package/contract/id?packageId=' +
              this.props.id +
              '&releaseID=' +
              this.props.releaseData.releaseId
          )
          .then((res) => {
            console.log('package contract');
            console.log(res);
            if (this._isMounted) {
              this.setState({
                postRequest: false,
                contractWatch: false,
                cntrctData: res.data.data,
                packageContractMapNbr: res.data.data['packageContractMapNbr'],
              });

              Object.keys(res.data.data).forEach((key) => {
                this.setState({
                  [key]: res.data.data[key],
                });
              });
            }
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      } else {
        return Promise.resolve();
      }
    } else {
      return Promise.resolve();
    }
  }

  render() {
    const { classes } = this.props;

    let contract = (
      <form onSubmit={this.savePkgContractDetailsHandler}>
        <Modal
          show={this.state.show}
          modalClosed={this.errorConfirmedHandler}
          title={'Something Went Wrong!'}
        >
          {this.state.modalContent}
        </Modal>

        <Grid container alignItems='flex-end' spacing={2}>
          {this.state.schema.map((formElement) => (
            <Input
              key={formElement.refName}
              {...formElement}
              disabled={formElement.isDisabled == 'Y' ? true : false}
              required={formElement.isMandatory == 'Y' ? true : false}
              value={this.state[formElement.refName]}
              changed={(event) => {
                if (!event.target) {
                  this.setState({
                    [formElement.refName]: event,
                  });
                } else {
                  if (event.target.type !== 'checkbox')
                    this.setState({
                      [formElement.refName]: event.target.value,
                    });
                  else
                    this.setState({
                      [formElement.refName]: event.target.checked,
                    });
                }
              }}
            />
          ))}
        </Grid>
        {this.props.releaseData.releaseId && (
          <div className={classes.alignRight}>
            <StyledButton
              //   variant="contained"
              style={{
                // background: "#02bfa0",
                textTransform: 'none',
                marginTop: '3%',
                background: '#5dc17f',
              }}
              type='submit'
            >
              Save
            </StyledButton>
          </div>
        )}
      </form>
    );

    if (this.state.loading) contract = <Loader relative />;
    return contract;
  }
}

export default withStyles(useStyles)(WithErrorHandler(Contract, axios));

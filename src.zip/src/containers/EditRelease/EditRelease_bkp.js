import React, { Component } from 'react';
import { connect } from 'react-redux';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import Loader from '../../UI/Loader/Loader';
import BasicDetails from './BasicDetails';
import Box from '@material-ui/core/Box';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Divider from '@material-ui/core/Divider';
import { withStyles } from '@material-ui/core/styles';
import ProductsData from './ProductsData';
import PricingData from './PricingData';
import AttributesData from './AttributesData';
import OfferabilityData from './OfferabilityData';
import ContractData from './ContractData';
import TextField from '@material-ui/core/TextField';
import AddIcon from '@material-ui/icons/Add';
import * as actionTypes from '../../store/actions/actionTypes';
import DeleteIcon from '@material-ui/icons/Delete';
import ModalAction from '../../UI/ModalAction/ModalAction';
import SubdirectoryArrowRightIcon from '@material-ui/icons/SubdirectoryArrowRight';
import Popover from '@material-ui/core/Popover';
import CardActions from '@material-ui/core/CardActions';
import Button from '@material-ui/core/Button';
import Autocomplete from '@material-ui/lab/Autocomplete';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Modal from '../../UI/Modal/Modal';
import { IconButton, Paper } from '@material-ui/core';
import InputBase from '@material-ui/core/InputBase';

import SearchIcon from '@material-ui/icons/Search';

const useStyles = (theme) => ({
  cardHeader: {
    background: '#546D7A',
    height: '4.5vh',
  },
  subheader: {
    color: 'white',
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    // flexBasis: "95%",
    // flexShrink: 0,
  },
});

class EditRelease extends Component {
  _isMounted = false;
  state = {
    error: false,
    loading: true,
    releaseDetails: {},
    expanded: false,
    version: '',
    offerKeys: [],
    schema: [],
    refUiMap: {},
    searchPkg: '',
    searchGenPro: '',
    packages: [],
    genericProducts: [],
    anchorEl: null,
    anchorElPkg: null,
    prdId: null,
    pkgId: null,
    entityContent:null,
    // otherEntitiesMap: {
    //     "PpmAttributes": 'Attribute',
    //     "PpmAttrGroups": 'Attribute Group',
    //     "products": 'Product',
    //     "Contracts": 'Contract',
    //     "RatePlan": "Rate Plan",
    // },
    otherEntitiesMap: {
      Attributes: 'PpmAttributes',
      'Attribute Groups': 'PpmAttrGroups',
      Products: 'products',
      Contracts: 'Contracts',
      'Rate Plans': 'RatePlan',
    },
    otherEntitiesUrlMap: {
      Attributes: '/attributeConfiguration',
      'Attribute Groups': '/attributeConfiguration',
      Contracts: '/contractsCreation',
      'Rate Plans': '/ratePlanConfiguration',
    },
    selOtherEntity: null,
  };
  componentWillUnmount() {
    this._isMounted = false;
  }

  

  versions() {
    return axios
      .get('package/config/version?entityName=offerability', {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {
        console.log('version is' + res.data.data.version);
        this.setState({ version: res.data.data.version });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  uiFields() {
    if (
      localStorage.getItem('offerability') &&
      localStorage.getItem('offerabilityKeys') &&
      localStorage.offerability_version &&
      localStorage.offerability_version == this.state.version
    ) {
      console.log('fetching from local storage');
      try {
        this.setState({
          schema: JSON.parse(localStorage.getItem('offerability')),
          offerKeys: JSON.parse(localStorage.getItem('offerabilityKeys')),
          refUiMap: JSON.parse(localStorage.getItem('offerabilityUiRefMap')),
        });
      } catch (e) {
        localStorage.removeItem('offerability');
        localStorage.removeItem('offerabilityKeys');
        localStorage.removeItem('offerabilityUiRefMap');
      }
      return Promise.resolve();
    } else {
      console.log('fetching from api');
      return axios
        .get('package/config?entityName=offerability', {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
            Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        })
        .then((res) => {
          let schema = [];
          schema = res.data.data.map(function (el) {
            if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });

          let offerKeys = [];
          let refUiMap = {};
          console.log(res.data.data);
          res.data.data.forEach((el) => {
            let offerabilityType = {};
            offerabilityType.value = el.refLovs ? el.refLovs : '';
            offerabilityType.type = el.refType;
            offerKeys.push(el.refName);
            refUiMap[el.refName] = el.uiName;
          });

          this.setState({
            schema: schema,
            offerKeys: offerKeys,
            refUiMap: refUiMap,
          });
          localStorage.setItem('offerability', JSON.stringify(schema));
          localStorage.setItem('offerabilityKeys', JSON.stringify(offerKeys));
          localStorage.setItem(
            'offerabilityUiRefMap',
            JSON.stringify(refUiMap)
          );
          localStorage.offerability_version = this.state.version;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  releaseDataHandler = () => {
    return axios
      .get('ratePlan/edit?releaseId=' + this.props.releaseData.releaseId, {
        headers: {
          Accept: 'application/json,text/plan,*/*',
          buId: this.props.userInfo.buId,
          channelId: 'CSA',
          language: 'ENG',
          opId: this.props.userInfo.opId,
        },
      })
      .then((res) => {
        console.log('release data');
        if (res) {
          let getCurrentReleaseData = res.data.data;
          if (getCurrentReleaseData.genericProducts == null)
            getCurrentReleaseData.genericProducts = [];
          else {
            let genericProducts = [];
            let products = [];
            getCurrentReleaseData.genericProducts.map((pro) => {
              if (pro.alaCarte == 'Y') genericProducts.push(pro);
              else products.push(pro);
            });

            getCurrentReleaseData.genericProducts = genericProducts;
            getCurrentReleaseData.otherentities = {
              ...getCurrentReleaseData.otherentities,
              products: products,
            };
          }
          if (getCurrentReleaseData.packages == null)
            getCurrentReleaseData.packages = [];

          if (this._isMounted)
            this.setState({
              loading: false,
			  releaseDetails: getCurrentReleaseData,
			  products: [...getCurrentReleaseData.otherentities.products],
              packages: [...getCurrentReleaseData.packages],
              genericProducts: [...getCurrentReleaseData.genericProducts],
            });
          console.log('mounted');
          console.log(getCurrentReleaseData);
        } else this.setState({ loading: false, error: true });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };
  changeHandler = (panel) => (event, isExpanded) => {
    this.setState({ expanded: isExpanded ? panel : false });
  };
  componentDidMount = () => {
    this._isMounted = true;
    this.setState({ loading: true });
    this.releaseDataHandler().then(() => {
      this.versions().then(() => {
        this.uiFields().then(() => {
          if (this._isMounted) {
            this.setState({ loading: false });
            console.log(this.state.refUiMap);
          }
        });
      });
    });
  };

  searchPkgHandler = (event) => {
    this.setState({ searchPkg: event.target.value });
    let packages = [];
    if (event.target.value.length == 0) {
      packages = [...this.state.releaseDetails.packages];
      this.setState({ packages: packages });
    } else {
      packages = this.state.releaseDetails.packages.filter(function (item) {
        return (
          item.packageId
            .toUpperCase()
            .includes(event.target.value.toUpperCase()) ||
          item.packageName
            .toUpperCase()
            .includes(event.target.value.toUpperCase())
        );
      });
      this.setState({ packages: packages });
    }
  };

  searchGenProHandler = (event) => {
    this.setState({ searchGenPro: event.target.value });
    let genPro = [];
    if (event.target.value.length == 0) {
      genPro = [...this.state.releaseDetails.genericProducts];
      this.setState({ genericProducts: genPro });
    } else {
      genPro = this.state.releaseDetails.genericProducts.filter(function (
        item
      ) {
        return (
          item.productId
            .toUpperCase()
            .includes(event.target.value.toUpperCase()) ||
          item.productName
            .toUpperCase()
            .includes(event.target.value.toUpperCase())
        );
      });
      this.setState({ genericProducts: genPro });
    }
  };

  deletePkgHandler = () => {
    this.setState({ loading: true });
    axios
      .get(
        'package/basicDetails/delete?id=' +
          this.state.pkgId +
          '&releaseID=' +
          this.props.releaseData.releaseId,
        {
          headers: {
            opId: this.props.userInfo.opId,
          },
        }
      )
      .then((response) => {
        console.log(response);
        if (response) {
          if (this._isMounted)
            this.setState((prevState) => ({
              packages: prevState.packages.filter((pkg) => {
                return pkg.packageId !== prevState.pkgId;
              }),
              loading: false,
              anchorElPkg: null,
            }));
        } else {
          this.setState({
            loading: false,
            anchorElPkg: null,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted)
          this.setState({ loading: false, anchorElPkg: null });
      });
  };

  deleteProHandler = () => {
    this.setState({ loading: true });
    axios
      .get(
        'product/basicDetails/delete?id=' +
          this.state.prdId +
          '&releaseID=' +
          this.props.releaseData.releaseId,
        {
          headers: {
            opId: this.props.userInfo.opId,
          },
        }
      )
      .then((response) => {
        console.log(response);
        if (response) {
          if (this._isMounted)
            this.releaseDataHandler().then(() => {
              this.setState({
                loading: false,
                anchorEl: null,
              });
            });
        } else {
          this.setState({
            loading: false,
            anchorEl: null,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false, anchorEl: null });
      });
  };

  errorConfirmedHandler = () => {
    this.setState({ error: false });
  };

  onChangeEntity = (selOtherEntity) => {
    if(selOtherEntity) {
      const entityContent = (
				<div style={{margin: '2rem 0 0 0'}}>
					<div
						style={{
							fontSize: '22px',
							fontWeight: 'bold',
							marginBottom: '1rem',
							display: 'flex',
              width:'1rem'
						}}>
						<div style={{ flexGrow: 1 }}>
							<span style={{ display: 'block', lineHeight: 1,}}>
								{selOtherEntity}
							</span>
							
						</div>
						{/*<div>
							<Paper
								component="form"
								style={{
									height: '44px',
									borderRadius: '50px',
									boxShadow: 'none',
									padding: '4px 6px 4px 24px',
									display: 'flex',
									alignItems: 'center',
								}}>
								<InputBase
									variant="outlined"
									style={{
										// borderRadius: "50px",
										background: '#fff',
										// padding: "4px 24px",
										width: '320px',
									}}
									placeholder={`Search ${selOtherEntity}`}
									value={this.state[`search${this.state.otherEntitiesMap[selOtherEntity]}`]}
									onChange={this.searchPkgHandler}
								/>
								<IconButton aria-label="search" disabled>
									<SearchIcon />
								</IconButton>
							</Paper>
						</div>

						<Button
							style={{
								//  background: '#000',
								color: '#fff',
								borderRadius: '50px',
								marginLeft: '16px',
								textTransform: 'capitalize',
								padding: '4px 32px',
								height: '44px',
								background: '#5dc17f',
							}}
							onClick={() => {
								this.props.changePackageActiveStep(0);
								this.props.onPackageEnter({});
								this.props.history.push('/planConfiguration');
							}}>
							Create
						</Button> */}
					</div>
					<div
						style={{
							background: '#fff',
							borderRadius: '5px',
							padding: '20px',
							boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.08)',
						}}>
						{Object.keys(this.state.releaseDetails).length > 0 &&
							this.state.releaseDetails.otherentities[
							this.state.otherEntitiesMap[selOtherEntity]
							].length > 0 ? (
								selOtherEntity == "Products" ?
								(this.state.releaseDetails.otherentities[
									this.state.otherEntitiesMap[selOtherEntity]
								].map((entity) => {
									return (
										<Accordion
											key={entity.productId}
											expanded={this.state.expanded === entity.productId}
										>
											<AccordionSummary
												aria-controls="panel1bh-content"
												id="panel1bh-header"
												style={{ minHeight: 48 }}>
												<Typography>{entity.productName}</Typography>
												<div style={{ marginLeft: 'auto' }}>
													<SubdirectoryArrowRightIcon
														onClick={(event) => {
															event.stopPropagation();
															this.props.changeProductActiveStep(0);
															this.props.onProductEnter(entity);
															this.props.history.push(
																'/productConfiguration'
															);
														}}
														style={{
															color: '#000',
															
														}}
													/>
												</div>
											</AccordionSummary>
										</Accordion>
										);
							})
						) : (this.state.releaseDetails.otherentities[
								this.state.otherEntitiesMap[selOtherEntity]
						  ].map((entity) => {
								return (		<Accordion
									key={entity.entityId}
									expanded={this.state.expanded === entity.entityId}
								>
									<AccordionSummary
										aria-controls="panel1bh-content"
										id="panel1bh-header"
										style={{ minHeight: 48 }}>
										<Typography>{entity.entityName}</Typography>
										<div style={{ marginLeft: 'auto' }}>
											<SubdirectoryArrowRightIcon
												onClick={(event) => {
													event.stopPropagation();
												}}
												style={{
													color: '#000',
													
												}}
											/>
										</div>
									</AccordionSummary>
								</Accordion>
							);
						})
					) 
					) 

	 : (
							<React.Fragment>
								<Typography
								// style={{ fontWeight: "bold", fontSize: "18px" }}
								>
									There are no {selOtherEntity} added on this release yet.
								</Typography>
							</React.Fragment>
						)}
					</div>
				</div>
			);
      this.setState({entityContent , selOtherEntity})
      
    } else {
      this.setState({entityContent: null , selOtherEntity: null})
    }
  }

  render() {
    const { classes } = this.props;

    let editRelease = <Loader />;
    const open = Boolean(this.state.anchorEl);
    const openPkg = Boolean(this.state.anchorElPkg);
    const id = open ? 'simple-popover' : undefined;
    const idPkg = openPkg ? 'simple-popover-pkg' : undefined;

    if (!this.state.loading)
      editRelease = (
				<React.Fragment>
					<Modal
						show={this.state.error}
						modalClosed={this.errorConfirmedHandler}
						title={'Something Went Wrong!'}>
						{this.state.error ? (
							<Typography variant="h6">
								Api Details:
								{'ratePlan/edit?releaseId=' + this.props.releaseData.releaseId}
							</Typography>
						) : null}
					</Modal>
					<Popover
						id={id}
						open={open}
						anchorEl={this.state.anchorEl}
						onClose={() => {
							this.setState({
								anchorEl: null,
							});
						}}
						anchorOrigin={{
							vertical: 'bottom',
							horizontal: 'left',
						}}
						transformOrigin={{
							vertical: 'top',
							horizontal: 'right',
						}}>
						<Card>
							<CardHeader
								className={classes.cardHeader}
								classes={{
									subheader: classes.subheader,
								}}
								subheader={
									'Do you want to remove ' +
									this.state.prdId +
									' from this release?'
								}
							/>
							<CardContent style={{ padding: '4px' }}>
								<div
									style={{
										marginTop: '10px',
										display: 'flex',
										justifyContent: 'flex-end',
									}}>
									<Button
										size="small"
										color="primary"
										style={{
											textTransform: 'none',
										}}
										onClick={() => {
											this.setState({
												anchorEl: null,
											});
										}}>
										Close
									</Button>
									<Button
										size="small"
										color="primary"
										style={{
											textTransform: 'none',
										}}
										onClick={this.deleteProHandler}>
										Ok
									</Button>
								</div>
							</CardContent>
						</Card>
					</Popover>

					<Popover
						id={idPkg}
						open={openPkg}
						anchorEl={this.state.anchorElPkg}
						onClose={() => {
							this.setState({
								anchorElPkg: null,
							});
						}}
						anchorOrigin={{
							vertical: 'bottom',
							horizontal: 'left',
						}}
						transformOrigin={{
							vertical: 'top',
							horizontal: 'right',
						}}>
						<Card>
							<CardHeader
								className={classes.cardHeader}
								classes={{
									subheader: classes.subheader,
								}}
								subheader={
									'Do you want to remove ' +
									this.state.pkgId +
									' from this release?'
								}
							/>
							<CardContent style={{ padding: '4px' }}>
								<div
									style={{
										marginTop: '10px',
										display: 'flex',
										justifyContent: 'flex-end',
									}}>
									<Button
										size="small"
										color="primary"
										style={{
											textTransform: 'none',
										}}
										onClick={() => {
											this.setState({
												anchorElPkg: null,
											});
										}}>
										Close
									</Button>

									<Button
										size="small"
										color="primary"
										style={{
											textTransform: 'none',
										}}
										onClick={this.deletePkgHandler}>
										Ok
									</Button>
								</div>
							</CardContent>
						</Card>
					</Popover>

					<BasicDetails
						releaseData={this.props.releaseData}
						userInfo={this.props.userInfo}
					/>

					{/* NEW RENDER */}
					<div
						style={{
							padding: '0 40px',
							marginBottom: '40px',
							marginTop: '2%',
						}}>
						<div
							style={{
								fontSize: '22px',
								fontWeight: 'bold',
								marginBottom: '10px',
								display: 'flex',
							}}>
							<div style={{ flexGrow: 1 }}>
								<Autocomplete
									clearOnEscape
									value={this.state.selOtherEntity}
									onChange={(event, val) =>
										this.onChangeEntity(val)
									}
									options={Object.keys(this.state.otherEntitiesMap)}
									renderInput={(params) => (
										<div ref={params.InputProps.ref} style={{width:'10rem',margin:' 0 0 0 auto',
                    textAlign: 'right',}}>
											<input
												style={{
                          autosize:true,
										 background: 'white',
										color: 'black',
										borderRadius: '50px',
                    float: 'right',
										margin: '1rem 0',
                    // marginLeft:'50em',
										textTransform: 'capitalize',
										padding: '4px 32px',
										height: '44px',
										// background: '#5dc17f',
									}}
												type="text"
												{...params.inputProps}
												placeholder="Entities"
											/>
										</div>
									)}
								/>
                
								{this.state.selOtherEntity && this.state.entityContent ? (
									this.state.entityContent
								) : (
									<>
										<span style={{ display: 'block', lineHeight: 3, }}>
											Item Details
										</span>
										<span style={{ fontSize: '14px', fontWeight: 'normal' }}>
											Add new Entities for this release
										</span>
									</>
								)}
							</div>
							
						</div>
					</div>

					<div style={{ margin: '50px 0' }}>
						<div style={{ padding: '0 40px', marginBottom: '40px' }}>
							<div
								style={{
									fontSize: '22px',
									fontWeight: 'bold',
									marginBottom: '10px',
									display: 'flex',
								}}>
								<div style={{ flexGrow: 1 }}>
									<span style={{ display: 'block', lineHeight: 1 }}>
										Packages
									</span>
									<span style={{ fontSize: '14px', fontWeight: 'normal' }}>
										Search or create new package for this release
									</span>
								</div>
								<div>
									<Paper
										component="form"
										style={{
											height: '44px',
											borderRadius: '50px',
											boxShadow: 'none',
											padding: '4px 6px 4px 24px',
											display: 'flex',
											alignItems: 'center',
										}}>
										<InputBase
											variant="outlined"
											style={{
												// borderRadius: "50px",
												background: '#fff',
												// padding: "4px 24px",
												width: '320px',
											}}
											placeholder="Search Packages"
											value={this.state.searchPkg}
											onChange={this.searchPkgHandler}
										/>
										<IconButton aria-label="search" disabled>
											<SearchIcon />
										</IconButton>
									</Paper>
								</div>

								<Button
									style={{
										//  background: '#000',
										color: '#fff',
										borderRadius: '50px',
										marginLeft: '16px',
										textTransform: 'capitalize',
										padding: '4px 32px',
										height: '44px',
										background: '#5dc17f',
									}}
									onClick={() => {
										this.props.changePackageActiveStep(0);
										this.props.onPackageEnter({});
										this.props.history.push('/planConfiguration');
									}}>
									Create
								</Button>
							</div>
							<div
								style={{
									background: '#fff',
									borderRadius: '5px',
									padding: '20px',
									boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.08)',
								}}>
								{this.state.packages.length > 0 ? (
									this.state.packages.map((pkg) => {
										return (
											<Accordion
												key={pkg.packageId}
												expanded={this.state.expanded === pkg.packageId}
												onChange={this.changeHandler(pkg.packageId)}>
												<AccordionSummary
													aria-controls="panel1bh-content"
													id="panel1bh-header"
													style={{ minHeight: 48 }}>
													<ExpandMoreIcon />
													<Typography className={classes.heading}>
														{pkg.packageName}
													</Typography>
													<div style={{ marginLeft: 'auto' }}>
														<SubdirectoryArrowRightIcon
															onClick={(event) => {
																event.stopPropagation();
																this.props.changePackageActiveStep(0);
																this.props.onPackageEnter(pkg);
																this.props.history.push('/planConfiguration');
															}}
															style={{
																color: '#000',
																// marginRight: "10px",
															}}
														/>
														<DeleteIcon
															// style={{ color: "red" }}
															style={{ color: 'red', cursor: 'pointer' }}
															onClick={(event) => {
																event.stopPropagation();
																this.setState({
																	pkgId: pkg.packageId,
																	anchorElPkg: event.currentTarget,
																});
															}}
														/>
													</div>
												</AccordionSummary>
												<AccordionDetails style={{ display: 'block' }}>
													{pkg.attribute != null &&
														Object.keys(pkg.attribute).length > 0 && (
															<AttributesData attribute={pkg.attribute} />
														)}
													{pkg.products != null && pkg.products.length > 0 && (
														<ProductsData products={pkg.products} />
													)}
													{pkg.pricing && pkg.pricing.length > 0 && (
														<PricingData pricing={pkg.pricing} />
													)}
													{pkg.offerability && (
														<OfferabilityData
															offerability={pkg.offerability}
															refUiMap={this.state.refUiMap}
														/>
													)}
													{pkg.contract &&
														Object.keys(pkg.contract).length > 0 && (
															<ContractData contract={pkg.contract} />
														)}
												</AccordionDetails>
											</Accordion>
										);
									})
								) : (
									<React.Fragment>
										<Typography
										// style={{ fontWeight: "bold", fontSize: "18px" }}
										>
											There are no packages added on this release yet.
										</Typography>
									</React.Fragment>
								)}
							</div>
						</div>
						<div style={{ padding: '0 40px' }}>
							<div
								style={{
									fontSize: '22px',
									fontWeight: 'bold',
									display: 'flex',
								}}>
								<div style={{ flexGrow: '1' }}>
									<span style={{ display: 'block', lineHeight: 1 }}>
										Generic Products
									</span>
									<span style={{ fontSize: '14px', fontWeight: 'normal' }}>
										Search or create product for this release
									</span>
								</div>
								<div>
									<Paper
										component="form"
										style={{
											height: '44px',
											borderRadius: '50px',
											boxShadow: 'none',
											padding: '4px 6px 4px 24px',
											display: 'flex',
											alignItems: 'center',
										}}>
										<InputBase
											variant="outlined"
											style={{
												// borderRadius: "50px",
												background: '#fff',
												// padding: "4px 24px",
												width: '320px',
											}}
											placeholder="Search Generic Products"
											value={this.state.searchGenPro}
											onChange={this.searchGenProHandler}
										/>
										<IconButton aria-label="search" disabled>
											<SearchIcon />
										</IconButton>
									</Paper>
								</div>

								<Button
									style={{
										background: '#5dc17f',
										//  background: '#000',
										color: '#fff',
										borderRadius: '50px',
										marginLeft: '16px',
										textTransform: 'capitalize',
										padding: '4px 32px',
										height: '44px',
									}}
									onClick={() => {
										this.props.changeProductActiveStep(0);
										this.props.onProductEnter({});
										this.props.history.push('/productConfiguration');
									}}>
									Create
								</Button>
							</div>
							<div
								style={{
									background: '#fff',
									borderRadius: '5px',
									padding: '20px',
									boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.08)',
								}}>
								{this.state.genericProducts.length > 0 ? (
									this.state.genericProducts.map((genPro) => {
										return (
											<Accordion
												key={genPro.productId}
												expanded={this.state.expanded === genPro.productId}
												onChange={this.changeHandler(genPro.productId)}>
												<AccordionSummary
													aria-controls="panel1bh-content"
													id="panel1bh-header">
													<ExpandMoreIcon />
													<Typography className={classes.heading}>
														{genPro.productName}
													</Typography>
													<div style={{ marginLeft: 'auto' }}>
														<SubdirectoryArrowRightIcon
															onClick={(event) => {
																event.stopPropagation();
																this.props.changeProductActiveStep(0);
																this.props.onProductEnter(genPro);
																this.props.history.push(
																	'/productConfiguration'
																);
															}}
														/>
														<DeleteIcon
															style={{ color: 'red', cursor: 'pointer' }}
															onClick={(event) => {
																event.stopPropagation();
																this.setState({
																	prdId: genPro.productId,
																	anchorEl: event.currentTarget,
																});
															}}
														/>
													</div>
												</AccordionSummary>
												<AccordionDetails style={{ display: 'block' }}>
													{genPro.attribute != null &&
														Object.keys(genPro.attribute).length > 0 && (
															<AttributesData attribute={genPro.attribute} />
														)}
													{genPro.pricing && genPro.pricing.length > 0 && (
														<PricingData pricing={genPro.pricing} />
													)}
													{genPro.offerability && (
														<OfferabilityData
															offerability={genPro.offerability}
															refUiMap={this.state.refUiMap}
														/>
													)}
													{genPro.contract &&
														Object.keys(genPro.contract).length > 0 && (
															<ContractData contract={genPro.contract} />
														)}
												</AccordionDetails>
											</Accordion>
										);
									})
								) : (
									<React.Fragment>
										<Typography
										// style={{ fontWeight: "bold", fontSize: "18px" }}
										>
											There are no products added on this release yet.
										</Typography>
									</React.Fragment>
								)}
							</div>
						</div>
					</div>
					{/* END NEW RENDER */}
				</React.Fragment>
			);

    return editRelease;
  }
}

const mapStateToProps = (state) => {
  return {
    releaseData: state.releaseData.releaseData,
    userInfo: state.login.loggedInUserInfo,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onPackageEnter: (packageData) =>
      dispatch({ type: actionTypes.INSIDE_PACKAGE, packageData: packageData }),
    changePackageActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
        activeStep: activeStep,
      }),
    onProductEnter: (productData) =>
      dispatch({ type: actionTypes.INSIDE_PRODUCT, productData: productData }),
    changeProductActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP,
        activeStep: activeStep,
      }),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(EditRelease, axios)));

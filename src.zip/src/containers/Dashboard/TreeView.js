import React, { Component } from 'react';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import TreeView from '@material-ui/lab/TreeView';
import TreeItem from '@material-ui/lab/TreeItem';
import Typography from '@material-ui/core/Typography';
import Label from '@material-ui/icons/Label';
import LocalOfferIcon from '@material-ui/icons/LocalOffer';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
import ArrowRightIcon from '@material-ui/icons/ArrowRight';
import Modal from '../../UI/Modal/Modal';
import Loader from '../../UI/Loader/Loader';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../axios-epc';
import LibraryBooksIcon from '@material-ui/icons/LibraryBooks';
import BrightnessAutoIcon from '@material-ui/icons/BrightnessAuto';
import ExtensionIcon from '@material-ui/icons/Extension';
import MonetizationOnIcon from '@material-ui/icons/MonetizationOn';
import MenuBookIcon from '@material-ui/icons/MenuBook';
import FolderIcon from '@material-ui/icons/Folder';
import StoreIcon from '@material-ui/icons/Store';
import MoneyIcon from '@material-ui/icons/Money';
import CurrencyRupeeIcon from '@mui/icons-material/CurrencyRupee';
import { Tooltip } from '@mui/material';

const useTreeItemStyles = makeStyles((theme) => ({
    root: {
        color: theme.palette.text.secondary,
        '&:hover > $content': {
            backgroundColor: theme.palette.action.hover,
        },
        '&:focus > $content, &$selected > $content': {
            backgroundColor: `var(--tree-view-bg-color, ${theme.palette.grey[400]})`,
            color: 'var(--tree-view-color)',
        },
        '&:focus > $content $label, &:hover > $content $label, &$selected > $content $label': {
            backgroundColor: 'transparent',
        },
    },
    content: {
        color: theme.palette.text.secondary,
        borderTopRightRadius: theme.spacing(2),
        borderBottomRightRadius: theme.spacing(2),
        paddingRight: theme.spacing(1),
        fontWeight: theme.typography.fontWeightMedium,
        '$expanded > &': {
            fontWeight: theme.typography.fontWeightRegular,
        },
    },
    group: {
        marginLeft: 0,
        '& $content': {
            paddingLeft: theme.spacing(2),
        },
    },
    expanded: {},
    selected: {},
    label: {
        fontWeight: 'inherit',
        color: 'inherit',
    },
    labelRoot: {
        display: 'flex',
        alignItems: 'center',
        padding: theme.spacing(0.5, 0),
    },
    labelIcon: {
        marginRight: theme.spacing(1),
    },
    labelText: {
        fontWeight: 'inherit',
        flexGrow: 1,
    },
    iconContainer: {
        '& .close': {
            opacity: 0.3,
        },
    },
    group: {
        marginLeft: 7,
        paddingLeft: 18,
        borderLeft: `1px dashed #546D7A`,
    },
}));

function StyledTreeItem(props) {
    const classes = useTreeItemStyles();
    const { labelText, labelIcon: LabelIcon, labelInfo, color, bgColor, iconColor, ...other } = props;

    return (
        <TreeItem
            label={
                <div className={classes.labelRoot}>
                    <LabelIcon style={{ color: iconColor }} className={classes.labelIcon} />
                    <Typography variant="body2" className={classes.labelText}>
                        {labelText}
                    </Typography>
                  
                        <Tooltip
                        title= {labelInfo  && labelInfo.replace('ANY','ALL').replace('1024 MBPS','1 GBPS')}>
                        <span style={{float:'right',width:'25%'}}>


    
 {labelInfo ? labelInfo.length > 20
    ? labelInfo.replace('ANY','ALL').replace('1024 MBPS','1 GBPS').substring(0, 20) + '...'
    : labelInfo  && labelInfo.replace('ANY','ALL').replace('1024 MBPS','1 GBPS')
  : ''}
                        </span>
                      
                        </Tooltip>
                    
                </div>
            }
            style={{
                '--tree-view-color': color,
                '--tree-view-bg-color': bgColor,
            }}
            classes={{
                root: classes.root,
                content: classes.content,
                expanded: classes.expanded,
                selected: classes.selected,
                group: classes.group,
                label: classes.label,
            }}
            {...other}
        />
    );
}

const useStyles = (theme) => ({
    root: {
        height: 264,
        flexGrow: 1,
        maxWidth: 400,
    },
});

class ReleaseTreeView extends Component {
    _isMounted = false;

    state = {
        show: true,
        loading: true,
        releaseDetails: {},
        genericProducts: [],
        packages: [],
        version: '',
        offerKeys: [],
        schema: [],
        refUiMap: {},
    }

    componentWillUnmount() {
        this._isMounted = false;
    }
    componentDidMount() {
        this._isMounted = true;
        this.getReleaseDetails().then(() => {
            this.versions().then(() => {
                this.uiFields().then(() => {
                    this.setState({ loading: false });

                })
            })
        })

    }

    versions() {
        return axios
            .get(
                "package/config/version?entityName=offerability",
                {
                    headers: {
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId

                    }
                }
            )
            .then(res => {
                console.log("version is" + res.data.data.version);
                this.setState({ version: res.data.data.version })
            })
            .catch(error => {
                console.log(error);
                if (this._isMounted)
                    this.setState({ loading: false });

            });
    }

    uiFields() {
        if (
            localStorage.getItem("offerability") &&
            localStorage.getItem("offerabilityKeys") &&
            localStorage.offerability_version &&
            localStorage.offerability_version == this.state.version
        ) {
            console.log("fetching from local storage");
            try {
                this.setState({
                    schema: JSON.parse(localStorage.getItem("offerability")),
                    offerKeys: JSON.parse(localStorage.getItem("offerabilityKeys")),
                    refUiMap: JSON.parse(
                        localStorage.getItem("offerabilityUiRefMap"))
                });
            } catch (e) {
                localStorage.removeItem("offerability");
                localStorage.removeItem("offerabilityKeys");
                localStorage.removeItem("offerabilityUiRefMap");
            }
            return Promise.resolve();
        } else {
            console.log("fetching from api");
            return axios
                .get("package/config?entityName=offerability", {
                    headers: {
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId
                    }
                })
                .then(res => {
                    let schema = []
                    schema = res.data.data.map(function (el) {
                        if (el.refType == "SelectInput" || el.refType == "MultiSelect") {
                            if (el.refLovs != null) el.refLovs = el.refLovs.split(",");
                            else if (el.refLovs == null) el.refLovs = [];
                        }
                        return el;
                    });

                    let offerKeys = []
                    let refUiMap = {}
                    console.log(res.data.data)
                    res.data.data.forEach((el) => {
                        let offerabilityType = {};
                        offerabilityType.value = el.refLovs ? el.refLovs : "";
                        offerabilityType.type = el.refType;
                        offerKeys.push(el.refName);
                        refUiMap[el.refName] = el.uiName;
                    });

                    this.setState({
                        schema: schema,
                        offerKeys: offerKeys,
                        refUiMap: refUiMap
                    });
                    localStorage.setItem("offerability", JSON.stringify(schema));
                    localStorage.setItem(
                        "offerabilityKeys",
                        JSON.stringify(offerKeys)
                    );
                    localStorage.setItem(
                        "offerabilityUiRefMap",
                        JSON.stringify(refUiMap)
                    );
                    localStorage.offerability_version = this.state.version;
                })
                .catch(error => {
                    console.log(error);
                    if (this._isMounted)
                        this.setState({ loading: false });

                });
        }
    }


  getData(bytes){

      bytes = bytes * 1024;
          var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
          if (bytes == 0) return '0 Byte';
          var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
          return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
       
  }

    getReleaseDetails() {
        return axios
            .get(
                "ratePlan/edit?releaseId=" +
                this.props.releaseData.releaseId,
                {
                    headers: {
                        Accept: "application/json,text/plan,*/*",
                        buId: this.props.userInfo.buId,
                        channelId: "CSA",
                        language: "ENG",
                        opId: this.props.userInfo.opId
                    }
                }
            )
            // .then(res => {
            //     console.log("release data");
            //     let getCurrentReleaseData = res.data.data;
            //     if (getCurrentReleaseData.genericProducts == null)
            //         getCurrentReleaseData.genericProducts = [];
            //     else {
            //         let genericProducts = []
            //         let products = []
            //         getCurrentReleaseData.genericProducts.map(pro => {
            //             if (pro.alaCarte == 'Y')
            //                 genericProducts.push(pro)
            //             else
            //                 products.push(pro)
            //         })

            //         getCurrentReleaseData.genericProducts = genericProducts
            //         getCurrentReleaseData.otherentities = {
            //             ...getCurrentReleaseData.otherentities,
            //             products: products
            //         }
            //     }
            //     if (getCurrentReleaseData.packages == null)
            //         getCurrentReleaseData.packages = [];


                  
            //          if ((getCurrentReleaseData.packages).length > 0){
            //         let test =  getCurrentReleaseData.packages[0].offerability.offerField2;
            //           for (var i =0; i<test.length() ; i++)
            //           {
            //               console.log("&&&&&&"+ test[i]);
            //               test[i] = test[i] + 'kbps';
            //           }
            //           //getCurrentReleaseData.packages = test[i];
            //         }

             

            //     if (this._isMounted)
            //         this.setState({
            //             releaseDetails: getCurrentReleaseData,
            //             packages: [...getCurrentReleaseData.packages],
            //             genericProducts: [...getCurrentReleaseData.genericProducts]
            //         });
            //     console.log(getCurrentReleaseData)
            // }
            // )
            .then(res => {
                console.log("release data");
                let getCurrentReleaseData = res.data.data;
                if (getCurrentReleaseData.genericProducts == null)
                    getCurrentReleaseData.genericProducts = [];
                else {
                    let genericProducts = []
                    let products = []
                    // getCurrentReleaseData.genericProducts.map(pro => {
                    //     if (pro.alaCarte == 'Y'){
                    //         //  genericProducts.push(pro)
                    //         if ((pro.alaCarte == 'Y') && (getCurrentReleaseData.genericProducts).length > 0){
                    //             genericProducts=getCurrentReleaseData.genericProducts.reduce((acc,pro)=>{
                    //         if((pro.alaCarte == 'Y') && (pro.offerability.offerField2).length > 0){
                    //                 let newVal =pro.offerability.offerField2.map((x)=> x/1024 +' MBPS')
                                   
                                   
                    //                 let updatedOff={...pro.offerability ,offerField2:newVal};
                    //                 let updatedproduct={...pro,offerability:updatedOff};
                      
                    //                 genericProducts.push(updatedproduct)
                    //                 }
        
                    //             return genericProducts;
                    //             },[]);
                    //         }
                    //     }
                            
                    //     else{
                    //         products.push(pro)
                    // }
                    // })

                    getCurrentReleaseData.genericProducts.map((pro) => {
                        // console.log("*******" + pro.offerability)
                        if (pro.alaCarte == 'Y') {
                      if ((pro.offerability) != null && (pro.offerability.offerField2).length > 0) {
                        let newVal =pro.offerability.offerField2.map((x)=> x/1024 +' MBPS')
                        let updatedOff={...pro.offerability ,offerField2:newVal};
                        let updatedproduct={...pro,offerability:updatedOff};
          
                        genericProducts.push(updatedproduct)
                        }
                      else {
                    
                    
                        genericProducts.push(pro);
                      }
                    }
                        else products.push(pro);
                    }
                    
                    );
        

                    getCurrentReleaseData.genericProducts = genericProducts
                    getCurrentReleaseData.otherentities = {
                        ...getCurrentReleaseData.otherentities,
                        products: products
                    }
                }
                let ans=[];
                if (getCurrentReleaseData.packages == null)
                    ans = [];


if ((getCurrentReleaseData.packages).length > 0){
                        ans=getCurrentReleaseData.packages.reduce((acc,curr)=>{
                          
                    if(curr.offerability != null ){

                //    if(curr.offerability.offerField2 > )
                            let newVal =curr.offerability.offerField2.map((x)=> x/1024 +' MBPS')

                    


                            let updatedOff={...curr.offerability ,offerField2:newVal};
                            let updatedpackage={...curr,offerability:updatedOff};
              
                    acc.push(updatedpackage)
                            
                
                }else{
                                
                                acc.push(...getCurrentReleaseData.packages)
                            }
                        

                        return acc;
                        },[]);
                    }

             

                if (this._isMounted)
                    this.setState({
                        releaseDetails: getCurrentReleaseData,
                        packages: [...ans],
                        genericProducts: [...getCurrentReleaseData.genericProducts]
                    });
                console.log(getCurrentReleaseData)
            })
            .catch(error => {
                console.log(error);
                if (this._isMounted)
                    this.setState({ loading: false });

            });
    }

    attributes = (entity, id) => {

        return entity.attribute != null && Object.keys(entity.attribute).length > 0 &&
        
            <StyledTreeItem nodeId={id + "attribute"}
                labelText="Attributes" labelIcon={FolderIcon} iconColor='#546D7A'>
                {Object.keys(entity.attribute).map(attribute => {
                    return <StyledTreeItem nodeId={attribute}
                        labelText={attribute} labelIcon={FolderIcon} iconColor='#546D7A' >
                        {entity.attribute[attribute].map(attribute => {
                            return <StyledTreeItem nodeId={attribute.productAttributeId}
                                labelText={attribute.productAttributeId}
                                labelInfo={attribute.productAttributeValue}
                                labelIcon={BrightnessAutoIcon}
                                iconColor="#F60076">

                            </StyledTreeItem>


                        })}
                    </StyledTreeItem>
                })}
            </StyledTreeItem>

    }

    pricing = (entity, id) => {

        return (entity.pricing && entity.pricing.length > 0) &&
            <StyledTreeItem nodeId={id + "pricing"}
                labelText="Pricing" labelIcon={FolderIcon} iconColor='#546D7A'
            >

                {entity.pricing[0].rcPrice &&
                    <StyledTreeItem nodeId={entity.packageId + 'rc'}
                        labelText={'RC'}
                        labelInfo={entity.pricing[0].rcPrice}
                        labelIcon={CurrencyRupeeIcon}
                        iconColor="#8D6D62" >
                    </StyledTreeItem>
                }

                {entity.pricing[0].nrcPrice &&
                    <StyledTreeItem nodeId={entity.packageId + 'nrc'}
                        labelText={'NRC'}
                        labelInfo={entity.pricing[0].nrcPrice}
                        labelIcon={CurrencyRupeeIcon}
                        iconColor="#8D6D62">
                    </StyledTreeItem>
                }

            </StyledTreeItem>

    }

    offerability = (entity, id) => {

        return (entity.offerability) &&
            <StyledTreeItem nodeId={id + "offerability"}
                labelText="Offerability" labelIcon={FolderIcon} iconColor='#546D7A' >

                {Object.keys(entity.offerability).filter(offerability => offerability != 'deviceIdentifier'
                    ).map(offerability => {
                    return entity.offerability[offerability] && entity.offerability[offerability].length > 0
                        && entity.offerability[offerability][0] != null && offerability != 'isEdit' ?
                        <StyledTreeItem nodeId={offerability}
                            labelText={this.state.refUiMap[offerability]
                                ? this.state.refUiMap[offerability] : offerability}
                            labelIcon={LocalOfferIcon}
                            labelInfo={entity.offerability[offerability].join()}
                            iconColor="#a87f32" >

                        </StyledTreeItem>
                        : null
                })}


            </StyledTreeItem>

    }


    contract = (entity, id) => {

        return entity.contract && Object.keys(entity.contract).length > 0 &&
            <StyledTreeItem nodeId={id + "contract"}
                labelText="Contract" labelIcon={FolderIcon} iconColor='#546D7A'>

                <StyledTreeItem nodeId={"contract" + id}
                    labelText={'Contract'}
                    labelInfo={Object.keys(entity.contract)[0]}
                    labelIcon={MenuBookIcon}
                    iconColor="#008E7B">
                </StyledTreeItem>

                <StyledTreeItem nodeId={"Contract Profile" + id}
                    labelText={'Contract Profile'}
                    labelInfo={entity.contract[Object.keys(entity.contract)[0]].contractProfile}
                    labelIcon={MenuBookIcon}
                    iconColor="#008E7B">
                </StyledTreeItem>

                <StyledTreeItem nodeId={"Monthly Penalty Fee" + id}
                    labelText={'Monthly Penalty Fee'}
                    labelInfo={entity.contract[Object.keys(entity.contract)[0]].monthlypenaltyFee}
                    labelIcon={MenuBookIcon}
                    iconColor="#008E7B">
                </StyledTreeItem>

                <StyledTreeItem nodeId={"Penalty Fix Fee" + id}
                    labelText={'Penalty Fix Fee'}
                    labelInfo={entity.contract[Object.keys(entity.contract)[0]].penaltyFixFee}
                    labelIcon={MenuBookIcon}
                    iconColor="#008E7B">
                </StyledTreeItem>

                <StyledTreeItem nodeId={"Sign Up Fee" + id}
                    labelText={'Sign Up Fee'}
                    labelInfo={entity.contract[Object.keys(entity.contract)[0]].signUpFee}
                    labelIcon={MenuBookIcon}
                    iconColor="#008E7B">
                </StyledTreeItem>
            </StyledTreeItem>

    }
    render() {
        const { classes } = this.props;

        let treeView = <Modal
            show={this.state.show}
            modalClosed={() => {
                this.setState({ show: false })
                this.props.showTreeView()
            }}
            title={"Release Id " + this.props.releaseData.externalReleaseId}
        >
            {this.state.loading ? <Loader /> :
                <TreeView
                    // className={classes.root}
                    defaultExpanded={['release']}
                    defaultCollapseIcon={<ArrowDropDownIcon />}
                    defaultExpandIcon={<ArrowRightIcon />}
                    defaultEndIcon={<div style={{ width: 24 }} />}
                >
                    <StyledTreeItem nodeId="release" iconColor='#ff1921' labelText={"Release Id " + this.props.releaseData.externalReleaseId}
                        labelIcon={Label}>

                        {this.state.packages.length > 0 &&
                            <StyledTreeItem nodeId="package" iconColor='#546D7A' labelText="Packages" labelIcon={FolderIcon} >
                                {this.state.packages.map(pkg => {
                                    return <StyledTreeItem
                                        nodeId={pkg.packageId}
                                        labelText={pkg.packageName}
                                        labelIcon={LibraryBooksIcon}
                                        labelInfo={pkg.packageId}
                                        iconColor='#8175CB'>

                                        {this.attributes(pkg, pkg.packageId)}

                                        {(pkg.products != null && pkg.products.length > 0) &&
                                            <StyledTreeItem nodeId={pkg.packageId + "product"}
                                                labelText="Products" labelIcon={FolderIcon} iconColor='#546D7A' >
                                                {pkg.products.map(product => {
                                                    return <StyledTreeItem nodeId={product.productId}
                                                        labelText={product.productDesc}
                                                        labelInfo={product.productId}
                                                        labelIcon={ExtensionIcon}
                                                        iconColor="#00ACC2">

                                                    </StyledTreeItem>
                                                })}
                                            </StyledTreeItem>
                                        }
                                        {this.pricing(pkg, pkg.packageId)}
                                        {this.contract(pkg, pkg.packageId)}
                                        {this.offerability(pkg, pkg.packageId)}

                                    </StyledTreeItem>
                                })}
                            </StyledTreeItem>
                        }

                        {this.state.genericProducts.length > 0 &&
                            <StyledTreeItem nodeId="genericProduct" labelText="Generic Products"
                                labelIcon={FolderIcon} iconColor='#546D7A'>
                                {this.state.genericProducts.map(genPro => {
                                    return <StyledTreeItem
                                        nodeId={genPro.productId}
                                        labelText={genPro.productName}
                                        labelIcon={StoreIcon}
                                        labelInfo={genPro.productId}
                                        iconColor="#00ACC2">

                                        {this.attributes(genPro, genPro.productId)}
                                        {this.pricing(genPro, genPro.productId)}
                                        {this.contract(genPro, genPro.productId)}
                                        {this.offerability(genPro, genPro.productId)}



                                    </StyledTreeItem>
                                })}
                            </StyledTreeItem>
                        }

                        {Object.keys(this.state.releaseDetails).length > 0 && this.state.releaseDetails.otherentities.products &&
                            this.state.releaseDetails.otherentities.products.length > 0 &&
                            <StyledTreeItem nodeId="product" iconColor='#546D7A'
                                labelText="Products" labelIcon={FolderIcon} >
                                {this.state.releaseDetails.otherentities.products.map(pro => {
                                    return <StyledTreeItem
                                        nodeId={pro.productId}
                                        labelText={pro.productName}
                                        labelIcon={StoreIcon}
                                        labelInfo={pro.productId}
                                        iconColor='#00ACC2'>
                                    </StyledTreeItem>
                                })}
                            </StyledTreeItem>
                        }

                        {Object.keys(this.state.releaseDetails).length > 0 && this.state.releaseDetails.otherentities.PpmAttributes &&
                            this.state.releaseDetails.otherentities.PpmAttributes.length > 0 &&
                            <StyledTreeItem nodeId="attribute" iconColor='#546D7A'
                                labelText="Attributes" labelIcon={FolderIcon} >
                                {this.state.releaseDetails.otherentities.PpmAttributes.map(attr => {
                                    return <StyledTreeItem
                                        nodeId={attr.entityId}
                                        labelText={attr.entityName}
                                        labelIcon={BrightnessAutoIcon}
                                        labelInfo={attr.entityId}
                                        iconColor='#F60076'>
                                    </StyledTreeItem>
                                })}
                            </StyledTreeItem>
                        }

                        {Object.keys(this.state.releaseDetails).length > 0 && this.state.releaseDetails.otherentities.PpmAttrGroups &&
                            this.state.releaseDetails.otherentities.PpmAttrGroups.length > 0 &&
                            <StyledTreeItem nodeId="attributeGroups" iconColor='#546D7A'
                                labelText="Attributes Groups" labelIcon={FolderIcon} >
                                {this.state.releaseDetails.otherentities.PpmAttrGroups.map(attrGrp => {
                                    return <StyledTreeItem
                                        nodeId={attrGrp.entityId}
                                        labelText={attrGrp.entityName}
                                        labelIcon={BrightnessAutoIcon}
                                        labelInfo={attrGrp.entityId}
                                        iconColor='#F60076'>
                                    </StyledTreeItem>
                                })}
                            </StyledTreeItem>
                        }
                        {Object.keys(this.state.releaseDetails).length > 0 && this.state.releaseDetails.otherentities.Contracts &&
                            this.state.releaseDetails.otherentities.Contracts.length > 0 &&
                            <StyledTreeItem nodeId="Contracts" iconColor='#546D7A'
                                labelText="Contracts" labelIcon={FolderIcon} >
                                {this.state.releaseDetails.otherentities.Contracts.map(contract => {
                                    return <StyledTreeItem
                                        nodeId={contract.entityId}
                                        labelText={contract.entityName}
                                        labelIcon={MenuBookIcon}
                                        labelInfo={contract.entityId}
                                        iconColor='#008E7B'>
                                    </StyledTreeItem>
                                })}
                            </StyledTreeItem>
                        }

                        {Object.keys(this.state.releaseDetails).length > 0 && this.state.releaseDetails.otherentities.RatePlan &&
                            this.state.releaseDetails.otherentities.RatePlan.length > 0 &&
                            <StyledTreeItem nodeId="RatePlan" iconColor='#546D7A'
                                labelText="RatePlans" labelIcon={FolderIcon} >
                                {this.state.releaseDetails.otherentities.RatePlan.map(rp => {
                                    return <StyledTreeItem
                                        nodeId={rp.entityId}
                                        labelText={rp.entityName}
                                        labelIcon={CurrencyRupeeIcon}
                                        labelInfo={rp.entityId}
                                        iconColor='red'>
                                    </StyledTreeItem>
                                })}
                            </StyledTreeItem>
                        }





                    </StyledTreeItem>


                </TreeView>}

        </Modal>

        return treeView
    }
}

export default withStyles(useStyles)(WithErrorHandler(ReleaseTreeView, axios))
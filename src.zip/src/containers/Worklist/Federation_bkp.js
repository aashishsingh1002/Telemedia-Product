import React, { Component } from "react";
import ModalAction from "../../UI/ModalAction/ModalAction";
import Loader from "../../UI/Loader/Loader";
import axios from "axios";
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import { withStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemSecondaryAction from "@material-ui/core/ListItemSecondaryAction";
import ListItemText from "@material-ui/core/ListItemText";
import Checkbox from "@material-ui/core/Checkbox";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import Paper from "@material-ui/core/Paper";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import SettingsSystemDaydreamIcon from "@material-ui/icons/SettingsSystemDaydream";
import VideoLabelIcon from "@material-ui/icons/VideoLabel";
import Box from "@material-ui/core/Box";
import Divider from "@material-ui/core/Divider";
import Accordion from "@material-ui/core/Accordion";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { directiveLiteral } from "@babel/types";

const useStyles = (theme) => ({
  root: {
    width: "100%",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "65%",
    flexShrink: 0,
  },
  secondaryHeading: {
    fontSize: theme.typography.pxToRem(15),
  },
});

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

class Federate extends Component {
  _isMounted = false;

  state = {
    show: true,
    loading: false,
    federate: [],
    activeTab: 0,
    fedResponse: {},
  };

  modalCloseHandler = () => {
    this.setState({ show: false });
    this.props.showFederation();
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  fedStatusHandler = () => {
    return axios
      .get(process.env.REACT_APP_URL + "addonService/status", {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
          releaseId: this.props.releaseData.releaseId,
          authUserId: this.props.userInfo.id,
          Authorization: 'Bearer ' + this.props.userInfo.jwt,
         1
        },
      })
      .then((res) => {
        console.log(res);
        if (res) {
          this.setState({
            fedResponse: res.data.data,
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };
  componentDidMount() {
    this._isMounted = true;
    this.setState({ loading: true });
    this.fedStatusHandler().then(() => {
      this.setState({ loading: false });
    });
  }

  handleToggle = (value) => () => {
    const currentIndex = this.state.federate.indexOf(value);
    const newFederate = [...this.state.federate];

    if (currentIndex === -1) {
      newFederate.push(value);
    } else {
      newFederate.splice(currentIndex, 1);
    }
    this.setState({
      federate: newFederate,
    });
  };

  fxFederation = () => {
    if (this.state.federate.includes("FX")) {
      console.log(
        "fx-fed-telemedia-rs/fxfed-Telemedia/execget?epcEnv=preprod&relName=" +
          this.props.releaseData.releaseId +
          "&fedBy=" +
          this.props.userInfo.id +
          "&opId=" +
          this.props.userInfo.opId +
          "&buId=" +
          this.props.userInfo.buId
      );
      return axios
        .get(
          process.env.REACT_APP_URL +
            "fx-fed-telemedia-rs/fxfed-Telemedia/execget?epcEnv=preprod&relName=" +
            this.props.releaseData.releaseId +
            "&fedBy=" +
            this.props.userInfo.id +
            "&opId=" +
            this.props.userInfo.opId +
            "&buId=" +
            this.props.userInfo.buId,
          {
            headers: {
              authUserId: this.props.userInfo.id,
              // Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        )
        .then((res) => {
          console.log(res);
        })
        .catch((error) => {
          console.log(error);
        });
    } else return Promise.resolve();
  };

  dirsFederation = () => {
    if (this.state.federate.includes("DIRS")) {
      return axios
        .post(
          process.env.REACT_APP_URL +
            "ratePlan/dirsFed?releaseId=" +
            this.props.releaseData.releaseId +
            "&opId=" +
            this.props.userInfo.opId +
            "&federatedBy=" +
            this.props.userInfo.id +
            "&authUserId=" +
            this.props.userInfo.id,
          {
            headers: {
              // opId: this.props.userInfo.opId,
              authUserId: this.props.userInfo.id,
              Authorization: 'Bearer ' + this.props.userInfo.jwt,
              federatedBy: this.props.userInfo.id,
            },
          }
        )
        .then((res) => {
          console.log(res);
        })
        .catch((error) => {
          console.log(error);
        });
    } else return Promise.resolve();
  };

  siebelFederation = () => {
    if (this.state.federate.includes("Siebel")) {
      return axios
        .get(process.env.REACT_APP_URL + "addonService/SiebelFederate", {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
            releaseId: this.props.releaseData.releaseId,
            federatedBy: this.props.userInfo.id,
            environment: "preprod",
            authUserId: this.props.userInfo.id,
            Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        })
        .then((res) => {
          console.log(res);
        })
        .catch((error) => {
          console.log(error);
        });
    } else return Promise.resolve();
  };

  omFederation = () => {
    if (this.state.federate.includes("OM")) {
      return axios
        .get(process.env.REACT_APP_URL + "addonService/OMfederate", {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
            releaseId: this.props.releaseData.releaseId,
            federatedBy: this.props.userInfo.id,
            authUserId: this.props.userInfo.id,
            Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        })
        .then((res) => {
          console.log(res);
        })
        .catch((error) => {
          console.log(error);
        });
    } else return Promise.resolve();
  };
  federationHandler = () => {
    if (this.state.federate.length > 0) {
      this.setState({ loading: true });
      this.fxFederation().then(() => {
        this.dirsFederation().then(() => {
          this.siebelFederation().then(() => {
            this.omFederation().then(() => {
              this.fedStatusHandler().then(() => {
                this.setState({
                  loading: false,
                  activeTab: 1,
                });
              });
            });
          });
        });
      });
    }
  };

  render() {
    const { classes } = this.props;

    let federate = (
      <ModalAction
        show={this.state.show}
        modalClosed={this.modalCloseHandler}
        actionText={"Federate"}
        size="md"
        title={"Release Id " + this.props.releaseData.externalReleaseId}
        action={this.federationHandler}
      >
        {this.state.loading ? (
          <div style={{ minHeight: "35vh" }}>
            <Loader />
          </div>
        ) : (
          <Paper square style={{ minHeight: "35vh" }}>
            <Tabs
              value={this.state.activeTab}
              onChange={(event, newValue) => {
                this.setState({
                  activeTab: newValue,
                });
              }}
              variant="fullWidth"
              indicatorColor="white"
              textColor="primary"
            >
              <Tab icon={<SettingsSystemDaydreamIcon />} label="Federation" />
              <Tab icon={<VideoLabelIcon />} label="Status" />
            </Tabs>

            <TabPanel value={this.state.activeTab} index={0}>
              {this.state.fedResponse &&
                Object.keys(this.state.fedResponse).length > 0 && (
                  <List>
                    {this.state.fedResponse["FX"] && (
                      <ListItem
                        disabled={
                          this.state.fedResponse["FX"]["Overall Status"][
                            "Overall Status"
                          ] == "Success"
                        }
                        dense
                        button
                        onClick={this.handleToggle("FX")}
                      >
                        <ListItemIcon>
                          <Checkbox
                            disabled={
                              this.state.fedResponse["FX"]["Overall Status"][
                                "Overall Status"
                              ] == "Success"
                            }
                            edge="start"
                            checked={this.state.federate.indexOf("FX") !== -1}
                            tabIndex={-1}
                            disableRipple
                            style={{ color: "#ff1921" }}
                          />
                        </ListItemIcon>
                        <ListItemText primary={"FX"} />
                      </ListItem>
                    )}

                    {this.state.fedResponse["FX"] && (
                      <ListItem
                        disabled={
                          this.state.fedResponse["FX"]["Overall Status"][
                            "Overall Status"
                          ] == "Success"
                            ? false
                            : true
                        }
                        dense
                        button
                        onClick={this.handleToggle("DIRS")}
                      >
                        <ListItemIcon>
                          <Checkbox
                            disabled={
                              this.state.fedResponse["FX"]["Overall Status"][
                                "Overall Status"
                              ] == "Success"
                                ? false
                                : true
                            }
                            edge="start"
                            checked={this.state.federate.indexOf("DIRS") !== -1}
                            tabIndex={-1}
                            disableRipple
                            style={{ color: "#ff1921" }}
                          />
                        </ListItemIcon>
                        <ListItemText primary={"DIRS"} />
                      </ListItem>
                    )}

                    <ListItem
                      dense
                      button
                      onClick={this.handleToggle("Siebel")}
                    >
                      <ListItemIcon>
                        <Checkbox
                          edge="start"
                          checked={this.state.federate.indexOf("Siebel") !== -1}
                          tabIndex={-1}
                          disableRipple
                          style={{ color: "#ff1921" }}
                        />
                      </ListItemIcon>
                      <ListItemText primary={"Siebel"} />
                    </ListItem>
                    <ListItem
                      disabled={
                        !(
                          this.state.fedResponse["FX"]["Overall Status"][
                            "Overall Status"
                          ] == "Success" &&
                          this.state.fedResponse["Siebel"]["Overall Status"][
                            "Overall Status"
                          ] == "Success"
                        )
                      }
                      dense
                      button
                      onClick={this.handleToggle("OM")}
                    >
                      <ListItemIcon>
                        <Checkbox
                          disabled={
                            !(
                              this.state.fedResponse["FX"]["Overall Status"][
                                "Overall Status"
                              ] == "Success" &&
                              this.state.fedResponse["Siebel"][
                                "Overall Status"
                              ]["Overall Status"] == "Success"
                            )
                          }
                          edge="start"
                          checked={this.state.federate.indexOf("OM") !== -1}
                          tabIndex={-1}
                          disableRipple
                          style={{ color: "#ff1921" }}
                        />
                      </ListItemIcon>
                      <ListItemText primary={"OM"} />
                    </ListItem>
                  </List>
                )}
            </TabPanel>

            <TabPanel value={this.state.activeTab} index={1}>
              {this.state.fedResponse &&
                Object.keys(this.state.fedResponse).length > 0 && (
                  <React.Fragment>
                    <Grid container alignContent="flex-end" spacing={2}>
                      <Grid item xs={4}>
                        <Typography variant="subtitle1"> System</Typography>
                      </Grid>
                      <Grid item xs={3}></Grid>
                      <Grid item xs={5}>
                        <Typography variant="subtitle1"> Status</Typography>
                      </Grid>
                    </Grid>
                    <Divider
                      style={{ marginBottom: "10px", marginTop: "5px" }}
                    />
                    {this.state.fedResponse["FX"]["Overall Status"][
                      "Overall Status"
                    ] == "Not Federated" ? (
                      <React.Fragment>
                        <Grid container alignContent="flex-end" spacing={2}>
                          <Grid item xs={4}>
                            <Typography variant="subtitle1">
                              {" "}
                              FX Status
                            </Typography>
                          </Grid>
                          <Grid item xs={3}></Grid>
                          <Grid item xs={5}>
                            <Typography
                              variant="subtitle1"
                              style={{ wordBreak: "break-all" }}
                            >
                              {" "}
                              {
                                this.state.fedResponse["FX"]["Overall Status"][
                                  "Overall Status"
                                ]
                              }
                            </Typography>
                          </Grid>
                        </Grid>
                      </React.Fragment>
                    ) : (
                      <Accordion>
                        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                          <Typography className={classes.heading}>
                            FX Status
                          </Typography>
                          <Typography className={classes.secondaryHeading}>
                            {
                              this.state.fedResponse["FX"]["Overall Status"][
                                "Overall Status"
                              ]
                            }
                          </Typography>
                        </AccordionSummary>
                        <AccordionDetails style={{}}>
                          <Grid container alignContent="flex-end" spacing={2}>
                            {Object.keys(
                              this.state.fedResponse["FX"]["Api Status"]
                            ).map((key) => {
                              return (
                                <React.Fragment>
                                  <Grid
                                    item
                                    xs={4}
                                    style={{
                                      borderBottom: "1px solid #b3b3b3",
                                    }}
                                  >
                                    <span style={{ wordBreak: "break-all" }}>
                                      {" "}
                                      {key}
                                    </span>
                                  </Grid>
                                  <Grid
                                    item
                                    xs={1}
                                    style={{
                                      borderBottom: "1px solid #b3b3b3",
                                    }}
                                  ></Grid>
                                  <Grid
                                    item
                                    xs={7}
                                    style={{
                                      borderBottom: "1px solid #b3b3b3",
                                    }}
                                  >
                                    <span style={{ wordBreak: "break-all" }}>
                                      {
                                        this.state.fedResponse["FX"][
                                          "Api Status"
                                        ][key]
                                      }
                                    </span>
                                  </Grid>
                                </React.Fragment>
                              );
                            })}
                          </Grid>
                        </AccordionDetails>
                      </Accordion>
                    )}
                    <Divider
                      style={{ marginBottom: "10px", marginTop: "5px" }}
                    />

                    {this.state.fedResponse["DIRS"]["Overall Status"][
                      "Overall Status"
                    ] == "Not Federated" ? (
                      <React.Fragment>
                        <Grid container alignContent="flex-end" spacing={2}>
                          <Grid item xs={4}>
                            <Typography variant="subtitle1">
                              {" "}
                              DIRS Status
                            </Typography>
                          </Grid>
                          <Grid item xs={3}></Grid>
                          <Grid item xs={5}>
                            <Typography
                              variant="subtitle1"
                              style={{ wordBreak: "break-all" }}
                            >
                              {" "}
                              {
                                this.state.fedResponse["DIRS"][
                                  "Overall Status"
                                ]["Overall Status"]
                              }
                            </Typography>
                          </Grid>
                        </Grid>
                      </React.Fragment>
                    ) : (
                      <Accordion>
                        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                          <Typography className={classes.heading}>
                            DIRS Status
                          </Typography>
                          <Typography className={classes.secondaryHeading}>
                            {
                              this.state.fedResponse["DIRS"]["Overall Status"][
                                "Overall Status"
                              ]
                            }
                          </Typography>
                        </AccordionSummary>
                        <AccordionDetails style={{}}>
                          <Grid container alignContent="flex-end" spacing={2}>
                            {Object.keys(
                              this.state.fedResponse["DIRS"]["Api Status"]
                            ).map((key) => {
                              return (
                                <React.Fragment>
                                  <Grid
                                    item
                                    xs={4}
                                    style={{
                                      borderBottom: "1px solid #b3b3b3",
                                    }}
                                  >
                                    <span style={{ wordBreak: "break-all" }}>
                                      {" "}
                                      {key}
                                    </span>
                                  </Grid>
                                  <Grid
                                    item
                                    xs={1}
                                    style={{
                                      borderBottom: "1px solid #b3b3b3",
                                    }}
                                  ></Grid>
                                  <Grid
                                    item
                                    xs={7}
                                    style={{
                                      borderBottom: "1px solid #b3b3b3",
                                    }}
                                  >
                                    <span style={{ wordBreak: "break-all" }}>
                                      {
                                        this.state.fedResponse["DIRS"][
                                          "Api Status"
                                        ][key]
                                      }
                                    </span>
                                  </Grid>
                                </React.Fragment>
                              );
                            })}
                          </Grid>
                        </AccordionDetails>
                      </Accordion>
                    )}
                    <Divider
                      style={{ marginBottom: "10px", marginTop: "5px" }}
                    />

                    {this.state.fedResponse["Siebel"]["Overall Status"][
                      "Overall Status"
                    ] == "Not Federated" ? (
                      <React.Fragment>
                        <Grid container alignContent="flex-end" spacing={2}>
                          <Grid item xs={4}>
                            <Typography variant="subtitle1">
                              {" "}
                              Siebel Status
                            </Typography>
                          </Grid>
                          <Grid item xs={3}></Grid>
                          <Grid item xs={5}>
                            <Typography
                              variant="subtitle1"
                              style={{ wordBreak: "break-all" }}
                            >
                              {" "}
                              {
                                this.state.fedResponse["Siebel"][
                                  "Overall Status"
                                ]["Overall Status"]
                              }
                            </Typography>
                          </Grid>
                        </Grid>
                      </React.Fragment>
                    ) : (
                      <Accordion>
                        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                          <Typography className={classes.heading}>
                            Siebel Status
                          </Typography>
                          <Typography className={classes.secondaryHeading}>
                            {
                              this.state.fedResponse["Siebel"][
                                "Overall Status"
                              ]["Overall Status"]
                            }
                          </Typography>
                        </AccordionSummary>
                        <AccordionDetails style={{}}>
                          <Grid container alignContent="flex-end" spacing={2}>
                            {Object.keys(
                              this.state.fedResponse["Siebel"]["Api Status"]
                            ).map((key) => {
                              return (
                                <React.Fragment>
                                  <Grid
                                    item
                                    xs={4}
                                    style={{
                                      borderBottom: "1px solid #b3b3b3",
                                    }}
                                  >
                                    <span style={{ wordBreak: "break-all" }}>
                                      {" "}
                                      {key}
                                    </span>
                                  </Grid>
                                  <Grid
                                    item
                                    xs={1}
                                    style={{
                                      borderBottom: "1px solid #b3b3b3",
                                    }}
                                  ></Grid>

                                  <Grid
                                    item
                                    xs={7}
                                    style={{
                                      borderBottom: "1px solid #b3b3b3",
                                    }}
                                  >
                                    <span style={{ wordBreak: "break-all" }}>
                                      {
                                        this.state.fedResponse["Siebel"][
                                          "Api Status"
                                        ][key]
                                      }
                                    </span>
                                  </Grid>
                                </React.Fragment>
                              );
                            })}
                          </Grid>
                        </AccordionDetails>
                      </Accordion>
                    )}

                    <Divider
                      style={{ marginBottom: "10px", marginTop: "5px" }}
                    />

                    {this.state.fedResponse["OM"]["Overall Status"][
                      "Overall Status"
                    ] == "Not Federated" ? (
                      <React.Fragment>
                        <Grid container alignContent="flex-end" spacing={2}>
                          <Grid item xs={4}>
                            <Typography variant="subtitle1">
                              {" "}
                              OM Status
                            </Typography>
                          </Grid>
                          <Grid item xs={3}></Grid>
                          <Grid item xs={5}>
                            <Typography
                              variant="subtitle1"
                              style={{ wordBreak: "break-all" }}
                            >
                              {" "}
                              {
                                this.state.fedResponse["OM"]["Overall Status"][
                                  "Overall Status"
                                ]
                              }
                            </Typography>
                          </Grid>
                        </Grid>
                      </React.Fragment>
                    ) : (
                      <Accordion>
                        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                          <Typography className={classes.heading}>
                            OM Status
                          </Typography>
                          <Typography className={classes.secondaryHeading}>
                            {
                              this.state.fedResponse["OM"]["Overall Status"][
                                "Overall Status"
                              ]
                            }
                          </Typography>
                        </AccordionSummary>
                        <AccordionDetails style={{}}>
                          <Grid container alignContent="flex-end" spacing={2}>
                            {Object.keys(
                              this.state.fedResponse["OM"]["Api Status"]
                            ).map((key) => {
                              return (
                                <React.Fragment>
                                  <Grid
                                    item
                                    xs={4}
                                    style={{
                                      borderBottom: "1px solid #b3b3b3",
                                    }}
                                  >
                                    <span style={{ wordBreak: "break-all" }}>
                                      {" "}
                                      {key}
                                    </span>
                                  </Grid>
                                  <Grid
                                    item
                                    xs={1}
                                    style={{
                                      borderBottom: "1px solid #b3b3b3",
                                    }}
                                  ></Grid>

                                  <Grid
                                    item
                                    xs={7}
                                    style={{
                                      borderBottom: "1px solid #b3b3b3",
                                    }}
                                  >
                                    <span style={{ wordBreak: "break-all" }}>
                                      {
                                        this.state.fedResponse["OM"][
                                          "Api Status"
                                        ][key]
                                      }
                                    </span>
                                  </Grid>
                                </React.Fragment>
                              );
                            })}
                          </Grid>
                        </AccordionDetails>
                      </Accordion>
                    )}
                  </React.Fragment>
                )}
            </TabPanel>
          </Paper>
        )}
      </ModalAction>
    );

    return federate;
  }
}

export default withStyles(useStyles)(Federate);

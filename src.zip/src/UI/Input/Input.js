import React, { useState } from 'react';
// import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import { Autocomplete } from '@material-ui/lab';
import moment from 'moment';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import { Picky } from 'react-picky';
import 'react-picky/dist/picky.css';
import './input.css';
import Slider from '@material-ui/core/Slider';
//import TextField from './TextField';
import TextField from '@material-ui/core/TextField';
//import CustomTextField from '@material-ui/core/TextField';

const Input = (props) => {
	let inputElement = null;
	const [error, setError] = useState(false);
	const [invalid, setInvalid] = useState(false);

	const hasDecimal = (value) => {
		const check = value % 1 !== 0;
		return check;
	};

	switch (props.refType) {
		case 'maxNumberInput':
			const validationCheck = (e, ref) => {
				const value = e.currentTarget.value;
				if (ref === 'minChannel' && props.catalogId === 'TDM PRI') {
					setInvalid(value > 30 || value < 1 || hasDecimal(value));
				} else {
					setInvalid(value < 1 || hasDecimal(value));
				}
			};
			inputElement = (
				<TextField
					fullWidth
					value={props.value}
					onChange={(event) => {
						const num = Number.isInteger(parseFloat(event.target.value));
						const value = Number(event.currentTarget.value);
						setError(!num);
						props.changed(event);
						validationCheck(event, props.refName);
						//props.onValidationCheck(props.refName == 'minChannel' ? value > 30 || value < 0 || hasDecimal(value) : hasDecimal(value), props.refName);
						props.onValidationCheck(
							props.catalogId === 'TDM PRI' && props.refName === 'minChannel'
								? value > 30 || value < 1 || hasDecimal(value)
								: hasDecimal(value),
							props.refName
						);
					}}
					helperText={
						props.catalogId === 'TDM PRI' && props.refName === 'minChannel'
							? invalid
								? hasDecimal(props.value)
									? 'Please enter whole number'
									: 'Please input between 1 to 30'
								: 'Please input between 1 to 30'
							: error && 'Please enter whole number'
					}
					error={
						props.catalogId === 'TDM PRI' && props.refName === 'minChannel'
							? invalid
							: error
					}
					required={props.required}
					InputProps={{ inputProps: { max: props.maxLength, min: '1' } }}
				/>
			);

			break;


		case 'Range':
			let rangeVal = props.value ? props.value : ['', ''];
			console.log(props.value);
			// const hasDecimal = (value) => {
			//     const check = value%1 !== 0;
			//     return check;
			// }
			inputElement = (
				<div style={{}}>
					<div>
						<Grid container spacing={1} alignItems="flex-start">
							<Grid
								item
								sm="3"
								style={{
									paddingTop: '8px',
								}}>
								Min
							</Grid>
							<Grid item sm="9">
								<TextField
									// type='number'
									fullWidth
									value={rangeVal[0]}
									helperText={
										// hasDecimal(rangeVal[0])
										// 	? 'Please enter whole number'
										// 	: Number(rangeVal[0]) > Number(rangeVal[1])
										// 	? 'Min is greater than Max'
										// 	: ''
										hasDecimal(rangeVal[0]) ||
											Number(rangeVal[0]) < 0 ||
											rangeVal[0].includes('+') ||
											rangeVal[0].includes('.')
											? 'Please enter whole number'
											:
											''}
									error={
										hasDecimal(rangeVal[0]) ||
										Number(rangeVal[0]) < 0 ||
										rangeVal[0].includes('+') ||
										rangeVal[0].includes('.')
										// ||
										// Number(rangeVal[0]) > Number(rangeVal[1])
									}
									required
									InputProps={{ inputProps: { max: rangeVal[1], min: '0' } }}
									// onChange={(event) =>
									//     props.sliderChange(event, 'min')
									// }
									onChange={(event) => {
										const value = Number(event.currentTarget.value);
										props.sliderChange(event, 'min');
										//props.onValidationCheck(hasDecimal(value) || hasDecimal(rangeVal[1]) || value > Number(props.value[1]));
										props.onValidationCheck(
											hasDecimal(value) ||
											value < 0 ||
											event.currentTarget.value.includes('+') ||
											event.currentTarget.value.includes('.'),
											// ||
											// 	hasDecimal(rangeVal[1]) ||
											// 	value > Number(props.valu
											props.refName
										);
									}}
								/>
							</Grid>
						</Grid>
					</div>
					<div>
						<Grid container spacing={1} alignItems="flex-start">
							<Grid
								item
								sm="3"
								style={{
									paddingTop: '8px',
								}}>
								Max
							</Grid>
							<Grid item sm="9">
								<TextField
									disabled
									// type='number'
									fullWidth
									value={rangeVal[0]}
									helperText={
										hasDecimal(rangeVal[0]) ||
											Number(rangeVal[0]) < 0 ||
											rangeVal[0].includes('+') ||
											rangeVal[0].includes('.')
											? 'Please enter whole number'
											: ''
									}
									error={
										hasDecimal(rangeVal[0]) ||
										Number(rangeVal[0]) < 0 ||
										rangeVal[0].includes('+') ||
										rangeVal[0].includes('.')
									}
									required
									InputProps={{
										inputProps: { min: rangeVal[0] ? rangeVal[0] : '0' },
									}}
									onChange={(event) => {
										const value = Number(event.currentTarget.value);
										props.sliderChange(event, 'max');
										//props.onValidationCheck(hasDecimal(value) || hasDecimal(rangeVal[0]) || value < Number(props.value[0]));
										props.onValidationCheck(
											hasDecimal(value) ||
											hasDecimal(rangeVal[0]) ||
											// value < Number(props.value[0]),
											value < 0 ||
											event.currentTarget.value.includes('+') ||
											event.currentTarget.value.includes('.'),
											props.refName
										);
									}}
								/>
							</Grid>
						</Grid>
					</div>
				</div>
			);
			break;




		case 'NumberInput':
			let nbrValue = props.value ? props.value : '';
			inputElement = (
				<TextField
					type="number"
					helperText={props.helperText}
					error={props.error}
					fullWidth
					onKeyUp={props.keyUp ?? null}
					value={nbrValue}
					onChange={(e) => props.changed(e)}
					disabled={props.disabled}
					required={props.required}
				/>
			);
			break;
		case 'TextInput':
			const displayMsg = [
				'icmDesc',
				'packageDesc',
				'productDesc',
				'ppmAttrName',
				'ppmAttrValue',
				'defaultValue',
				'attrGrpName',
			].includes(props.refName);

			const charLength = props.refName === 'icmDesc' ? 500 : 100;

			let txtValue = props.value ? props.value : '';
			inputElement = (
				<TextField
					fullWidth
					value={txtValue}
					onChange={(event) => {
						const num = event.target.value.length < charLength;
						setError(!num);
						props.changed(event);
					}}
					InputProps={{ maxLength: charLength ,
						disableUnderline:true,
						style:{borderBottom:'1px solid rgba(0,0,0,0.5)'}
					}}
					helperText={displayMsg ? `Max Length: ${charLength}` : false}
					// style={{borderBottom:'1px solid rgba(0,0,0,0.5)' }}
					error={displayMsg ? error : ''}
					disabled={props.disabled}
					required={props.required}
				/>
			);

			break;
		case 'Checkbox':
			console.log(props.value);
			console.log('check');

			inputElement = (
				<FormControlLabel
					control={
						<Checkbox
							checked={props.value === 'Y' ? true : false}
							onChange={props.checkChanged}
							color="primary"
							disabled={props.disabled}
						/>
					}
				/>
			);
			break;
		case 'TextArea':
			const display = props.refName === 'description';
			let txtAreaValue = props.value ? props.value : '';
			inputElement = (
				<TextField
					fullWidth
					value={txtAreaValue}
					onChange={(event) => {
						// const num = Number.isInteger(parseFloat(event.target.value));
						const num = event.target.value.length < 500;
						setError(!num);
						props.changed(event);
					}}
					inputProps={{ maxLength: 500 }}
					// onChange={props.changed}
					helperText={display ? 'Max Length: 500' : ''}
					error={display ? error : ''}
					disabled={props.disabled}
					required={props.required}
					placeholder={props.uiName}
					rowsMin={4}
					rowsMax={5}
					multiline
				// variant="outlined"
				/>
			);
			break;
		case 'Date':
			let value = props.value
				? moment(props.value).format('YYYY-MM-DD')
				: moment().format('YYYY-MM-DD');
			inputElement = (
				<TextField
					fullWidth
					type="date"
					disabled={props.disabled}
					value={value}
					onChange={props.changed}
					InputLabelProps={{
						shrink: true,
					}}
				/>
			);
			break;

		case 'SelectInput':
			let selValue = props.value ? props.value : '';
			inputElement = (
				<React.Fragment>
					<Picky
						clearFilterOnClose={true}
						id="picky"
						keepOpen={false}
						disabled={props.disabled}
						required={props.required}
						options={props.refLovs}
						value={selValue}
						multiple={false}
						includeFilter={true}
						onChange={props.changed}
						dropdownHeight={130}
						
						render={({ style, isSelected, item, selectValue }) => {
							return (
								<li
									style={style}
									className={isSelected ? 'selected' : ''}
									key={item}
									onClick={() => selectValue(item)}>
									<span
										style={{
											display: 'block',
											// wordWrap:'break-word',
											width: 'max-content',
											// width:'100%',
											minWidth:"100%",
											// wordBreak:'break-all',
											wordWrap: 'break-word',
											fontSize: '14px',
										}}>
										{item}
									</span>
								</li>
							);
						}}
					/>
					{props.required && (
						<input
							required
							value={selValue}
							style={{
								opacity: 0,
								position: 'absolute',
								zIndex: -1,
							}}
						/>
					)}
				</React.Fragment>
				// <Autocomplete
				//   options={props.refLovs}
				//   value={selValue}
				//   renderInput={(params) => (
				//     <TextField
				//       params={params}
				//       placeholder={'Select an option'}
				//       InputLabelProps={{
				//         shrink: true,
				//       }}
				//     />
				//   )}
				//   onChange={(event, value) => {
				//     props.changed(value);
				//   }}
				// />
			);
			// inputElement =
			//     <React.Fragment>
			//         <Picky
			//             clearFilterOnClose={true}
			//             id="picky"
			//             keepOpen={false}
			//             disabled={props.disabled}
			//             required={props.required}
			//             options={props.refLovs}
			//             value={selValue}
			//             multiple={false}
			//             includeFilter={true}
			//             onChange={props.changed}
			//             dropdownHeight={300}
			//             render={({
			//                 style,
			//                 isSelected,
			//                 item,
			//                 selectValue,
			//             }) => {
			//                 return (
			//                     <li
			//                         style={style}
			//                         className={isSelected ? 'selected' : ''}
			//                         key={item}
			//                         onClick={() => selectValue(item)}
			//                     >
			//                         <span style={{
			//                             display: 'block',
			//                             width: '100%',
			//                             wordWrap: 'break-word'
			//                         }}>{item}</span>
			//                     </li >
			//                 );
			//             }}
			//         />
			//         {props.required &&
			//             <input required value={selValue}
			//                 style={{
			//                     opacity: 0,
			//                     position: 'absolute',
			//                     zIndex: -1
			//                 }} />}
			//     </React.Fragment>

			break;

		default:
			inputElement = (
				<TextField
					fullWidth
					value={props.value}
					onChange={props.changed}
					disabled={props.disabled}
					required={props.required}
				/>
			);
	}

	let input = (
		<Grid
			item
			xs={12}
			sm={4}
			md={props.colSize ? props.colSize : 3}
			style={{
				display:
					props.uiName === 'Account ID' || props.uiName === 'Account Name'
						? 'contents'
						: 'block',
			}}>
			<Box>
				<span style={{ fontSize: '14px', fontWeight: '400' }}>
					{props.catalogId === 'TDM PRI' &&
						props.refType === 'maxNumberInput' &&
						props.refName === 'minChannel'
						? 'No. of Channels'
						: props.uiName}
					{props.required && (
						<span
							style={{
								color: 'red',
								marginLeft: '5px',
								fontWeight: 'bold',
							}}>
							*
						</span>
					)}
				</span>
			</Box>
			<Box mt={2}>{inputElement}</Box>
		</Grid>
	);
	if (props.table) return inputElement;
	if (props.resize)
		input = (
			<Grid item xs={12} sm={5}>
				<Box>
					<span>
						{props.uiName}
						{props.required && (
							<span
								style={{
									color: 'red',
									marginLeft: '5px',
									fontWeight: 'bold',
								}}>
								*
							</span>
						)}
					</span>
				</Box>
				<Box mt={2}>{inputElement}</Box>
			</Grid>
		);

	return input;
};

export default Input;

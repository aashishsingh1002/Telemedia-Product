import React, { Component } from "react";
import axios from "../../../axios-epc";
import Grid from "@material-ui/core/Grid";
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";
import { withStyles } from "@material-ui/core/styles";
import WithErrorHandler from "../../../HOC/WithErrorHandler/WithErrorHandler";
import Input from "../../../UI/Input/Input";
import Button from "../../../UI/Button/Button";
// import Button from "@material-ui/core/Button";
import Loader from "../../../UI/Loader/Loader";
import Modal from "../../../UI/Modal/Modal";
import Typography from "@material-ui/core/Typography";
import moment from "moment";
import Tooltip from "@material-ui/core/Tooltip";
import AddIcon from "@material-ui/icons/Add";
import MultiSelect from "../../../UI/Input/MultiSelect";
import Box from "@material-ui/core/Box";
import { connect } from "react-redux";
import * as actionTypes from "../../../store/actions/actionTypes";
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';



function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
}

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: "#525354",
    color: "white",
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

const useStyles = (theme) => ({
  cardHeader: {
    // background: "#546D7A",
    // height: "4.5vh",
    paddingBottom: 0,
  },
  subheader: {
    color: "rgba(0, 0, 0, 0.87)",
    fontSize: "16px",
    fontWeight: "600",
    // color: "white",
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "96%",
    flexShrink: 0,
  },
});

class DiscountPricing extends Component {
  _isMounted = false;

  state = {
    loading: true,
    show: false,
    modalContent: null,
    discountUsageGroup: {},
    discountedItemsData: {},
    schemaDiscount: [],
    discountGroups: {},
    schemaDiscountAppliesToUsage: [],
    schemaDiscountAppliesToRcNrc: [],
    schemaDiscountAll1: [],
    schemaDiscountAll2: [],
    schemaDiscountAll3: [],
    schemaDiscountIr1: [],
    schemaDiscountIr2: [],
    schemaDiscountIr3: [],
    schemaDiscountIsd1: [],
    schemaDiscountIsd2: [],
    schemaDiscountIsd3: [],
    schemaDiscountTiered: [],
    componentIdDiscount: "",
    discountLovs: {},
    serviceType:'/service',
  };

  componentDidUpdate(prevProps, prevState) {
    if (prevState["zone"] !== this.state["zone"]) {
      if (this.state["zone"]) {
        let countries = [];
        this.state["zone"].map((zone) => {
          countries.push(...this.state.discountedItemsData["zones"][zone]);
        });
        // console.log(countries)
        this.setState({
          classifier1: countries,
        });
      }
    } else if (
      prevState["discountAppliedOn"] !== this.state["discountAppliedOn"]
    ) {
      if (this.state["discountAppliedOn"]) {
        this.setState({
          ugcType: null,
          ugcSubType1: null,
          discountedItem: null,
        });

        if (
          this.state["discountAppliedOn"] == "RC" ||
          this.state["discountAppliedOn"] == "NRC"
        ) {
          this.setState({
            loading: true,
          });
          axios
            .get(
              "pricing/allComp?releaseID=" + this.props.releaseData.releaseId,
              {
                headers: {
                  opId: this.props.userInfo.opId,
                },
              }
            )
            .then((res) => {
              let lovs = [];
              if (this.state["discountAppliedOn"] == "RC") {
                Object.keys(res.data.data).forEach((key) => {
                  let prdId = key;
                  if (res.data.data[key]["RC"]) {
                    res.data.data[key]["RC"].filter((comp) => {
                      lovs.push(key + "/" + comp);
                    });
                  }
                });
              } else if (this.state["discountAppliedOn"] == "NRC") {
                Object.keys(res.data.data).forEach((key) => {
                  let prdId = key;
                  if (res.data.data[key]["NRC"]) {
                    res.data.data[key]["NRC"].filter((comp) => {
                      lovs.push(key + "/" + comp);
                    });
                  }
                });
              }

              let schemaDiscountAppliesToRcNrc = [
                ...this.state.schemaDiscountAppliesToRcNrc,
              ];

              schemaDiscountAppliesToRcNrc.map((el) => {
                if (el.refName == "discountedItem") {
                  el.refLovs = [];
                  el.refLovs = lovs;
                }
              });
              this.setState({
                loading: false,
                schemaDiscountAppliesToRcNrc: schemaDiscountAppliesToRcNrc,
              });
            })
            .catch((error) => {
              console.log(error);
              if (this._isMounted) this.setState({ loading: false });
            });
        }
      }
    } else if (prevState["ugcType"] !== this.state["ugcType"]) {
      if (this.state["ugcType"]) {
        let serviceSubTypes = [];
        let schemaDiscountAppliesToUsage = [
          ...this.state.schemaDiscountAppliesToUsage,
        ];
        serviceSubTypes = Object.keys(
          this.state.discountUsageGroup[this.state.ugcType]
        );
        schemaDiscountAppliesToUsage.map((el) => {
          if (el.refName == "ugcSubType1") {
            el.refLovs = [];
            el.refLovs = serviceSubTypes;
          }
        });
        let schemaDiscountAll1 = [...this.state.schemaDiscountAll1];
        let schemaDiscountAll2 = [...this.state.schemaDiscountAll2];
        schemaDiscountAll1.map((el) => {
          if (el.refName == "ugcSubType2") {
            el.refLovs = [];
          }
        });

        schemaDiscountAll2.map((el) => {
          if (el.refName == "ugcSubType3") {
            el.refLovs = [];
          }
        });

        this.setState({
          schemaDiscountAppliesToUsage: schemaDiscountAppliesToUsage,
          schemaDiscountAll1: schemaDiscountAll1,
          schemaDiscountAll2: schemaDiscountAll2,
          classifier1: [],
          classifier2: [],
          classifier3: [],
          classifier4: [],
          zone: [],
          ugcSubType1: null,
          ugcSubType2: [],
          ugcSubType3: [],
        });
      }
    } else if (prevState["ugcSubType1"] !== this.state["ugcSubType1"]) {
      if (this.state["ugcSubType1"]) {
        let serviceSubSubType = [];
        let schemaDiscountAll1 = [...this.state.schemaDiscountAll1];
        serviceSubSubType = Object.keys(
          this.state.discountUsageGroup[this.state.ugcType][
            this.state.ugcSubType1
          ]
        );
        schemaDiscountAll1.map((el) => {
          if (el.refName == "ugcSubType2") {
            el.refLovs = [];
            el.refLovs = serviceSubSubType;
          }
        });

        this.setState({
          ugcSubType2: [],
          schemaDiscountAll1: schemaDiscountAll1,
        });
      }
    } else if (prevState["ugcSubType2"] !== this.state["ugcSubType2"]) {
      if (this.state["ugcSubType2"]) {
        let usageGroup = [];

        this.state.ugcSubType2.map((element) => {
          usageGroup.push(
            ...this.state.discountUsageGroup[this.state.ugcType][
              this.state.ugcSubType1
            ][element]
          );
        });
        usageGroup = Array.from(new Set(usageGroup));

        let schemaDiscountAll2 = [...this.state.schemaDiscountAll2];

        schemaDiscountAll2.map((el) => {
          if (el.refName == "ugcSubType3") {
            el.refLovs = [];
            el.refLovs = usageGroup;
          }
        });

        this.setState({
          schemaDiscountAll2: schemaDiscountAll2,
          ugcSubType3: usageGroup,
        });
      }
    } else if (prevState["classifier2"] !== this.state["classifier2"]) {
      if (this.state["classifier2"]) {
        let jurisdiction = [];

        this.state["classifier2"].map((countryCode) => {
          if (this.state.discountedItemsData["countryCodes"][countryCode]) {
            jurisdiction.push(
              ...this.state.discountedItemsData["countryCodes"][countryCode]
            );
          }
        });

        let schemaDiscountIsd1 = [...this.state.schemaDiscountIsd1];

        jurisdiction = Array.from(new Set(jurisdiction));

        schemaDiscountIsd1.map((el) => {
          if (el.refName == "classifier4") {
            el.refLovs = [];
            el.refLovs = jurisdiction;
          }
        });

        this.setState({
          schemaDiscountIsd1: schemaDiscountIsd1,
          classifier4: jurisdiction,
        });
      }
    } else if (prevState["classifier1"] !== this.state["classifier1"]) {
      if (this.state["classifier1"]) {
        if (this.state.ugcType == "IR") {
          let tapCodes = [];
          this.state["classifier1"].map((country) => {
            if (this.state.discountedItemsData["ir"][country]) {
              tapCodes.push(...this.state.discountedItemsData["ir"][country]);
            }
          });

          let schemaDiscountIr1 = [...this.state.schemaDiscountIr1];

          schemaDiscountIr1.map((el) => {
            if (el.refName == "classifier3") {
              el.refLovs = [];
              el.refLovs = tapCodes;
            }
          });

          this.setState({
            schemaDiscountIr1: schemaDiscountIr1,
            classifier3: tapCodes,
          });
        } else if (this.state.ugcType == "ISD") {
          let countryCodes = [];
          this.state["classifier1"].map((country) => {
            if (this.state.discountedItemsData["isd"][country]) {
              countryCodes.push(
                ...this.state.discountedItemsData["isd"][country]
              );
            }
          });
          let schemaDiscountIsd1 = [...this.state.schemaDiscountIsd1];

          schemaDiscountIsd1.map((el) => {
            if (el.refName == "classifier2") {
              el.refLovs = [];
              el.refLovs = countryCodes;
            }
          });
          this.setState({
            schemaDiscountIsd1: schemaDiscountIsd1,
            classifier2: countryCodes,
          });
        }
      }
    }
  }

  discountUsageGroupLovsData() {
    if (
      localStorage.getItem("discountUsageGroup") &&
      localStorage.discountUsageGroup_version &&
      localStorage.discountUsageGroup_version ==
        this.props.discountUsageGroupVersion
    ) {
      console.log("fetching discountUsageGroup from local storage");
      try {
        this.setState({
          discountUsageGroup: JSON.parse(
            localStorage.getItem("discountUsageGroup")
          ),
        });
      } catch (e) {
        localStorage.removeItem("discountUsageGroup");
      }
      return Promise.resolve();
    } else {
      console.log("fetching discountUsageGroup from api");
      return axios
        .get("discount/usageGrps", {
          headers: {
            opId: this.props.userInfo.opId,
          },
        })
        .then((res) => {
          localStorage.setItem(
            "discountUsageGroup",
            JSON.stringify(res.data.data)
          );
          this.setState({
            discountUsageGroup: res.data.data,
          });
          localStorage.discountUsageGroup_version =
            this.props.discountUsageGroupVersion;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  discountedItemsDataLovsData() {
    if (
      localStorage.getItem("discountedItemsData") &&
      localStorage.discountedItemsData_version &&
      localStorage.discountedItemsData_version ==
        this.props.discountedItemsDataVersion
    ) {
      console.log("fetching discountedItemsData from local storage");
      try {
        this.setState({
          discountedItemsData: JSON.parse(
            localStorage.getItem("discountedItemsData")
          ),
        });
      } catch (e) {
        localStorage.removeItem("discountedItemsData");
      }
      return Promise.resolve();
    } else {
      console.log("fetching discountedItemsData from api");
      return axios
        .get("discount/irIsdZone", {
          headers: {
            opId: this.props.userInfo.opId,
          },
        })
        .then((res) => {
          console.log(res);
          localStorage.setItem(
            "discountedItemsData",
            JSON.stringify(res.data.data)
          );
          this.setState({
            discountedItemsData: res.data.data,
          });
          localStorage.discountedItemsData_version =
            this.props.discountedItemsDataVersion;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  discountFields() {
    if (
      localStorage.getItem("discount") &&
      localStorage.discount_version &&
      localStorage.discount_version == this.props.discountVersion
    ) {
      console.log("fetching discount from local storage");
      try {
        this.setState({
          schemaDiscount: JSON.parse(localStorage.getItem("discount")),
        });
      } catch (e) {
        localStorage.removeItem("discount");
      }
      return Promise.resolve();
    } else {
      console.log("fetching discount from api");
      return axios
        .get("package/config?entityName=package.discount", {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
            Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        })
        .then((res) => {
          console.log(res);
          localStorage.setItem("discount", JSON.stringify(res.data.data));
          this.setState({
            schemaDiscount: res.data.data,
          });
          localStorage.discount_version = this.props.discountVersion;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }
  componentWillUnmount() {
    this._isMounted = false;
  }

  discountlovData() {
    if (this.props.entity === "Product" && this.props.id) {
      console.log("required");

      return axios
        .get("ratePlan/dependentLovs?param=product.discount", {
          headers: {
            opId: this.props.userInfo.opId,
          },
        })
        .then((res) => {
          console.log(res);
          this.setState({
            discountLovs: res.data.data,
          });
        })
        .catch((error) => {
          console.log(error);
          this.setState({ loading: false });
        });
    } else {
      console.log("not required");
      return Promise.resolve();
    }
  }

  componentDidMount() {
    this._isMounted = true;
    this.discountUsageGroupLovsData().then(() => {
      this.discountedItemsDataLovsData().then(() => {
        this.discountlovData().then(() => {
          this.discountFields().then(() => {
            let discountGroups = {};
            this.state.schemaDiscount.map((el) => {
              let arr = [];
              let lovs = [];
              if (!(el.uiGroup in discountGroups)) {
                this.state.schemaDiscount.filter((elem) => {
                  if (
                    elem.uiGroup == el.uiGroup &&
                    elem.uiGroup != "Discounted Items" &&
                    elem.uiGroup != "Discount Definition"
                  ) {
                    if (
                      elem.refType == "SelectInput" ||
                      elem.refType == "MultiSelect"
                    ) {
                      if (elem.refLovs) {
                        lovs = elem.refLovs.split(",");
                        elem.refLovs = lovs;
                      } else {
                        elem.refLovs = [];
                      }
                    }
                    arr.push(elem);
                  }
                });
                discountGroups[el.uiGroup] = arr;
              }
            });

            let arrDt = [];
            let arrDd = [];
            let schemaDiscountAppliesToUsage = [];
            let schemaDiscountAppliesToRcNrc = [];
            let schemaDiscountAll1 = [];
            let schemaDiscountAll2 = [];
            let schemaDiscountAll3 = [];
            let schemaDiscountIr1 = [];
            let schemaDiscountIr2 = [];
            let schemaDiscountIr3 = [];
            let schemaDiscountIsd1 = [];
            let schemaDiscountIsd2 = [];
            let schemaDiscountIsd3 = [];
            let schemaDiscountTiered = [];

            this.state.schemaDiscount.map((elem) => {
              let lovs = [];

              if (elem.uiGroup == "Discount Definition") {
                if (
                  elem.refType == "SelectInput" ||
                  elem.refType == "MultiSelect"
                ) {
                  if (elem.refLovs) {
                    lovs = elem.refLovs.split(",");
                    lovs = lovs.map((val) => {
                      return val.replace("-", ",");
                    });
                    elem.refLovs = lovs;
                  } else {
                    elem.refLovs = [];
                  }
                }
                console.log(elem);
                if (elem.groupName == "mandatory") {
                  arrDd.push(elem);
                } else if (elem.groupName.includes("tiered")) {
                  schemaDiscountTiered.push(elem);
                }
              } else if (elem.uiGroup == "Discounted Items") {
                if (
                  elem.refType == "SelectInput" ||
                  elem.refType == "MultiSelect"
                ) {
                  if (elem.refName == "zone") {
                    elem.refLovs = Object.keys(
                      this.state.discountedItemsData["zones"]
                    );
                  } else if (elem.refName == "classifier1") {
                    let lovs = [];
                    Object.keys(this.state.discountedItemsData["zones"]).filter(
                      (el) => {
                        lovs = lovs.concat(
                          this.state.discountedItemsData["zones"][el]
                        );
                      }
                    );
                    console.log(lovs);
                    elem.refLovs = lovs;
                  } else if (elem.refName == "ugcType") {
                    let lovs = [];
                    lovs = Object.keys(this.state.discountUsageGroup);
                    lovs = lovs.map((val) => {
                      return val.replace("-", ",");
                    });
                    elem.refLovs = lovs;
                  } else if (elem.refLovs) {
                    lovs = elem.refLovs.split(",");
                    lovs = lovs.map((val) => {
                      return val.replace("-", ",");
                    });
                    elem.refLovs = lovs;
                  } else {
                    elem.refLovs = [];
                  }
                }

                if (elem.groupName == "mandatory") {
                  arrDt.push(elem);
                } else if (elem.groupName.includes("all")) {
                  if (elem.groupName.includes("all1")) {
                    schemaDiscountAll1.push(elem);
                    schemaDiscountIr1.push(elem);
                    schemaDiscountIsd1.push(elem);
                  } else if (elem.groupName.includes("all2")) {
                    schemaDiscountAll2.push(elem);
                    schemaDiscountIr2.push(elem);
                    schemaDiscountIsd2.push(elem);
                  } else if (elem.groupName.includes("all3")) {
                    schemaDiscountAll3.push(elem);
                    schemaDiscountIr3.push(elem);
                    schemaDiscountIsd3.push(elem);
                  }
                } else if (elem.groupName.includes("appliesToRc_Nrc")) {
                  schemaDiscountAppliesToRcNrc.push(elem);
                } else if (elem.groupName.includes("appliesToUsage")) {
                  schemaDiscountAppliesToUsage.push(elem);
                } else {
                  if (elem.groupName.includes("IR")) {
                    if (elem.groupName.includes("IR1"))
                      schemaDiscountIr1.push(elem);
                    else if (elem.groupName.includes("IR2"))
                      schemaDiscountIr2.push(elem);
                    else if (elem.groupName.includes("IR3"))
                      schemaDiscountIr3.push(elem);
                  }
                  if (elem.groupName.includes("ISD")) {
                    if (elem.groupName.includes("ISD1"))
                      schemaDiscountIsd1.push(elem);
                    else if (elem.groupName.includes("ISD2"))
                      schemaDiscountIsd2.push(elem);
                    else if (elem.groupName.includes("ISD3"))
                      schemaDiscountIsd3.push(elem);
                  }
                }
              }
            });

            discountGroups["Discounted Items"] = arrDt;
            discountGroups["Discount Definition"] = arrDd;

            if (this.props.entity === "Product" && this.props.id) {
              let cts =
                this.props.productData.productCategoryId +
                "-" +
                this.props.productData.productTypeId +
                "-" +
                this.props.productData.productSubTypeId;
              console.log(cts);
              if (this.state.discountLovs[cts]) {
                let discountDefinition = [
                  ...discountGroups["Discount Definition"],
                ];
                discountDefinition.map((field) => {
                  if (field.refName === "uom") {
                    field.refLovs = [...this.state.discountLovs[cts]];
                  }
                });
                discountGroups["Discount Definition"] = [...discountDefinition];
              }
            }
            this.setState({
              discountGroups: discountGroups,
              schemaDiscountAppliesToUsage: schemaDiscountAppliesToUsage,
              schemaDiscountAppliesToRcNrc: schemaDiscountAppliesToRcNrc,
              schemaDiscountAll1: schemaDiscountAll1,
              schemaDiscountAll2: schemaDiscountAll2,
              schemaDiscountAll3: schemaDiscountAll3,
              schemaDiscountIr1: schemaDiscountIr1,
              schemaDiscountIr2: schemaDiscountIr2,
              schemaDiscountIr3: schemaDiscountIr3,
              schemaDiscountIsd1: schemaDiscountIsd1,
              schemaDiscountIsd2: schemaDiscountIsd2,
              schemaDiscountIsd3: schemaDiscountIsd3,
              schemaDiscountTiered: schemaDiscountTiered,
              loading: false,
            });
            console.log(this.props.discountData);
            console.log(this.props.discountData.componentIdDiscount);

            if (Object.keys(this.props.discountData).length > 0) {
              Object.keys(this.props.discountData).forEach((key) => {
                this.setState({ [key]: this.props.discountData[key] });
              });
              if (
                this.state.discountAppliedOn == "RC" ||
                this.state.discountAppliedOn == "NRC"
              ) {
                let discountedItem = this.state.discountedItem.substring(
                  0,
                  this.state.discountedItem.lastIndexOf(
                    "_",
                    this.state.discountedItem.lastIndexOf("_") - 1
                  )
                );

                discountedItem =
                  discountedItem + "/" + this.state.discountedItem;
                this.setState({
                  discountedItem: discountedItem,
                });
              }
            }
          });
        });
      });
    });
  }

  validateHandler = () => {
    try{
		return axios
			.get(
				`attribute/validation?packageId=${this.props.id}&releaseID=${this.props.releaseData.releaseId}`,
				{
					headers: {
						opId: this.props.userInfo.opId,
						buId: this.props.userInfo.buId,
            Authorization:'Bearer '+ this.props.userInfo.jwt
					},
				}
			)
			.then((res) => {
				if(res.data.statusMsg==="SUCCESS"){
				this.setState({
					
					isValidated: true,
					openSnack:true,
					message:"Success",
				});}
				else{
					this.setState({
					openSnack:true,
					message:"Failure",
					})
				}
			});
    }catch(err) {
      console.error(err);
    }
	};

  errorConfirmedHandler = () => {
    this.setState({ show: false });
  };
  handleClose = (event, reason) => {
		if (reason === 'clickaway') {
						return;
					}
		this.setState({ openSnack: false })
	};
  

  inputHelper(formElement) {
    if (formElement.refType == "MultiSelect")
      return (
        <Grid item xs={12} sm={4} md={2} key={formElement.refName}>
          <Box>
            <span style={{}}>{formElement.uiName}</span>
          </Box>
          <Box mt={2}>
            <MultiSelect
              refLovs={formElement.refLovs}
              value={this.state[formElement.refName]}
              {...formElement}
              changed={(selected) => {
                console.log(selected);
                if (!(selected instanceof Array)) selected = [selected];

                this.setState({
                  [formElement.refName]: selected,
                });
              }}
              // placeholder={offerability}
            />
          </Box>
        </Grid>
      );
    else
      return (
        <Input
          key={formElement.refName}
          {...formElement}
          value={formElement.refName === 'componentFlag' 
        ? this.state[formElement.refName] ??
          formElement.defaultValue:
          formElement.refName === "componentLevel" ?
          this.state.serviceType:
          this.state[formElement.refName]}

          disabled={formElement.isDisabled == "Y" ? true : false}
          required={formElement.isMandatory == "Y" ? true : false}
          checkChanged={(event) => {
            this.setState({
              [formElement.refName]: event.target.checked ? "Y" : "N",
            });
          }}
          changed={(event) => {
            if (!event.target) {
              // this.setState({
              //   [formElement.refName]: event,
              // });
              if (formElement.refName==='componentLevel'){
                this.setState({serviceType :event })
              }
              else{
                this.setState({
                  [formElement.refName]: event,
                });
              } 

            } else {
              // if (event.target.type !== 'checkbox')
              this.setState({
                [formElement.refName]: event.target.value,
              });
              // else {
              //     console.log(event.target.checked)
              //     this.setState({
              //         [formElement.refName]:
              //             event.target.checked
              //     })
              // }
            }
          }}
        />
      );
  }

  saveDirectDiscountHandler = (event) => {
		event.preventDefault();
    debugger;
		if (this.props.id) {
			this.setState({
				loading: true,
			});
			let payload = {};
			let date = moment().format('DD-MMM-YY');
			this.state.schemaDiscount.map((formElement) => {
				console.log(formElement);
				if (formElement.refType === 'Date') {
					payload[formElement.refName] = moment(
						this.state[formElement.refName]
					).format('DD-MMM-YY');
				} else if (formElement.refType === 'Checkbox') {
					payload[formElement.refName] =
						this.state[formElement.refName] === null ||
						this.state[formElement.refName] === undefined
							? 'N'
							: this.state[formElement.refName];
				} else if (
					formElement.refType === 'TextInput' ||
					formElement.refType === 'TextArea'
				) {
					payload[formElement.refName] = this.state[formElement.refName];
				} else {
					console.log(formElement.refType);
					payload[formElement.refName] =
						this.state[formElement.refName] ?? formElement.defaultValue;
				}
			})
      payload.catalogId = 'B2C';
			payload.createdBy = this.props.userInfo.id;
			payload.createdDate = date;
			payload.endDate = '30-Dec-30';
			payload.startDate = date;
			payload.buId = this.props.userInfo.buId;
			payload.opId = this.props.userInfo.opId;
			payload.releaseId = this.props.releaseData.releaseId;
			payload.id = this.props.id;
			payload.componentType = this.props.entity + 'Components';
			payload.chargeCurrency = 'INR';
			payload.componentLevel=this.state.serviceType
      payload.componentFlag=this.state.componentFlag? 
      this.state.componentFlag === 'Yes'
      ? 'Yes'
      : 'No'
    : 'Yes';

			if (
				this.state.discountAppliedOn === 'RC' ||
				this.state.discountAppliedOn === 'NRC'
			)
				payload.discountedItem = this.state.discountedItem.split('/')[1];
        console.log('KIKI',this.state.discountedItem)

			if (!this.state.componentIdDiscount) {
        console.log('KK',this.state.componentIdDiscount)
				console.log('post request');
				console.log(payload);
        debugger;
				axios
        
					.post('discount/direct', payload, {
						headers: {
							opId: this.props.userInfo.opId,
						},
					})
          .then((response) => {
						console.log(response);
            

						let objDiscount = {};
						objDiscount.discountId = response.data.data;
						objDiscount.discountAppliedOn = this.state.discountAppliedOn;
						if (this.state.isDiscountTiered === 'Y')
							objDiscount.discountValue =
								this.state.discountCeiling + ' ' + this.state.uom;
						else
							objDiscount.discountValue =
								this.state.discountValue + ' ' + this.state.uom;
						this.props.addComponent(objDiscount);

						this.setState({
							componentIdDiscount: response.data.data,
							loading: false,
              // componentIdDiscount:''
						});

            if (this._isMounted){
              
              this.state.timeBand = '';
              this.state.ugcSubType3 = '';
              this.state.ugcSubType2 = '';
              this.state.ugcSubType1 = '';
              this.state.ugcType = '';
               this.state.discountCeiling = '';
            this.state.discountFloor = '';
              this.state.discountedItem='';
              this.state.discountAppliedOn = '';
              this.state.uom = '';
                this.state.discountValue = '';
                this.state.discountConfType = '';}

					})
					.catch((error) => {
						console.log(error);
						if (this._isMounted) this.setState({ loading: false });
					});
			} 
      else {
				console.log('put request');

				payload.componentId = this.state.componentIdDiscount;
				console.log(payload);

				axios
					.post('discount/direct', payload, {
						headers: {
							opId: this.props.userInfo.opId,
						},
					})
					.then((response) => {
						console.log(response.data.data);
						let objDiscount = {};
						objDiscount.discountId = response.data.data;
						objDiscount.discountAppliedOn = this.state.discountAppliedOn;
						if (this.state.isDiscountTiered === 'Y')
							objDiscount.discountValue =
								this.state.discountCeiling + ' ' + this.state.uom;
						else
							objDiscount.discountValue =
								this.state.discountValue + ' ' + this.state.uom;

						this.props.updateComponent(
							objDiscount,
							this.state.componentIdDiscount
						);
            this.setState({
							componentIdDiscount: response.data.data,
              // componentIdDiscount:'', 
							loading: false,
						});
            if (this._isMounted){
              
              this.state.timeBand = '';
              this.state.ugcSubType3 = '';
              this.state.ugcSubType2 = '';
              this.state.ugcSubType1 = '';
              this.state.ugcType = '';
            this.state.discountFloor = '';
            this.state.discountCeiling = '';
              
              this.state.discountAppliedOn = '';
              
              this.state.discountedItem = '';
              this.state.uom = '';
                this.state.discountValue = '';
                this.state.discountConfType = '';}
					})
					.catch((error) => {
						console.log(error);
						if (this._isMounted) this.setState({ loading: false });
					});
			}
		} else {
			let modalContent = (
				<Typography variant="h6">
					{' '}
					Submit Basic {this.props.entity} Details first.{' '}
				</Typography>
			);
			this.setState({ modalContent: modalContent, show: true });
		}
	
};

  render() {
    const { classes } = this.props;
    const vertical='top'
    const horizontal='center' 
    let pricing = (
      <>
      <Snackbar anchorOrigin={{ vertical, horizontal }}
                        open={this.state.openSnack} autoHideDuration={3000} onClose={this.handleClose}>
                        <Alert onClose={this.handleClose} severity="success">
                            {this.state.message}
                        </Alert>
                    </Snackbar>
      <Grid container alignContent="flex-start" spacing={2}>
        <Modal
          show={this.state.show}
          modalClosed={this.errorConfirmedHandler}
          title={"Something Went Wrong!"}
        >
          {this.state.modalContent}
        </Modal>
        <Grid item xs={12}>
          <form onSubmit={this.saveDirectDiscountHandler}>
            {Object.keys(this.state.discountGroups).map((key) => {
              return (
                <Card
                  key={key}
                  style={{ marginTop: "1%", overflow: "visible" }}
                >
                  <CardHeader
                    className={classes.cardHeader}
                    classes={{
                      subheader: classes.subheader,
                    }}
                    subheader={key}
                    action={
                      key == "Discount Definition" && (
                        <LightTooltip title="New Discount Component" arrow>
                          <AddIcon
                            onClick={() => {
                              this.setState({
                                componentIdDiscount: "",
                              });

                              this.state.schemaDiscount.map((formElement) => {
                                if (formElement.refType == "Date")
                                  this.setState({
                                    [formElement.refName]:
                                      formElement.defaultValue
                                        ? moment(
                                            formElement.defaultValue
                                          ).format("DD-MMM-YY")
                                        : moment().format("DD-MMM-YY"),
                                  });
                                else if (formElement.refType == "Checkbox")
                                  this.setState({
                                    [formElement.refName]: "N",
                                  });
                                else if (formElement.refType == "MultiSelect")
                                  this.setState({
                                    [formElement.refName]: [],
                                  });
                                else
                                  this.setState({
                                    [formElement.refName]: "",
                                  });
                              });
                            }}
                            style={{
                              color: "white",
                              marginRight: "10px",
                              cursor: "pointer",
                            }}
                          />
                        </LightTooltip>
                      )
                    }
                  />

                  <CardContent>
                    <Grid container alignItems="flex-end" spacing={2}>
                      {this.state.discountGroups[key].map((formElement) =>
                        this.inputHelper(formElement)
                      )}
                    </Grid>
                    {this.state.isDiscountTiered == "Y" &&
                      key == "Discount Definition" && (
                        <Grid
                          container
                          alignItems="flex-end"
                          spacing={2}
                          style={{
                            marginTop: ".5%",
                          }}
                        >
                          {this.state.schemaDiscountTiered.map((formElement) =>
                            this.inputHelper(formElement)
                          )}
                        </Grid>
                      )}

                    {this.state.discountAppliedOn == "USAGE" &&
                      key == "Discounted Items" && (
                        <Grid
                          container
                          alignItems="flex-end"
                          spacing={2}
                          style={{
                            marginTop: ".5%",
                          }}
                        >
                          {this.state.schemaDiscountAppliesToUsage.map(
                            (formElement) => this.inputHelper(formElement)
                          )}
                        </Grid>
                      )}

                    {(this.state.discountAppliedOn == "RC" ||
                      this.state.discountAppliedOn == "NRC") &&
                      key == "Discounted Items" && (
                        <Grid
                          container
                          alignItems="flex-end"
                          spacing={2}
                          style={{
                            marginTop: ".5%",
                          }}
                        >
                          {this.state.schemaDiscountAppliesToRcNrc.map(
                            (formElement) => this.inputHelper(formElement)
                          )}
                        </Grid>
                      )}

                    {this.state.discountAppliedOn == "USAGE" &&
                      this.state.ugcType == "IR" &&
                      key == "Discounted Items" && (
                        <React.Fragment>
                          <Grid
                            container
                            alignItems="flex-end"
                            spacing={2}
                            style={{
                              marginTop: ".5%",
                            }}
                          >
                            {this.state.schemaDiscountIr1.map((formElement) =>
                              this.inputHelper(formElement)
                            )}
                          </Grid>
                          <Grid
                            container
                            alignItems="flex-end"
                            spacing={2}
                            style={{
                              marginTop: ".5%",
                            }}
                          >
                            {this.state.schemaDiscountIr2.map((formElement) =>
                              this.inputHelper(formElement)
                            )}
                          </Grid>
                          <Grid
                            container
                            alignItems="flex-end"
                            spacing={2}
                            style={{
                              marginTop: ".5%",
                            }}
                          >
                            {this.state.schemaDiscountIr3.map((formElement) =>
                              this.inputHelper(formElement)
                            )}
                          </Grid>
                        </React.Fragment>
                      )}

                    {this.state.discountAppliedOn == "USAGE" &&
                      this.state.ugcType == "ISD" &&
                      key == "Discounted Items" && (
                        <React.Fragment>
                          <Grid
                            container
                            alignItems="flex-end"
                            spacing={2}
                            style={{
                              marginTop: ".5%",
                            }}
                          >
                            {this.state.schemaDiscountIsd1.map((formElement) =>
                              this.inputHelper(formElement)
                            )}
                          </Grid>
                          <Grid
                            container
                            alignItems="flex-end"
                            spacing={2}
                            style={{
                              marginTop: ".5%",
                            }}
                          >
                            {this.state.schemaDiscountIsd2.map((formElement) =>
                              this.inputHelper(formElement)
                            )}
                          </Grid>
                          <Grid
                            container
                            alignItems="flex-end"
                            spacing={2}
                            style={{
                              marginTop: ".5%",
                            }}
                          >
                            {this.state.schemaDiscountIsd3.map((formElement) =>
                              this.inputHelper(formElement)
                            )}
                          </Grid>
                        </React.Fragment>
                      )}

                    {this.state.discountAppliedOn == "USAGE" &&
                      this.state.ugcType &&
                      this.state.ugcType != "ISD" &&
                      this.state.ugcType != "IR" &&
                      key == "Discounted Items" && (
                        <React.Fragment>
                          <Grid
                            container
                            alignItems="flex-end"
                            spacing={2}
                            style={{
                              marginTop: ".5%",
                            }}
                          >
                            {this.state.schemaDiscountAll1.map((formElement) =>
                              this.inputHelper(formElement)
                            )}
                          </Grid>
                          <Grid
                            container
                            alignItems="flex-end"
                            spacing={2}
                            style={{
                              marginTop: ".5%",
                            }}
                          >
                            {this.state.schemaDiscountAll2.map((formElement) =>
                              this.inputHelper(formElement)
                            )}
                          </Grid>
                          <Grid
                            container
                            alignItems="flex-end"
                            spacing={2}
                            style={{
                              marginTop: ".5%",
                            }}
                          >
                            {this.state.schemaDiscountAll3.map((formElement) =>
                              this.inputHelper(formElement)
                            )}
                          </Grid>
                        </React.Fragment>
                      )}
                  </CardContent>
                </Card>
              );
            })}

            {this.props.releaseData.releaseId && (
              <div
                style={{
                  display: "flex",
                    justifyContent: "flex-end",
                  alignItems: "center",
                }}
              >
                <Button
                  //   variant="contained"
                  onClick={() => {
                    if (this.props.entity === "Package")
                      this.props.changePackageActiveStep(2);
                    else this.props.changeProductActiveStep(1);
                  }}
                  style={{
                    // background: "#02bfa0",
                    textTransform: 'none',
                    marginTop: '1%',
                    marginLeft: '20px',
                    background: '#5dc17f',
                  }}
                  className={classes.btn}
                >
                  Back
                </Button>
                <Button
                //   variant="contained"
                onClick={this.validateHandler}
                style={{
                  // background: "#02bfa0",
                  textTransform: 'none',
                  marginTop: '1%',
                  marginLeft: '20px',
                  background: '#5dc17f',
                }}
                disabled={!this.props.id}
              >
                Validate
              </Button>

                <Button
                //   variant="contained"
                type="submit"
                style={{
                  // background: "#02bfa0",
                  textTransform: 'none',
                  marginTop: '1%',
                  marginLeft: '20px',
                  background: '#5dc17f',
                }}
                disabled={this.props.releaseData.releaseStatus !== 'InProgress'}
              >
                Save
              </Button>
                <Button
                  //   variant="contained"
                  onClick={() => {
                    if (this.props.entity === "Package")
                      this.props.changePackageActiveStep(4);
                    else this.props.changeProductActiveStep(3);
                  }}
                  style={{
                    
                      // background: "#02bfa0",
                      textTransform: 'none',
                      marginTop: '1%',
                      marginLeft: '20px',
                      background: '#5dc17f',
                    
                  }}
                  className={classes.btn}
                >
                  Next
                </Button>
               
              </div>
            )}
          </form>
        </Grid>
      </Grid>
      </>
    );

    if (this.state.loading) pricing = <Loader relative />;
    return pricing;
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    changePackageActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
        activeStep: activeStep,
      }),
    changeProductActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP,
        activeStep: activeStep,
      }),
  };
};

export default connect(
  null,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(DiscountPricing, axios)));

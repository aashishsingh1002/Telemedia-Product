const es = {
    loginPage: {
        userName: "Usuario Nombre",
        password: "Contraseña",
        login: 'Iniciar sesión'
    },
    dashboard: {
        myReleases: 'Mi Lanzamientos',
        newRelease: 'Nuevo lanzamiento',
        releaseNo: 'Número de versión',
        releaseObj: 'Objetivo de lanzamiento',
        creationDate: 'Fecha de creación',
        status: 'Estado',
        pendingWith: 'Pendiente de',
        enablers: 'Habilitadores',
        proConfig: 'Configuración del producto',
        bundles: 'manojos',
        products: 'Productos',
        contracts: 'Contratos',
        contractsProfiles: 'Perfiles de contratos',
        attributeConfiguration: 'Configuración de atributos',
        ratePlanConfiguration: 'Configuración del plan de tarifas',
        eventsConfiguration: 'Configuración de eventos',
        workQueue: 'Cola de trabajo',
        productPerformance: 'Rendimiento del producto',
        attachment: 'Adjunto archivo',
        auditLogs: 'Registros de auditoría',
        releaseTreeView: 'Vista de árbol de versiones',
        selectApprover: 'Seleccionar aprobador',
        advanceSearch: 'Búsqueda avanzada'
    }
}

export default es;
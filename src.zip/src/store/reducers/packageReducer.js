import * as actionTypes from '../actions/actionTypes';

const initialState = {
    packageData: {},
    pkgKey: 'pkg',
    activeStep: 0
};

const insidePackage = (state, action) => {
    console.log(action.packageData)
    console.log('insidePackage')

    return {
        ...state,
        packageData: { ...action.packageData },
    }
};

const changePackageKey = (state, action) => {
    let key = action.pkgKey.length > 10 ? 'pkg' : action.pkgKey
    return {
        ...state,
        pkgKey: key,
    }
};

const changePackageActiveStep = (state, action) => {
    return {
        ...state,
        activeStep: action.activeStep,
    }
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.INSIDE_PACKAGE: return insidePackage(state, action);
        case actionTypes.CHANGE_PACKAGE_KEY: return changePackageKey(state, action);
        case actionTypes.CHANGE_PACKAGE_ACTIVE_STEP: return changePackageActiveStep(state, action);
        default:
            return state;
    }
};

export default reducer;

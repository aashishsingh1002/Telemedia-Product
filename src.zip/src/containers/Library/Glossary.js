import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { createSelector } from "reselect";
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import ImageIcon from "@material-ui/icons/Image";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import axios from "../../axios-epc";

const useStyles = makeStyles({
	cardContainer: { padding: "1rem" },
	cardItem: {
		textAlign: "center",
		padding: "2rem",
		cursor: "pointer",
		
	},
	iconStyle: {
		width: "5rem",
		height: "3rem",
	},
});

const selectUserInfo = createSelector(
	(state) => state.login.loggedInUserInfo,
	(loggedInUserInfo) => loggedInUserInfo
);

const getGlossaryItem = (userInfo) => {
	return axios
		.get("telemediaAttach/get/appendix-documents", {
			headers: {
				opId: userInfo.opId,
				buId: userInfo.buId,
			},
		})
		.then((res) => {
			return res.data.data;
		})
		.catch((error) => {
			console.log(error);
		});
};

const downloadFile = (glossary, userInfo) => {
	debugger;
	return axios
		.get("telemediaAttach/download/appendix?name=" + glossary.key, {
			headers: {
				opId: userInfo.opId,
				buId: userInfo.buId,
			},
			responseType: "blob",
		})
		.then((res) => {
			console.log(res);
			var headers = res.headers;
			var blob = new Blob([res.data], {
				type: headers["content-type"],
			});

			var link = document.createElement("a");
			link.href = window.URL.createObjectURL(blob);
			link.download = `${glossary.fileName}.${glossary.fileType.toLowerCase()}`;
			document.body.appendChild(link);
			link.click();
		})
		.catch((error) => {
			console.log(error);
		});
};

const Glossary = () => {
	const classes = useStyles();
	const [glossaries, setGlossaries] = useState([]);

	const userInfo = useSelector(selectUserInfo);

	useEffect(() => {
		getGlossaryItem(userInfo).then((res) => {
			setGlossaries(res);
		});
	}, []);
debugger;
	return (
		<>
			<Card className={classes.cardContainer}>
				<Typography paragraph variant={"h6"}>
					Glossary
				</Typography>
				<Grid container spacing={20}>
					{glossaries.length > 0 &&
						glossaries.map((glossary) => {
							return (
								<Grid item xs={9} sm={3}>
									<Card
										className={classes.cardItem}
										onClick={() => {
											downloadFile(glossary, userInfo);
										}}>
										<ImageIcon className={classes.iconStyle} />
										<Typography>{glossary.fileName}</Typography>
									</Card>
								</Grid>
							);
						})}
				</Grid>
			</Card>
		</>
	);
};

export default Glossary;

import React, { Component } from "react";
import Table from "../../UI/Table/Table";
import axios from "../../axios-epc";
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import Tooltip from "@material-ui/core/Tooltip";
import Loader from "../../UI/Loader/Loader";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import IconButton from "@material-ui/core/IconButton";
import Chip from "@material-ui/core/Chip";
import BookIcon from "@material-ui/icons/Book";
import MenuBookIcon from "@material-ui/icons/MenuBook";
import AttachmentIcon from "@material-ui/icons/Attachment";
import Attachment from "../Dashboard/AttachmentAllrelease";
import AuditLogs from "../Dashboard/AuditLogs";
// import Literature from '../Dashboard/Literature'
import * as actionTypes from "../../store/actions/actionTypes";
import Title from "../../UI/Typography/Title";

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: "#525354",
    color: "white",
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

const getColor = {
  Deployed: "#1565c0",
  InProgress: "#528548",
  Cancelled: "#fc0a5b",
  "Approval In Progress": "#ff9100",
  "Design InProgress": "#528548",
  Approved: "#1565c0",
  "PCN Approved": "#1565c0",
};

class AllReleases extends Component {
  _isMounted = false;

  state = {
    anchorEls: [],
    attachment: false,
    auditLogs: false,
    literature: false,
    show: false,
    relData: {},
    attachment: false,
    loading: true,
    data: [],
    columns: [
      {
        title: "Release No.",
        field: "externalReleaseId",
        // cellStyle: { width: '10%' }
      },
      {
        title: "Release Objective",
        field: "remarks",
        sorting: false,
        render: (rowData) => (
          <Tooltip
            interactive
            title={
              <pre
                style={{
                  fontSize: "12px",
                  overflow: "auto",
                  maxHeight: "40vh",
                  maxWidth: "60vw",
                }}
              >
                {rowData.remarks}
              </pre>
            }
          >
            <span>
              {" "}
              {rowData.remarks
                ? rowData.remarks.length > 25
                  ? rowData.remarks.substring(0, 25) + "..."
                  : rowData.remarks
                : ""}
            </span>
          </Tooltip>
        ),
        // cellStyle: { width: '25%' },
      },

      {
        title: "Creation Date",
        field: "createdOn",
        // cellStyle: { width: '10%' },
      },
      {
        title: "Status",
        field: "releaseStatus",
        // cellStyle: { width: '10%' },
        render: (rowData) => (
          //   <Chip
          //     label={rowData.releaseStatus}
          //     style={{
          //       background: getColor[rowData.releaseStatus],
          //       color: "white",
          //       fontSize: "10px",
          //     }}
          //   />
          <span style={{ color: getColor[rowData.releaseStatus] }}>
            {rowData.releaseStatus}
          </span>
        ),
        sorting: false,
      },
      {
        title: "Pending With",
        field: "pendingWith",
        sorting: false,
        render: (rowData) => (
          <Tooltip
            interactive
            title={
              <pre
                style={{
                  fontSize: "12px",
                  overflow: "auto",
                  maxHeight: "40vh",
                  maxWidth: "60vw",
                }}
              >
                {rowData.pendingWith}
              </pre>
            }
          >
            <span>
              {" "}
              {rowData.pendingWith
                ? rowData.pendingWith.length > 25
                  ? rowData.pendingWith.substring(0, 25) + "..."
                  : rowData.pendingWith
                : ""}
            </span>
          </Tooltip>
        ),
        // cellStyle: { width: '15%' },
      },
      {
        title: "Created By",
        field: "createdBy",
        sorting: false,
        // cellStyle: { width: '10%' }
      },

      {
        title: "Enablers",
        field: "enablers",
        filtering: false,
        cellStyle: { width: "100px" },
        render: (rowData) => (
          <React.Fragment>
            <LightTooltip title={"Attachment"} arrow>
              <IconButton
                onClick={(event) => {
                  event.stopPropagation();
                  if (rowData.releaseStatus !== "Cancelled") {
                    this.setState({ relData: { ...rowData } });
                    this.setState({ attachment: true });
                  }
                }}
                style={{ marginRight: "2%" }}
              >
                <AttachmentIcon />
              </IconButton>
            </LightTooltip>
            <LightTooltip title={"Audit Logs"} arrow>
              <IconButton
                onClick={(event) => {
                  event.stopPropagation();
                  this.setState({ relData: { ...rowData } });
                  this.setState({ auditLogs: true });
                }}
                style={{ marginRight: "2%" }}
              >
                <BookIcon />
              </IconButton>
            </LightTooltip>
          </React.Fragment>
        ),
        sorting: false,
      },
    ],
  };

  componentDidMount() {
    this._isMounted = true;
    this.props.onReleaseExit();
    this.allReleasesHandler().then(() => {
      if (this._isMounted) this.setState({ loading: false });
    });
  }

  allReleasesHandler = () => {
    return axios
      .get("telemediaDashboard/allReleases", {
        headers: {
          buId: this.props.userInfo.buId,
          opId: this.props.userInfo.opId,
          Authorization : 'Bearer ' + this.props.userInfo.jwt,
        },
      })
      .then((res) => {
        console.log(res);
        let data = [];
        res.data.data.filter((element) => {
          var obj = {};
          obj = { ...element.myReleases };
          obj.pendingWith = element.pendingWith;
          data.push(obj);
        });
        if (this._isMounted) {
          this.setState({ data: data });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  showAttachmentHandler = () => {
    this.setState({ attachment: false });
  };

  showAuditLogsHandler = () => {
    this.setState({ auditLogs: false });
  };

  showLiteratureHandler = () => {
    this.setState({ literature: false });
  };

  render() {
    let allReleases = (
      <React.Fragment>
        {/* <Modal
                    show={this.state.show}
                    modalClosed={this.errorConfirmedHandler}
                    title={'Something Went Wrong!'}
                >
                    {this.state.modalContent}
                </Modal> */}
        <div>
          <Title>All Releases</Title>
        </div>
        <Table
          title="All Releases"
          data={this.state.data}
          columns={this.state.columns}
          pageSize={5}
          fontSize={"12px"}
        />
        {this.state.attachment ? (
          <Attachment
            userInfo={this.props.userInfo}
            showAttachment={this.showAttachmentHandler}
            releaseData={this.state.relData}
          />
        ) : null}
        {this.state.auditLogs ? (
          <AuditLogs
            showAuditLogs={this.showAuditLogsHandler}
            releaseData={this.state.relData}
          />
        ) : null}

        {/* {this.state.literature ?
                    <Literature userInfo={this.props.userInfo}
                        showLiterature={this.showLiteratureHandler}
                        releaseData={this.state.relData} /> : null} */}
      </React.Fragment>
    );
    if (this.state.loading) allReleases = <Loader />;
    return allReleases;
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onReleaseExit: () =>
      dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: {} }),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(WithErrorHandler(AllReleases, axios));

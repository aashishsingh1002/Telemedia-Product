import * as actionTypes from '../actions/actionTypes';

const initialState = {
    searchItems: [],
    searchValue: '',
    entity: ''
};

const setSearchItems = (state, action) => {
    return {
        ...state,
        searchValue: '',
        searchItems: [...action.searchItems],
        entity: action.entity
    }
};

const setSearchValue = (state, action) => {
    return {
        ...state,
        searchValue: action.searchValue
    }
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.SET_SEARCH_ITEMS: return setSearchItems(state, action);
        case actionTypes.SET_SEARCH_VALUE: return setSearchValue(state, action);
        default:
            return state;
    }
};

export default reducer;
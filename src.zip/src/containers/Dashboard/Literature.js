import React, { Component } from 'react';
import Modal from '../../UI/Modal/Modal';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';
import Button from '@material-ui/core/Button';
import AttachmentIcon from '@material-ui/icons/Attachment';
import { connect } from 'react-redux';

class Literature extends Component {
	_isMounted = false;

	state = {
		show: true,
		loading: true,
	};

	modalCloseHandler = () => {
		this.setState({ show: false });
		this.props.showLiterature();
	};

	componentWillUnmount() {
		this._isMounted = false;
	}

	componentDidMount() {
		this._isMounted = true;
		this.setState({ loading: false });
	}
	downloadFile = (url) => {
		this.setState({ loading: true });

		return axios
			.get(url, {
				headers: {
					opId: this.props.userInfo.opId,
					buId: this.props.userInfo.buId,
				},
				responseType: 'blob',
			})
			.then((res) => {
				console.log(res);
				console.log(res.data);

				this.setState({ loading: false });
				var headers = res.headers;
				var blob = new Blob([res.data], {
					type: headers['content-type'],
				});

				var link = document.createElement('a');
				link.href = window.URL.createObjectURL(blob);
				link.download =
					'Literature_' + this.props.releaseData.externalReleaseId;
				link.click();
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	};

	render() {
		let literature = (
			<Modal
				show={this.state.show}
				size={'sm'}
				modalClosed={this.modalCloseHandler}
				title={'Release Id ' + this.props.releaseData.externalReleaseId}>
				{
					this.state.loading ? (
						<div style={{ minHeight: '20vh' }}>
							{' '}
							<Loader />{' '}
						</div>
					) : (
						<React.Fragment>
							<div
								style={{
									display: 'flex',
									justifyContent: 'center',
									alignItems: 'center',
									minHeight: '20vh',
								}}>
								<Button
									variant="outlined"
									color="primary"
									onClick={() => {
										const url =
											'telemediaDashboard//literature/excel/download?releaseId=' +
											this.props.releaseData.externalReleaseId;
										this.downloadFile(url);
									}}
									style={{
										textTransform: 'none',
										marginRight: 20,
									}}>
									<AttachmentIcon
										style={{
											marginRight: '10px',
										}}
									/>{' '}
									Download as Excel
								</Button>

								<Button
									variant="outlined"
									color="primary"
									onClick={() => {
										const url =
											'telemediaDashboard/pdf?releaseId=' +
											this.props.releaseData.externalReleaseId;
										this.downloadFile(url);
									}}
									style={{
										textTransform: 'none',
									}}>
									<AttachmentIcon
										style={{
											marginRight: '10px',
										}}
									/>{' '}
									Download as Pdf
								</Button>
							</div>
						</React.Fragment>
					)
					// : < Typography variant="h5" style={{
					//     textAlign: 'center'
					// }} > No Data Found </Typography >
				}
			</Modal>
		);

		return literature;
	}
}

const mapStateToProps = (state) => {
	return {
		userInfo: state.login.loggedInUserInfo,
	};
};

export default connect(mapStateToProps)(WithErrorHandler(Literature, axios));

import { combineReducers } from "redux";
import { persistReducer } from "redux-persist";
import sessionStorage from "redux-persist/lib/storage/session";
import loginReducer from "./loginReducer";
import editReleaseReducer from "./editReleaseReducer";
import packageReducer from "./packageReducer";
import productReducer from "./productReducer";
import searchReducer from "./searchItemsReducer";
import { i18nReducer } from "react-redux-i18n";
import approverReducer from "./approverReducer";
import editHandlerReducer from "./editHandlerReducer";
import drawerReducer from "./drawerReducer";
import RoleSelectionReducer from "./RoleSelectionReducer";

const persistConfig = {
  key: "root",
  storage: sessionStorage,
  whitelist: [
    "login",
    "releaseData",
    "packageData",
    "productData",
    "searchData",
    "i18n",
    "approverData",
    "editData",
    "roleSelected",
  ],
};

const appReducer = combineReducers({
  login: loginReducer,
  releaseData: editReleaseReducer,
  packageData: packageReducer,
  productData: productReducer,
  searchData: searchReducer,
  i18n: i18nReducer,
  approverData: approverReducer,
  editData: editHandlerReducer,
  drawerData: drawerReducer,
  roleSelected:RoleSelectionReducer,
});

const rootReducer = (state, action) => {
  if (action.type === "LOG_OUT") {
    state = undefined;
  }
  return appReducer(state, action);
};

export default persistReducer(persistConfig, rootReducer);

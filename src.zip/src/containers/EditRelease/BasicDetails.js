import React from 'react';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import CardActions from '@material-ui/core/CardActions';
import Button from '@material-ui/core/Button';
import { makeStyles } from '@material-ui/core/styles';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import TextField from '@material-ui/core/TextField';
import Loader from '../../UI/Loader/Loader';
import { connect } from 'react-redux';
import * as actionTypes from '../../store/actions/actionTypes';
import Popover from '@material-ui/core/Popover';
import moment from 'moment';
import { withStyles } from '@material-ui/styles';
import KeyboardReturnIcon from '@material-ui/icons/KeyboardReturn';
import Modal from '../../UI/Modal/Modal';
import Tooltip from '@material-ui/core/Tooltip';

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: '#525354',
    color: 'white',
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);
const useStyles = makeStyles((theme) => ({
  cardHeader: {
    background: '#546d79',
    height: '4.5vh',
  },
  subheader: {
    color: 'white',
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  btn: {
    textTransform: 'unset !important',
  },
  underline:{
    "&&&:before":{
      borderBottom:"none"
    },
    "&&:after":{
      borderBottom:'none'
    }
  }
}));
const StyledButton = withStyles((theme) => ({
  root: {
    textTransform: 'capitalize',
    background: 'transparent',
    letterSpacing: '-1px',
    fontWeight: '600',
    color: '#000',
    fontSize: '16px',
    border: '2px solid #ffcc00',
    borderRadius: '50px',
    padding: '6px 24px',
    '&:hover': {
      border: '2px solid #ffcc00',
      opacity: 0.8,
      //  background: '#ffcc00',
    },
  },
}))(Button);



const buttonStyle = {
  // textTransform: 'capitalize',
  background: '#02bfa0',
  // letterSpacing: "-1px",
  fontWeight: '600',
  color: '#000',
  fontSize: '16px',
  border: '2px solid #459338',
  borderRadius: '50px',
  padding: '6px 24px',
};

const getColor = {
  Deployed: '#1565c0',
  InProgress: '#009337',
  Cancelled: '#CF4405',
  'Approval In Progress': '#ff9100', //"#C62828",
};

const BasicDetails = (props) => {
  const classes = useStyles();
  const [remarks, setRemarks] = React.useState(props.releaseData.remarks);
  const [loading, setLoading] = React.useState(false);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [anchorElDeploy, setAnchorElDeploy] = React.useState(null);

  const [showDeployStatus, setShowDeployStatus] = React.useState(false);
  const [message, setMessage] = React.useState(false);
  const [modalContent, setModalContent] = React.useState(null);

  const remarksChangeHandler = (event) => {
    setRemarks(event.target.value);
  };
  const submitBasicDetailsHandler = () => {
    console.log(props.userInfo.id);
    console.log(remarks);
    setLoading(true);
    axios
      .post('telemediaDashboard/myReleases/update', {
        releaseNbr: props.releaseData.releaseNbr,
        remarks: remarks,
        updatedBy: props.userInfo.id,
      })
      .then((response) => {
        console.log(response);
        props.onReleaseEnter({
          ...props.releaseData,
          remarks: remarks,
        });
        setLoading(false);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  const modalCloseHandlerDeploy = () => {
    setShowDeployStatus(false);
  };
  
  // const cancelReleaseHandler = () => {
  //   setLoading(true);
  //   setAnchorEl(null);
  //   axios
  //       .post('cancel/release?releaseId=' + props.releaseData.releaseId, {
  //       })
  //       .then(res => {
  //           console.log(res);
  //           props.onReleaseEnter({
  //               ...props.releaseData,
  //               releaseStatus: 'Cancelled'
  //           })
  //          setLoading(false)
  //       })
  //       .catch(error => {
  //           console.log(error);
  //       });
  //   console.log('cancel1');
  //   axios
  //     .post(
  //       'telemediaCancel/release?releaseId=' + props.releaseData.releaseId,
  //       {
  //         updatedBy: props.userInfo.opId,
  //         updatedDate: moment().format('DD-MMM-YY'),
  //       }
  //     )
  //     .then((res) => {
  //       console.log(res);
  //       if (props.releaseData.pendingWith !== 'WorkFlow Not Initiated') {
  //         console.log('cancel2');

  //         axios
  //           .post(
  //             'Telecustom/cancelTask?releaseId=' + props.releaseData.releaseId,
  //             {}
  //           )
  //           .then((res) => {
  //             console.log(res);
  //             props.onReleaseEnter({
  //               ...props.releaseData,
  //               releaseStatus: 'Cancelled',
  //             });
  //             setLoading(false);
  //           })
  //           .catch((error) => {
  //             console.log(error);
  //             setLoading(false);
  //           });
  //       } else {
  //         props.onReleaseEnter({
  //           ...props.releaseData,
  //           releaseStatus: 'Cancelled',
  //         });
  //         setLoading(false);
  //       }
  //     })

  //     .catch((error) => {
  //       console.log(error);
  //       setLoading(false);
  //     });
  // };

  const cancelReleaseHandler = () => {
    setLoading(true);
    setAnchorEl(null);
    console.log('cancel1');
    axios
      .post('cancel/release?releaseId=' + props.releaseData.releaseId, {
        updatedBy: props.userInfo.opId,
        updatedDate: moment().format('DD-MMM-YY'),
      })
      .then((res) => {
        console.log(res);
        if (props.releaseData.pendingWith != 'WorkFlow Not Initiated') {
          console.log('cancel2');

          axios
            .post(
              'Telecustom/cancelTask?releaseId=' + props.releaseData.releaseId,
              {}
            )
            .then((res) => {
              console.log(res);
              props.onReleaseEnter({
                ...props.releaseData,
                releaseStatus: 'Cancelled',
              });
              setLoading(false);
            })
            .catch((error) => {
              console.log(error);
              setLoading(false);
            });
        } else {
          props.onReleaseEnter({
            ...props.releaseData,
            releaseStatus: 'Cancelled',
          });
          setLoading(false);
        }
      })

      .catch((error) => {
        console.log(error);
        setLoading(false);
      });
  };

  const deployReleaseHandler = () => {
    setLoading(true);
    setAnchorElDeploy(null);
    console.log('deploy');
    axios
      .post(
        'telemediaDeploy/release?releaseId=' + props.releaseData.releaseId,
        {},
        {
          headers: {
            updatedBy: props.userInfo.id,
            'Content-Type': 'application/json',
            Accept: 'application/json,text/plan,*/*',
          },
        }
      )
      .then((res) => {
        console.log(res);
        props.onReleaseEnter({
          ...props.releaseData,
          releaseStatus: 'Deployed',
        });
        setLoading(false);
      })
      .catch((error) => {
        console.log(error);
        setLoading(false);
      });
  };
  const open = Boolean(anchorEl);
  const openDeploy = Boolean(anchorElDeploy);
  const id = open ? 'simple-popover' : undefined;
  const idDeploy = openDeploy ? 'simple-popover-pkg' : undefined;

  let basicDetails = (
    <div>
      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={() => {
          setAnchorEl(null);
        }}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      >
        <Card>
          <CardHeader
            className={classes.cardHeader}
            classes={{
              subheader: classes.subheader,
            }}
            subheader={
              'Do you want to cancel release ' +
              props.releaseData.externalReleaseId +
              ' ?'
            }
          />
          <CardContent style={{ padding: '4px' }}>
            <div
              style={{
                marginTop: '10px',
                display: 'flex',
                justifyContent: 'flex-end',
              }}
            >
              <Button
                size='small'
                color='primary'
                style={{
                  textTransform: 'none',
                }}
                onClick={() => {
                  setAnchorEl(null);
                }}
              >
                Close
              </Button>
              <Button
                size='small'
                color='primary'
                style={{
                  textTransform: 'none',
                }}
                onClick={cancelReleaseHandler}
              >
                Ok
              </Button>
            </div>
          </CardContent>
        </Card>
      </Popover>
      <Popover
        id={idDeploy}
        open={openDeploy}
        anchorEl={anchorElDeploy}
        onClose={() => {
          setAnchorElDeploy(null);
        }}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      >
        <Card>
          <CardHeader
            className={classes.cardHeader}
            classes={{
              subheader: classes.subheader,
            }}
            subheader={
              'Do you want to deploy release ' +
              props.releaseData.externalReleaseId +
              ' ?'
            }
            style={{   
            boxShadow:'0 5px 10px 0  #b61d1d',
          backgroundColor:'#b61d1d'}}
          />
          <CardContent style={{ padding: '4px' }}>
            <div
              style={{
                marginTop: '10px',
                display: 'flex',
                justifyContent: 'flex-end',
              
              }}
            >
              <Button
                size='small'
                color='primary'
                style={{
                  textTransform: 'none',
                }}
                onClick={() => {
                  setAnchorElDeploy(null);
                }}
              >
                Close
              </Button>
              <Button
                size='small'
                color='primary'
                style={{
                  textTransform: 'none',
                }}
                onClick={deployReleaseHandler}
              >
                Ok
              </Button>
            </div>
          </CardContent>
        </Card>
      </Popover>

      {/* NEW RENDER */}
      <div
        style={{
          width: '100%',
          background: '#fff',
          height: '70px',
          display: 'flex',
          justifyContent: 'center',
          padding: '10px',
        }}
      >
        <div style={{ flexGrow: 1, display: 'flex', alignItems: 'center' }}>
          <span style={{ fontSize: '24px', fontWeight: 'bold' }}>
            Release {props.releaseData.externalReleaseId} 
          </span>
        </div>
        <div>
          <CardActions className={classes.center}>
            <LightTooltip title='Update Release Objective'>
              <StyledButton
                style={{
                  //  background: '#000',
                  color: '#fff',
                  borderRadius: '50px',
                  marginLeft: '16px',
                  textTransform: 'capitalize',
                  padding: '4px 32px',
                  height: '44px',
                  background: '#5dc17f',
                }}
                onClick={submitBasicDetailsHandler}
                className={classes.btn}
                disabled={
                  props.releaseData.releaseStatus !== "InProgress"
                }
              >
                Save
              </StyledButton>
            </LightTooltip>

          {/*  <LightTooltip title='Deploy the current Release to Master'>
              <StyledButton
                style={{ background: "#c46c08",
								color: "white", }}
                onClick={(event) => {
                  setAnchorElDeploy(event.currentTarget);
                }}
                className={classes.btn}
                disabled={
                  props.releaseData.releaseStatus === 'Cancelled' ||
                  props.releaseData.releaseStatus === 'Deployed'
                }
              >
                Deploy
              </StyledButton>
              </LightTooltip> */}

           

            
          </CardActions>
        </div>
      </div>

      <div
        style={{
          borderTop: '2px solid #eee',
          width: '100%',
          background: '#fff',
          minHeight: '120px',
          // display: "flex",
          justifyContent: 'center',
          padding: '25px 40px',
        }}
      >
       {/* <div style={{ width: '50%', float: 'left' }}>
          <span
            style={{
              display: 'inline-block',
              width: '160px',
              fontWeight: 'bold',
            }}
          >
            Creation Date
          </span>{' '}
          <span>{props.releaseData.createdOn}</span>
        </div>
          */}
        <div
          style={{
            width: '100%',
            float: 'left',
            // display: "flex",
            // alignItems: "center",
          }}
        >
          <span
            style={{
              display: 'inline-block',
              width: '160px',
              fontWeight: 'bold',
            }}
          >
            Release Objective
          </span>{' '}
          <span >
            <TextField
              InputProps={{

                disableUnderline:true
              }}
              
              style={{borderBottom:'1px solid rgba(0,0,0,0.5)' }}
              disabled={'true'}
              value={remarks}
              onChange={remarksChangeHandler}
              // required={true}
              placeholder='Release Objective'
              //   rowsMin={4}
              //   rowsMax={5}
              // multiline
              //   variant="outlined"
            />
          </span>
          {/* <span>{props.releaseData.releaseType}</span> */}
        </div>
        {/*
        <div style={{ width: '50%', float: 'left' }}>
          <span
            style={{
              display: 'inline-block',
              width: '160px',
              fontWeight: 'bold',
            }}
          >
            Created By
          </span>{' '}
          <span>{props.releaseData.createdBy}</span>
        </div> 
          */}
        <div style={{ width: '100%', float: 'left' }}>
          <span
            style={{
              display: 'inline-block',
              width: '160px',
              fontWeight: 'bold',
              marginTop:'15px'
            }}
          >
            Release Status
          </span>
          <span>
            <span style={{ color: getColor[props.releaseData.releaseStatus] }}>
              {props.releaseData.releaseStatus} 
            </span>
            &nbsp;&nbsp;
({props.releaseData.pendingWith})
          </span>
        </div>
      </div>
      {/* END NEW RENDER */}
      <Modal
        show={showDeployStatus}
        modalClosed={modalCloseHandlerDeploy}
        title={'Rollback Status'}
      >
        <h3>{modalContent ? modalContent : loading}</h3>
      </Modal>
    </div>
  );

  return basicDetails;
};

const mapStateToProps = (state) => {
  return {
    releaseData: state.releaseData.releaseData,
    userInfo: state.login.loggedInUserInfo,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onReleaseEnter: (releaseData) =>
      dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: releaseData }),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(WithErrorHandler(BasicDetails, axios));

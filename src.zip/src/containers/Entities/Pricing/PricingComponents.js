import React, { Component } from 'react';
import Carousel from 'react-material-ui-carousel';
import Card from '@material-ui/core/Card';
import { connect } from 'react-redux';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Typography from '@material-ui/core/Typography';
import PermIdentityIcon from '@material-ui/icons/PermIdentity';
import CategoryIcon from '@material-ui/icons/Category';
import NoteIcon from '@material-ui/icons/Note';
import CardActions from '@material-ui/core/CardActions';
import EditIcon from '@material-ui/icons/Edit';
import DeleteIcon from '@material-ui/icons/Delete';
import CurrencyRupeeIcon from '@mui/icons-material/CurrencyRupee';
import LoopIcon from '@mui/icons-material/Loop';
import CalculateIcon from '@mui/icons-material/Calculate';

const useStyles = (theme) => ({
  cardHeader: {
    // background: "#546D7A",
    // height: "4.5vh",
    paddingBottom: 0,
  },
  subheader: {
    color: 'rgba(0, 0, 0, 0.87)',
    fontSize: '16px',
    fontWeight: '600',
    // color: "white",
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: '1%',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
  navIcon: {
    minWidth: '0px',
    paddingRight: '5%',
  },
});
class PricingComponents extends Component {
  constructor(props) {
    super(props);
    let n = 3;
    let groupedPricingComponents = props.pricingComponents.reduce(
      (r, e, i) => (i % n ? r[r.length - 1].push(e) : r.push([e])) && r,
      []
    );
    this.state = {
      allPricingComponents: [...props.pricingComponents],
      key: 'app',
      groupedPricingComponents: [...groupedPricingComponents],
    };
  }
  componentDidMount() {
    console.log(this.state.allPricingComponents);
    console.log(this.state.groupedPricingComponents);
  }

  render() {
    const { classes } = this.props;
    let pricingComponents = null;
    if (this.state.allPricingComponents.length == 0)
      pricingComponents = (
        <div className={classes.center}>
          <Typography variant='h6'>No existing Components</Typography>
        </div>
      );
    else
      pricingComponents = (
        <Carousel
          navButtonsAlwaysVisible={true}
          autoPlay={false}
          key={this.state.key}
        >
          {this.state.groupedPricingComponents.map((group, i) => {
            console.log('group', group);
            return group.map((component, j) => {
              return (
                <Card
                  style={{
                    display: 'inline-block',
                    width: '30%',
                    marginLeft: '2.5%',
                  }}
                  key={j}
                >
                  <CardHeader
                    className={classes.cardHeader}
                    classes={{
                      subheader: classes.subheader,
                    }}
                    subheader={
                      component.componentType === 'USAGE'
                        ? 'TARIFF'
                        : component.componentType
                        ? component.componentType
                        : 'DISCOUNT'
                    }
                  />
                  <CardContent style={{ overflow: 'visible' }}>
                    {(component.componentType === 'RENTAL' ||
                      component.componentType === 'Rental') &&
                    component.computationType === 'MATRIX' ? (
                      <List>
                        <ListItem button>
                          <ListItemIcon className={classes.navIcon}>
                            <CalculateIcon style={{ color: '#009B88' }} />
                          </ListItemIcon>
                          <ListItemText
                            primary={
                              'Computation Type: ' + component.computationType
                            }
                          />
                        </ListItem>
                        <ListItem button>
                          <ListItemIcon className={classes.navIcon}>
                            <CategoryIcon style={{ color: '#fc0a5b' }} />
                          </ListItemIcon>
                          <ListItemText
                            primary={'Type: ' + component.componentSubType}
                          />
                        </ListItem>
                        <ListItem button>
                          <ListItemIcon className={classes.navIcon}>
                            <NoteIcon style={{ color: '#a87f32' }} />
                          </ListItemIcon>
                          <ListItemText
                            primary={'Value: ' + component.componentValue}
                          />
                        </ListItem>
                      </List>
                    ) : component.componentType === 'RENTAL' ||
                      component.componentType === 'Rental' ? (
                      <List>
                        <ListItem button>
                          <ListItemIcon className={classes.navIcon}>
                            <PermIdentityIcon style={{ color: '#009B88' }} />
                          </ListItemIcon>
                          <ListItemText
                            primary={'Component Id: ' + component.componentId}
                          />
                        </ListItem>
                        <ListItem button>
                          <ListItemIcon className={classes.navIcon}>
                            <CategoryIcon style={{ color: '#fc0a5b' }} />
                          </ListItemIcon>
                          <ListItemText
                            primary={'Type: ' + component.componentSubType}
                          />
                        </ListItem>
                        <ListItem button>
                          <ListItemIcon className={classes.navIcon}>
                            <NoteIcon style={{ color: '#a87f32' }} />
                          </ListItemIcon>
                          <ListItemText
                            primary={'Value: ' + component.componentValue}
                          />
                        </ListItem>
                      </List>
                    ) : component.componentType === 'USAGE' ? (
                      <List>
                        <ListItem button>
                          <ListItemIcon className={classes.navIcon}>
                            <PermIdentityIcon style={{ color: '#009B88' }} />
                          </ListItemIcon>
                          <ListItemText
                            primary={
                              'Component Id: ' + component.productComponentId
                            }
                          />
                        </ListItem>
                        <ListItem button>
                          <ListItemIcon className={classes.navIcon}>
                            <CategoryIcon style={{ color: '#fc0a5b' }} />
                          </ListItemIcon>
                          <ListItemText
                            primary={'Type: ' + component.rcFrequency}
                          />
                        </ListItem>
                        <ListItem button>
                          <ListItemIcon className={classes.navIcon}>
                            <NoteIcon style={{ color: '#a87f32' }} />
                          </ListItemIcon>
                          <ListItemText
                            primary={
                              'Rate Plan: ' + component.productComponentRefId
                            }
                          />
                        </ListItem>
                      </List>
                    ) : (
                      <List>
                        <ListItem button>
                          <ListItemIcon className={classes.navIcon}>
                            <PermIdentityIcon style={{ color: '#009B88' }} />
                          </ListItemIcon>
                          <ListItemText
                            primary={'Component Id: ' + component.discountId}
                          />
                        </ListItem>
                        <ListItem button>
                          <ListItemIcon className={classes.navIcon}>
                            <CategoryIcon style={{ color: '#fc0a5b' }} />
                          </ListItemIcon>
                          <ListItemText
                            primary={
                              'Applied On: ' + component.discountAppliedOn
                            }
                          />
                        </ListItem>
                        <ListItem button>
                          <ListItemIcon className={classes.navIcon}>
                            <NoteIcon style={{ color: '#a87f32' }} />
                          </ListItemIcon>
                          <ListItemText
                            primary={'Value: ' + component.discountValue}
                          />
                        </ListItem>
                      </List>
                    )}
                  </CardContent>
                  {this.props.releaseData.releaseStatus === 'InProgress' &&(
                  <CardActions
                    style={{
                      display: 'flex',
                      justifyContent: 'flex-end',
                      marginRight: '2.5%',
                    }}
                  >
                    {component.componentType &&
                    component.computationType === 'MATRIX' ? (
                      <EditIcon
                        style={{ color: 'green', cursor: 'pointer' }}
                        onClick={() => this.props.editMatrixComp(component)}
                      />
                    ) : (
                      <EditIcon
                        style={{ color: 'green', cursor: 'pointer' }}
                        onClick={() => this.props.editComp(component)}
                      />
                    )}
                    {component.componentType &&
                    component.computationType === 'MATRIX' ? (
                      
                      <DeleteIcon
                        style={{ color: 'red', cursor: 'pointer' }}
                        onClick={() =>
                          this.props.delMatrixComp(component.componentId)
                        }
                        disabled={this.props.releaseData.releaseStatus !== 'InProgress'}
                      />
                      
                    ) :
                    component.componentType === "USAGE" ? (
                      <DeleteIcon
                        style={{ color: "red", cursor: "pointer" }}
                        onClick={() =>
                          this.props.delTariffComp(
                            component.productComponentId
                          )
                        }
                        disabled={this.props.releaseData.releaseStatus !== 'InProgress'}
                      />
                    )
                    : component.componentType ? (
                      <DeleteIcon
                        style={{ color: 'red', cursor: 'pointer' }}
                        onClick={() =>{
                          this.props.delRentalComp(component.componentId);window.location.reload()}
                        }
                        disabled={this.props.releaseData.releaseStatus !== 'InProgress'}
                      />
                    ) : (
                      <DeleteIcon
                        style={{ color: 'red', cursor: 'pointer' }}
                        onClick={() =>{
                          this.props.delDiscComp(component.discountId);window.location.reload()}
                        }
                        disabled={this.props.releaseData.releaseStatus !== 'InProgress'}
                      />
                    )}
                  </CardActions>
                  )}
                </Card>
              );
            });
          })}
        </Carousel>
      );
    return pricingComponents;
  }
}
const mapStateToProps = (state) => {
  return {
    releaseData: state.releaseData.releaseData,
  };
};

export default connect(mapStateToProps)(withStyles(useStyles)(PricingComponents));

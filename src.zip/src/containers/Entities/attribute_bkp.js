import React, { Component } from 'react';
import axios from '../../axios-epc';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import Loader from '../../UI/Loader/Loader';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import Box from '@material-ui/core/Box';
import CustomInput from '../../UI/Input/Input';
import TextField from '@material-ui/core/TextField';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Typography from '@material-ui/core/Typography';
import DeleteIcon from '@material-ui/icons/Delete';
import moment from "moment";
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import Input from '@material-ui/core/Input';
import Modal from '../../UI/Modal/Modal';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import AppsIcon from '@material-ui/icons/Apps';


const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250,
        },
    },
};
const useStyles = (theme) => ({
    cardHeader: {
        background: '#546D7A',
        height: '4.5vh'
    },
    subheader: {
        color: 'white',
        // fontWeight: 'bold'
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        flexBasis: '96%',
        flexShrink: 0,
    },
    btn: {
        textTransform: 'unset !important'
    }

});


class Attribute extends Component {
    _isMounted = false;

    state = {
        attrGrps: {},
        loading: true,
        selAttrGrp: null,
        selAttrGrps: {},
        errors: [],
        show: false,
        modalContent: null
    }

    componentWillUnmount() {
        this._isMounted = false;
    }
    componentDidMount() {
        this._isMounted = true;
        this.attributeGrpData().then(() => {
            this.packageAttributeData().then(() => {
                this.setState({ loading: false })
            })
        })
    }

    attributeGrpData() {
        if (this.props.releaseData.releaseId) {

            return axios
                .get(
                    "package/attrGrp?releaseId=" +
                    this.props.releaseData.releaseId,
                    {
                        headers: {
                            opId: this.props.userInfo.opId,
                        }
                    }
                )
                .then(res => {
                    let attrGrpsMap = {}
                    res.data.data.map(attributeGrp => {
                        attrGrpsMap[attributeGrp.attrGrpName] = attributeGrp.attrGrpId
                    });
                    if (this._isMounted)
                        this.setState({ attrGrps: attrGrpsMap })
                })
                .catch(error => {
                    console.log(error)
                    if (this._isMounted)
                        this.setState({ loading: false })
                });
        } else {
            return Promise.resolve();
        }
    }

    getAttributesHandler = (attrGrp) => {
        this.setState({ selAttrGrp: attrGrp, loading: true })
        if (attrGrp) {
            if (attrGrp in this.state.selAttrGrps) {
                let modalContent = < Typography variant="h6">Attribute Group Already Selected.
                 </ Typography>
                this.setState({ modalContent: modalContent, show: true, loading: false, selAttrGrp: null })
            } else {
                axios
                    .get(
                        "package/attrGrp/attributes?attrGrpId=" +
                        this.state.attrGrps[attrGrp] +
                        "&releaseId=" +
                        this.props.releaseData.releaseId,
                        {
                            headers: {
                                opId: this.props.userInfo.opId,
                            }
                        }
                    )
                    .then(res => {
                        let obj = {};
                        obj["attrGrp"] = res.data.data.attrGrp;
                        obj["attributes"] = res.data.data.listOfPpmAttributes;

                        if (this._isMounted)
                            this.setState((prevState) => {
                                return {
                                    loading: false,
                                    selAttrGrp: null,
                                    selAttrGrps: {
                                        ...prevState.selAttrGrps,
                                        [res.data.data.attrGrp.attrGrpName]: obj
                                    }
                                };
                            });
                        console.log(this.state.selAttrGrps)

                    })
                    .catch(error => {
                        console.log(error)
                        if (this._isMounted)
                            this.setState({ loading: false })
                    });
            }
        }
    }

    packageAttributeData() {
        if (this.props.id) {
            return axios
                .get(
                    "package/attrGrp/mapping?id=" +
                    this.props.id + "&releaseID=" +
                    this.props.releaseData.releaseId
                )
                .then(res => {
                    console.log('attr')
                    console.log(res)
                    if (Object.keys(res.data.data).length > 0) {
                        let selAttrGrps = {}
                        Object.keys(res.data.data).forEach(key => {
                            let obj = {};
                            let date = moment().format("DD-MMM-YY");
                            obj["attrGrp"] = {};
                            obj["attrGrp"].attrGrpAllocateValue = "PRODUCT";
                            obj["attrGrp"].attrGrpDescription = key;
                            obj["attrGrp"].attrGrpId = this.state.attrGrps[key];
                            obj["attrGrp"].attrGrpName = key;
                            obj["attrGrp"].buid = this.props.userInfo.buid;
                            obj["attrGrp"].createdBy = this.props.userInfo.id;
                            obj["attrGrp"].createdDate = date;
                            // obj["attrGrp"].endDate = "31-Dec-31";
                            obj["attrGrp"].opid = this.props.userInfo.opId;
                            obj["attrGrp"].startDate = date;
                            obj["attrGrp"].updatedBy = this.props.userInfo.id;
                            obj["attrGrp"].updatedDate = date;
                            obj["attributes"] = [];
                            res.data.data[key].filter(attribute => {
                                this.setState({
                                    [attribute['attrGrpDescription'] + attribute['productAttributeKey']]:
                                        attribute.productAttributeValue
                                })


                                let attrGrpAttr = attribute;
                                attrGrpAttr.ppmAttrType = attrGrpAttr.ppmAttrValueType;
                                // if (attrGrpAttr.ppmAttrValueType == "MULTI-SELECT")
                                //     attrGrpAttr.defaultValue = attrGrpAttr.defaultValue.split(
                                //         ","
                                //     );

                                attrGrpAttr.ppmAttrName = attribute.productAttributeKey;
                                obj["attributes"].push(attrGrpAttr);
                            });

                            selAttrGrps[key] = obj;

                        });
                        if (this._isMounted)
                            this.setState({ selAttrGrps: selAttrGrps })
                    }
                })
                .catch(error => {
                    console.log(error)
                    if (this._isMounted)
                        this.setState({ loading: false })
                });
        }
        else {
            return Promise.resolve();
        }
    }
    savePkgAttrDetailsHandler = (event) => {
        event.preventDefault();
        if (this.props.id) {
            let errors = []
            Object.keys(this.state.selAttrGrps).map(attrGrp => {
                this.state.selAttrGrps[attrGrp][['attributes']].map(attribute => {
                    if (!document.getElementById(attribute.attrGrpDescription + attribute.ppmAttrName).validity.valid) {
                        errors.push(attribute.attrGrpDescription + ' - ' + attribute.ppmAttrName)
                    }
                })
            })
            this.setState({ errors: errors })
            if (errors.length == 0) {
                // this.setState({ loading: true })
                let payload = {};
                let ppmProdAttrGroupsAudWrapper = [];
                let ppmProdAttributesAudWrapper = [];
                Object.keys(this.state.selAttrGrps).forEach(key => {
                    let obj = this.state.selAttrGrps[key].attrGrp;
                    obj.productId = this.props.id;
                    obj.version = "1.0";
                    obj.attrGrpMapId = this.state.selAttrGrps[key].attrGrp.attrGrpId;
                    obj.buId = this.state.selAttrGrps[key].attrGrp.buid
                        ? this.state.selAttrGrps[key].attrGrp.buid
                        : this.props.userInfo.buId;
                    obj.opId = this.state.selAttrGrps[key].attrGrp.opid
                        ? this.state.selAttrGrps[key].attrGrp.opid
                        : this.props.userInfo.opId;
                    ppmProdAttrGroupsAudWrapper.push(obj);

                    this.state.selAttrGrps[key].attributes.map(attribute => {
                        let objAttr = { ...obj, ...attribute };
                        objAttr.isMandatory = "Y";
                        objAttr.productAttributeId = attribute.ppmAttrId;
                        objAttr.productAttributeKey = attribute.ppmAttrName;
                        objAttr.productAttributeValue = attribute.ppmAttrName;
                        console.log(attribute.ppmAttrType);
                        objAttr.ppmAttrValueType = attribute.ppmAttrType;

                        // if (attribute.ppmAttrType == "MULTI-SELECT") {
                        //     objAttr.defaultValue = attribute.defaultValue.join();
                        //     objAttr.productAttributeValue = attribute.defaultValue
                        //         ? attribute.defaultValue.join()
                        //         : "";
                        // } else
                        objAttr.productAttributeValue = this.state[attribute.attrGrpDescription + attribute.ppmAttrName] ?
                            this.state[attribute.attrGrpDescription + attribute.ppmAttrName] : objAttr.defaultValue
                        objAttr.ppmAttrValue = attribute.ppmAttrValue;
                        console.log(objAttr);
                        ppmProdAttributesAudWrapper.push(objAttr);
                    });
                });
                payload.releaseId = this.props.releaseData.releaseId;
                payload.id = this.props.id;
                payload.ppmProdAttrGroupsAudWrapper = ppmProdAttrGroupsAudWrapper;
                payload.ppmProdAttributesAudWrapper = ppmProdAttributesAudWrapper;
                console.log(payload);
                // axios
                //     .post("package/attrGrp/mapping", payload, {
                //         headers: {
                //             opId: this.props.userInfo.opId,
                //         }
                //     })
                //     .then(response => {
                //         console.log(response);
                //         if (this._isMounted)
                //             this.setState({ loading: false })

                //     })
                //     .catch(error => {
                //         console.log(error)
                //         if (this._isMounted)
                //             this.setState({ loading: false })
                //     });
            }
            else {
                let modalContent = <List
                    style={{ maxHeight: 200, overflow: 'auto' }}
                    component="nav"
                    aria-labelledby="nested-list-subheader"
                >
                    {errors.map((error) => {
                        return (
                            <ListItem button key={error}>
                                <ListItemIcon>
                                    <AppsIcon style={{ color: '#ff1921' }} />
                                </ListItemIcon>
                                <ListItemText primary={'Attribute ' + error + ' is required.'} />
                            </ListItem>
                        )
                    })
                    }
                </List>
                this.setState({ modalContent: modalContent, show: true })
            }
        } else {
            let modalContent = < Typography variant="h6"> Submit Basic {this.props.entity} Details first. </ Typography>
            this.setState({ modalContent: modalContent, show: true })

        }

    }
    errorConfirmedHandler = () => {
        this.setState({ show: false });
    }
    render() {
        const { classes } = this.props;

        let attribute = <React.Fragment>
            <Loader hide={this.state.loading ? false : true} />
            <Modal
                show={this.state.show}
                modalClosed={this.errorConfirmedHandler}
                title={'Something Went Wrong!'}
            >
                {this.state.modalContent}
            </Modal>
            <Grid container alignItems="flex-end" spacing={2}
                style={{ display: !this.state.loading ? 'block' : 'none' }}>
                <Grid item xs={12} sm={6} >
                    <Box >
                        <span style={{}}>Attribute Groups</span>
                    </Box>
                    <Box mt={1} >
                        <CustomInput
                            resize
                            refType='SelectInput'
                            value={this.state.selAttrGrp}
                            changed={this.getAttributesHandler}
                            refLovs={Object.keys(this.state.attrGrps)} />

                    </Box>

                </Grid>

                <Grid item xs={12} >

                    <Card >
                        <CardHeader
                            className={classes.cardHeader}
                            classes={{
                                subheader: classes.subheader,
                            }}
                            subheader={'Selected Attribute Groups'} />

                        <CardContent >

                            <form >
                                {
                                    Object.keys(this.state.selAttrGrps).map(attrGrp => {
                                        return <Accordion key={attrGrp}>
                                            <AccordionSummary
                                                aria-controls="panel1bh-content"
                                                id="panel1bh-header"
                                            >
                                                <ExpandMoreIcon />
                                                <Typography className={classes.heading}>{attrGrp}</Typography>
                                                <DeleteIcon onClick={(event) => {
                                                    event.stopPropagation()
                                                    let attrGrps = { ...this.state.selAttrGrps }
                                                    delete attrGrps[attrGrp]
                                                    this.setState({ selAttrGrps: attrGrps })

                                                }} style={{ color: 'red' }} />

                                            </AccordionSummary>
                                            <AccordionDetails style={{ display: 'block' }}>
                                                < List
                                                    component="nav"
                                                    aria-labelledby="nested-list-subheader"
                                                    style={{ width: '100%', maxHeight: '30vh', overflow: 'auto' }}
                                                >
                                                    {this.state.selAttrGrps[attrGrp][['attributes']].map(attribute => {
                                                        let input = <TextField style={{ minWidth: '20%' }}
                                                            placeholder={attribute.ppmAttrName}
                                                            defaultValue={attribute.defaultValue}
                                                            id={attribute.attrGrpDescription + attribute.ppmAttrName}
                                                            value={this.state[attribute.attrGrpDescription + attribute.ppmAttrName]}
                                                            onChange={(event) => this.setState({ [attribute.attrGrpDescription + attribute.ppmAttrName]: event.target.value })}
                                                            required={true}
                                                        />;

                                                        if (attribute.ppmAttrType == 'LIST') {
                                                            input = <FormControl style={{ minWidth: '20%' }}>
                                                                <Select
                                                                    name={attribute.ppmAttrName}
                                                                    defaultValue={attribute.defaultValue}
                                                                    MenuProps={MenuProps}
                                                                    displayEmpty
                                                                    value={this.state[attribute.attrGrpDescription + attribute.ppmAttrName]}
                                                                    onChange={(event) => {
                                                                        console.log(event.target.value)
                                                                        this.setState({
                                                                            [attribute.attrGrpDescription + attribute.ppmAttrName]:
                                                                                event.target.value
                                                                        })
                                                                    }}
                                                                    input={<Input required={true}
                                                                        id={attribute.attrGrpDescription + attribute.ppmAttrName}
                                                                    />}
                                                                    renderValue={(selected) => {
                                                                        if (selected) {
                                                                            if (selected.length === 0) {
                                                                                return <em>{attribute.ppmAttrName}</em>;
                                                                            }

                                                                            return selected

                                                                        }
                                                                    }}
                                                                    inputProps={{ 'aria-label': 'Without label' }}
                                                                >
                                                                    <MenuItem disabled value="">
                                                                        <em>{attribute.ppmAttrName}</em>
                                                                    </MenuItem>
                                                                    {attribute.ppmAttrValue.split(',').map((name) => (
                                                                        <MenuItem key={name} value={name} >
                                                                            {name}
                                                                        </MenuItem>
                                                                    ))}
                                                                </Select>
                                                            </FormControl>
                                                        }
                                                        else if (attribute.ppmAttrType == 'MULTI-SELECT') {
                                                            input = <FormControl style={{ minWidth: '20%' }}>
                                                                <Select
                                                                    multiple
                                                                    value={this.state[attribute.attrGrpDescription + attribute.ppmAttrName] ?
                                                                        this.state[attribute.attrGrpDescription + attribute.ppmAttrName] : []}
                                                                    onChange={(event) => {
                                                                        console.log(event.target.value)
                                                                        this.setState({
                                                                            [attribute.attrGrpDescription + attribute.ppmAttrName]:
                                                                                event.target.value
                                                                        })
                                                                    }}
                                                                    input={<Input required={true}
                                                                        id={attribute.attrGrpDescription + attribute.ppmAttrName}
                                                                    />}
                                                                    renderValue={(selected) => {
                                                                        if (selected) {
                                                                            if (selected.length === 0) {
                                                                                return <em>Value</em>;
                                                                            }

                                                                            selected = selected.filter(function (value) {
                                                                                return value !== undefined;
                                                                            });

                                                                            return selected.join()
                                                                        }
                                                                    }}

                                                                    MenuProps={MenuProps}
                                                                >
                                                                    {attribute.ppmAttrValue.split(',').map((name) => (
                                                                        <MenuItem key={name} value={name}>
                                                                            {/* <Checkbox style={{ color: '#ff1921' }}
                                                                                checked={this.state.attachments[file.name]['roles'].indexOf(name) > -1} /> */}
                                                                            <ListItemText primary={name} />
                                                                        </MenuItem>
                                                                    ))}
                                                                </Select>
                                                            </FormControl>

                                                        }
                                                        return <React.Fragment key={attribute.ppmAttrName}>
                                                            <ListItem >
                                                                <ListItemText primary={attribute.ppmAttrName}
                                                                />
                                                                {input}
                                                            </ListItem>
                                                            <Divider />
                                                        </React.Fragment>

                                                    })}
                                                </List>


                                            </AccordionDetails>
                                        </Accordion>
                                    })
                                }
                                {this.props.releaseData.releaseId && <div style={{
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                }}>
                                    <Button
                                        onClick={this.savePkgAttrDetailsHandler}
                                        style={{ background: '#02bfa0', marginTop: '3%' }}
                                        className={classes.btn}
                                    >
                                        Save
                        </Button>
                                </div>}
                            </form>



                        </CardContent>
                    </Card>



                </Grid>

            </Grid>
        </React.Fragment>

        return attribute;
    }


}




export default withStyles(useStyles)(WithErrorHandler(Attribute, axios));



import React, { useState, useEffect } from 'react';
import TextField from '@material-ui/core/TextField';

const InputNumber = (props) => {
  const [query, setQuery] = useState(props.value);

  useEffect(() => {
    const timeOutId = setTimeout(() => {
      if (props.decimal) {
        if (query) {
          if (query < 0) {
            setQuery('');
          } else {
            const val = Number(query).toFixed(2);
            setQuery(val);
            props.onChange({
              target: {
                value: val,
              },
            });
          }
        }
      } else {
        props.onChange({
          target: {
            value: query,
          },
        });
      }
    }, 800);
    return () => clearTimeout(timeOutId);
  }, [query]);

  return (
    <TextField
      type='number'
    //   fullWidth
      defaultValue={props.value}
      value={query}
      InputProps={{
        ...props.InputProps,
        inputProps: { min: 0 },
      }}
      onKeyDown={(e) =>
        ['e', 'E', '+', '-'].includes(e.key) && e.preventDefault()
      }
      onChange={(event) => setQuery(event.target.value)}
      disabled={props.disabled}
      required={props.required}
      onClick={(event)=> event.stopPropagation()}
    />
  );
};

export default InputNumber;

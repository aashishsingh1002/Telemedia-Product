// import React, { Component } from 'react';
// import { connect } from 'react-redux';
// import { withStyles } from '@material-ui/core/styles';
// import Drawer from '@material-ui/core/Drawer';
// import AppBar from '@material-ui/core/AppBar';
// import GradientIcon from '@material-ui/icons/Gradient';
// import CssBaseline from '@material-ui/core/CssBaseline';
// import Toolbar from '@material-ui/core/Toolbar';
// import List from '@material-ui/core/List';
// import Typography from '@material-ui/core/Typography';
// import ListItem from '@material-ui/core/ListItem';
// import ListItemIcon from '@material-ui/core/ListItemIcon';
// import ListItemText from '@material-ui/core/ListItemText';
// import Avatar from '@material-ui/core/Avatar';
// import Divider from '@material-ui/core/Divider';
// import IconButton from '@material-ui/core/IconButton';
// import MenuIcon from '@material-ui/icons/Menu';
// import ExitToAppIcon from '@material-ui/icons/ExitToApp';
// import clsx from 'clsx';
// import * as actionTypes from '../../store/actions/actionTypes';
// import { withRouter } from 'react-router-dom';
// import Collapse from '@material-ui/core/Collapse';
// import PermDataSettingIcon from '@material-ui/icons/PermDataSetting';
// import ExpandLess from '@material-ui/icons/ExpandLess';
// import ExpandMore from '@material-ui/icons/ExpandMore';
// import AppsIcon from '@material-ui/icons/Apps';
// import { createMuiTheme } from '@material-ui/core/styles';
// import { ThemeProvider } from '@material-ui/styles';
// import BrightnessAutoIcon from '@material-ui/icons/BrightnessAuto';
// import RedeemIcon from '@material-ui/icons/Redeem';
// import LibraryBooksIcon from '@material-ui/icons/LibraryBooks';
// import MoneyIcon from '@material-ui/icons/Money';
// import StoreIcon from '@material-ui/icons/Store';
// import LocalOfferIcon from '@material-ui/icons/LocalOffer';
// import MenuBookIcon from '@material-ui/icons/MenuBook';
// import LocalAtmIcon from '@material-ui/icons/LocalAtm';
// import AccountCircleIcon from '@material-ui/icons/AccountCircle';
// import WorkIcon from '@material-ui/icons/Work';
// import AllInboxIcon from '@material-ui/icons/AllInbox';
// import { setLocale } from 'react-redux-i18n';
// import { Translate } from 'react-redux-i18n';
// import FindInPageIcon from '@material-ui/icons/FindInPage';
// import TurnedInNotIcon from '@material-ui/icons/TurnedInNot';
// import TCSLogo from '../../assests/images/logo.png';
// // import Logo from "../../assests/images/mtn-logo.svg";
// // import LogoImage from "../../assests/images/mtnIlulaLogo.png";
// import InsertDriveFileOutlinedIcon from '@material-ui/icons/InsertDriveFileOutlined';
// import logo1 from '../../assests/images/logo1.jpg';
// import ModalAction from "../../UI/ModalAction/ModalAction";
// import CloseIcon from '@material-ui/icons/Close';
// import { AccountCircle, HomeOutlined } from '@material-ui/icons';
// import PowerSettingsNewIcon from '@mui/icons-material/PowerSettingsNew';
// import { BrighterSans } from './fonts';
// import { Menu, MenuItem } from '@material-ui/core';
// import Grid from '@material-ui/core/Grid';
// import Autocomplete from '@material-ui/lab/Autocomplete';
// import { createTheme } from '@material-ui/core/styles';
// import TimelineIcon from '@material-ui/icons/Timeline';
// import { FaHandshake } from '@react-icons/all-files/fa/FaHandshake';
// import CollectionsBookmarkIcon from '@material-ui/icons/CollectionsBookmark';
// //import MoneyIcon from '@mui/icons-material/Money';
// import EventNoteIcon from '@material-ui/icons/EventNote';
// //import UploadFileIcon from '@material-ui/icons/UploadFileIcon';
// import DriveFolderUploadIcon from '@mui/icons-material/DriveFolderUpload';
// import UploadModal from '../../common/Upload/UploadModal';
// import IdleTimer from "react-idle-timer";
// import axios from 'axios';

// const theme = createMuiTheme({
//   typography: {
//     fontFamily: 'BrighterSans',
//     body1: {
//       fontSize: '14px',
//     },
//   },
//   overrides: {
//     MuiCssBaseline: {
//       '@global': {
//         '@font-face': [BrighterSans],
//       },
//     },
//   },
// });

// const drawerWidth = 255; 

// const useStyles = (theme) => ({
//   root: {
//     display: 'flex',
//   },
//   appBar: {
//     zIndex: theme.zIndex.drawer + 1,
//     backgroundColor: '#ff1921',
//     boxShadow: 'none',
//   },
//   avatar: {
// 		width: theme.spacing(18),
// 		height: theme.spacing(18),
// 		backgroundColor: '#ff1921'},

//     large: {
//       width: theme.spacing(15),
//       height: theme.spacing(15),
//     },


//   menuButton: {
//     marginRight: 36,
//   },
//   hide: {
//     display: 'none',
//   },
//   drawer: {
//     width: drawerWidth,
//     flexShrink: 0,
//     whiteSpace: 'nowrap',
//   },
//   drawerPaper: {
//     background: '#dfe4ec',
//     // background: "#272c2f",
//   },
//   drawerOpen: {
//     width: drawerWidth,
//     transition: theme.transitions.create('width', {
//       easing: theme.transitions.easing.sharp,
//       duration: theme.transitions.duration.enteringScreen,
//     }),
//   },
//   drawerClose: {
//     transition: theme.transitions.create('width', {
//       easing: theme.transitions.easing.sharp,
//       duration: theme.transitions.duration.leavingScreen,
//     }),
//     overflowX: 'hidden',
//     width: theme.spacing(7) + 1,
//     [theme.breakpoints.up('sm')]: {
//       width: theme.spacing(9) + 1,
//     },
//   },
//   toolbar: {
//     display: 'flex',
//     alignItems: 'center',
//     justifyContent: 'flex-end',
//     padding: theme.spacing(0, 1),
//     // necessary for content to be below app bar
//     ...theme.mixins.toolbar,
//   },
//   content: {
//     flexGrow: 1,
//     padding: `0 ${theme.spacing(3)}px`,
//     // background: "rgba(0, 0, 0, 0.04)",
//   },
//   content2: {
//     flexGrow: 1,
//     // background: "rgba(0, 0, 0, 0.04)",
//   },
//   selected: {
//     background: '#ff1921',
//     color: '#FFF',
//   },
//   nested: {
//     color: '#000',
//   },
//   title: {
//     flexGrow: 1,
//   },
//   listItem: {
//     borderBottom: '1px solid #999',
//     // color: '#000',
//     '&:hover': {
//       // color: "#FFF",
//       background: '#ff1921',
//     },
//   },
//   listItemSelected: {
//     color: '#FFF',
//     background: '#ff1921',
//     '&:hover': {
//       color: '#FFF',
//       background: '#ff1921',
//     },
//   },
// });

// class Layout extends Component {
//   state = {
//     open: true,
//     planConfig: false,
//     contractConfig: false,
//     plan: false,
//     product: false,
//     offerability: false,
//     contract: false,
//     contractProfile: false,
//     ratePlan: false,
//     rental: false,
//     discount: false,
//     user: false,
//     workflow: false,
//     library: false,
//     show: false,
//     timerConfig: {},
//     release: false,
//     genericConfiguration: false,
//     rateplanConfiguration: false,
//     isOpen: false,
//     show: false,
//     timerConfig: {},
//   };

//   constructor(props) {
//     super(props);
//     this.idleTimerRef = React.createRef();
//     this.sessionTimerRef = React.createRef();
//   }

//   componentDidMount() {
//     console.log("layout mounted");
//     axios
//       .get(process.env.REACT_APP_URL + "telemediaDashboard/telemediaPopup")
//       .then((res) => {
//         console.log(res);
//         this.setState({
//           timerConfig: res.data.data,
//         });
//       })
//       .catch((error) => {
//         console.log(error);
//       });
//   }

//   logoutHandler = () => {
//     sessionStorage.clear();
//     this.props.onLogout();
//     this.props.history.replace('/login');
//     localStorage.clear() 
//     this.setState({show:false})
//       // this.props.changeLocale('en')
//   };

//   drawerHandler = () => {
//     this.props.setDrawer(!this.props.openDrawer);
//   };

//   handleClick = (item) => {
//     this.setState((prevState) => {
//       return { [item]: !prevState[item] };
//     });
//   };

//   render() {
//     const { classes } = this.props;
//     const { pathname } = this.props.history.location;

//     if (!(Object.keys(this.props.userInfo).length > 0)) {
//       return this.props.children;
//     }

//     return (
//       <ThemeProvider theme={theme}>
//         <div className={classes.root}>
        
//         {Object.keys(this.props.userInfo).length > 0 &&
//           Object.keys(this.state.timerConfig).length > 0 && (
//             <IdleTimer
//               ref={this.idleTimerRef}
//               timeout={Number(this.state.timerConfig.inactiveTime)}
//               // timeout={6000}
//               onIdle={() => {
//                 console.log("idle timer log");
//                 this.setState({ show: true });
//                 this.sessionTimerRef.current = setTimeout(
//                   this.logoutHandler,
//                   Number(this.state.timerConfig.autoLogout)
//                 );
//               }}
//             ></IdleTimer>
//           )}  
            

//         <ModalAction
//           show={this.state.show}
//           modalClosed={() => {
//             clearTimeout(this.sessionTimerRef.current);
//             this.setState({ show: false });
//           }}
//           actionText={"Log me out"}
//           closeText={"Keep me signed in"}
//           title={"Timeout"}
//           action={() => {
//             clearTimeout(this.sessionTimerRef.current);
//             this.logoutHandler();
//           }}
//         >
//           <div style={{ padding: "20" }}>
//             <h2>You've been idle for a while!</h2>
//             <p>You will be logged out soon</p>
//           </div>
//         </ModalAction>
//           <CssBaseline />
//           <AppBar
//             position='fixed'
//             className={clsx(classes.appBar, {
//               [classes.appBarShift]: this.props.openDrawer,
//             })}
//             // className={classes.appBar}
//           >
//             <Toolbar
//             // style={{ height: "70px" }}
            
                
//             >
//            {/* <ListItem
//             button
//             onClick={this.drawerHandler}
//             style={{ width: "3%",marginLeft:'0px' }}
//           >
//             <ListItemIcon>
//               {this.props.openDrawer ? (
//                 <CloseIcon style={{ color: '#000' }} />
//               ) : (
//                 <MenuIcon style={{ color: '#000' }} />
//               )}
//             </ListItemIcon>
            
//               </ListItem>*/}
//               <img
//                 src={logo1}
//                 style={{
//                   cursor: 'pointer',
//                   height: '9vh',
//                   marginBottom: '0px',
              
                  
//                 }}
//                 onClick={() => this.props.history.push('/')}
//               />

//               {(pathname == '/planConfiguration' ||
//                 pathname == '/productConfiguration') && (
//                 <div style={{ marginLeft: '5%' }}>
//                   <Grid container spacing={1} alignItems='flex-end'>
//                     <Grid item>
//                       <Autocomplete
//                         value={this.props.searchValue}
//                         onChange={(event, value) => {
//                           if (value) {
//                             this.props.setSearchValue(value);
//                             if (this.props.entity == 'PACKAGE') {
//                               this.props.changePackageActiveStep(0);
//                               let pkgData = { ...this.props.packageData };
//                               pkgData['packageId'] = value.split('/')[0];
//                               this.props.onPackageEnter(pkgData);
//                               this.props.changePackageKey(
//                                 this.props.pkgKey + '1'
//                               );
//                               this.props.history.push('/planConfiguration');
//                               this.props.history.go();
//                             } else if (this.props.entity == 'PRODUCT') {
//                               this.props.changeProductActiveStep(0);
//                               let proData = { ...this.props.productData };
//                               proData['productId'] = value.split('/')[0];
//                               this.props.onProductEnter(proData);
//                               this.props.changeProductKey(
//                                 this.props.productKey + '1'
//                               );
//                               this.props.history.push('/productConfiguration');
//                               this.props.history.go();
//                             }
//                             this.props.setSearchValue(null);
//                           }
//                         }}
//                         options={this.props.searchItems}
//                         // getOptionLabel={(option) => ""}
//                         renderOption={(option) => {
//                           var matches = option.match(/\[(.*?)\]/);

//                           if (matches) {
//                             var submatch = matches[0];
//                             var submatch0 = option.split(submatch)[0];
//                           }

//                           if (pathname == '/productConfiguration') {
//                             var usedesc = submatch0 || option || '';
//                             var submatch0arr = usedesc.split('/');
//                             submatch0arr.shift();
//                             var submatchdesc = submatch0arr.join('/');
//                           }

//                           return (
//                             <>
//                               {submatchdesc || option}{' '}
//                               <span style={{ color: '#ff0000' }}>
//                                 {submatch}
//                               </span>
//                             </>
//                           );
//                         }}
//                         renderInput={(params) => (
//                           <div ref={params.InputProps.ref}>
//                             <input
//                               style={{
//                                 width: '30vw',
//                                 height: '4vh',
//                                 border: 'none',
//                                 borderRadius: '3px',
//                               }}
//                               type='text'
//                               {...params.inputProps}
//                             />
//                           </div>
//                         )}
//                       />
//                     </Grid>
//                   </Grid>
//                 </div>
//               )}

//               <Typography variant='h6' className={classes.title}>
//                 {/* Ilula */}
//               </Typography>
              

//               <div
//               style={{
//                 display: 'flex',
//                 textTransform: 'capitalize',
//                 color: '#FFF',
//                 alignItems: 'center',
//               }}
//             >
//               <IconButton
//                 aria-label='account of current user'
//                 aria-controls='menu-appbar'
//                 aria-haspopup='true'
//                 onClick={(event) => {
//                   this.setState({
//                     anchorEl: event.currentTarget,
//                     menuOpen: false,
//                   });
//                 }}
//                 color='inherit'
//               >
//                 <PowerSettingsNewIcon onClick={this.logoutHandler} />
//               </IconButton>
//               <Menu
//                 id='menu-appbar'
//                 anchorEl={this.state.anchorEl}
//                 anchorOrigin={{
//                   vertical: 'top',
//                   horizontal: 'right',
//                 }}
//                 keepMounted
//                 transformOrigin={{
//                   vertical: 'top',
//                   horizontal: 'right',
//                 }}
//                 open={this.state.menuOpen}
//                 onClose={() => this.setState({ menuOpen: false })}
//               >
//              {/* <MenuItem onClick={this.logoutHandler}>Logout</MenuItem>*/}
//               </Menu>
//               <div style={{ display: 'flex', flexDirection: 'column' ,marginLeft:'5px' }}>
//                 <span>
//                   {`${this.props.userInfo.firstName.toLowerCase()} ${this.props.userInfo.lastName.toLowerCase()}`}
//                 </span>
//                 {/* {this.props.approversData && */}
//                 {this.props.userInfo.group &&
//                   this.props.userInfo.group.map((grp) => {
//                     return (
//                       <span key={grp} style={{ fontSize: '11px' }}>
//                         {grp}
//                         {/* {console.log(this.props.userInfo)} */}

//                         {/* {this.props.approversData[grp]} */}
//                       </span>
//                     );
//                   })}
//               </div>
//             </div>



//             </Toolbar>
//           </AppBar>
//           {
//             // this.props.roleGroup 
// // &&
//             //  (

//               (this.props.roleGroup || this.props.userInfo.group.includes('CIT_OPS') || this.props.userInfo.group.includes('ceoB2c')|| this.props.userInfo.group.includes('ceoB2b')
//               ||this.props.userInfo.group.includes('MS_TEST')||this.props.userInfo.group.includes('Selfcare_UAT')||this.props.userInfo.group.includes('NCA_UAT')||this.props.userInfo.group.includes('preProdTest')||
//               this.props.userInfo.group.includes('cmoB2c')

//               ) &&(

//           <Drawer
//             variant='permanent'
//             className={clsx(classes.drawer, {
//               [classes.drawerOpen]: this.props.openDrawer,
//               [classes.drawerClose]: !this.props.openDrawer,
//             })}
//             classes={{
//               paper: clsx(classes.drawerPaper, {
//                 [classes.drawerOpen]: this.props.openDrawer,
//                 [classes.drawerClose]: !this.props.openDrawer,
//               }),
//             }}
//           >
//             <div className={classes.toolbar}>
//               { <IconButton onClick={this.drawerHandler}>
//                 {theme.direction === "rtl" ? <CloseIcon /> : <CloseIcon />}
//               </IconButton> }
//             </div>
            
            
//             {/*<div
// 								style={{
// 									height: '30vh',
//                   marginTop:'20px',
//                   marginLeft:'30px',
//                   marginBottom:'10px'
// 								}}>
// 								<div className={classes.center}  >
// 									<Avatar className={classes.avatar}>
// 										<AccountCircle className={classes.large} />
// 									</Avatar>
// 								</div>
// 								<div style={{ marginLeft: '0px' ,marginTop:'15px' }}>
// 									<Grid
// 										container
// 										alignContent="center"
// 										style={{ marginBottom: '5px' }}>
// 										<span
// 											style={{
// 												fontWeight: 'bold',
// 												width: drawerWidth,
// 												wordBreak: 'break-all',
// 												paddingLeft: '10px',
// 												paddingRight: '10px',
// 											}}>
// 											{' ' +
// 												this.props.userInfo.firstName +
// 												' ' +
// 												this.props.userInfo.lastName}
// 										</span>
// 									</Grid>
// 									<Grid alignContent="center">
// 										{this.props.approversData && this.props.userInfo.group && (
// 											<React.Fragment>
// 												{this.props.userInfo.group
// 													.filter(
// 														(value, index) =>
// 															this.props.userInfo.group.indexOf(value) === index
// 													)
// 													.filter((value, index, theArray) => {
// 														if (
// 															this.props.userInfo.group[index]
// 																.substring(
// 																	this.props.userInfo.group[index].length - 3,
// 																	this.props.userInfo.group[index].length
// 																)
// 																.toLowerCase() === 'b2b' &&
// 															theArray.includes(
// 																`${this.props.userInfo.group[index].substring(
// 																	0,
// 																	3
// 																)}B2c`
// 															)
// 														) {
// 															return;
// 														} else {
// 															return value;
// 														}
// 													})
// 													.map((grp) => {
// 														return (
// 															this.props.approversData[grp] && (
// 																<Grid
// 																	container
// 																	alignContent="center"
// 																	style={{ marginBottom: '5px' }}>
// 																	<span
// 																		style={{
// 																			fontWeight: 'bold',
// 																			width: drawerWidth,
// 																			wordBreak: 'break-all',
// 																			paddingLeft: '10px',
// 																			paddingRight: '10px',
// 																		}}>
// 																		{this.props.approversData[grp]}
// 																	</span>
// 																</Grid>
// 															)
// 														);
// 													})}
// 											</React.Fragment>
// 										)}
// 									</Grid>
// 								</div>
//                         </div>*/}
                
//             <Divider style={{ marginTop: '0px' }} />
//             {this.props.userInfo.group && this.props.roleGroup &&

//               this.props.userInfo.group.includes('TelemediaProductManager') && (
//                 <List>
//                 {/*<ListItem
//                     button
//                     onClick={this.drawerHandler}
//                     style={{ borderBottom: '1px solid #999', color: '#000' }}
//                   >
//                     <ListItemIcon>
//                       {this.props.openDrawer ? (
//                         <CloseIcon style={{ color: '#000' }} />
//                       ) : (
//                         <MenuIcon style={{ color: '#000' }} />
//                       )}
//                     </ListItemIcon>
//                     <ListItemText primary={'Menu'} />
//                       </ListItem> */}
//                  <ListItem
//                     className={
//                       pathname === '/allReleases'
//                         ? classes.listItemSelected
//                         : classes.listItem
//                     }
//                     button
//                     onClick={() => this.props.history.push('/allReleases')}
//                   ><div style={{ marginRight : '-20px' }} >

//                     <ListItemIcon className={classes.navIcon}>
//                     <AllInboxIcon style={{ color: 'blue' }} />
//                     </ListItemIcon>
//                     </div>
//                     <ListItemText primary={`All Releases`}  />
//                   </ListItem>





//                   <ListItem
//                     className={
//                       pathname === '/'
//                         ? classes.listItemSelected
//                         : classes.listItem
//                     }
//                     button
//                     onClick={() => this.props.history.push('/')}
//                   ><div style={{ marginRight : '-20px' }} >
//                     <ListItemIcon className={classes.navIcon}>
//                       <HomeOutlined
//                         style={{ color: pathname === '/' ? '#FFF' : '#000' }}
//                       />
//                     </ListItemIcon> 
//                     </div>
//                     <ListItemText primary={`My Releases`} />
//                   </ListItem>
//                   {this.props.releaseData.releaseId && (
//                     <>
//                       <ListItem
//                         className={
//                           pathname === '/editRelease'
//                             ? classes.listItemSelected
//                             : classes.listItem
//                         }
//                         button
//                         onClick={() => {
//                           this.handleClick('release');
//                           this.props.history.push('/editRelease');
//                         }}
//                       ><div style={{ marginRight : '-20px' }} >
//                         <ListItemIcon className={classes.navIcon}>
//                           <TurnedInNotIcon
//                             style={{
//                               color:
//                                 pathname === '/editRelease' ? 'green' : 'green',
//                             }}
//                           />
//                         </ListItemIcon>
//                         </div>
//                         <ListItemText
//                           primary={`Release ${this.props.releaseData.externalReleaseId}`}
//                         />
//                       </ListItem>
//                       <Collapse
//                         in={this.state.release}
//                         timeout='auto'
//                         unmountOnExit
//                       >
//                         <Divider style={{ background: '#fff' }} />
//                       </Collapse>
                    
//                       {this.props.releaseData.releaseStatus === 'InProgress'
//                       &&(

//                   <React.Fragment>
                 
//                     <ListItem
//                       style={{
//                         borderBottom: '1px solid #999',
//                         color: '#000',
//                       }}
//                       button
//                       onClick={() => this.handleClick('planConfig')}
//                     >
//                     <div style={{ marginRight : '-20px' }} >
//                       <ListItemIcon className={classes.navIcon}>
//                         <PermDataSettingIcon
//                           style={{
//                             color: '#009B88',
//                           }}
//                         />
//                       </ListItemIcon>
//                       </div>
//                       <ListItemText
//                         primary={<Translate value='dashboard.proConfig' />}
//                       />
//                       {this.state.planConfig ? (
//                         <ExpandLess style={{ fontSize: '18px' }} />
//                       ) : (
//                         <ExpandMore style={{ fontSize: '18px' }} />
//                       )}
//                     </ListItem>
//                     <Collapse
//                       in={this.state.planConfig}
//                       timeout='auto'
//                       unmountOnExit
//                     >
//                       <List component='div' disablePadding>
//                         <ListItem
//                           button
//                           className={clsx(classes.nested, {
//                             [classes.listItem]:
//                               pathname !== '/planConfiguration',
//                             [classes.listItemSelected]:
//                               pathname === '/planConfiguration',
//                           })}
//                           onClick={() => {
//                             console.log(this.props.pkgKey);
//                             this.props.changePackageActiveStep(0);
//                             this.props.onPackageEnter({});
//                             this.props.changePackageKey(
//                               this.props.pkgKey + '1'
//                             );
//                             this.props.history.push('/planConfiguration');
//                           }}
//                         ><div style={{ marginRight : '-20px' }} >
//                           <ListItemIcon>
//                             <AppsIcon
//                               className={classes.nested}
//                               style={{
//                                 color:
//                                   pathname === '/planConfiguration'
//                                     ? '#FFF'
//                                     : '#000',
//                               }}
//                             />
//                           </ListItemIcon>
//                           </div>
//                           <ListItemText
//                             primary={<Translate value='dashboard.bundles' />}
//                           />
//                         </ListItem>
//                         <ListItem
//                           button
//                           className={clsx(classes.nested, {
//                             [classes.listItem]:
//                               pathname !== '/productConfiguration',
//                             [classes.listItemSelected]:
//                               pathname === '/productConfiguration',
//                           })}
//                           onClick={() => {
//                             this.props.changeProductActiveStep(0);
//                             this.props.onProductEnter({});
//                             this.props.changeProductKey(
//                               this.props.productKey + '1'
//                             );
//                             this.props.history.push('/productConfiguration');
//                           }}
//                         ><div style={{ marginRight : '-20px' }} >
//                           <ListItemIcon>
//                             <AppsIcon
//                               className={classes.nested}
//                               style={{
//                                 color:
//                                   pathname === '/productConfiguration'
//                                     ? '#FFF'
//                                     : '#000',
//                               }}
//                             />
//                           </ListItemIcon>
//                           </div>
//                           <ListItemText
//                             primary={<Translate value='dashboard.products' />}
//                           />
//                         </ListItem>
//                         <ListItem
//                           className={clsx(classes.nested, {
//                             [classes.listItem]:
//                               pathname !== '/ratePlanConfiguration',
//                             [classes.listItemSelected]:
//                               pathname === '/ratePlanConfiguration',
//                           })}
//                           button
//                           onClick={() =>
//                             this.props.history.push('/ratePlanConfiguration')
//                           }
//                         ><div style={{ marginRight : '-20px' }} >
//                           <ListItemIcon className={classes.navIcon}>
//                             <AppsIcon
//                               style={{
//                                 color:
//                                   pathname === '/ratePlanConfiguration'
//                                     ? '#FFF'
//                                     : '#000',
//                               }}
//                             />
//                           </ListItemIcon>
//                           </div>
//                           <ListItemText
//                             primary={
//                               <Translate value='dashboard.Rate Plan Configuration' />
//                             }
//                           />
//                         </ListItem>
//                         {this.props.userInfo.group &&
//                           this.props.userInfo.group.includes('SuperUser') && (
//                             <>

//                         <ListItem
//                           className={clsx(classes.nested, {
//                             [classes.listItem]: pathname !== '/events',
//                             [classes.listItemSelected]: pathname === '/events',
//                           })}
//                           button
//                           onClick={() => this.props.history.push('/events')}
//                         ><div style={{ marginRight : '-20px' }} >
//                           <ListItemIcon className={classes.navIcon}>
//                             <AppsIcon
//                               style={{
//                                 color: pathname === '/events' ? '#FFF' : '#000',
//                               }}
//                             />
//                           </ListItemIcon>
//                           </div>
//                           <ListItemText
//                             primary={
//                               <Translate value='dashboard.Rules Configuration' />
//                             }
//                           />
//                         </ListItem>
//                         <ListItem
//                           className={clsx(classes.nested, {
//                             [classes.listItem]:
//                               pathname !== '/attributeConfiguration',
//                             [classes.listItemSelected]:
//                               pathname === '/attributeConfiguration',
//                           })}
//                           button
//                           onClick={() =>
//                             this.props.history.push('/attributeConfiguration')
//                           }
//                         ><div style={{ marginRight : '-20px' }} >
//                           <ListItemIcon>
//                             <AppsIcon
//                               className={classes.nested}
//                               style={{
//                                 color:
//                                   pathname === '/attributeConfiguration'
//                                     ? '#FFF'
//                                     : '#000',
//                               }}
//                             />
//                           </ListItemIcon>
//                           </div>
//                           <ListItemText primary={'Attribute Configuration'} />
//                         </ListItem>
//                         </> )}
//                       </List>
//                     </Collapse>
                  
//                   </React.Fragment>
//                   )}
//                   </>

//                   )}
//                   {/* 
//                    <ListItem
//                     style={{ borderBottom: '1px solid #999', color: '#000' }}
//                     button
//                     className={classes.nested}
//                     onClick={() => this.handleClick('genericConfiguration')}
//                   ><div style={{ marginRight : '-20px' }} >
//                     <ListItemIcon className={classes.navIcon}>
//                      <LibraryBooksIcon style={{ color: "#C66B00" }} /> 
//                       <BrightnessAutoIcon style={{ color: '#000' }} />
//                     </ListItemIcon>
//                     </div>
//                     <ListItemText primary='Attribute Configuration' />
//                     {this.state.genericConfiguration ? (
//                       <ExpandLess style={{ fontSize: '18px' }} />
//                     ) : (
//                       <ExpandMore style={{ fontSize: '18px' }} />
//                     )}
//                   </ListItem>

//                   <Collapse
//                     in={this.state.genericConfiguration}
//                     timeout='auto'
//                     unmountOnExit
//                   >
//                     <List component='div' disablePadding>
//                       <ListItem
//                         className={clsx(classes.nested, {
//                           [classes.listItem]:
//                             pathname !== '/attributeConfiguration',
//                           [classes.listItemSelected]:
//                             pathname === '/attributeConfiguration',
//                         })}
//                         button
//                         onClick={() =>
//                           this.props.history.push('/attributeConfiguration')
//                         }
//                       ><div style={{ marginRight : '-20px' }} >
//                         <ListItemIcon>
//                           <AppsIcon
//                             className={classes.nested}
//                             style={{
//                               color:
//                                 pathname === '/attributeConfiguration'
//                                   ? '#FFF'
//                                   : '#000',
//                             }}
//                           />
//                         </ListItemIcon>
//                         </div>
//                         <ListItemText
//                           primary={'Attribure & Attribute Groups'}
//                         />
//                       </ListItem>
                      
//                     </List>
//                   </Collapse> 
//  */}
//                   {/* <Collapse
//                     in={this.state.ratePlanConfiguration}
//                     timeout='auto'
//                     unmountOnExit
//                   >
//                     <List component='div' disablePadding>
//                       <ListItem
//                         className={clsx(classes.nested, {
//                           [classes.listItem]:
//                             pathname !== '/ratePlanConfiguration',
//                           [classes.listItemSelected]:
//                             pathname === '/ratePlanConfiguration',
//                         })}
//                         button
//                         onClick={() =>
//                           this.props.history.push('/ratePlanConfiguration')
//                         }
//                       ><div style={{ marginRight : '-20px' }} >
//                         <ListItemIcon>
//                           <AppsIcon
//                             className={classes.nested}
//                             style={{
//                               color:
//                                 pathname === '/ratePlanConfiguration'
//                                   ? '#FFF'
//                                   : '#000',
//                             }}
//                           />
//                         </ListItemIcon>
//                         </div>
//                         <ListItemText primary={'Rate Plan Configuration'} />
//                       </ListItem>
//                     </List>
//                   </Collapse> */}

//                   <ListItem
//                   className={
//                     pathname === '/worklist'
//                       ? classes.listItemSelected
//                       : classes.listItem
//                   }
//                   button
//                   onClick={() => this.props.history.push('/worklist')}
//                 ><div style={{ marginRight : '-20px' }} >
//                   <ListItemIcon className={classes.navIcon}>
//                   <WorkIcon style={{ color: '#a87f32' }} />
//                   </ListItemIcon> 
//                   </div>
//                   <ListItemText primary={`My Work Queue`} />
//                 </ListItem>

                  
                  
                      
                    
//                   {/* <ListItem button onClick={() => this.props.history.push('/')}>
//                                     <ListItemIcon className={classes.navIcon}>
//                                         <TurnedInNotIcon style={{ color: "green" }} />
//                                     </ListItemIcon>
//                                     <ListItemText primary="My Releases" />
//                                 </ListItem> */}

                 
                                

//                   {/*<ListItem
//                     className={clsx(classes.nested, {
//                       [classes.listItem]: pathname !== '/advanceSearch',
//                       [classes.listItemSelected]: pathname === '/advanceSearch',
//                     })}
//                     button
//                     onClick={() => this.props.history.push('/advanceSearch')}
//                   >
//                     <ListItemIcon className={classes.navIcon}>
//                       <FindInPageIcon
//                         style={{
//                           color:
//                             pathname === '/advanceSearch' ? '#FFF' : '#000',
//                         }}
//                       />
//                     </ListItemIcon>
//                     <ListItemText
//                       primary={<Translate value='dashboard.advanceSearch' />}
//                     />
//                       </ListItem>*/}

//                   <ListItem
//                     style={{ borderBottom: '1px solid #999', color: '#000' }}
//                     className={classes.nested}
//                     button
//                     onClick={() => this.handleClick('library')}
//                   ><div style={{ marginRight : '-20px' }} >
//                     <ListItemIcon className={classes.navIcon}>
//                       <LibraryBooksIcon className={classes.nested} style={{color:'#C66B00'}} />
//                     </ListItemIcon>
//                     </div>
//                     <ListItemText primary='Report' />

//                     {this.state.library ? (
//                       <ExpandLess style={{ fontSize: '18px' }} />
//                     ) : (
//                       <ExpandMore style={{ fontSize: '18px' }} />
//                     )}
//                   </ListItem>
//                   <Divider />

//                   <Collapse
//                     in={this.state.library}
//                     timeout='auto'
//                     unmountOnExit
//                   >
//                     <List component='div' disablePadding>
//                       {/*// <ListItem
//                       //   className={clsx(classes.nested, {
//                       //     [classes.listItem]: pathname !== '/attributeReport',
//                       //     [classes.listItemSelected]:
//                       //       pathname === '/attributeReport',
//                       //   })}
//                       //   button
//                       //   onClick={() => {
//                       //     this.props.history.push('/attributeReport');
//                       //   }}
//                       // >
//                       //   <ListItemIcon>
//                       //     <AppsIcon
//                       //       style={{
//                       //         color:
//                       //           pathname === '/attributeReport'
//                       //             ? '#FFF'
//                       //             : '#000',
//                       //       }}
//                       //     />
//                       //   </ListItemIcon>
//                       //   <ListItemText primary={'Attribute Report'} />
//                     // </ListItem> */}

                      

//                       <ListItem
//                       className={clsx(classes.nested, {
//                         [classes.listItem]: pathname !== '/EpcDailyReleaseReport',
//                         [classes.listItemSelected]:
//                           pathname === '/EpcDailyReleaseReport',
//                       })}
//                       button
//                       onClick={() => {
//                         this.props.history.push('/EpcDailyReleaseReport');
//                       }}
//                     ><div style={{ marginRight : '-20px' }} >
//                       <ListItemIcon>
//                         <AppsIcon
//                           style={{
//                             color:
//                               pathname === '/EpcDailyReleaseReport'
//                                 ? '#FFF'
//                                 : '#000',
//                           }}
//                         />
//                       </ListItemIcon>
//                       </div>
//                       <ListItemText primary={'Daily Release Report'} />
//                     </ListItem>






//                     <ListItem
//                         className={clsx(classes.nested, {
//                           [classes.listItem]: pathname !== '/EpcOfferabilityReport',
//                           [classes.listItemSelected]:
//                             pathname === '/EpcOfferabilityReport',
//                         })}
//                         button
//                         onClick={() => {
//                           this.props.history.push('/EpcOfferabilityReport');
//                         }}
//                       ><div style={{ marginRight : '-20px' }} >
//                         <ListItemIcon>
//                           <AppsIcon
//                             style={{
//                               color:
//                                 pathname === '/EpcOfferabilityReport'
//                                   ? '#FFF'
//                                   : '#000',
//                             }}
//                           />
//                         </ListItemIcon>
//                         </div>
//                         <ListItemText primary={'Offerability Report'} />
//                       </ListItem>




//                       <ListItem
//                         className={clsx(classes.nested, {
//                           [classes.listItem]: pathname !== '/RatePlanReport',
//                           [classes.listItemSelected]:
//                             pathname === '/RatePlanReport',
//                         })}
//                         button
//                         onClick={() => {
//                           this.props.history.push('/RatePlanReport');
//                         }}
//                       ><div style={{ marginRight : '-20px' }} >
//                         <ListItemIcon>
//                           <AppsIcon
//                             style={{
//                               color:
//                                 pathname === '/RatePlanReport'
//                                   ? '#FFF'
//                                   : '#000',
//                             }}
//                           />
//                         </ListItemIcon>
//                         </div>
//                         <ListItemText primary={'Rate Plan Report'} />
//                       </ListItem>





//                       <ListItem
//                         className={clsx(classes.nested, {
//                           [classes.listItem]: pathname !== '/planReport',
//                           [classes.listItemSelected]:
//                             pathname === '/planReport',
//                         })}
//                         button
//                         onClick={() => {
//                           this.props.history.push('/planReport');
//                         }}
//                       ><div style={{ marginRight : '-20px' }} >
//                         <ListItemIcon>
//                           <AppsIcon
//                             style={{
//                               color:
//                                 pathname === '/planReport' ? '#FFF' : '#000',
//                             }}
//                           />
//                         </ListItemIcon>
//                         </div>
//                         <ListItemText primary={'Plan Report'} />
//                       </ListItem>

//                       <ListItem
//                         className={clsx(classes.nested, {
//                           [classes.listItem]: pathname !== '/libraryPlanProductAccountId',
//                           [classes.listItemSelected]:
//                             pathname === '/libraryPlanProductAccountId',
//                         })}
//                         button
//                         onClick={() => {
//                           this.props.history.push('/libraryPlanProductAccountId');
//                         }}
//                       ><div style={{ marginRight : '-20px' }} >
//                         <ListItemIcon>
//                           <AppsIcon
//                             style={{
//                               color:
//                                 pathname === '/libraryPlanProductAccountId' ? '#FFF' : '#000',
//                             }}
//                           />
//                         </ListItemIcon>
//                         </div>
//                         <ListItemText primary={'Plan Product Account ID Report'} />
//                       </ListItem>
//                       <ListItem
//                       className={clsx(classes.nested, {
//                         [classes.listItem]: pathname !== '/epcFederationReport',
//                         [classes.listItemSelected]:
//                           pathname === '/epcFederationReport',
//                       })}
//                       button
//                       onClick={() => {
//                         this.props.history.push('/epcFederationReport');
//                       }}
//                     > <div style={{ marginRight : '-20px' }} >
//                       <ListItemIcon>
//                         <AppsIcon
//                           style={{
//                             color:
//                               pathname === '/epcFederationReport' ? '#FFF' : '#000',
//                           }}
//                         />
//                       </ListItemIcon>
//                       </div>
//                       <ListItemText primary={'Federation Report'} />
//                     </ListItem>
                    
//                       {/*<ListItem
                      
// 													button
// 													className={classes.nested}
// 													onClick={() => {
// 														this.props.history.push(
// 															"/libraryPlanProductAccountId"
// 														);
// 													}}>
// 													<ListItemIcon>
//                           <AppsIcon
//                           style={{
//                             color:
//                               pathname === "/libraryPlanProductAccountId"? '#FFF' : '#000',
//                           }}
//                         />
// 													</ListItemIcon>
// 													<ListItemText
// 														primary={"Plan Product Account ID Report"}
// 													/>
// 												</ListItem>
//                         <ListItem
// 													button
// 													className={classes.nested}
// 													onClick={() => {
// 														this.props.history.push("/epcFederationReport");
// 													}}>
// 													<ListItemIcon>
//                           <AppsIcon
//                           style={{
//                             color:
//                               pathname === '/epcFederationReport' ? '#FFF' : '#000',
//                           }}
//                         />
// 													</ListItemIcon>
// 													<ListItemText primary={"Federation Report"} />
// 												</ListItem>
//                         <ListItem
// 													button
// 													className={classes.nested}
// 													onClick={() => {
// 														this.props.history.push("/libraryGlossary");
// 													}}>
// 													<ListItemIcon>
//                           <AppsIcon
//                           style={{
//                             color:
//                               pathname === '/libraryGlossary' ? '#FFF' : '#000',
//                           }}
//                         />
// 													</ListItemIcon>
// 													<ListItemText primary={"Glossary"} />
// 												</ListItem>
//                         */}

//                       {/*<ListItem
//                         className={clsx(classes.nested, {
//                           [classes.listItem]: pathname !== '/productReport',
//                           [classes.listItemSelected]:
//                             pathname === '/productReport',
//                         })}
//                         button
//                         onClick={() => {
//                           this.props.history.push('/productReport');
//                         }}
//                       >
//                         <ListItemIcon>
//                           <AppsIcon
//                             style={{
//                               color:
//                                 pathname === '/productReport' ? '#FFF' : '#000',
//                             }}
//                           />
//                         </ListItemIcon>
//                         <ListItemText primary={'Product Report'} />
//                           </ListItem>*/}

//                       {/* <ListItem button className={classes.nested}
//                                             onClick={() => {
//                                                 this.props.history.push('/epcDailyReleaseReport')
//                                             }}>
//                                             <ListItemIcon>
//                                                 <AppsIcon />
//                                             </ListItemIcon>
//                                             <ListItemText primary={'Daily Release Report'} />
//                                         </ListItem> */}
//                       {/* <ListItem button className={classes.nested}
//                                             onClick={() => {
//                                                 this.props.history.push('/epcFederationReport')
//                                             }}>
//                                             <ListItemIcon>
//                                                 <AppsIcon />
//                                             </ListItemIcon>
//                                             <ListItemText primary={'Federation Report'} />
//                                         </ListItem> */}
//                       {/* <ListItem button className={classes.nested}
//                                             onClick={() => {
//                                                 this.props.history.push('/epcOfferabilityReport')
//                                             }}>
//                                             <ListItemIcon>
//                                                 <AppsIcon />
//                                             </ListItemIcon>
//                                             <ListItemText primary={'Offerability Report'} />
//                                         </ListItem> */}
//                       {/* <ListItem button className={classes.nested}
//                                             onClick={() => {
//                                                 this.props.history.push('/ratePlanReport')
//                                             }}>
//                                             <ListItemIcon>
//                                                 <AppsIcon />
//                                             </ListItemIcon>
//                                             <ListItemText primary={'Rate Plan Report'} />
//                                         </ListItem> */}
//                     </List>
//                   </Collapse>
//                   {/* <ListItem
//                     className={clsx(classes.nested, {
//                       [classes.listItem]: pathname !== '/productPerformance',
//                       [classes.listItemSelected]:
//                         pathname === '/productPerformance',
//                     })}
//                     button
//                     onClick={() => this.setState({ isOpen: true })}
//                   >
//                     <ListItemIcon className={classes.navIcon}>
//                       <DriveFolderUploadIcon
//                         style={{
//                           color:
//                             pathname === '/productPerformance'
//                               ? '#FFF'
//                               : '#000',
//                         }}
//                       />
//                       {this.state.isOpen && (
//                         <UploadModal setIsOpen={this.state.isOpen} />
//                       )}
//                     </ListItemIcon>
//                     <ListItemText
//                       primary={<Translate value='dashboard.Bulk Upload' />}
//                     />
//                   </ListItem> */}
//                   <ListItem
//                       className={clsx(classes.nested, {
//                         [classes.listItem]: pathname !== '/libraryGlossary',
//                         [classes.listItemSelected]:
//                           pathname === '/libraryGlossary',
//                       })}
//                       button
//                       onClick={() => {
//                         this.props.history.push('/libraryGlossary');
//                       }}
//                     ><div style={{ marginRight : '-20px' }} >
//                       <ListItemIcon>
//                         <GradientIcon
//                           style={{
//                             color:
//                               pathname === '/libraryGlossary' ? '#FFF' : '#000',
//                           }}
//                         />
//                       </ListItemIcon>
//                       </div>
//                       <ListItemText primary={'Glossary'} />
//                     </ListItem>
//                 </List>
//               )}

//             {this.props.userInfo.group &&
//               this.props.userInfo.group.includes('Admin') && (
//                 <List>
//                   <ListItem button onClick={() => this.handleClick('plan')}>
//                   <div style={{ marginRight : '-20px' }} >
//                     <ListItemIcon className={classes.navIcon}>
//                       <LibraryBooksIcon style={{ color: '#8175CB' }} />
//                     </ListItemIcon>
//                     </div>
//                     <ListItemText primary='Package' />
//                     {this.state.plan ? (
//                       <ExpandLess style={{ fontSize: '18px' }} />
//                     ) : (
//                       <ExpandMore style={{ fontSize: '18px' }} />
//                     )}
//                   </ListItem>
//                   <Collapse in={this.state.plan} timeout='auto' unmountOnExit>
//                     <List component='div' disablePadding>
//                       <ListItem
//                         button
//                         className={classes.nested}
//                         onClick={() =>
//                           this.props.history.push('/adminPlanConfiguration')
//                         }
//                       ><div style={{ marginRight : '-20px' }} >
//                         <ListItemIcon>
//                           {' '}
//                           <AppsIcon />{' '}
//                         </ListItemIcon>
//                         </div>
//                         <ListItemText primary='Modify Fields' />
//                       </ListItem>
//                     </List>
//                   </Collapse>

//                   <ListItem button onClick={() => this.handleClick('product')}>
//                   <div style={{ marginRight : '-20px' }} >
//                     <ListItemIcon className={classes.navIcon}>
//                       <StoreIcon style={{ color: '#00ACC2' }} />
//                     </ListItemIcon>
//                     </div>
//                     <ListItemText primary='Product' />
//                     {this.state.product ? (
//                       <ExpandLess style={{ fontSize: '18px' }} />
//                     ) : (
//                       <ExpandMore style={{ fontSize: '18px' }} />
//                     )}
//                   </ListItem>
//                   <Collapse
//                     in={this.state.product}
//                     timeout='auto'
//                     unmountOnExit
//                   >
//                     <List component='div' disablePadding>
//                       <ListItem
//                         button
//                         className={classes.nested}
//                         onClick={() =>
//                           this.props.history.push('/adminProductConfiguration')
//                         }
//                       >
//                         <ListItemIcon>
//                           {' '}
//                           <AppsIcon />{' '}
//                         </ListItemIcon>
//                         <ListItemText primary='Modify Fields' />
//                       </ListItem>
//                       <ListItem
//                         button
//                         onClick={() => {
//                           this.props.history.push('/adminCtsConfiguration');
//                         }}
//                       >
//                         <ListItemIcon>
//                           <AppsIcon />
//                         </ListItemIcon>
//                         <ListItemText primary='Modify CTS' />
//                       </ListItem>
//                     </List>
//                   </Collapse>

//                   <ListItem
//                     button
//                     onClick={() => this.handleClick('offerability')}
//                   >
//                     <ListItemIcon className={classes.navIcon}>
//                       <LocalOfferIcon style={{ color: '#EB646F' }} />
//                     </ListItemIcon>
//                     <ListItemText primary='Offerability' />
//                     {this.state.offerability ? (
//                       <ExpandLess style={{ fontSize: '18px' }} />
//                     ) : (
//                       <ExpandMore style={{ fontSize: '18px' }} />
//                     )}
//                   </ListItem>
//                   <Collapse
//                     in={this.state.offerability}
//                     timeout='auto'
//                     unmountOnExit
//                   >
//                     <List component='div' disablePadding>
//                       <ListItem
//                         button
//                         className={classes.nested}
//                         onClick={() =>
//                           this.props.history.push(
//                             '/adminOfferabilityConfiguration'
//                           )
//                         }
//                       >
//                         <ListItemIcon>
//                           {' '}
//                           <AppsIcon />{' '}
//                         </ListItemIcon>
//                         <ListItemText primary='Modify Offerability' />
//                       </ListItem>
//                     </List>
//                   </Collapse>
//                   <ListItem button onClick={() => this.handleClick('contract')}>
//                     <ListItemIcon className={classes.navIcon}>
//                       <MenuBookIcon style={{ color: '#008E7B' }} />
//                     </ListItemIcon>
//                     <ListItemText primary='Contract' />
//                     {this.state.contract ? (
//                       <ExpandLess style={{ fontSize: '18px' }} />
//                     ) : (
//                       <ExpandMore style={{ fontSize: '18px' }} />
//                     )}
//                   </ListItem>
//                   <Collapse
//                     in={this.state.contract}
//                     timeout='auto'
//                     unmountOnExit
//                   >
//                     <List component='div' disablePadding>
//                       <ListItem
//                         button
//                         className={classes.nested}
//                         onClick={() =>
//                           this.props.history.push(
//                             '/adminBundleContractConfiguration'
//                           )
//                         }
//                       >
//                         <ListItemIcon>
//                           {' '}
//                           <AppsIcon />{' '}
//                         </ListItemIcon>
//                         <ListItemText primary='Bundle Contract' />
//                       </ListItem>
//                       <ListItem
//                         button
//                         className={classes.nested}
//                         onClick={() =>
//                           this.props.history.push(
//                             '/adminContractCreationConfiguration'
//                           )
//                         }
//                       >
//                         <ListItemIcon>
//                           {' '}
//                           <AppsIcon />{' '}
//                         </ListItemIcon>
//                         <ListItemText primary='Contract Creation' />
//                       </ListItem>
//                       <ListItem
//                         button
//                         className={classes.nested}
//                         onClick={() =>
//                           this.props.history.push(
//                             '/adminContractProfileConfiguration'
//                           )
//                         }
//                       >
//                         <ListItemIcon>
//                           {' '}
//                           <AppsIcon />{' '}
//                         </ListItemIcon>
//                         <ListItemText primary='Contract Profile' />
//                       </ListItem>
//                     </List>
//                   </Collapse>
//                   {/* <ListItem button onClick={() => this.handleClick('contractProfile')}>
//                                         <ListItemIcon className={classes.navIcon}>
//                                             <LocalLibraryIcon style={{ color: "#D77CD8" }} />
//                                         </ListItemIcon>
//                                         <ListItemText primary="Contract Profile" />
//                                         {this.state.contractProfile ? <ExpandLess style={{ fontSize: '18px' }} /> :
//                                             <ExpandMore style={{ fontSize: "18px" }} />}
//                                     </ListItem>
//                                     <Collapse in={this.state.contractProfile} timeout="auto" unmountOnExit>
//                                         <List component="div" disablePadding>
//                                             <ListItem button className={classes.nested}
//                                                 onClick={() => this.props.history.push("/adminContractProfileConfiguration")} >
//                                                 <ListItemIcon> <AppsIcon />  </ListItemIcon>
//                                                 <ListItemText primary="Modify Fields" />
//                                             </ListItem>
//                                         </List>
//                                     </Collapse> */}
//                   <ListItem
//                     button
//                     onClick={() => this.handleClick('attribute')}
//                   >
//                     <ListItemIcon className={classes.navIcon}>
//                       <BrightnessAutoIcon style={{ color: '#F60076' }} />
//                     </ListItemIcon>
//                     <ListItemText primary='Attribute' />
//                     {this.state.attribute ? (
//                       <ExpandLess style={{ fontSize: '18px' }} />
//                     ) : (
//                       <ExpandMore style={{ fontSize: '18px' }} />
//                     )}
//                   </ListItem>
//                   <Collapse
//                     in={this.state.attribute}
//                     timeout='auto'
//                     unmountOnExit
//                   >
//                     <List component='div' disablePadding>
//                       <ListItem
//                         button
//                         className={classes.nested}
//                         onClick={() =>
//                           this.props.history.push('/adminAttrConfiguration')
//                         }
//                       >
//                         <ListItemIcon>
//                           {' '}
//                           <AppsIcon />{' '}
//                         </ListItemIcon>
//                         <ListItemText primary='Attribute' />
//                       </ListItem>
//                       <ListItem
//                         button
//                         className={classes.nested}
//                         onClick={() =>
//                           this.props.history.push('/adminAttrGrpConfiguration')
//                         }
//                       >
//                         <ListItemIcon>
//                           {' '}
//                           <AppsIcon />{' '}
//                         </ListItemIcon>
//                         <ListItemText primary='Attribute Group' />
//                       </ListItem>
//                     </List>
//                   </Collapse>
//                   <ListItem button onClick={() => this.handleClick('ratePlan')}>
//                     <ListItemIcon className={classes.navIcon}>
//                       <MoneyIcon style={{ color: '#FFB800' }} />
//                     </ListItemIcon>
//                     <ListItemText primary='Rate Plan' />
//                     {this.state.ratePlan ? (
//                       <ExpandLess style={{ fontSize: '18px' }} />
//                     ) : (
//                       <ExpandMore style={{ fontSize: '18px' }} />
//                     )}
//                   </ListItem>
//                   <Collapse
//                     in={this.state.ratePlan}
//                     timeout='auto'
//                     unmountOnExit
//                   >
//                     <List component='div' disablePadding>
//                       <ListItem
//                         button
//                         className={classes.nested}
//                         onClick={() =>
//                           this.props.history.push('/adminRatePlanConfiguration')
//                         }
//                       >
//                         <ListItemIcon>
//                           {' '}
//                           <AppsIcon />{' '}
//                         </ListItemIcon>
//                         <ListItemText primary='Modify Fields' />
//                       </ListItem>
//                     </List>
//                   </Collapse>
//                   <ListItem button onClick={() => this.handleClick('rental')}>
//                     <ListItemIcon className={classes.navIcon}>
//                       <LocalAtmIcon style={{ color: '#8D6D62' }} />
//                     </ListItemIcon>
//                     <ListItemText primary='Pricing' />
//                     {this.state.rental ? (
//                       <ExpandLess style={{ fontSize: '18px' }} />
//                     ) : (
//                       <ExpandMore style={{ fontSize: '18px' }} />
//                     )}
//                   </ListItem>
//                   <Collapse in={this.state.rental} timeout='auto' unmountOnExit>
//                     <List component='div' disablePadding>
//                       <ListItem
//                         button
//                         className={classes.nested}
//                         onClick={() =>
//                           this.props.history.push('/adminRentalConfiguration')
//                         }
//                       >
//                         <ListItemIcon>
//                           {' '}
//                           <AppsIcon />{' '}
//                         </ListItemIcon>
//                         <ListItemText primary='Rental' />
//                       </ListItem>
//                       <ListItem
//                         button
//                         className={classes.nested}
//                         onClick={() =>
//                           this.props.history.push('/adminDiscountConfiguration')
//                         }
//                       >
//                         <ListItemIcon>
//                           {' '}
//                           <AppsIcon />{' '}
//                         </ListItemIcon>
//                         <ListItemText primary='Discount' />
//                       </ListItem>
//                     </List>
//                   </Collapse>
//                   <ListItem button onClick={() => this.handleClick('user')}>
//                     <ListItemIcon className={classes.navIcon}>
//                       <AccountCircleIcon style={{ color: '#FF6239' }} />
//                     </ListItemIcon>
//                     <ListItemText primary='User' />
//                     {this.state.user ? (
//                       <ExpandLess style={{ fontSize: '18px' }} />
//                     ) : (
//                       <ExpandMore style={{ fontSize: '18px' }} />
//                     )}
//                   </ListItem>
//                   <Collapse in={this.state.user} timeout='auto' unmountOnExit>
//                     <List component='div' disablePadding>
//                       <ListItem
//                         button
//                         className={classes.nested}
//                         onClick={() =>
//                           this.props.history.push('/adminuserConfiguration')
//                         }
//                       >
//                         <ListItemIcon>
//                           {' '}
//                           <AppsIcon />{' '}
//                         </ListItemIcon>
//                         <ListItemText primary='User Creation' />
//                       </ListItem>
//                     </List>
//                   </Collapse>
//                   <ListItem button onClick={() => this.handleClick('workflow')}>
//                     <ListItemIcon className={classes.navIcon}>
//                       <WorkIcon style={{ color: '#1dad03' }} />
//                     </ListItemIcon>
//                     <ListItemText primary='Workflow' />
//                     {this.state.workflow ? (
//                       <ExpandLess style={{ fontSize: '18px' }} />
//                     ) : (
//                       <ExpandMore style={{ fontSize: '18px' }} />
//                     )}
//                   </ListItem>
//                   <Collapse
//                     in={this.state.workflow}
//                     timeout='auto'
//                     unmountOnExit
//                   >
//                     <List component='div' disablePadding>
//                       <ListItem
//                         button
//                         className={classes.nested}
//                         onClick={() =>
//                           this.props.history.push('/adminWorklist')
//                         }
//                       >
//                         <ListItemIcon>
//                           {' '}
//                           <AppsIcon />{' '}
//                         </ListItemIcon>
//                         <ListItemText primary='Worklist' />
//                       </ListItem>
//                     </List>
//                   </Collapse>
//                   {/* <ListItem button onClick={() => this.handleClick('discount')}>
//                                         <ListItemIcon className={classes.navIcon}>
//                                             <AddShoppingCartIcon style={{ color: "#FF6239" }} />
//                                         </ListItemIcon>
//                                         <ListItemText primary="Discount" />
//                                         {this.state.discount ? <ExpandLess style={{ fontSize: '18px' }} /> :
//                                             <ExpandMore style={{ fontSize: "18px" }} />}
//                                     </ListItem>
//                                     <Collapse in={this.state.discount} timeout="auto" unmountOnExit>
//                                         <List component="div" disablePadding>
//                                             <ListItem button className={classes.nested}
//                                                 onClick={() => this.props.history.push("/adminDiscountConfiguration")} >
//                                                 <ListItemIcon> <AppsIcon />  </ListItemIcon>
//                                                 <ListItemText primary="Modify Fields" />
//                                             </ListItem>
//                                         </List>
//                                     </Collapse> */}
//                 </List>
//               )}

//             {this.props.userInfo.group &&
//               !this.props.userInfo.group.includes('Admin') &&
//               !this.props.userInfo.group.includes('TelemediaProductManager') && 
//               !this.props.userInfo.group.includes('SuperUser') &&(
//                 <List>
//                   <ListItem
//                     button
//                     onClick={() => this.props.history.push('/allReleases')}
//                   >
//                     <ListItemIcon className={classes.navIcon}>
//                       <AllInboxIcon style={{ color: 'blue' }} />
//                     </ListItemIcon>
//                     <ListItemText primary='All Releases' />
//                   </ListItem>

//                   <ListItem
//                     button
//                     onClick={() => this.props.history.push('/worklist')}
//                   >
//                     <ListItemIcon className={classes.navIcon}>
//                       <WorkIcon style={{ color: '#a87f32' }} />
//                     </ListItemIcon>
//                     <ListItemText
//                       primary={<Translate value='My Work Queue' />}
//                     />
//                   </ListItem>
//                 </List>
//               )}
              
              
//           </Drawer>
//                   )}
          
//           <main
//             className={
//               pathname !== '/editRelease' &&
//               pathname !== '/federate' &&
//               pathname !== '/validateTransformRelease' &&
//               pathname !== '/selectApprover'
//                 ? classes.content
//                 : classes.content2
//             }
//             style={{width: '1rem'}}
//           >
//             <div className={classes.toolbar} />
//             {/* <Toolbar /> */}

//             {this.props.children}
//           </main>
//         </div>
//       </ThemeProvider>
//     );
//   }
// }

// const mapStateToProps = (state) => {
//   return {
//     approversData: state.approverData.approversData,
//     userInfo: state.login.loggedInUserInfo,
//     pkgKey: state.packageData.pkgKey,
//     productKey: state.productData.productKey,
//     searchItems: state.searchData.searchItems,
//     searchValue: state.searchData.searchValue,
//     entity: state.searchData.entity,
//     packageData: state.packageData.packageData,
//     productData: state.productData.productData,
//     openDrawer: state.drawerData.open,
//     releaseData: state.releaseData.releaseData,
//     roleGroup: state.roleSelected.roleGroup
//   };
// };

// const mapDispatchToProps = (dispatch) => {
//   return {
//     setDrawer: (open) =>
//       dispatch({ type: actionTypes.DRAWER_TOGGLE, open: open }),
//     onLogout: () => dispatch({ type: actionTypes.LOG_OUT }),
//     onPackageEnter: (packageData) =>
//       dispatch({ type: actionTypes.INSIDE_PACKAGE, packageData: packageData }),
//     changePackageKey: (pkgKey) =>
//       dispatch({ type: actionTypes.CHANGE_PACKAGE_KEY, pkgKey: pkgKey }),
//     changePackageActiveStep: (activeStep) =>
//       dispatch({
//         type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
//         activeStep: activeStep,
//       }),
//     changeProductKey: (productKey) =>
//       dispatch({
//         type: actionTypes.CHANGE_PRODUCT_KEY,
//         productKey: productKey,
//       }),
//     onProductEnter: (productData) =>
//       dispatch({ type: actionTypes.INSIDE_PRODUCT, productData: productData }),
//     changeProductActiveStep: (activeStep) =>
//       dispatch({
//         type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP,
//         activeStep: activeStep,
//       }),
//     setSearchValue: (searchValue) =>
//       dispatch({
//         type: actionTypes.SET_SEARCH_VALUE,
//         searchValue: searchValue,
//       }),
//     changeLocale: (locale) => dispatch(setLocale(locale)),
//   };
// };

// export default connect(
//   mapStateToProps,
//   mapDispatchToProps
// )(withStyles(useStyles)(withRouter(Layout)));


import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import GradientIcon from '@material-ui/icons/Gradient';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import Typography from '@material-ui/core/Typography';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Avatar from '@material-ui/core/Avatar';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import clsx from 'clsx';
import * as actionTypes from '../../store/actions/actionTypes';
import { withRouter } from 'react-router-dom';
import Collapse from '@material-ui/core/Collapse';
import PermDataSettingIcon from '@material-ui/icons/PermDataSetting';
import ExpandLess from '@material-ui/icons/ExpandLess';
import ExpandMore from '@material-ui/icons/ExpandMore';
import AppsIcon from '@material-ui/icons/Apps';
import { createMuiTheme } from '@material-ui/core/styles';
import { ThemeProvider } from '@material-ui/styles';
import BrightnessAutoIcon from '@material-ui/icons/BrightnessAuto';
import RedeemIcon from '@material-ui/icons/Redeem';
import LibraryBooksIcon from '@material-ui/icons/LibraryBooks';
import MoneyIcon from '@material-ui/icons/Money';
import StoreIcon from '@material-ui/icons/Store';
import LocalOfferIcon from '@material-ui/icons/LocalOffer';
import MenuBookIcon from '@material-ui/icons/MenuBook';
import LocalAtmIcon from '@material-ui/icons/LocalAtm';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import WorkIcon from '@material-ui/icons/Work';
import AllInboxIcon from '@material-ui/icons/AllInbox';
import { setLocale } from 'react-redux-i18n';
import { Translate } from 'react-redux-i18n';
import FindInPageIcon from '@material-ui/icons/FindInPage';
import TurnedInNotIcon from '@material-ui/icons/TurnedInNot';
import TCSLogo from '../../assests/images/logo.png';
// import Logo from "../../assests/images/mtn-logo.svg";
// import LogoImage from "../../assests/images/mtnIlulaLogo.png";
import InsertDriveFileOutlinedIcon from '@material-ui/icons/InsertDriveFileOutlined';
import logo1 from '../../assests/images/logo1.jpg';
import ModalAction from "../../UI/ModalAction/ModalAction";
import CloseIcon from '@material-ui/icons/Close';
import { AccountCircle, HomeOutlined } from '@material-ui/icons';
import PowerSettingsNewIcon from '@mui/icons-material/PowerSettingsNew';
import { BrighterSans } from './fonts';
import { Menu, MenuItem } from '@material-ui/core';
import Grid from '@material-ui/core/Grid';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { createTheme } from '@material-ui/core/styles';
import TimelineIcon from '@material-ui/icons/Timeline';
import { FaHandshake } from '@react-icons/all-files/fa/FaHandshake';
import CollectionsBookmarkIcon from '@material-ui/icons/CollectionsBookmark';
//import MoneyIcon from '@mui/icons-material/Money';
import EventNoteIcon from '@material-ui/icons/EventNote';
//import UploadFileIcon from '@material-ui/icons/UploadFileIcon';
import DriveFolderUploadIcon from '@mui/icons-material/DriveFolderUpload';
import UploadModal from '../../common/Upload/UploadModal';
import IdleTimer from "react-idle-timer";
import axios from 'axios';

const theme = createMuiTheme({
  typography: {
    fontFamily: 'BrighterSans',
    body1: {
      fontSize: '14px',
    },
  },
  overrides: {
    MuiCssBaseline: {
      '@global': {
        '@font-face': [BrighterSans],
      },
    },
  },
});

const drawerWidth = 255; 

const useStyles = (theme) => ({
  root: {
    display: 'flex',
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    backgroundColor: '#ff1921',
    boxShadow: 'none',
  },
  avatar: {
		width: theme.spacing(18),
		height: theme.spacing(18),
		backgroundColor: '#ff1921'},

    large: {
      width: theme.spacing(15),
      height: theme.spacing(15),
    },


  menuButton: {
    marginRight: 36,
  },
  hide: {
    display: 'none',
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
  },
  drawerPaper: {
    background: '#dfe4ec',
    // background: "#272c2f",
  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerClose: {
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: theme.spacing(7) + 1,
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(9) + 1,
    },
  },
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
    padding: `0 ${theme.spacing(3)}px`,
    // background: "rgba(0, 0, 0, 0.04)",
  },
  content2: {
    flexGrow: 1,
    // background: "rgba(0, 0, 0, 0.04)",
  },
  selected: {
    background: '#ff1921',
    color: '#FFF',
  },
  nested: {
    color: '#000',
  },
  title: {
    flexGrow: 1,
  },
  listItem: {
    borderBottom: '1px solid #999',
    // color: '#000',
    '&:hover': {
      // color: "#FFF",
      background: '#ff1921',
    },
  },
  listItemSelected: {
    color: '#FFF',
    background: '#ff1921',
    '&:hover': {
      color: '#FFF',
      background: '#ff1921',
    },
  },
});

class Layout extends Component {
  state = {
    open: true,
    planConfig: false,
    contractConfig: false,
    plan: false,
    product: false,
    offerability: false,
    contract: false,
    contractProfile: false,
    ratePlan: false,
    rental: false,
    discount: false,
    user: false,
    workflow: false,
    library: false,
    show: false,
    timerConfig: {},
    release: false,
    genericConfiguration: false,
    rateplanConfiguration: false,
    isOpen: false,
    show: false,
    timerConfig: {},
  };

  constructor(props) {
    super(props);
    this.idleTimerRef = React.createRef();
    this.sessionTimerRef = React.createRef();
  }

  componentDidMount() {
    console.log("layout mounted");
    axios
      .get(process.env.REACT_APP_URL + "telemediaDashboard/telemediaPopup")
      .then((res) => {
        console.log(res);
        this.setState({
          timerConfig: res.data.data,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  }

  logoutHandler = () => {

   
    this.props.onLogout();
    this.props.history.replace('/login');
    localStorage.clear();
    this.setState({show:false});
    sessionStorage.clear();
    this.props.onLogout();
 

		this.props.changeLocale('en');
      // this.props.changeLocale('en')

      // var cookies = document.cookie.split(';');

      // for (var i = 0; i < cookies.length; i++) {
      //   var cookie = cookies[i];
      //   var eqPos = cookie.indexOf('=');
      //   var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
      //   console.log(name);
      //   document.cookie =
      //     name +
      //     '=;expires=Thu, 01 Jan 1970 00:00:01 GMT; path=/;domain=ace.airtelworld.in;';
      // }
      window.location.replace('https://10.5.198.129/EPCLogin/');
      // document.cookie = "username=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";

  
      
      // window.location.replace(process.env.REACT_APP_URL + "EPCLogin");
    
  };

  drawerHandler = () => {
    this.props.setDrawer(!this.props.openDrawer);
  };

  handleClick = (item) => {
    this.setState((prevState) => {
      return { [item]: !prevState[item] };
    });
  };

  render() {
    const { classes } = this.props;
    const { pathname } = this.props.history.location;

    if (!(Object.keys(this.props.userInfo).length > 0)) {
      return this.props.children;
    }

    return (
      <ThemeProvider theme={theme}>
        <div className={classes.root}>
        
         {Object.keys(this.props.userInfo).length > 0 &&
          Object.keys(this.state.timerConfig).length > 0 && (
            <IdleTimer
              ref={this.idleTimerRef}
              timeout={Number(this.state.timerConfig.inactiveTime)}
              // timeout={6000}
              onIdle={() => {
                console.log("idle timer log");
                this.setState({ show: true });
                this.sessionTimerRef.current = setTimeout(
                  this.logoutHandler,
                  Number(this.state.timerConfig.autoLogout)
                );
              }}
            ></IdleTimer>
          )}  
            

        <ModalAction
          show={this.state.show}
          modalClosed={() => {
            clearTimeout(this.sessionTimerRef.current);
            this.setState({ show: false });
          }}
          actionText={"Log me out"}
          closeText={"Keep me signed in"}
          title={"Timeout"}
          action={() => {
            clearTimeout(this.sessionTimerRef.current);
            this.logoutHandler();
          }}
        >
          <div style={{ padding: "20" }}>
            <h2>You've been idle for a while!</h2>
            <p>You will be logged out soon</p>
          </div>
        </ModalAction>
          <CssBaseline />
          <AppBar
            position='fixed'
            className={clsx(classes.appBar, {
              [classes.appBarShift]: this.props.openDrawer,
            })}
            // className={classes.appBar}
          >
            <Toolbar
            // style={{ height: "70px" }}
            
                
            >
           {/* <ListItem
            button
            onClick={this.drawerHandler}
            style={{ width: "3%",marginLeft:'0px' }}
          >
            <ListItemIcon>
              {this.props.openDrawer ? (
                <CloseIcon style={{ color: '#000' }} />
              ) : (
                <MenuIcon style={{ color: '#000' }} />
              )}
            </ListItemIcon>
            
              </ListItem>*/}
              <img
                src={logo1}
                style={{
                  cursor: 'pointer',
                  height: '9vh',
                  marginBottom: '0px',
              
                  
                }}
                onClick={() => this.props.history.push('/')}
              />

              {(pathname == '/planConfiguration' ||
                pathname == '/productConfiguration') && (
                <div style={{ marginLeft: '5%' }}>
                  <Grid container spacing={1} alignItems='flex-end'>
                    <Grid item>
                      <Autocomplete
                        value={this.props.searchValue}
                        onChange={(event, value) => {
                          if (value) {
                            this.props.setSearchValue(value);
                            if (this.props.entity == 'PACKAGE') {
                              this.props.changePackageActiveStep(0);
                              let pkgData = { ...this.props.packageData };
                              pkgData['packageId'] = value.split('/')[0];
                              this.props.onPackageEnter(pkgData);
                              this.props.changePackageKey(
                                this.props.pkgKey + '1'
                              );
                              this.props.history.push('/planConfiguration');
                              this.props.history.go();
                            } else if (this.props.entity == 'PRODUCT') {
                              this.props.changeProductActiveStep(0);
                              let proData = { ...this.props.productData };
                              proData['productId'] = value.split('/')[0];
                              this.props.onProductEnter(proData);
                              this.props.changeProductKey(
                                this.props.productKey + '1'
                              );
                              this.props.history.push('/productConfiguration');
                              this.props.history.go();
                            }
                            this.props.setSearchValue(null);
                          }
                        }}
                        options={this.props.searchItems}
                        // getOptionLabel={(option) => ""}
                        renderOption={(option) => {
                          var matches = option.match(/\[(.*?)\]/);

                          if (matches) {
                            var submatch = matches[0];
                            var submatch0 = option.split(submatch)[0];
                          }

                          if (pathname == '/productConfiguration') {
                            var usedesc = submatch0 || option || '';
                            var submatch0arr = usedesc.split('/');
                            submatch0arr.shift();
                            var submatchdesc = submatch0arr.join('/');
                          }

                          return (
                            <>
                              {submatchdesc || option}{' '}
                              <span style={{ color: '#ff0000' }}>
                                {submatch}
                              </span>
                            </>
                          );
                        }}
                        renderInput={(params) => (
                          <div ref={params.InputProps.ref}>
                            <input
                              style={{
                                width: '30vw',
                                height: '4vh',
                                border: 'none',
                                borderRadius: '3px',
                              }}
                              type='text'
                              {...params.inputProps}
                            />
                          </div>
                        )}
                      />
                    </Grid>
                  </Grid>
                </div>
              )}

              <Typography variant='h6' className={classes.title}>
                {/* Ilula */}
              </Typography>
              

              <div
              style={{
                display: 'flex',
                textTransform: 'capitalize',
                color: '#FFF',
                alignItems: 'center',
              }}
            >
              <IconButton
                aria-label='account of current user'
                aria-controls='menu-appbar'
                aria-haspopup='true'
                onClick={(event) => {
                  this.setState({
                    anchorEl: event.currentTarget,
                    menuOpen: false,
                  });
                }}
                color='inherit'
              >
                <PowerSettingsNewIcon onClick={this.logoutHandler} />
              </IconButton>
              <Menu
                id='menu-appbar'
                anchorEl={this.state.anchorEl}
                anchorOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                keepMounted
                transformOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                open={this.state.menuOpen}
                onClose={() => this.setState({ menuOpen: false })}
              >
             {/* <MenuItem onClick={this.logoutHandler}>Logout</MenuItem>*/}
              </Menu>
              <div style={{ display: 'flex', flexDirection: 'column' ,marginLeft:'5px' }}>
                <span>
                  {`${this.props.userInfo.firstName.toLowerCase()} ${this.props.userInfo.lastName.toLowerCase()}`}
                </span>
                {/* {this.props.approversData && */}
                {this.props.userInfo.group &&
                  this.props.userInfo.group.map((grp) => {
                    return (
                      <span key={grp} style={{ fontSize: '11px' }}>
                        {grp}
                        {/* {console.log(this.props.userInfo)} */}

                        {/* {this.props.approversData[grp]} */}
                      </span>
                    );
                  })}
              </div>
            </div>



            </Toolbar>
          </AppBar>
          {
            // this.props.roleGroup 
// &&
            //  (

              (this.props.roleGroup || this.props.userInfo.group.includes('CIT_OPS') || 
              this.props.userInfo.group.includes('ceoB2c')|| 
              this.props.userInfo.group.includes('ceoB2b')||
              this.props.userInfo.group.includes('MS_TEST')||
              this.props.userInfo.group.includes('Selfcare_UAT')||
              this.props.userInfo.group.includes('NCA_UAT')||
              this.props.userInfo.group.includes('preProdTest') ||
              this.props.userInfo.group.includes('cmoB2c') ||
              this.props.userInfo.group.includes('csdB2c')

              ) &&(

          <Drawer
            variant='permanent'
            className={clsx(classes.drawer, {
              [classes.drawerOpen]: this.props.openDrawer,
              [classes.drawerClose]: !this.props.openDrawer,
            })}
            classes={{
              paper: clsx(classes.drawerPaper, {
                [classes.drawerOpen]: this.props.openDrawer,
                [classes.drawerClose]: !this.props.openDrawer,
              }),
            }}
          >
            <div className={classes.toolbar}>
              { <IconButton onClick={this.drawerHandler}>
                {theme.direction === "rtl" ? <CloseIcon /> : <CloseIcon />}
              </IconButton> }
            </div>
            
            
            {/*<div
								style={{
									height: '30vh',
                  marginTop:'20px',
                  marginLeft:'30px',
                  marginBottom:'10px'
								}}>
								<div className={classes.center}  >
									<Avatar className={classes.avatar}>
										<AccountCircle className={classes.large} />
									</Avatar>
								</div>
								<div style={{ marginLeft: '0px' ,marginTop:'15px' }}>
									<Grid
										container
										alignContent="center"
										style={{ marginBottom: '5px' }}>
										<span
											style={{
												fontWeight: 'bold',
												width: drawerWidth,
												wordBreak: 'break-all',
												paddingLeft: '10px',
												paddingRight: '10px',
											}}>
											{' ' +
												this.props.userInfo.firstName +
												' ' +
												this.props.userInfo.lastName}
										</span>
									</Grid>
									<Grid alignContent="center">
										{this.props.approversData && this.props.userInfo.group && (
											<React.Fragment>
												{this.props.userInfo.group
													.filter(
														(value, index) =>
															this.props.userInfo.group.indexOf(value) === index
													)
													.filter((value, index, theArray) => {
														if (
															this.props.userInfo.group[index]
																.substring(
																	this.props.userInfo.group[index].length - 3,
																	this.props.userInfo.group[index].length
																)
																.toLowerCase() === 'b2b' &&
															theArray.includes(
																`${this.props.userInfo.group[index].substring(
																	0,
																	3
																)}B2c`
															)
														) {
															return;
														} else {
															return value;
														}
													})
													.map((grp) => {
														return (
															this.props.approversData[grp] && (
																<Grid
																	container
																	alignContent="center"
																	style={{ marginBottom: '5px' }}>
																	<span
																		style={{
																			fontWeight: 'bold',
																			width: drawerWidth,
																			wordBreak: 'break-all',
																			paddingLeft: '10px',
																			paddingRight: '10px',
																		}}>
																		{this.props.approversData[grp]}
																	</span>
																</Grid>
															)
														);
													})}
											</React.Fragment>
										)}
									</Grid>
								</div>
           </div>*/}
                
            <Divider style={{ marginTop: '0px' }} />
            {this.props.userInfo.group && this.props.roleGroup &&

              this.props.userInfo.group.includes('TelemediaProductManager') && (
                <List>
                {/*<ListItem
                    button
                    onClick={this.drawerHandler}
                    style={{ borderBottom: '1px solid #999', color: '#000' }}
                  >
                    <ListItemIcon>
                      {this.props.openDrawer ? (
                        <CloseIcon style={{ color: '#000' }} />
                      ) : (
                        <MenuIcon style={{ color: '#000' }} />
                      )}
                    </ListItemIcon>
                    <ListItemText primary={'Menu'} />
                      </ListItem> */}
                 <ListItem
                    className={
                      pathname === '/allReleases'
                        ? classes.listItemSelected
                        : classes.listItem
                    }
                    button
                    onClick={() => this.props.history.push('/allReleases')}
                  ><div style={{ marginRight : '-20px' }} >

                    <ListItemIcon className={classes.navIcon}>
                    <AllInboxIcon style={{ color: 'blue' }} />
                    </ListItemIcon>
                    </div>
                    <ListItemText primary={`All Releases`}  />
                  </ListItem>





                  <ListItem
                    className={
                      pathname === '/'
                        ? classes.listItemSelected
                        : classes.listItem
                    }
                    button
                    onClick={() => this.props.history.push('/')}
                  ><div style={{ marginRight : '-20px' }} >
                    <ListItemIcon className={classes.navIcon}>
                      <HomeOutlined
                        style={{ color: pathname === '/' ? '#FFF' : '#000' }}
                      />
                    </ListItemIcon> 
                    </div>
                    <ListItemText primary={`My Releases`} />
                  </ListItem>
                  {this.props.releaseData.releaseId && (
                    <>
                      <ListItem
                        className={
                          pathname === '/editRelease'
                            ? classes.listItemSelected
                            : classes.listItem
                        }
                        button
                        onClick={() => {
                          this.handleClick('release');
                          this.props.history.push('/editRelease');
                        }}
                      ><div style={{ marginRight : '-20px' }} >
                        <ListItemIcon className={classes.navIcon}>
                          <TurnedInNotIcon
                            style={{
                              color:
                                pathname === '/editRelease' ? 'green' : 'green',
                            }}
                          />
                        </ListItemIcon>
                        </div>
                        <ListItemText
                          primary={`Release ${this.props.releaseData.externalReleaseId}`}
                        />
                      </ListItem>
                      <Collapse
                        in={this.state.release}
                        timeout='auto'
                        unmountOnExit
                      >
                        <Divider style={{ background: '#fff' }} />
                      </Collapse>
                    
                      {this.props.releaseData.releaseStatus === 'InProgress'
                      &&(

                  <React.Fragment>
                 
                    <ListItem
                      style={{
                        borderBottom: '1px solid #999',
                        color: '#000',
                      }}
                      button
                      onClick={() => this.handleClick('planConfig')}
                    >
                    <div style={{ marginRight : '-20px' }} >
                      <ListItemIcon className={classes.navIcon}>
                        <PermDataSettingIcon
                          style={{
                            color: '#009B88',
                          }}
                        />
                      </ListItemIcon>
                      </div>
                      <ListItemText
                        primary={<Translate value='dashboard.proConfig' />}
                      />
                      {this.state.planConfig ? (
                        <ExpandLess style={{ fontSize: '18px' }} />
                      ) : (
                        <ExpandMore style={{ fontSize: '18px' }} />
                      )}
                    </ListItem>
                    <Collapse
                      in={this.state.planConfig}
                      timeout='auto'
                      unmountOnExit
                    >
                      <List component='div' disablePadding>
                        <ListItem
                          button
                          className={clsx(classes.nested, {
                            [classes.listItem]:
                              pathname !== '/planConfiguration',
                            [classes.listItemSelected]:
                              pathname === '/planConfiguration',
                          })}
                          onClick={() => {
                            console.log(this.props.pkgKey);
                            this.props.changePackageActiveStep(0);
                            this.props.onPackageEnter({});
                            this.props.changePackageKey(
                              this.props.pkgKey + '1'
                            );
                            this.props.history.push('/planConfiguration');
                          }}
                        ><div style={{ marginRight : '-20px' }} >
                          <ListItemIcon>
                            <AppsIcon
                              className={classes.nested}
                              style={{
                                color:
                                  pathname === '/planConfiguration'
                                    ? '#FFF'
                                    : '#000',
                              }}
                            />
                          </ListItemIcon>
                          </div>
                          <ListItemText
                            primary={<Translate value='dashboard.bundles' />}
                          />
                        </ListItem>
                        <ListItem
                          button
                          className={clsx(classes.nested, {
                            [classes.listItem]:
                              pathname !== '/productConfiguration',
                            [classes.listItemSelected]:
                              pathname === '/productConfiguration',
                          })}
                          onClick={() => {
                            this.props.changeProductActiveStep(0);
                            this.props.onProductEnter({});
                            this.props.changeProductKey(
                              this.props.productKey + '1'
                            );
                            this.props.history.push('/productConfiguration');
                          }}
                        ><div style={{ marginRight : '-20px' }} >
                          <ListItemIcon>
                            <AppsIcon
                              className={classes.nested}
                              style={{
                                color:
                                  pathname === '/productConfiguration'
                                    ? '#FFF'
                                    : '#000',
                              }}
                            />
                          </ListItemIcon>
                          </div>
                          <ListItemText
                            primary={<Translate value='dashboard.products' />}
                          />
                        </ListItem>
                        <ListItem
                          className={clsx(classes.nested, {
                            [classes.listItem]:
                              pathname !== '/ratePlanConfiguration',
                            [classes.listItemSelected]:
                              pathname === '/ratePlanConfiguration',
                          })}
                          button
                          onClick={() =>
                            this.props.history.push('/ratePlanConfiguration')
                          }
                        ><div style={{ marginRight : '-20px' }} >
                          <ListItemIcon className={classes.navIcon}>
                            <AppsIcon
                              style={{
                                color:
                                  pathname === '/ratePlanConfiguration'
                                    ? '#FFF'
                                    : '#000',
                              }}
                            />
                          </ListItemIcon>
                          </div>
                          <ListItemText
                            primary={
                              <Translate value='dashboard.Rate Plan Configuration' />
                            }
                          />
                        </ListItem>
                        {this.props.userInfo.group &&
                          this.props.userInfo.group.includes('SuperUser') && (
                            <>

                        <ListItem
                          className={clsx(classes.nested, {
                            [classes.listItem]: pathname !== '/events',
                            [classes.listItemSelected]: pathname === '/events',
                          })}
                          button
                          onClick={() => this.props.history.push('/events')}
                        ><div style={{ marginRight : '-20px' }} >
                          <ListItemIcon className={classes.navIcon}>
                            <AppsIcon
                              style={{
                                color: pathname === '/events' ? '#FFF' : '#000',
                              }}
                            />
                          </ListItemIcon>
                          </div>
                          <ListItemText
                            primary={
                              <Translate value='dashboard.Rules Configuration' />
                            }
                          />
                        </ListItem>
                        <ListItem
                          className={clsx(classes.nested, {
                            [classes.listItem]:
                              pathname !== '/attributeConfiguration',
                            [classes.listItemSelected]:
                              pathname === '/attributeConfiguration',
                          })}
                          button
                          onClick={() =>
                            this.props.history.push('/attributeConfiguration')
                          }
                        ><div style={{ marginRight : '-20px' }} >
                          <ListItemIcon>
                            <AppsIcon
                              className={classes.nested}
                              style={{
                                color:
                                  pathname === '/attributeConfiguration'
                                    ? '#FFF'
                                    : '#000',
                              }}
                            />
                          </ListItemIcon>
                          </div>
                          <ListItemText primary={'Attribute Configuration'} />
                        </ListItem>
                        </> )}
                      </List>
                    </Collapse>
                  
                  </React.Fragment>
                  )}
                  </>

                  )}
                  {/* 
                   <ListItem
                    style={{ borderBottom: '1px solid #999', color: '#000' }}
                    button
                    className={classes.nested}
                    onClick={() => this.handleClick('genericConfiguration')}
                  ><div style={{ marginRight : '-20px' }} >
                    <ListItemIcon className={classes.navIcon}>
                     <LibraryBooksIcon style={{ color: "#C66B00" }} /> 
                      <BrightnessAutoIcon style={{ color: '#000' }} />
                    </ListItemIcon>
                    </div>
                    <ListItemText primary='Attribute Configuration' />
                    {this.state.genericConfiguration ? (
                      <ExpandLess style={{ fontSize: '18px' }} />
                    ) : (
                      <ExpandMore style={{ fontSize: '18px' }} />
                    )}
                  </ListItem>

                  <Collapse
                    in={this.state.genericConfiguration}
                    timeout='auto'
                    unmountOnExit
                  >
                    <List component='div' disablePadding>
                      <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]:
                            pathname !== '/attributeConfiguration',
                          [classes.listItemSelected]:
                            pathname === '/attributeConfiguration',
                        })}
                        button
                        onClick={() =>
                          this.props.history.push('/attributeConfiguration')
                        }
                      ><div style={{ marginRight : '-20px' }} >
                        <ListItemIcon>
                          <AppsIcon
                            className={classes.nested}
                            style={{
                              color:
                                pathname === '/attributeConfiguration'
                                  ? '#FFF'
                                  : '#000',
                            }}
                          />
                        </ListItemIcon>
                        </div>
                        <ListItemText
                          primary={'Attribure & Attribute Groups'}
                        />
                      </ListItem>
                      
                    </List>
                  </Collapse> 
 */}
                  {/* <Collapse
                    in={this.state.ratePlanConfiguration}
                    timeout='auto'
                    unmountOnExit
                  >
                    <List component='div' disablePadding>
                      <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]:
                            pathname !== '/ratePlanConfiguration',
                          [classes.listItemSelected]:
                            pathname === '/ratePlanConfiguration',
                        })}
                        button
                        onClick={() =>
                          this.props.history.push('/ratePlanConfiguration')
                        }
                      ><div style={{ marginRight : '-20px' }} >
                        <ListItemIcon>
                          <AppsIcon
                            className={classes.nested}
                            style={{
                              color:
                                pathname === '/ratePlanConfiguration'
                                  ? '#FFF'
                                  : '#000',
                            }}
                          />
                        </ListItemIcon>
                        </div>
                        <ListItemText primary={'Rate Plan Configuration'} />
                      </ListItem>
                    </List>
                  </Collapse> */}

                  <ListItem
                  className={
                    pathname === '/worklist'
                      ? classes.listItemSelected
                      : classes.listItem
                  }
                  button
                  onClick={() => this.props.history.push('/worklist')}
                ><div style={{ marginRight : '-20px' }} >
                  <ListItemIcon className={classes.navIcon}>
                  <WorkIcon style={{ color: '#a87f32' }} />
                  </ListItemIcon> 
                  </div>
                  <ListItemText primary={`My Work Queue`} />
                </ListItem>

                  
                  
                      
                    
                  {/* <ListItem button onClick={() => this.props.history.push('/')}>
                                    <ListItemIcon className={classes.navIcon}>
                                        <TurnedInNotIcon style={{ color: "green" }} />
                                    </ListItemIcon>
                                    <ListItemText primary="My Releases" />
                                </ListItem> */}

                 
                                

                  {/*<ListItem
                    className={clsx(classes.nested, {
                      [classes.listItem]: pathname !== '/advanceSearch',
                      [classes.listItemSelected]: pathname === '/advanceSearch',
                    })}
                    button
                    onClick={() => this.props.history.push('/advanceSearch')}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <FindInPageIcon
                        style={{
                          color:
                            pathname === '/advanceSearch' ? '#FFF' : '#000',
                        }}
                      />
                    </ListItemIcon>
                    <ListItemText
                      primary={<Translate value='dashboard.advanceSearch' />}
                    />
                      </ListItem>*/}

                  <ListItem
                    style={{ borderBottom: '1px solid #999', color: '#000' }}
                    className={classes.nested}
                    button
                    onClick={() => this.handleClick('library')}
                  ><div style={{ marginRight : '-20px' }} >
                    <ListItemIcon className={classes.navIcon}>
                      <LibraryBooksIcon className={classes.nested} style={{color:'#C66B00'}} />
                    </ListItemIcon>
                    </div>
                    <ListItemText primary='Report' />

                    {this.state.library ? (
                      <ExpandLess style={{ fontSize: '18px' }} />
                    ) : (
                      <ExpandMore style={{ fontSize: '18px' }} />
                    )}
                  </ListItem>
                  <Divider />

                  <Collapse
                    in={this.state.library}
                    timeout='auto'
                    unmountOnExit
                  >
                    <List component='div' disablePadding>
                      {/*// <ListItem
                      //   className={clsx(classes.nested, {
                      //     [classes.listItem]: pathname !== '/attributeReport',
                      //     [classes.listItemSelected]:
                      //       pathname === '/attributeReport',
                      //   })}
                      //   button
                      //   onClick={() => {
                      //     this.props.history.push('/attributeReport');
                      //   }}
                      // >
                      //   <ListItemIcon>
                      //     <AppsIcon
                      //       style={{
                      //         color:
                      //           pathname === '/attributeReport'
                      //             ? '#FFF'
                      //             : '#000',
                      //       }}
                      //     />
                      //   </ListItemIcon>
                      //   <ListItemText primary={'Attribute Report'} />
                    // </ListItem> */}

                      

                      <ListItem
                      className={clsx(classes.nested, {
                        [classes.listItem]: pathname !== '/EpcDailyReleaseReport',
                        [classes.listItemSelected]:
                          pathname === '/EpcDailyReleaseReport',
                      })}
                      button
                      onClick={() => {
                        this.props.history.push('/EpcDailyReleaseReport');
                      }}
                    ><div style={{ marginRight : '-20px' }} >
                      <ListItemIcon>
                        <AppsIcon
                          style={{
                            color:
                              pathname === '/EpcDailyReleaseReport'
                                ? '#FFF'
                                : '#000',
                          }}
                        />
                      </ListItemIcon>
                      </div>
                      <ListItemText primary={'Daily Release Report'} />
                    </ListItem>






                    <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]: pathname !== '/EpcOfferabilityReport',
                          [classes.listItemSelected]:
                            pathname === '/EpcOfferabilityReport',
                        })}
                        button
                        onClick={() => {
                          this.props.history.push('/EpcOfferabilityReport');
                        }}
                      ><div style={{ marginRight : '-20px' }} >
                        <ListItemIcon>
                          <AppsIcon
                            style={{
                              color:
                                pathname === '/EpcOfferabilityReport'
                                  ? '#FFF'
                                  : '#000',
                            }}
                          />
                        </ListItemIcon>
                        </div>
                        <ListItemText primary={'Offerability Report'} />
                      </ListItem>




                      <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]: pathname !== '/RatePlanReport',
                          [classes.listItemSelected]:
                            pathname === '/RatePlanReport',
                        })}
                        button
                        onClick={() => {
                          this.props.history.push('/RatePlanReport');
                        }}
                      ><div style={{ marginRight : '-20px' }} >
                        <ListItemIcon>
                          <AppsIcon
                            style={{
                              color:
                                pathname === '/RatePlanReport'
                                  ? '#FFF'
                                  : '#000',
                            }}
                          />
                        </ListItemIcon>
                        </div>
                        <ListItemText primary={'Rate Plan Report'} />
                      </ListItem>





                      <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]: pathname !== '/planReport',
                          [classes.listItemSelected]:
                            pathname === '/planReport',
                        })}
                        button
                        onClick={() => {
                          this.props.history.push('/planReport');
                        }}
                      ><div style={{ marginRight : '-20px' }} >
                        <ListItemIcon>
                          <AppsIcon
                            style={{
                              color:
                                pathname === '/planReport' ? '#FFF' : '#000',
                            }}
                          />
                        </ListItemIcon>
                        </div>
                        <ListItemText primary={'Plan Report'} />
                      </ListItem>

                      <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]: pathname !== '/libraryPlanProductAccountId',
                          [classes.listItemSelected]:
                            pathname === '/libraryPlanProductAccountId',
                        })}
                        button
                        onClick={() => {
                          this.props.history.push('/libraryPlanProductAccountId');
                        }}
                      ><div style={{ marginRight : '-20px' }} >
                        <ListItemIcon>
                          <AppsIcon
                            style={{
                              color:
                                pathname === '/libraryPlanProductAccountId' ? '#FFF' : '#000',
                            }}
                          />
                        </ListItemIcon>
                        </div>
                        <ListItemText primary={'Plan Product Account ID Report'} />
                      </ListItem>
                      <ListItem
                      className={clsx(classes.nested, {
                        [classes.listItem]: pathname !== '/epcFederationReport',
                        [classes.listItemSelected]:
                          pathname === '/epcFederationReport',
                      })}
                      button
                      onClick={() => {
                        this.props.history.push('/epcFederationReport');
                      }}
                    > <div style={{ marginRight : '-20px' }} >
                      <ListItemIcon>
                        <AppsIcon
                          style={{
                            color:
                              pathname === '/epcFederationReport' ? '#FFF' : '#000',
                          }}
                        />
                      </ListItemIcon>
                      </div>
                      <ListItemText primary={'Federation Report'} />
                    </ListItem>
                    
                      {/*<ListItem
                      
													button
													className={classes.nested}
													onClick={() => {
														this.props.history.push(
															"/libraryPlanProductAccountId"
														);
													}}>
													<ListItemIcon>
                          <AppsIcon
                          style={{
                            color:
                              pathname === "/libraryPlanProductAccountId"? '#FFF' : '#000',
                          }}
                        />
													</ListItemIcon>
													<ListItemText
														primary={"Plan Product Account ID Report"}
													/>
												</ListItem>
                        <ListItem
													button
													className={classes.nested}
													onClick={() => {
														this.props.history.push("/epcFederationReport");
													}}>
													<ListItemIcon>
                          <AppsIcon
                          style={{
                            color:
                              pathname === '/epcFederationReport' ? '#FFF' : '#000',
                          }}
                        />
													</ListItemIcon>
													<ListItemText primary={"Federation Report"} />
												</ListItem>
                        <ListItem
													button
													className={classes.nested}
													onClick={() => {
														this.props.history.push("/libraryGlossary");
													}}>
													<ListItemIcon>
                          <AppsIcon
                          style={{
                            color:
                              pathname === '/libraryGlossary' ? '#FFF' : '#000',
                          }}
                        />
													</ListItemIcon>
													<ListItemText primary={"Glossary"} />
												</ListItem>
                        */}

                      {/*<ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]: pathname !== '/productReport',
                          [classes.listItemSelected]:
                            pathname === '/productReport',
                        })}
                        button
                        onClick={() => {
                          this.props.history.push('/productReport');
                        }}
                      >
                        <ListItemIcon>
                          <AppsIcon
                            style={{
                              color:
                                pathname === '/productReport' ? '#FFF' : '#000',
                            }}
                          />
                        </ListItemIcon>
                        <ListItemText primary={'Product Report'} />
                          </ListItem>*/}

                      {/* <ListItem button className={classes.nested}
                                            onClick={() => {
                                                this.props.history.push('/epcDailyReleaseReport')
                                            }}>
                                            <ListItemIcon>
                                                <AppsIcon />
                                            </ListItemIcon>
                                            <ListItemText primary={'Daily Release Report'} />
                                        </ListItem> */}
                      {/* <ListItem button className={classes.nested}
                                            onClick={() => {
                                                this.props.history.push('/epcFederationReport')
                                            }}>
                                            <ListItemIcon>
                                                <AppsIcon />
                                            </ListItemIcon>
                                            <ListItemText primary={'Federation Report'} />
                                        </ListItem> */}
                      {/* <ListItem button className={classes.nested}
                                            onClick={() => {
                                                this.props.history.push('/epcOfferabilityReport')
                                            }}>
                                            <ListItemIcon>
                                                <AppsIcon />
                                            </ListItemIcon>
                                            <ListItemText primary={'Offerability Report'} />
                                        </ListItem> */}
                      {/* <ListItem button className={classes.nested}
                                            onClick={() => {
                                                this.props.history.push('/ratePlanReport')
                                            }}>
                                            <ListItemIcon>
                                                <AppsIcon />
                                            </ListItemIcon>
                                            <ListItemText primary={'Rate Plan Report'} />
                                        </ListItem> */}
                    </List>
                  </Collapse>
                  {/* <ListItem
                    className={clsx(classes.nested, {
                      [classes.listItem]: pathname !== '/productPerformance',
                      [classes.listItemSelected]:
                        pathname === '/productPerformance',
                    })}
                    button
                    onClick={() => this.setState({ isOpen: true })}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <DriveFolderUploadIcon
                        style={{
                          color:
                            pathname === '/productPerformance'
                              ? '#FFF'
                              : '#000',
                        }}
                      />
                      {this.state.isOpen && (
                        <UploadModal setIsOpen={this.state.isOpen} />
                      )}
                    </ListItemIcon>
                    <ListItemText
                      primary={<Translate value='dashboard.Bulk Upload' />}
                    />
                  </ListItem> */}
                  <ListItem
                      className={clsx(classes.nested, {
                        [classes.listItem]: pathname !== '/libraryGlossary',
                        [classes.listItemSelected]:
                          pathname === '/libraryGlossary',
                      })}
                      button
                      onClick={() => {
                        this.props.history.push('/libraryGlossary');
                      }}
                    ><div style={{ marginRight : '-20px' }} >
                      <ListItemIcon>
                        <GradientIcon
                          style={{
                            color:
                              pathname === '/libraryGlossary' ? '#FFF' : '#000',
                          }}
                        />
                      </ListItemIcon>
                      </div>
                      <ListItemText primary={'Glossary'} />
                    </ListItem>
                </List>
              )}

            {this.props.userInfo.group &&
              this.props.userInfo.group.includes('Admin') && (
                <List>
                  <ListItem button onClick={() => this.handleClick('plan')}>
                  <div style={{ marginRight : '-20px' }} >
                    <ListItemIcon className={classes.navIcon}>
                      <LibraryBooksIcon style={{ color: '#8175CB' }} />
                    </ListItemIcon>
                    </div>
                    <ListItemText primary='Package' />
                    {this.state.plan ? (
                      <ExpandLess style={{ fontSize: '18px' }} />
                    ) : (
                      <ExpandMore style={{ fontSize: '18px' }} />
                    )}
                  </ListItem>
                  <Collapse in={this.state.plan} timeout='auto' unmountOnExit>
                    <List component='div' disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push('/adminPlanConfiguration')
                        }
                      ><div style={{ marginRight : '-20px' }} >
                        <ListItemIcon>
                          {' '}
                          <AppsIcon />{' '}
                        </ListItemIcon>
                        </div>
                        <ListItemText primary='Modify Fields' />
                      </ListItem>
                    </List>
                  </Collapse>

                  <ListItem button onClick={() => this.handleClick('product')}>
                  <div style={{ marginRight : '-20px' }} >
                    <ListItemIcon className={classes.navIcon}>
                      <StoreIcon style={{ color: '#00ACC2' }} />
                    </ListItemIcon>
                    </div>
                    <ListItemText primary='Product' />
                    {this.state.product ? (
                      <ExpandLess style={{ fontSize: '18px' }} />
                    ) : (
                      <ExpandMore style={{ fontSize: '18px' }} />
                    )}
                  </ListItem>
                  <Collapse
                    in={this.state.product}
                    timeout='auto'
                    unmountOnExit
                  >
                    <List component='div' disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push('/adminProductConfiguration')
                        }
                      >
                        <ListItemIcon>
                          {' '}
                          <AppsIcon />{' '}
                        </ListItemIcon>
                        <ListItemText primary='Modify Fields' />
                      </ListItem>
                      <ListItem
                        button
                        onClick={() => {
                          this.props.history.push('/adminCtsConfiguration');
                        }}
                      >
                        <ListItemIcon>
                          <AppsIcon />
                        </ListItemIcon>
                        <ListItemText primary='Modify CTS' />
                      </ListItem>
                    </List>
                  </Collapse>

                  <ListItem
                    button
                    onClick={() => this.handleClick('offerability')}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <LocalOfferIcon style={{ color: '#EB646F' }} />
                    </ListItemIcon>
                    <ListItemText primary='Offerability' />
                    {this.state.offerability ? (
                      <ExpandLess style={{ fontSize: '18px' }} />
                    ) : (
                      <ExpandMore style={{ fontSize: '18px' }} />
                    )}
                  </ListItem>
                  <Collapse
                    in={this.state.offerability}
                    timeout='auto'
                    unmountOnExit
                  >
                    <List component='div' disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push(
                            '/adminOfferabilityConfiguration'
                          )
                        }
                      >
                        <ListItemIcon>
                          {' '}
                          <AppsIcon />{' '}
                        </ListItemIcon>
                        <ListItemText primary='Modify Offerability' />
                      </ListItem>
                    </List>
                  </Collapse>
                  <ListItem button onClick={() => this.handleClick('contract')}>
                    <ListItemIcon className={classes.navIcon}>
                      <MenuBookIcon style={{ color: '#008E7B' }} />
                    </ListItemIcon>
                    <ListItemText primary='Contract' />
                    {this.state.contract ? (
                      <ExpandLess style={{ fontSize: '18px' }} />
                    ) : (
                      <ExpandMore style={{ fontSize: '18px' }} />
                    )}
                  </ListItem>
                  <Collapse
                    in={this.state.contract}
                    timeout='auto'
                    unmountOnExit
                  >
                    <List component='div' disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push(
                            '/adminBundleContractConfiguration'
                          )
                        }
                      >
                        <ListItemIcon>
                          {' '}
                          <AppsIcon />{' '}
                        </ListItemIcon>
                        <ListItemText primary='Bundle Contract' />
                      </ListItem>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push(
                            '/adminContractCreationConfiguration'
                          )
                        }
                      >
                        <ListItemIcon>
                          {' '}
                          <AppsIcon />{' '}
                        </ListItemIcon>
                        <ListItemText primary='Contract Creation' />
                      </ListItem>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push(
                            '/adminContractProfileConfiguration'
                          )
                        }
                      >
                        <ListItemIcon>
                          {' '}
                          <AppsIcon />{' '}
                        </ListItemIcon>
                        <ListItemText primary='Contract Profile' />
                      </ListItem>
                    </List>
                  </Collapse>
                  {/* <ListItem button onClick={() => this.handleClick('contractProfile')}>
                                        <ListItemIcon className={classes.navIcon}>
                                            <LocalLibraryIcon style={{ color: "#D77CD8" }} />
                                        </ListItemIcon>
                                        <ListItemText primary="Contract Profile" />
                                        {this.state.contractProfile ? <ExpandLess style={{ fontSize: '18px' }} /> :
                                            <ExpandMore style={{ fontSize: "18px" }} />}
                                    </ListItem>
                                    <Collapse in={this.state.contractProfile} timeout="auto" unmountOnExit>
                                        <List component="div" disablePadding>
                                            <ListItem button className={classes.nested}
                                                onClick={() => this.props.history.push("/adminContractProfileConfiguration")} >
                                                <ListItemIcon> <AppsIcon />  </ListItemIcon>
                                                <ListItemText primary="Modify Fields" />
                                            </ListItem>
                                        </List>
                                    </Collapse> */}
                  <ListItem
                    button
                    onClick={() => this.handleClick('attribute')}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <BrightnessAutoIcon style={{ color: '#F60076' }} />
                    </ListItemIcon>
                    <ListItemText primary='Attribute' />
                    {this.state.attribute ? (
                      <ExpandLess style={{ fontSize: '18px' }} />
                    ) : (
                      <ExpandMore style={{ fontSize: '18px' }} />
                    )}
                  </ListItem>
                  <Collapse
                    in={this.state.attribute}
                    timeout='auto'
                    unmountOnExit
                  >
                    <List component='div' disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push('/adminAttrConfiguration')
                        }
                      >
                        <ListItemIcon>
                          {' '}
                          <AppsIcon />{' '}
                        </ListItemIcon>
                        <ListItemText primary='Attribute' />
                      </ListItem>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push('/adminAttrGrpConfiguration')
                        }
                      >
                        <ListItemIcon>
                          {' '}
                          <AppsIcon />{' '}
                        </ListItemIcon>
                        <ListItemText primary='Attribute Group' />
                      </ListItem>
                    </List>
                  </Collapse>
                  <ListItem button onClick={() => this.handleClick('ratePlan')}>
                    <ListItemIcon className={classes.navIcon}>
                      <MoneyIcon style={{ color: '#FFB800' }} />
                    </ListItemIcon>
                    <ListItemText primary='Rate Plan' />
                    {this.state.ratePlan ? (
                      <ExpandLess style={{ fontSize: '18px' }} />
                    ) : (
                      <ExpandMore style={{ fontSize: '18px' }} />
                    )}
                  </ListItem>
                  <Collapse
                    in={this.state.ratePlan}
                    timeout='auto'
                    unmountOnExit
                  >
                    <List component='div' disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push('/adminRatePlanConfiguration')
                        }
                      >
                        <ListItemIcon>
                          {' '}
                          <AppsIcon />{' '}
                        </ListItemIcon>
                        <ListItemText primary='Modify Fields' />
                      </ListItem>
                    </List>
                  </Collapse>
                  <ListItem button onClick={() => this.handleClick('rental')}>
                    <ListItemIcon className={classes.navIcon}>
                      <LocalAtmIcon style={{ color: '#8D6D62' }} />
                    </ListItemIcon>
                    <ListItemText primary='Pricing' />
                    {this.state.rental ? (
                      <ExpandLess style={{ fontSize: '18px' }} />
                    ) : (
                      <ExpandMore style={{ fontSize: '18px' }} />
                    )}
                  </ListItem>
                  <Collapse in={this.state.rental} timeout='auto' unmountOnExit>
                    <List component='div' disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push('/adminRentalConfiguration')
                        }
                      >
                        <ListItemIcon>
                          {' '}
                          <AppsIcon />{' '}
                        </ListItemIcon>
                        <ListItemText primary='Rental' />
                      </ListItem>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push('/adminDiscountConfiguration')
                        }
                      >
                        <ListItemIcon>
                          {' '}
                          <AppsIcon />{' '}
                        </ListItemIcon>
                        <ListItemText primary='Discount' />
                      </ListItem>
                    </List>
                  </Collapse>
                  <ListItem button onClick={() => this.handleClick('user')}>
                    <ListItemIcon className={classes.navIcon}>
                      <AccountCircleIcon style={{ color: '#FF6239' }} />
                    </ListItemIcon>
                    <ListItemText primary='User' />
                    {this.state.user ? (
                      <ExpandLess style={{ fontSize: '18px' }} />
                    ) : (
                      <ExpandMore style={{ fontSize: '18px' }} />
                    )}
                  </ListItem>
                  <Collapse in={this.state.user} timeout='auto' unmountOnExit>
                    <List component='div' disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push('/adminuserConfiguration')
                        }
                      >
                        <ListItemIcon>
                          {' '}
                          <AppsIcon />{' '}
                        </ListItemIcon>
                        <ListItemText primary='User Creation' />
                      </ListItem>
                    </List>
                  </Collapse>
                  <ListItem button onClick={() => this.handleClick('workflow')}>
                    <ListItemIcon className={classes.navIcon}>
                      <WorkIcon style={{ color: '#1dad03' }} />
                    </ListItemIcon>
                    <ListItemText primary='Workflow' />
                    {this.state.workflow ? (
                      <ExpandLess style={{ fontSize: '18px' }} />
                    ) : (
                      <ExpandMore style={{ fontSize: '18px' }} />
                    )}
                  </ListItem>
                  <Collapse
                    in={this.state.workflow}
                    timeout='auto'
                    unmountOnExit
                  >
                    <List component='div' disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push('/adminWorklist')
                        }
                      >
                        <ListItemIcon>
                          {' '}
                          <AppsIcon />{' '}
                        </ListItemIcon>
                        <ListItemText primary='Worklist' />
                      </ListItem>
                    </List>
                  </Collapse>
                  {/* <ListItem button onClick={() => this.handleClick('discount')}>
                                        <ListItemIcon className={classes.navIcon}>
                                            <AddShoppingCartIcon style={{ color: "#FF6239" }} />
                                        </ListItemIcon>
                                        <ListItemText primary="Discount" />
                                        {this.state.discount ? <ExpandLess style={{ fontSize: '18px' }} /> :
                                            <ExpandMore style={{ fontSize: "18px" }} />}
                                    </ListItem>
                                    <Collapse in={this.state.discount} timeout="auto" unmountOnExit>
                                        <List component="div" disablePadding>
                                            <ListItem button className={classes.nested}
                                                onClick={() => this.props.history.push("/adminDiscountConfiguration")} >
                                                <ListItemIcon> <AppsIcon />  </ListItemIcon>
                                                <ListItemText primary="Modify Fields" />
                                            </ListItem>
                                        </List>
                                    </Collapse> */}
                </List>
              )}

            {this.props.userInfo.group &&
              !this.props.userInfo.group.includes('Admin') &&
              !this.props.userInfo.group.includes('TelemediaProductManager') && 
              !this.props.userInfo.group.includes('SuperUser') &&(
                <List>
                  <ListItem
                    button
                    onClick={() => this.props.history.push('/allReleases')}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <AllInboxIcon style={{ color: 'blue' }} />
                    </ListItemIcon>
                    <ListItemText primary='All Releases' />
                  </ListItem>

                  <ListItem
                    button
                    onClick={() => this.props.history.push('/worklist')}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <WorkIcon style={{ color: '#a87f32' }} />
                    </ListItemIcon>
                    <ListItemText
                      primary={<Translate value='My Work Queue' />}
                    />
                  </ListItem>
                </List>
              )}
              
              
          </Drawer>
                  )}
          
          <main
            className={
              pathname !== '/editRelease' &&
              pathname !== '/federate' &&
              pathname !== '/validateTransformRelease' &&
              pathname !== '/selectApprover'
                ? classes.content
                : classes.content2
            }
            style={{width: '1rem'}}
          >
            <div className={classes.toolbar} />
            {/* <Toolbar /> */}

            {this.props.children}
          </main>
        </div>
      </ThemeProvider>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    approversData: state.approverData.approversData,
    userInfo: state.login.loggedInUserInfo,
    pkgKey: state.packageData.pkgKey,
    productKey: state.productData.productKey,
    searchItems: state.searchData.searchItems,
    searchValue: state.searchData.searchValue,
    entity: state.searchData.entity,
    packageData: state.packageData.packageData,
    productData: state.productData.productData,
    openDrawer: state.drawerData.open,
    releaseData: state.releaseData.releaseData,
    roleGroup: state.roleSelected.roleGroup
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    setDrawer: (open) =>
      dispatch({ type: actionTypes.DRAWER_TOGGLE, open: open }),
    onLogout: () => dispatch({ type: actionTypes.LOG_OUT }),
    onPackageEnter: (packageData) =>
      dispatch({ type: actionTypes.INSIDE_PACKAGE, packageData: packageData }),
    changePackageKey: (pkgKey) =>
      dispatch({ type: actionTypes.CHANGE_PACKAGE_KEY, pkgKey: pkgKey }),
    changePackageActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
        activeStep: activeStep,
      }),
    changeProductKey: (productKey) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_KEY,
        productKey: productKey,
      }),
    onProductEnter: (productData) =>
      dispatch({ type: actionTypes.INSIDE_PRODUCT, productData: productData }),
    changeProductActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP,
        activeStep: activeStep,
      }),
    setSearchValue: (searchValue) =>
      dispatch({
        type: actionTypes.SET_SEARCH_VALUE,
        searchValue: searchValue,
      }),
    changeLocale: (locale) => dispatch(setLocale(locale)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(withRouter(Layout)));


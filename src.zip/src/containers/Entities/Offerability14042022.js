import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import Snackbar from '@material-ui/core/Snackbar';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import AppsIcon from '@material-ui/icons/Apps';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import MultiSelect from '../../UI/Input/MultiSelect';
import Input from '../../UI/Input/Input';
import Tooltip from '@material-ui/core/Tooltip';
// import Button from "@material-ui/core/Button";
import Button from '../../UI/Button/Button';
import Modal from '../../UI/Modal/Modal';
import Typography from '@material-ui/core/Typography';
import moment from 'moment';
import Divider from '@material-ui/core/Divider';
import { connect } from 'react-redux';
import * as actionTypes from '../../store/actions/actionTypes';
import StyledButton from '../../UI/Button/Button';
import SearchIcon from '@mui/icons-material/Search';
import MuiAlert from '@material-ui/lab/Alert';



function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
}
const useStyles = (theme) => ({
	cardHeader: {
		// background: "#546D7A",
		// height: "4.5vh",
		paddingBottom: 0,
	},
	subheader: {
		color: 'rgba(0, 0, 0, 0.87)',
		fontSize: '16px',
		fontWeight: '600',
		// color: "white",
		// fontWeight: 'bold'
	},
	heading: {
		fontSize: theme.typography.pxToRem(15),
		flexBasis: '96%',
		flexShrink: 0,
	},
});

class Offerability extends Component {
	_isMounted = false;
	state = {
		loading: true,
		version: '',
		offerKeys: [],
		schema: [],
		rsuLovs: {},
		refUiMap: {},
		selectedIndex: 0,
		selOfferability: '',
		show: false,
		modalContent: null,
		packageOfferData: {},
		offerablitiyLovs: {},
		errors: [],
		isValidated: false,
	};
	componentWillUnmount() {
		this._isMounted = false;
	}
	handleClose = (event, reason) => {
		if (reason === 'clickaway') {
						return;
					}
		this.setState({ openSnack: false })
	};
	versions() {
		return axios
			.get('package/config/version?entityName=offerability', {
				headers: {
					opId: this.props.userInfo.opId,
					buId: this.props.userInfo.buId,
				},
			})
			.then((res) => {
				console.log('version is' + res.data.data.version);
				this.setState({ version: res.data.data.version });
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	}

	uiFields() {
		if (
			localStorage.getItem('offerability') &&
			localStorage.getItem('originalOfferability') &&
			localStorage.getItem('offerabilityKeys') &&
			localStorage.offerability_version &&
			localStorage.offerability_version == this.state.version
		) {
			console.log('fetching from local storage');
			try {
				this.setState({
					originalSchema: JSON.parse(
						localStorage.getItem('originalOfferability')
					),
					schema: JSON.parse(localStorage.getItem('offerability')),
					offerKeys: JSON.parse(localStorage.getItem('offerabilityKeys')),
					refUiMap: JSON.parse(localStorage.getItem('offerabilityUiRefMap')),
				});
			} catch (e) {
				localStorage.removeItem('offerability');
				localStorage.removeItem('offerabilityKeys');
				localStorage.removeItem('offerabilityUiRefMap');
			}
			return Promise.resolve();
		} else {
			console.log('fetching from api');
			return axios
				.get('package/config?entityName=offerability', {
					headers: {
						opId: this.props.userInfo.opId,
						buId: this.props.userInfo.buId,
					},
				})
				.then(async (res) => {
					let schema = [];
					schema = res.data.data.map(function (el) {
						if (el.refType === 'SelectInput' || el.refType === 'MultiSelect') {
							if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
							else if (el.refLovs == null) el.refLovs = [];
						}
						return el;
					});
					const circleRsuLovs = await this.getCircleRsuLovs();
					console.log(circleRsuLovs);
					this.setState({
						rsuLovs: circleRsuLovs.data.data,
					});

					let offerKeys = [];
					let refUiMap = {};
					console.log(res.data.data);
					res.data.data.forEach((el) => {
						let offerabilityType = {};
						offerabilityType.value = el.refLovs ? el.refLovs : '';
						offerabilityType.type = el.refType;
						offerKeys.push(el.refName);
						refUiMap[el.refName] = el.uiName;
					});
					const originalSchema = schema.map((sch) => {
						return {
							...sch,
							refLovs:
								sch.uiName === 'RSU' ? circleRsuLovs.data.data : sch.refLovs,
						};
					});

					this.setState({
						originalSchema,
						schema: schema.map((sch) => {
							return {
								...sch,
								refLovs: sch.uiName === 'RSU' ? [] : sch.refLovs,
							};
						}),
						offerKeys: offerKeys,
						refUiMap: refUiMap,
					});
					localStorage.setItem('offerability', JSON.stringify(schema));
					localStorage.setItem(
						'originalOfferability',
						JSON.stringify(originalSchema)
					);
					localStorage.setItem('offerabilityKeys', JSON.stringify(offerKeys));
					localStorage.setItem(
						'offerabilityUiRefMap',
						JSON.stringify(refUiMap)
					);
					localStorage.offerability_version = this.state.version;
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		}
	}
	getCircleRsuLovs() {
		return axios.get('/package/offerability/rsu', {
			headers: {
				opId: this.props.userInfo.opId,
				buId: this.props.userInfo.buId,
			},
		});
	}
	offerabilityLovData() {
		if (this.props.entity === 'PACKAGE' && this.props.id) {
			console.log('required');

			return axios
				.get('ratePlan/dependentLovs?param=package.offerability', {
					headers: {
						opId: this.props.userInfo.opId,
					},
				})
				.then((res) => {
					console.log(res);
					this.setState({
						offerablitiyLovs: res.data.data,
					});
				})
				.catch((error) => {
					console.log(error);
					this.setState({ loading: false });
				});
		} else {
			console.log('not required');
			return Promise.resolve();
		}
	}
	componentDidMount = () => {
		this._isMounted = true;
		this.setState({ loading: true });
		this.versions().then(() => {
			this.uiFields().then(() => {
				this.offerabilityLovData().then(() => {
					console.log(this.state.schema);
					if (this.props.entity === 'PACKAGE' && this.props.id) {
						let offerabilities =
							this.state.offerablitiyLovs[this.props.planData.catalogId];
						if (offerabilities && offerabilities.length > 0) {
							let schema = [];
							this.state.schema.map((formElement) => {
								if (offerabilities.includes(formElement.uiName))
									schema.push(formElement);
							});
							this.setState({
								schema,
							});
						}
					}
					this.state.schema.map((formElement) => {
						if (formElement.refType == 'Date')
							this.setState({
								[formElement.uiName]: formElement.defaultValue
									? moment(formElement.defaultValue).format('DD-MMM-YY')
									: moment().format('DD-MMM-YY'),
							});
						else if (
							formElement.refType == 'TextInput' ||
							'TextArea' ||
							'SelectInput'
						) {
							console.log(formElement.uiName);
							console.log([formElement.defaultValue]);

							this.setState({
								[formElement.uiName]: [formElement.defaultValue],
							});
						}
					});
					this.packageOfferabilityData().then(() => {
						if (this._isMounted) {
							this.state.schema.map((obj) => {
								if (obj.refType == 'MultiSelect')
									this.setState({ [obj.uiName]: [] });
								// else
								//     this.setState({ [obj.uiName]: null })
							});
							if (Object.keys(this.state.packageOfferData).length > 0) {
								Object.keys(this.state.refUiMap).forEach((key) => {
									if (this.state.packageOfferData[key]) {
										let offer = this.state.refUiMap[key];
										console.log(offer);
										if (
											this.state.packageOfferData[key].length > 0 &&
											this.state.packageOfferData[key][0]
										)
											this.setState((prevState) => {
												return {
													[offer]: [...prevState.packageOfferData[key]],
												};
											});
									}
								});
							}
							const schema = this.state.schema;
							let options = [];

							if (this.state.Circle.length > 0) {
								this.state.Circle.forEach((item) => {
									options = [
										...options,
										...(this.state.originalSchema[
											this.state.originalSchema.findIndex(
												(item) => item.uiName === 'RSU'
											)
										].refLovs[item] ?? []),
									];
								});
								schema[
									schema.findIndex((item) => item.uiName === 'RSU')
								].refLovs = options;
							}
							this.setState({
								loading: false,
								selOfferability: this.state.schema[0].uiName,
								schema,
							});
						}
					});
				});
			});
		});
	};
	handleListItemClick = (event, index, key) => {
		this.setState({ selectedIndex: index, selOfferability: key.uiName });
	};

	cartesianProduct(arr) {
		return arr.reduce(
			function (a, b) {
				return a
					.map(function (x) {
						return b.map(function (y) {
							return x.concat([y]);
						});
					})
					.reduce(function (a, b) {
						return a.concat(b);
					}, []);
			},
			[[]]
		);
	}
	packageOfferabilityData() {
		if (this.props.releaseData.releaseId) {
			if (this.props.id) {
				return axios
					.get(
						'/package/offerability?id=' +
							this.props.id +
							'&releaseId=' +
							this.props.releaseData.releaseId,
						{
							headers: {
								createdBy: this.props.userInfo.id,
								opId: this.props.userInfo.opId,
							},
						}
					)
					.then((res) => {
						console.log(res.data.data);
						let packageOfferDataJSON = {};
						Object.keys(res.data.data).forEach((item) => {
							packageOfferDataJSON[item] = res.data.data[item].includes('ANY')
								? item === 'activityTypeId'
									? ['Both']
									: ['ALL']
								: res.data.data[item];
						});

						this.setState({
							packageOfferData: {
								// ...res.data.data,
								// activityTypeId: res.data.data.activityTypeId.includes("ANY")
								// 	? ["Both"]
								// 	: res.data.data.activityTypeId,
								...packageOfferDataJSON,
								// customerTypeId:
								// 	localStorage.getItem('isB2c') === 'true' ? ['B2C'] : ['B2B'],
								// customerTypeId: [localStorage.getItem('isB2c').toUpperCase()],
								customerTypeId: [
									...(packageOfferDataJSON['customerTypeId'].includes(null) ||
									packageOfferDataJSON['serviceCategoryId'].length === 0
										? this.props.roleGroup.toUpperCase() === 'B2C' ||
										  this.props.roleGroup.toUpperCase() === 'B2CMANUAL'
											? ['B2C']
											: ['B2B']
										: packageOfferDataJSON['customerTypeId']),
								],
								serviceCategoryId: [
									...(packageOfferDataJSON['serviceCategoryId'].includes(
										null
									) || packageOfferDataJSON['serviceCategoryId'].length === 0
										? this.props.planData
											? [this.props.planData.catalogId]
											: this.props.productData
											? [this.props.productData.catalogId]
											: []
										: packageOfferDataJSON['serviceCategoryId']),
								],
							},
						});
					})
					.catch((error) => {
						console.log(error);
						if (this._isMounted) this.setState({ loading: false });
					});
			} else {
				return Promise.resolve();
			}
		} else {
			return Promise.resolve();
		}
	}

	savePkgOfferDetailsHandler = (event) => {
		event.preventDefault();
		if (this.props.id) {
			let offerabilitiesValues = [];
			this.state.schema.forEach((key) => {
				offerabilitiesValues.push(this.state[key.uiName]);
			});
			console.log(offerabilitiesValues);

			offerabilitiesValues.forEach((part, index, theArray) => {
				if (theArray[index] instanceof Array && theArray[index].length === 0) {
					theArray[index] = [
						...(this.state.schema[index].refName === 'activityTypeId'
							? ['Both']
							: this.state.schema[index].refName === 'offerField1' ||
							  this.state.schema[index].refName === 'offerField2'
							? []
							: ['ALL']),
					];
					if (this.state.schema[index].refName === 'activityTypeId') {
						this.setState({
							[this.state.schema[index].uiName]: ['Both'],
						});
					} else if (
						this.state.schema[index].refName === 'offerField1' ||
						this.state.schema[index].refName === 'offerField2'
					) {
			
						this.setState({
							[this.state.schema[index].uiName]: [],
						});
					} else {
			
						this.setState({
							[this.state.schema[index].uiName]: ['ALL'],
						});
					}
				} else if (typeof theArray[index] === 'string') {
					theArray[index] =
						theArray[index] === 'Both' ? ['ALL'] : [theArray[index]];
				} else if (theArray[index] === null) {
					theArray[index] = [
						...(this.state.schema[index].refName === 'activityTypeId'
							? theArray[index][0] === 'Both'
								? ['Both']
								: theArray[index]
							: this.state.schema[index].refName === 'offerField1' ||
							  this.state.schema[index].refName === 'offerField2'
							? []
							: ['ALL']),
					];
				}
			});
			

			let crossMatrix = this.cartesianProduct(offerabilitiesValues);
			let offerJson = [];
			crossMatrix.filter((row, index) => {
				let val = index + 1;
				let oneOfferRule = {};
				let date = moment().format('DD-MMM-YY');
				oneOfferRule.opid = this.props.userInfo.opId;
				oneOfferRule.buid = this.props.userInfo.buId;
				oneOfferRule.createdBy = this.props.userInfo.id;
				oneOfferRule.createdDate = date;
				oneOfferRule.startDate = date;
				oneOfferRule.endDate = '31-Dec-31';
				oneOfferRule.version = '1.0';
				oneOfferRule.offerabilityRuleId = 'OFPK' + val;
				oneOfferRule.offerabilityRule = 'OFPK' + val;
				oneOfferRule.packageProductId = this.props.id;
				oneOfferRule.packageId = this.props.id;
				oneOfferRule.packageProductIdentifier = this.props.entity;

				row.forEach((val, index) => {
					let key = this.state.offerKeys[index];

					oneOfferRule[key] =
						key === 'activityTypeId' && val === 'Both' ? 'Both' : val;
				});
				offerJson.push(oneOfferRule);
			});
			console.log(offerJson);
			let payload = {};
			let listOfPPmOfferabilityAud = [];
			listOfPPmOfferabilityAud = offerJson;
			payload.id = this.props.id;
			payload.releaseId = this.props.releaseData.releaseId;

			// listOfPPmOfferabilityAud[0].activityTypeId =
			// 	listOfPPmOfferabilityAud[0].activityTypeId === "Both"
			// 		? "ANY"
			// 		: listOfPPmOfferabilityAud[0].activityTypeId;
			listOfPPmOfferabilityAud.map((offerabilityAud) => {
				return Object.keys(offerabilityAud).map((item) => {
					return (offerabilityAud[item] =
						offerabilityAud[item] === 'Both' || offerabilityAud[item] === 'ALL'
							? 'ANY'
							: offerabilityAud[item]);
				});
			});

			payload.listOfPPmOfferabilityAud = listOfPPmOfferabilityAud;

			console.log(payload);
			let errors = [];
			if (this.state['Offerable Speed']) {
				if (
					this.state['Offerable Speed'][0] === 'ALL' ||
					!this.state['Offerable Speed'][0]
				) {
					errors.push('Offerable Speed is required.');
				}
			}
			if (this.state['Technology']) {
				if (
					this.state['Technology'][0] === 'ALL' ||
					!this.state['Technology'][0]
				) {
					errors.push('Technology is required.');
				}
			}
			if (this.state['Order Type']) {
				if (
					this.state['Order Type'].includes('PreToPost') &&
					this.state['Order Type'].includes('PostToPre')
				) {
					errors.push(
						"Order Type - PreToPost and PostToPre can't be both selected."
					);
				} else if (
					this.state['Order Type'].includes('PostToPre') &&
					(this.props.planData.packageCategoryId === 'Infinity' ||
						this.props.planData.packageCategoryId === 'Airtel Office Internet')
				) {
					errors.push(
						`Order Type can't be PostToPre when brand is ${this.props.planData.packageCategoryId}.`
					);
				} else if (
					this.state['Order Type'].includes('PreToPost') &&
					!(
						this.props.planData.packageCategoryId === 'Infinity' ||
						this.props.planData.packageCategoryId === 'Airtel Office Internet'
					)
				) {
					errors.push(
						`Order Type can't be PreToPost when brand is ${this.props.planData.packageCategoryId}.`
					);
				}
			}
			// if (this.state["Technology"][0] === "ALL") {
			// 	errors.push("Technology");
			// }

			this.setState({ errors });
			if (errors.length === 0) {
				this.setState({ loading: true });
				axios
					.post('/package/offerability', payload)
					.then((response) => {
						console.log(response.data.data);

						let payloadRelData = {};
						payloadRelData.releaseId = this.props.releaseData.releaseId;
						payloadRelData.id = this.props.id;
						payloadRelData.listOfOfferabilities = response.data.data;
						axios
							.post('/package/offerability/releaseEntity', payloadRelData)
							.then((response) => {
								console.log(response);
								this.setState({ loading: false });
							});
					})
					.catch((error) => {
						console.log(error);
						if (this._isMounted) this.setState({ loading: false });
					});
			} else {
				errors.map((err) => {
					this.setState({
						[err]: [],
					});
				});
				let modalContent = (
					<List
						style={{ maxHeight: 200, overflow: 'auto' }}
						component="nav"
						aria-labelledby="nested-list-subheader">
						{errors.map((error) => {
							return (
								<ListItem button key={error}>
									<ListItemIcon>
										<AppsIcon style={{ color: '#ff1921' }} />
									</ListItemIcon>
									<ListItemText primary={'Offerability: ' + error} />
								</ListItem>
							);
						})}
					</List>
				);
				this.setState({ modalContent: modalContent, show: true });
			}
		} else {
			let modalContent = (
				<Typography variant="h6">
					{' '}
					Submit Basic {this.props.entity} Details first.{' '}
				</Typography>
			);
			this.setState({ modalContent: modalContent, show: true });
		}
	};

	errorConfirmedHandler = () => {
		this.setState({
			show: false,
			errors: [],
		});
	};

	deleteOfferabilityHandler = () => {
		this.setState({
			loading: true,
		});
		axios
			.get(
				'package/offerability/delete?id=' +
					this.props.id +
					'&releaseID=' +
					this.props.releaseData.releaseId
			)
			.then((res) => {
				console.log(res.data.data);
				if (this._isMounted) {
					this.state.schema.map((obj) => {
						if (obj.refType == 'MultiSelect')
							this.setState({ [obj.uiName]: [] });
						else this.setState({ [obj.uiName]: null });
					});
					this.setState({
						loading: false,
					});
				}
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	};


	inputHelper = (formElement) => {
		let schema = this.state.schema;
		let options = [];
		console.log(formElement);
		formElement = formElement[0];
		if (formElement) {
			if (formElement.refType === 'MultiSelect')
				return (
					<MultiSelect
						refLovs={formElement.refLovs}
						value={this.state[formElement.uiName]}
						{...formElement}
						changed={(selected) => {
							console.log(selected);

							if (!(selected instanceof Array)) selected = [selected];

							if (
								selected.length > 1 &&
								selected.includes('ANY') &&
								(formElement.uiName === 'Technology' ||
									formElement.uiName === 'Offerable Speed' ||
									formElement.uiName === 'Type')
							) {
								selected.splice(selected.indexOf('ANY'), 1);
							}
							if (formElement.uiName === 'Circle') {
								selected.map((sel) => {
									return (options = [
										...options,
										...(this.state.originalSchema[
											this.state.originalSchema.findIndex(
												(item) => item.uiName === 'RSU'
											)
										].refLovs[sel] ?? []),
									]);
								});

								schema[
									schema.findIndex((item) => item.uiName === 'RSU')
								].refLovs = options;
								this.setState((prev) => {
									return {
										schema,
										RSU: [],
									};
								});
							}

							this.setState({
								[formElement.uiName]: selected,
							});
						}}
						disabled={formElement.isDisabled === 'Y'}
					/>
				);
			else
				return (
					<Input
						table
						key={formElement.refName}
						{...formElement}
						value={this.state[formElement.uiName]}
						disabled={formElement.isDisabled == 'Y' ? true : false}
						required={formElement.isMandatory == 'Y' ? true : false}
						changed={(event) => {
							if (!event.target) {
								this.setState({
									[formElement.uiName]: event,
								});
							} else {
								if (event.target.type !== 'checkbox')
									this.setState({
										[formElement.uiName]: event.target.value,
									});
								else {
									console.log(event.target.checked);
									this.setState({
										[formElement.uiName]: event.target.checked,
									});
								}
							}
						}}
					/>
				);
		}
	};
	debugger;
	validateHandler = () => {
		try{
		return axios
			.get(
				`attribute/validation?packageId=${this.props.id}&releaseID=${this.props.releaseData.releaseId}`,
				{
					headers: {
						opId: this.props.userInfo.opId,
						buId: this.props.userInfo.buId,
					},
				}
			)
			.then((res) => {
				if(res.data.statusMsg==="SUCCESS"){
				this.setState({
					
					isValidated: true,
					openSnack:true,
					message:"Success",
				});}
				else{
					this.setState({
					openSnack:true,
					message:"Failure",
					})
				}
			});
		}catch(err) {
			console.error(err);
		  }
	};


	searchAccountId = (uiName) => {
		this.setState({
			loading: true,
			[uiName]: [],
		});
		return axios
			.get(
				`package/offerability/accountId?accId=${this.state.accountId}&accName=${this.state.accountName}`,
				{
					headers: {
						opId: this.props.userInfo.opId,
						buId: this.props.userInfo.buId,
					},
				}
			)
			.then((res) => {
				console.log(res);
				const listofAccounts = res.data.data.accountCategoryId;
				this.setState({
					listofAccounts,
					loading: false,
				});
			});
	};

	render() {
		const { classes } = this.props;
		let offerability = <Loader relative />;
		let selectedOfferability = null;

		if (!this.state.loading) {
			selectedOfferability = this.inputHelper(
				this.state.schema.filter((obj) => {
					if (obj.uiName == this.state.selOfferability) {
						return obj;
					}
				})
			);
			const vertical = 'top';
            const horizontal = 'center';
			offerability = (
				
				<React.Fragment>
				
				<Snackbar anchorOrigin={{ vertical, horizontal }}
                        open={this.state.openSnack} autoHideDuration={3000} onClose={this.handleClose}>
                        <Alert onClose={this.handleClose} severity="success">
                            {this.state.message}
                        </Alert>
                    </Snackbar>
					<Modal
						show={this.state.show}
						modalClosed={this.errorConfirmedHandler}
						title={'Something Went Wrong!'}>
						{this.state.modalContent}
					</Modal>
					<form
						onSubmit={this.savePkgOfferDetailsHandler}
						style={{ overflow: 'visible' }}>
						<Grid container spacing={3}>
							<Grid item xs={12} sm={6}>
								<Card style={{ height: '100%' }}>
									<CardHeader
										className={classes.cardHeader}
										classes={{
											subheader: classes.subheader,
										}}
										subheader={'Offerability List'}
									/>

									<CardContent style={{ maxHeight: '40vh', overflow: 'auto' }}>
										<div className={classes.root}>
											<List component="nav">
												{this.state.schema.map((key, index) => {
													return (
														<ListItem
															key={key.refName}
															button
															selected={this.state.selectedIndex === index}
															onClick={(event) =>
																this.handleListItemClick(event, index, key)
															}>
															{' '}
															<ListItemIcon>
																<AppsIcon />
															</ListItemIcon>
															<ListItemText primary={key.uiName} />
														</ListItem>
													);
												})}
											</List>
										</div>
									</CardContent>
								</Card>
							</Grid>

							<Grid item xs={12} sm={6}>
								<Card style={{ height: '100%', overflow: 'visible' }}>
									<CardHeader
										className={classes.cardHeader}
										classes={{
											subheader: classes.subheader,
										}}
										subheader={this.state.selOfferability}
									/>

									<CardContent
										style={{ maxHeight: '40vh', overflow: 'visible' }}>
										{selectedOfferability}
									</CardContent>
								</Card>
							</Grid>
							<Grid item xs={12}>
								<Card>
									<CardHeader
										className={classes.cardHeader}
										classes={{
											subheader: classes.subheader,
										}}
										subheader={'Selected Offerability'}
									/>

									<CardContent>
										{
											<List
												component="nav"
												aria-labelledby="nested-list-subheader"
												style={{
													width: '100%',
													maxHeight: '20vh',
													overflow: 'auto',
													display: 'flex',
													flexFlow: 'wrap',
												}}>
												{this.state.schema.map((key) => {
													return (
														<React.Fragment key={key.refName}>
															{
																
                                <Tooltip
                                arrow
                                placement="bottom-start"
                                style={{
                                  '& div': {
                                    margin: '0rem!important',
                                  },
                                }}
                                interactive
                                title={this.state[key.uiName].join(', ')}>
																<ListItem 
																style={{
																	display: 'inline-flex',
																	width: '20%',
																}}>
																	<ListItemText
																		primary={key.uiName}
																		secondary={
																			key.refType == 'MultiSelect' ||
																			key.refName === 'accountId'
																				? this.state[key.uiName].join()
																				: this.state[key.uiName]
																		}
																	/>
																</ListItem>
                                </Tooltip>
															}
															<Divider />
														</React.Fragment>
													);
												})}
											</List>
										}
									</CardContent>
								</Card>
							</Grid>

							{this.props.releaseData.releaseId && (
								<div
									style={{
										display: 'flex',
										justifyContent: 'flex-end',
										alignItems: 'center',
										width: '100%',
										marginTop: '1%',
									}}>
									{/* <Button
                    // variant="contained"
                    onClick={() => {
                      if (this.props.entity === 'PACKAGE')
                        this.props.changePackageActiveStep(3);
                      else this.props.changeProductActiveStep(2);
                    }}
                    style={{
                      textTransform: 'none',
                      paddingLeft: 0,
                      background: '#fff',
                      color: '#ff1921',
                    }}
                    className={classes.btn}
                  >
                    Back
                  </Button> */}
				  					<StyledButton
										// variant="contained"
										onClick={() => {
											if (this.props.entity === 'PACKAGE')
												this.props.changePackageActiveStep(3);
											else this.props.changeProductActiveStep(2);
										}}
										style={{
											//   background: "#02bfa0",
											marginTop: '3%',
                  							background: '#5dc17f',	
										}}>
										Back
									</StyledButton>
									<StyledButton
										// variant="contained"
										onClick={this.validateHandler}
										style={{
											//   background: "#02bfa0",
											background: '#5dc17f',
											margin:'3% 1rem 0'
										}}>
										Validate
									</StyledButton>
									<StyledButton
										// variant="contained"
										type="submit"
										style={{
											//   background: "#02bfa0",
											marginTop: '3%',
              								background: '#5dc17f',
										}}>
										Save
									</StyledButton>

									{/* <Button variant="contained" color="secondary"
                                style={{
                                    background: 'red', textTransform: 'none'
                                }}
                                onClick={this.deleteOfferabilityHandler}
                            >
                                Delete
                     </Button> */}
								</div>
							)}
						</Grid>
					</form>
				</React.Fragment>
			);

			
		}
		return offerability;
	}
}

const mapStateToProps = (state) => {
	return {
	  roleGroup: state.roleSelected.roleGroup,
	};
  };

const mapDispatchToProps = (dispatch) => {
	return {
		changePackageActiveStep: (activeStep) =>
			dispatch({
				type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
				activeStep: activeStep,
			}),
		changeProductActiveStep: (activeStep) =>
			dispatch({
				type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP,
				activeStep: activeStep,
			}),
			changeRoleGroup: (roleGroup) =>
      dispatch({ type: actionTypes.CHANGE_ROLE_GROUP, roleGroup })
	};
};

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(Offerability, axios)));


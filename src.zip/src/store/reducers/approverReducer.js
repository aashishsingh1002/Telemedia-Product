import * as actionTypes from '../actions/actionTypes';

const initialState = {
    approversData: {},
    workflowApprovers: {},
};

const setApproverMap = (state, action) => {
    return {
        ...state,
        approversData: { ...action.approversData },
    }
};
const setWorkflowApprover = (state, action) => {
	return {
		...state,
		workflowApprovers: { ...action.workflowApprovers },
	};
};


const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.APPROVER_MAP: return setApproverMap(state, action);
        case actionTypes.WORKFLOW_APPROVER:
			return setWorkflowApprover(state, action);
        default:
            return state;
    }
};

export default reducer;
import React, { Component } from 'react';
import { Route, Switch, Redirect, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import Login from './containers/Login/Login';
import Dashboard from './containers/Dashboard/Dashboard';
import Layout from './HOC/Layout/Layout_local';
import Worklist from './containers/Worklist/Worklist'
import EditRelease from './containers/EditRelease/EditRelease';
import PlanConfiguration from './containers/Entities/Package/PlanConfiguration'
import * as actionTypes from './store/actions/actionTypes';
import ProductConfiguration from './containers/Entities/Product/ProductConfiguration'
import Contract from './containers/EntityCreation/Contract'
import ContractProfile from './containers/EntityCreation/ContractProfile'
import Attribute from './containers/EntityCreation/Attribute'
import RatePlan from './containers/EntityCreation/RatePlan/RatePlan'
import WorkflowAdmin from './containers/WorkflowAdmin/WorkflowAdmin'
import Admin from './containers/Admin/Admin'
import ProductPerformance from './containers/ProductPerformance/ProductPerformance'
import Events from './containers/EntityCreation/Events'
import AdminPlanConfiguration from './containers/Admin/Plan/PlanConfiguration'
import AdminProductConfiguration from './containers/Admin/Product/ProductConfiguration'
import AdminOfferabilityConfiguration from './containers/Admin/Offerability/OfferabilityConfiguration'
import BundleContractConfiguration from './containers/Admin/Contract/BundleContractConfiguration'
import ContractCreationConfiguration from './containers/Admin/Contract/ContractCreationConfiguration'
import ContractProfileConfiguration from './containers/Admin/ContractProfile/ContractProfileConfiguration'
import AttributeConfiguration from './containers/Admin/Attribute/AttributeConfiguration'
import AttributeGroupConfiguration from './containers/Admin/Attribute/AttributeGroupConfiguration'
import RatePlanConfiguration from './containers/Admin/RatePlan/RatePlanConfiguration'
import RentalConfiguration from './containers/Admin/Rental/RentalConfiguration'
import DiscountConfiguration from './containers/Admin/Discount/DiscountConfiguration'
import CtsConfiguration from './containers/Admin/Product/CtsConfiguration'
import UserConfiguration from './containers/Admin/User/UserConfiguration'
import AdvanceSearch from './containers/AdvanceSearch/AdvanceSearch'
import PlanReport from './containers/Library/PlanReport'
import AllReleases from './containers/AllReleases/AllReleases'
import EpcDailyReleaseReport from './containers/Library/EpcDailyReleaseReport'
import RatePlanReport from './containers/Library/RatePlanReport'
import EpcFederationReport from './containers/Library/EpcFederationReport'
import EpcOfferabilityReport from './containers/Library/EpcOfferabilityReport'
import axios from 'axios'

class App extends Component {

    componentDidMount() {
        console.log('enviroment variable')
        console.log(process.env.REACT_APP_URL)
    }

    getCookie(cname) {
        var name = cname + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }

    render() {

        let routes = (
            <Switch>
                <Route path="/login" exact render={() => {
                    console.log('object')
                    let obj = {
                        "firstName": this.getCookie('firstName'),
                        "lastName": this.getCookie('lastName'),
                        "opId": this.getCookie('opid'),
                        "email": this.getCookie('email'),
                        "buId": this.getCookie('buid'),
                        "id": this.getCookie('username1'),
                        "group": this.getCookie('group')
                            ? this.getCookie('group').split(",") : ['TelemediaProductManager'],
                        'jwt': this.getCookie('token')
                    }
                    console.log('name')
                    console.log(this.getCookie('firstName'))
                    console.log(obj)
                    if (!this.getCookie('firstName')) {
                        window.location.replace("https://ace.airtelworld.in/EPCLogin");
                    }
                    this.props.onLogin(obj)

                    axios
                        .get(process.env.REACT_APP_URL + "TeleSelectApprovers/roleuimapping", {
                            headers: {
                                opId: obj.opId,
                                buId: obj.buId,
                                lob: "Postpaid",
                                // Authorization: 'Bearer ' + obj.jwt
                            }
                        })
                        .then(res => {
                            console.log(res)
                            let approverData = res.data.data;
                            approverData = {
                                ...approverData,
                                ['TelemediaProductManager']: "Product Manager"
                            }
                            console.log(approverData)

                            this.props.onApproversData(approverData)

                            // if (obj.group.includes("TelemediaProductManager"))
                            //     this.props.history.push('/dashboard')
                            // else if (obj.group.includes("WorkflowAdmin"))
                            //     this.props.history.push('/WorkflowAdminDashboard')
                            // else
                            //     this.props.history.push('/worklist')


                        })
                        .catch(error => {
                            console.log(error)
                            // this.props.onLogin(obj)
                            // if (obj.group.includes("TelemediaProductManager"))
                            //     this.props.history.push('/dashboard')
                            // else if (obj.group.includes("Admin"))
                            //     this.props.history.push('/adminDashboard')
                            // else
                            //     this.props.history.push('/worklist')
                        });

                }} />
                <Route path="/dashboard" exact component={Dashboard} />
                <Route path="/adminDashboard" exact component={Admin} />
                <Route path="/worklist" exact component={Worklist} />
                <Redirect to="/login" />
            </Switch>
        );

        if (Object.keys(this.props.userInfo).length > 0 && this.props.userInfo.firstName) {
            if (this.props.userInfo.group.includes("TelemediaProductManager")) {
                routes = (
                    <Switch>
                        <Route path="/" exact render={() => {
                            this.props.onReleaseExit();
                            return <Dashboard />
                        }} />
                        <Route path="/worklist" exact component={Worklist} />
                        <Route path="/editRelease" exact component={EditRelease} />
                        <Route path="/planConfiguration" exact component={PlanConfiguration} />
                        <Route path="/productConfiguration" exact component={ProductConfiguration} />
                        <Route path="/contractsCreation" exact component={Contract} />
                        <Route path="/contractProfileCreation" exact component={ContractProfile} />
                        <Route path="/attributeConfiguration" exact component={Attribute} />
                        <Route path="/ratePlanConfiguration" exact component={RatePlan} />
                        <Route path="/productPerformance" exact component={ProductPerformance} />
                        <Route path="/events" exact component={Events} />
                        <Route path="/advanceSearch" exact component={AdvanceSearch} />
                        <Route path="/libraryPlanReport" exact component={PlanReport} />
                        <Route path='/allReleases' exact component={AllReleases} />
                        <Route path="/epcDailyReleaseReport" exact component={EpcDailyReleaseReport} />
                        <Route path="/ratePlanReport" exact component={RatePlanReport} />
                        <Route path="/epcFederationReport" exact component={EpcFederationReport} />
                        <Route path="/epcOfferabilityReport" exact component={EpcOfferabilityReport} />

                        <Redirect to="/" />
                    </Switch>
                );
            }
            else if (this.props.userInfo.group.includes("Admin")) {
                routes = (
                    <Switch>
                        <Route path="/adminDashboard" exact component={Admin} />
                        <Route path="/adminPlanConfiguration" exact component={AdminPlanConfiguration} />
                        <Route path="/adminProductConfiguration" exact component={AdminProductConfiguration} />
                        <Route path="/adminOfferabilityConfiguration" exact component={AdminOfferabilityConfiguration} />
                        <Route path="/adminBundleContractConfiguration" exact component={BundleContractConfiguration} />
                        <Route path="/adminContractCreationConfiguration" exact component={ContractCreationConfiguration} />
                        <Route path="/adminContractProfileConfiguration" exact component={ContractProfileConfiguration} />
                        <Route path="/adminAttrConfiguration" exact component={AttributeConfiguration} />
                        <Route path="/adminAttrGrpConfiguration" exact component={AttributeGroupConfiguration} />
                        <Route path="/adminRatePlanConfiguration" exact component={RatePlanConfiguration} />
                        <Route path="/adminRentalConfiguration" exact component={RentalConfiguration} />
                        <Route path="/adminDiscountConfiguration" exact component={DiscountConfiguration} />
                        <Route path="/adminCtsConfiguration" exact component={CtsConfiguration} />
                        <Route path="/adminuserConfiguration" exact component={UserConfiguration} />
                        <Route path="/adminWorklist" exact component={WorkflowAdmin} />
                        <Redirect to="/adminDashboard" />
                    </Switch>
                );
            }

            else {
                routes = (
                    <Switch>
                        <Route path="/worklist" exact component={Worklist} />
                        <Route path='/allReleases' exact component={AllReleases} />
                        <Redirect to="/worklist" />
                    </Switch>
                );
            }
        }

        return (

            <div style={this.props.location.pathname != '/login' ? {
                transform: 'scale(.8)',
                width: '125vw',
                height: '100vh',
                marginLeft: '-12.7vw',
                // marginRight: '-10vw',
                marginTop: '-10vh',


            } : null}>
                <Layout>
                    {routes}
                </Layout>
            </div>

        );
    }
}

const mapStateToProps = state => {
    return {
        userInfo: state.login.loggedInUserInfo,
    };
}

const mapDispatchToProps = dispatch => {
    return {
        onReleaseExit: () => dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: {} }),
        onLogin: (loggedInUserInfo) => dispatch({ type: actionTypes.LOGIN_SUCCESS, loggedInUserInfo: loggedInUserInfo }),
        onApproversData: (approversData) => dispatch({ type: actionTypes.APPROVER_MAP, approversData: approversData }),
    };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(App));
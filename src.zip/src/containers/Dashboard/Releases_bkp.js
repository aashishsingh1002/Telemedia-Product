import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import TableNew from '../../UI/Table/TableNew';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import Tooltip from '@material-ui/core/Tooltip';
import Loader from '../../UI/Loader/Loader';
import { withStyles } from '@material-ui/core/styles';
import ModalAction from '../../UI/ModalAction/ModalAction';
import moment from 'moment';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import { Translate } from 'react-redux-i18n';
import Button from "@material-ui/core/Button";
import Typography from '@material-ui/core/Typography';
import Menu from '@material-ui/core/Menu';
import CancelIcon from '@material-ui/icons/Cancel';
import MenuItem from '@material-ui/core/MenuItem';
import Paper from '@material-ui/core/Paper';
import InfoOutlinedIcon from '@material-ui/icons/InfoOutlined';
import DescriptionOutlinedIcon from '@material-ui/icons/DescriptionOutlined';
import StyledButton from '../../UI/Button/Button';
import * as actionTypes from '../../store/actions/actionTypes';
import MenuIcon from '@material-ui/icons/Menu'; 
import CloseIcon from '@material-ui/icons/Close';
import AttachFileIcon from '@material-ui/icons/AttachFile';
import AccountTreeOutlinedIcon from '@material-ui/icons/AccountTreeOutlined';
import LibraryBooksOutlinedIcon from '@material-ui/icons/LibraryBooksOutlined';
import CheckCircleOutlineOutlinedIcon from '@material-ui/icons/CheckCircleOutlineOutlined';
// import Card from '@material-ui/core/Card';
// import CardContent from '@material-ui/core/CardContent';
// import Radio from '@material-ui/core/Radio';
// import RadioGroup from '@material-ui/core/RadioGroup';
// import FormControlLabel from '@material-ui/core/FormControlLabel';
// import Button from '@material-ui/core/Button';

import Title from '../../UI/Typography/Title';
import Select from '@material-ui/core/Select';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import LibraryBooksIcon from '@material-ui/icons/LibraryBooks';
import Modal from '../../UI/Modal/Modal';


//import { saveAsExcel } from '../BulkUpload/common/utils';

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: '#525354',
    color: 'white',
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

const getColor = {
  Deployed: '#1565c0',
  InProgress: '#009337',
  Cancelled: '#CF4405',
  'Approval In Progress': '#ff9100', //"#C62828",
};

const StyledMenu = withStyles({
  paper: {
    background: '#FFFFFF',
    border: '1px solid #EAEAEA',
    boxSizing: 'border-box',
    boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.08)',
    borderRadius: '8px',
  },
})((props) => <Menu elevation={0} getContentAnchorEl={null} {...props} />);

const StyledMenuItem = withStyles((theme) => ({
  root: {
    fontWeight: '600',
    fontSize: '12px',
    linHeight: '16px',
    color: '#0079FF',
  },
}))(MenuItem);

const StyledPaper = withStyles((theme) => ({
  root: {
    padding: '20px',
  },
}))(Paper);

const StyledTypoHeading = withStyles((theme) => ({
  root: {
    fontWeight: 'regular',
    fontSize: '14px',
    color: '#393939',
  },
}))(Typography);

const StyledTypoValue = withStyles((theme) => ({
  root: {
    fontWeight: 'bold',
    fontSize: '22px',
    color: '#000',
    marginTop: '5px',
  },
}))(Typography);

const StyledInfoIcon = withStyles((theme) => ({
  root: {
    fontSize: '16px',
    position: 'absolute',
    right: 0,
    top: 0,
  },
}))(InfoOutlinedIcon);

class Releases extends Component {
  _isMounted = false;
  state = {
    cancelledReleases: [],
    approvedReleases: [],
    inProgressReleases: [],
    inApprovalReleases: [],
    anchorEls: [],
    remarks: '',
    data: [],
    deployed: [],
    approval: [],
    allReleases: [],
    canceledRelease: [],
    inProgress: [],
    show: false,
    loading: false,
    schema: [],
    svData: [],
    "serviceSelected":[],
    roleSelected:[],
    showModal:false,
    currState: 'allReleases',
    
  };

  columns = [
    {
      title: <Translate value='dashboard.releaseObj' />,
      field: 'remarks',
      render: (rowData) => (
      //   <Typography
      //     style={{
      //       fontWeight: '600',
      //       fontSize: '14px',
      //       color: '#393939',
      //       minHeight: '40px',
      //       display: 'flex',
      //       alignItems: 'center',
      //     }}
      //   >
      //     {rowData.remarks
      //       ? rowData.remarks.length > 50
      //         ? rowData.remarks.substring(0, 50) + '...'
      //         : rowData.remarks
      //       : ''}
      //   </Typography>
      // ),
      <Tooltip
      title= {rowData.remarks}
      aria-label='Total number of Releases'
    >
      <Typography
        style={{
          fontWeight: '600',
          fontSize: '14px',
          color: '#393939',
          minHeight: '60px',
          display: 'flex',
          alignItems: 'center',
        }}
      >
        {rowData.remarks
          ? rowData.remarks.length > 30
            ? rowData.remarks.substring(0, 30) + '...'
            : rowData.remarks
          : ''}
      </Typography>
    </Tooltip>    
    ),


      sorting: false,
      cellStyle: { width: '20%' }
    },
    {
      title: '',
      field: 'externalReleaseId',
      render: (rowData) => (
        <Typography
          style={{ fontWeight: '400', fontSize: '14px', color: '#333333' }}
        >
           {rowData.externalReleaseId}
        </Typography>
      ),
    },
    {
      title: <Translate value='dashboard.creationDate' />,
      field: 'createdOn',
      render: (rowData) => (
        <Typography
          style={{ fontWeight: '400', fontSize: '14px', color: '#333333' }}
        >
          {rowData.createdOn}
        </Typography>
      ),
    },
    
    {
      title: <Translate value='dashboard.status' />,
      field: 'releaseStatus',
      render: (rowData) => (
        <Typography
          style={{
            fontWeight: '600',
            fontSize: '14px',
            color: getColor[rowData.releaseStatus],
          }}
        >
          {rowData.releaseStatus}
        </Typography>
      ),
      sorting: false,
      cellStyle: { width: 'nowrap' }

    },
    {
      title: <Translate value='dashboard.literature' />,
      field: 'literature',
      render: (rowData) => (
        <LibraryBooksIcon
        style={{ color: 'black' , marginRight: '10px'}}
        onClick={(event) => {
          event.stopPropagation();
          if (rowData.releaseStatus !== 'Deployed')
            this.props.literature(rowData);
        }}
      />
      ),
      sorting: false,
      cellStyle: { width: 'nowrap' }
    },
    
  ];

  menuHandleClose = (externalReleaseId) => {
    let anchorEls = [...this.state.anchorEls];
    anchorEls[externalReleaseId] = null;
    this.setState({ anchorEls });
  };

  modalCloseHandler = () => {
    this.setState({ show: false, remarks: '' ,showModal:false});
  };

  toggleMenu = (toggle) => {
    this.setState({ toggleActions: toggle });
  };

  dashboardOverview = () => {
    let cancelledReleases = [];
    let approvedReleases = [];
    let inProgressReleases = [];
    let inApprovalReleases = [];

    this.state.data.map((release) => {
      if (release.releaseStatus == 'InProgress')
        inProgressReleases.push(release);
      else if (release.releaseStatus == 'Cancelled')
        cancelledReleases.push(release);
      else if (release.releaseStatus == 'Approval In Progress')
        inApprovalReleases.push(release);
      else if (release.releaseStatus == 'Deployed')
        approvedReleases.push(release);
    });
    this.setState({
      cancelledReleases,
      approvedReleases,
      inProgressReleases,
      inApprovalReleases,
    });

    return Promise.resolve();
  };

  actionHandler = () => {
    let date = moment().format('YYYY-MM-DD');
    let payload = {
      buId: this.props.userInfo.buId,
      createdBy: this.props.userInfo.id,
      createdOn: date,
      remarks: this.state.remarks,
      catalogId: 'DEF_CATALOG',
      opId: this.props.userInfo.opId,
      releaseDate: date,
      replicationStatus:this.props.roleGroup,
    };
    this.setState({ loading: true });

    axios
      .post('telemediaDashboard/myReleases/create', payload, {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
          Authorization:'Bearer ' + this.props.userInfo.jwt
        },
      })
      .then((response) => {
        let obj = {};
        obj = { ...response.data.data.ppmReleaseMaster };
        obj.pendingWith = response.data.data.pendingWith;
        let data = [...this.state.data];
        data.unshift(obj);
        this.setState({
          data: data,
          loading: false,
          show: false,
          remarks: '',
        });
        // window.location.reload();
      })
      .catch((error) => {
        console.log(error);
        this.setState({ show: false, remarks: '', loading: false });
      });
  };
  newReleaseHandler = () => {
    this.setState({ show: true });
  };
  valueChangeHandler = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  };

  // getSvTableData(rowData) {
  //   return axios
  //     .get('mtn/sv/export?releaseID=' + this.state.selected.releaseId, {})
  //     .then((res) => {
  //       console.log('deal response', res);

  //       if (res) {
  //         this.setState({
  //           svData: res.data.data.map((row) => {
  //             return { ...row };
  //           }),
  //         });
  //         saveAsExcel({
  //           schema: this.state.schema.filter(
  //             (row) => row.groupName === 'UI Input'
  //           ),
  //           name: 'SV Release Export',
  //           data: this.state.svData,
  //         });
  //       }
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //       if (this._isMounted) this.setState({ loading: false });
  //     });
  // }
  // svExport() {
  //   return axios
  //     .get('config?entityName=svExport', {
  //       headers: {
  //         opId: this.props.userInfo.opId,
  //         buId: this.props.userInfo.buId,
  //       },
  //     })
  //     .then((res) => {
  //       let schema = [];
  //       schema = res.data.data.map(function (el) {
  //         if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
  //           if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
  //           else if (el.refLovs == null) el.refLovs = [];
  //         }
  //         return el;
  //       });
  //       if (this._isMounted) this.setState({ schema: schema });
  //       localStorage.setItem('svExport', JSON.stringify(schema));
  //       localStorage.svExport_version = this.state.version;
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //       if (this._isMounted) this.setState({ loading: false });
  //     });
  // }
  cancelRelease = () => {
		// console.log(this.state.data);
		// this.setState({ loading: true, anchorEl: null });
	const Authorization = 'Bearer ' + this.props.userInfo.jwt;
		axios
			.post(
				'telemediaCancel/release?releaseId=' + this.state.selected.releaseId,
				{
					updatedBy: this.props.userInfo.id,
					updatedDate: moment().format('DD-MMM-YY'),
					headers: {
						opId: this.props.userInfo.opId,
						buId: this.props.userInfo.buId,
					 Authorization
					},
				}
			)
			.then((res) => {
				console.log(res);
				if (res) {
					if (this.state.selected.pendingWith !== 'WorkFlow Not Initiated') {
						console.log('cancel2');

						axios
							.post(
								'Telecustom/cancelTask?releaseId=' +
									this.state.selected.releaseId,
								{}
							)
							.then((res) => {
								console.log(res);
								this.setState({
									data: this.state.data.map((el) =>
										el.releaseId === this.state.selected.releaseId
											? {
													...el,
													releaseStatus: 'Cancelled',
													pendingWith: '',
											  }
											: el
									),showModal:false
								});
								this.setState({ loading: false,showModal:false });
							})
							.catch((error) => {
								console.log(error);
								if (this._isMounted) this.setState({ loading: false,showModal:false });
							});
					} else {
						this.setState({
							data: this.state.data.map((el) =>
								el.releaseId === this.state.selected.releaseId
									? {
											...el,
											releaseStatus: 'Cancelled',
											pendingWith: '',
									  }
									: el
							),
              showModal:false
						});
						this.setState({ loading: false,showModal:false });
					}
				} else {
					this.setState({ loading: false ,showModal:false});
				}
			})

			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false,showModal:false });
			});
	};

  allReleasesHandler = async (roleGroup) => {
    if (this.props.roleGroup) {
			if (
				localStorage.getItem(
					// `${localStorage.getItem('isB2c') === 'true' ? 'b2c' : 'b2b'}Data`
					`${roleGroup ?? this.props.roleGroup}Data`
				)
			) {
				const res = await JSON.parse(
					localStorage.getItem(
						// `${localStorage.getItem('isB2c') === 'true' ? 'b2c' : 'b2b'}Data`
						`${roleGroup ?? this.props.roleGroup}Data`
					)
				);
				if (this._isMounted) {
					this.setState({
						data: res,
						loading: false,
					});
				}
			} else {
        ;
				return axios
					.get(
						'telemediaDashboard/myReleases?createdBy=' + this.props.userInfo.id,
						// 'dashboard/myReleases?createdBy=' + this.props.userInfo.id,
						{
							headers: {
								Accept: 'application/json,text/plan,*/*',
								buId: this.props.userInfo.buId,
								channelId: 'CSA',
								language: 'ENG',
								opId: this.props.userInfo.opId,
                Authorization:'Bearer '+ this.props.userInfo.jwt,
								// lob: localStorage.getItem('isB2c') === 'true' ? 'b2c' : 'b2b',
								lob:
									roleGroup ?? this.state.serviceType ?? this.props.roleGroup,
							},
						}
					)
					.then((res) => {
						console.log(res);
						let data = [];
						res.data.data.map((element) => {
							var obj = {};
							obj = { ...element.myReleases };
							obj.pendingWith = element.pendingWith;
							data.push(obj);
						});
						console.log(data);
						if (this._isMounted) {
							this.setState({ data: data, loading: false });
						}

						localStorage.setItem(
							// `${localStorage.getItem('isB2c') === 'true' ? 'b2c' : 'b2b'}Data`,
							`${localStorage.getItem('isB2c')}Data`,
							JSON.stringify(data)
						);
					})

					.catch((error) => {
						console.log(error);
						if (this._isMounted) this.setState({ loading: false });
					});
			}
		} else {
			return;
		}
  };
  componentDidMount = () => {
    this._isMounted = true;

    this.setState({ loading: true });

    this.allReleasesHandler().then(() => {
      this.dashboardOverview().then(() => {
        // this.svExport().then(() => {
          if (this._isMounted) {
            this.setState({ loading: false ,
            roleSelected:this.props.roleGroup

            });
            
          }

        // });
      });

      this.approversDataHandler().then(() => {
        if (this._isMounted) this.setState({ loading: false });
        // })
      });
    });

  };
  approversDataHandler(isInRelease) {
    console.log('fetching from api');
  
		const opId = this.props?.userInfo?.opId ?? this.userInfo.opId;
		const buId = this.props?.userInfo?.buId ?? this.userInfo.buId;
		const authUserId = this.props?.userInfo?.id ?? this.userInfo.id;
		const Authorization = this.props?.userInfo?.jwt ?? this.userInfo.jwt;
    const role=this.props?.roleGroup?? this.roleGroup;
		return axios
			.get(process.env.REACT_APP_URL + 'TeleAuthentication/approver', {
				headers: {
					opId: opId,
					buId: buId,
					// role: localStorage.getItem('isB2c') === 'true' ? 'b2c' : 'b2b',
					 role: role,
					lob: 'Postpaid',
					authUserId: authUserId,
					Authorization: 'Bearer ' + Authorization,
				},
			})
			.then((res) => {
				let approvalData = res.data.data;
				if (this._isMounted)
					this.setState({ approversData: { ...approvalData } });
				localStorage.setItem('approversData', JSON.stringify(approvalData));
				if (isInRelease) {
					this.props.onPopulateApprovers(approvalData);
				} else {
					this.onPopulateApprovers(approvalData);
				}
				localStorage.approversData_version = this.state.approversVersion;
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
  }
  componentDidUpdate = (previousProps, previousState) => {
    console.log('previousState', previousState);
    console.log('previousProps', previousProps);
  };

  // shouldComponentUpdate = (nextProps, nextState) => {
  //   // return this.props.value !== nextProps.value;
  //   console.log("n", nextProps);
  //   console.log("a", nextState);
  //   return true;
  // };

	serviceTypeHandler = async (event) => {
		const selected = event.target.value;
		// === 'PRI' ? 'B2BPRI' : event.target.value;
		// localStorage.setItem('isB2c', event.target.value === 'B2C');
		localStorage.setItem('isB2c', selected.toLowerCase());
		this.props.changeRoleGroup(selected.toLowerCase());
		this.setState({
			// serviceType: localStorage.getItem('isB2c') === 'true' ? 'B2C' : 'B2B',
			serviceType: selected.toUpperCase(),
			loading: true,
		});
    ;
		await this.allReleasesHandler(selected.toLowerCase());
   
		this.props.approverHandler(true);
	};

showCancelHandler=()=>{
  this.setState({showModal:false})
}
  

  componentWillUnmount() {
    this._isMounted = false;
  }
debugger;
  render() {
    let myReleases = (
      
      <React.Fragment>
        <div
          style={{
            margin: '0 auto',
            maxWidth: 1200,
            width: '100%',
            paddingBottom: '20px',

          }}
        >

        <span
						style={{
							display: 'inline-flex',
							textAlign: 'end',
							// marginBottom: '0rem',
							// marginRight: '1rem',
              
              
						}}>
            <Title>Dashboard</Title>
						<FormControl style={{width:'5rem',FontSize:'10px' ,marginTop:'10px',textAlign: 'start',marginLeft:'790px' }}>
							<InputLabel>Service Type</InputLabel>
							<Select
              
								value={this.props.roleGroup.toUpperCase()}
                
                onChange={(e) => {
                  localStorage.clear()
                  this.serviceTypeHandler(e);
                }}
                
              >
								{[
									'B2B',
									'B2C',
									'B2BPRI',
									'B2BMANUAL',
									'B2CMANUAL',
									'PRIMANUAL',
								].map((srvc) => {
									return (
										<MenuItem value={srvc} key={srvc}>
											{srvc}
										</MenuItem>
									);
								})}
							</Select>
						</FormControl>
					</span>


          
          
          <Grid container style={{ marginBottom: '14px',marginRight:'5rem' }}>
            <Grid
              item
              xs={2}
              style={{
                cursor: 'pointer',
              }}
              onClick={() =>
                this.setState({
                  data: this.state.allReleases,
                  currState: 'allReleases',
                })
              }
            >
              <StyledPaper>
                <div
                  style={{
                    position: 'relative',
                  }}
                >
                  <StyledTypoHeading>My releases</StyledTypoHeading>
                  <Tooltip
                    title='Total number of Releases'
                    aria-label='Total number of Releases'
                  >
                    <StyledInfoIcon />
                  </Tooltip>
                </div>
                <StyledTypoValue>
                  {this.state.allReleases.length}
                </StyledTypoValue>
              </StyledPaper>
            </Grid>


            
            <Grid
              item
              xs={2}
              style={{
                cursor: 'pointer',
                '&:hover': {
                  background: '#efefef',
                },
              }}
              
              onClick={() =>
                this.setState({
                  data: this.state.inProgressReleases.filter(
                    (x) => x.releaseStatus === 'InProgress'
                  ),
                  currState: 'InProgress',
                })
              }
            >
              <StyledPaper>
                <div
                  style={{
                    position: 'relative',
                  }}
                >
                  <StyledTypoHeading>In Progress   </StyledTypoHeading>
                  <Tooltip
                    title='Releases in Progress'
                    aria-label='Releases in Progress'
                  >
                    <StyledInfoIcon />
                  </Tooltip>
                </div>
                <StyledTypoValue style={{ color: '#009337' }}>
                  {this.state.inProgressReleases.length}
                </StyledTypoValue>
              </StyledPaper>
            </Grid>
            <Grid
              item
              xs={2}
              style={{
                cursor: 'pointer',
              }}
              onClick={() =>
                this.setState({
                  data: this.state.approval.filter(
                    (x) => x.releaseStatus === 'Approval In Progress'
                  ),
                  currState: 'InApproval',
                })
              }
            >
              <StyledPaper>
                <div
                  style={{
                    position: 'relative',
                  }}
                >
                  <StyledTypoHeading>In Approval </StyledTypoHeading>
                  <Tooltip
                    title='Releases in Approval'
                    aria-label='Releases in Approval'
                  >
                    <StyledInfoIcon />
                  </Tooltip>
                </div>
                <StyledTypoValue style={{ color: '#ff9100' }}>
                  {this.state.inApprovalReleases.length}
                </StyledTypoValue>
              </StyledPaper>
            </Grid>
            <Grid
              item
              xs={2}
              style={{
                cursor: 'pointer',
              }}
              onClick={() =>
                this.setState({
                  data: this.state.deployed.filter(
                    (x) => x.releaseStatus === 'Deployed'
                  ),
                  currState: 'Deployed',
                })
              }
            >
              <StyledPaper>
                <div
                  style={{
                    position: 'relative',
                  }}
                >
                  <StyledTypoHeading>Deployed</StyledTypoHeading>
                  <Tooltip
                    title='Releases Deployed'
                    aria-label='Releases Deployed'
                  >
                    <StyledInfoIcon />
                  </Tooltip>
                </div>
                <StyledTypoValue style={{ color: '#1565c0' }}>
                  {this.state.approvedReleases.length}
                </StyledTypoValue>
              </StyledPaper>
            </Grid>

            <Grid
              item
              xs={2}
              style={{
                cursor: 'pointer',
              }}
              onClick={() =>
                this.setState({
                  data: this.state.canceledRelease.filter(
                    (x) => x.releaseStatus === 'Cancelled'
                  ),
                  currState: 'Cancelled',
                })
              }
            >
              <StyledPaper>
                <div
                  style={{
                    position: 'relative',
                    cursor: 'pointer',
                  }}
                >
                  <StyledTypoHeading>Cancelled</StyledTypoHeading>
                  <Tooltip
                    title='Number of Cancelled Releases'
                    aria-label='Number of Cancelled Releases'
                  >
                    <StyledInfoIcon />
                  </Tooltip>
                </div>
                <StyledTypoValue style={{ color: '#CF4405' }}>
                  {this.state.cancelledReleases.length}
                </StyledTypoValue>
              </StyledPaper>
            </Grid>
             <Grid item xs={2}>
              <StyledPaper style={{ padding: '29px 15px' }}>
                <StyledButton
                  style={{
                    padding: '6px 16px',
                    background: '#5dc17f',
                  }}
                  onClick={() => this.newReleaseHandler()}
                >
                  New release
                </StyledButton>
              </StyledPaper>
            </Grid>
          </Grid>
          <div>
            <Typography
              style={{
                fontWeight: 'bold',
                fontSize: '20px',
                color: '#393939',
                 marginTop: "8px",
              }}
            >
              <span>
                <DescriptionOutlinedIcon />
                <Translate value='dashboard.myReleases' />
              </span>
            </Typography>
            <Typography
              style={{
                //   fontWeight: "bold",
                fontSize: '16px',
                color: '#393939',
                marginBottom: '14px',
              }}
            >
              Search and create new releases below and review or edit them in
              the right hand panel.
            </Typography>
            <div style={{ display: 'flex' }}>
              <div style={{ maxWidth: 820, width: '90%' }}>
                <TableNew
                  clickable
                  onRowClick={(event, data) => {
                    this.setState({ selected: data });
                  }}
                  selected={
                    this.state.selected && this.state.selected.externalReleaseId
                  }
                  data={this.state.data}
                  columns={this.columns}
                  pageSize={7}
                  fontSize={'14px'}
                  style={{
                    background: 'none',
                    boxShadow: 'none',
                    // boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.08)",
                  }}
                />
              </div>
              {this.state.selected && (
                <div
                  style={{
                    marginTop: '64px',
                    background: '#F5F5F5',
                    flexGrow: 1,
                    display: 'flex',
                    flexDirection: 'column',
                    borderRadius: '0 4px 4px 0',
                    borderLeft: '1px solid #ddd',
                    position: 'relative',
                  }}
                >
                  {this.state.toggleActions ? (
                    <React.Fragment>
                      <div
                        style={{
                          borderBottom: '1px solid #eee',
                          padding: '16px',
                        }}
                      >
                        <div
                          style={{
                            fontSize: '22px',
                            fontWeight: 'bold',
                            letterSpacing: '-1px',
                            height: '20px',
                            marginBottom: '14px',
                          }}
                        >
                          Release Actions
                          <span
                            style={{ position: 'absolute', right: 16, top: 16 }}
                          >
                            <CloseIcon
                              style={{ cursor: 'pointer' }}
                              onClick={() => {
                                this.toggleMenu(false);
                              }}
                            />
                          </span>
                        </div>
                      </div>
                      {this.state.selected.releaseStatus !== 'Cancelled' && (
                        <div
                          style={{
                            cursor: 'pointer',
                            fontSize: '16px',
                            letterSpacing: '-1px',
                            borderBottom: '1px solid #eee',
                            padding: '10px 16px',
                          }}
                          onClick={() => {
                            this.props.attachmentUpload(this.state.selected);
                          }}
                        >
                          <div
                            style={{
                              display: 'flex',
                            }}
                          >
                            <AttachFileIcon style={{ marginRight: '10px' }} />
                            <Translate value='dashboard.attachment' />
                          </div>
                        </div>
                      )}
                      <div
                        style={{
                          cursor: 'pointer',
                          fontSize: '16px',
                          letterSpacing: '-1px',
                          borderBottom: '1px solid #eee',
                          padding: '10px 16px',
                        }}
                        onClick={(event) => {
                          this.props.auditLogs(this.state.selected);
                        }}
                      >
                        <div
                          style={{
                            display: 'flex',
                          }}
                        >
                          <LibraryBooksOutlinedIcon
                            style={{ marginRight: '10px' }}
                          />
                          <Translate value='dashboard.auditLogs' />
                        </div>
                      </div>

                      {/*<div
                        style={{
                          cursor: 'pointer',
                          fontSize: '16px',
                          letterSpacing: '-1px',
                          borderBottom: '1px solid #eee',
                          padding: '10px 16px',
                        }}
                        onClick={(event) => {
                          this.props.treeView(this.state.selected);
                        }}
                      >
                        <div
                          style={{
                            display: 'flex',
                          }}
                        >
                          <AccountTreeOutlinedIcon
                            style={{ marginRight: '10px' }}
                          />
                          <Translate value='dashboard.TreeView' />111
                        </div>
                        </div> */}



                     {/* // {this.state.selected.releaseStatus === 'InProgress' && (
                      //   <div
                      //     style={{
                      //       cursor: 'pointer',
                      //       fontSize: '16px',
                      //       letterSpacing: '-1px',
                      //       borderBottom: '1px solid #eee',
                      //       padding: '10px 16px',
                      //     }}
                      //     onClick={(event) => {
                      //       this.props.onReleaseEnter(this.state.selected);
                      //       this.props.history.push('/selectApprover');
                      //       // this.props.workflow(this.state.selected);
                      //     }}
                      //   >
                      //     <div
                      //       style={{
                      //         display: 'flex',
                      //       }}
                      //     >
                      //       <CheckCircleOutlineOutlinedIcon
                      //         style={{ marginRight: '10px' }}
                      //       />
                      //       <Translate value='dashboard.initiateWorkflow' />
                      //     </div>
                      //   </div>
                        // )} */}



                      {this.state.selected.releaseStatus === 'InProgress' && (
                        <div
                                                style={{
                                                  cursor: 'pointer',
                                                  fontSize: '16px',
                                                  letterSpacing: '-1px',
                                                  borderBottom: '1px solid #eee',
                                                  padding: '10px 16px',
                                                }}
                                                onClick={(event) => {
                                                  // this.props.treeView(this.state.selected);
                                                  event.stopPropagation();
                                                  // this.props.uploadModal(rowData);
                                                  this.menuHandleClose(this.state.selected.externalReleaseId);
                                                 // this.props.history.push('/selectApprover');
                                                  this.props.workflow(this.state.selected);
                                                }}
                                              >
                                                <div
                                                  style={{
                                                    display: 'flex',
                                                  }}
                                                >
                                                  <AccountTreeOutlinedIcon
                                                    style={{ marginRight: '10px' }}
                                                  />
                                                  <Translate value='dashboard.SelectApprover' />
                                                </div>
                                              </div>
                        )}
                      
                      <div
                        style={{
                          cursor: 'pointer',
                          fontSize: '16px',
                          letterSpacing: '-1px',
                          borderBottom: '1px solid #eee',
                          padding: '10px 16px',
                        }}
                        onClick={ ()=>{ this.setState({showModal:true})}}  
                      >
                        <div
                          style={{
                            display: 'flex',
                          }}
                        >
                          <CancelIcon
                            style={{ marginRight: '10px' }}
                          />
                          <Translate value='dashboard.Cancel' />
                        </div>
                      </div>

                      {/* <div
                        style={{
                          cursor: 'pointer',
                          fontSize: '16px',
                          letterSpacing: '-1px',
                          borderBottom: '1px solid #eee',
                          padding: '10px 16px',
                        }}
                        onClick={(event) => {
                          console.log(this.state.selected);
                          this.getSvTableData();
                        }}
                      >
                        <div
                          style={{
                            display: 'flex',
                          }}
                        >
                          <GetAppIcon style={{ marginRight: '10px' }} />
                          <Translate value='dashboard.SV Release Export' />
                        </div>
                      </div> */}
                      {/* 
                      <StyledMenuItem onClick={(event) => {
                            event.stopPropagation();
                            this.menuHandleClose(rowData.releaseId)
                            this.props.csvDownload(rowData)
                        }}><Translate value="dashboard.CSVDownload" /></StyledMenuItem>
                        <Divider style={{ marginLeft: '10px', marginRight: '10px' }} />   */}
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      <div
                        style={{
                          borderBottom: '1px solid #eee',
                          padding: '16px',
                        }}
                      >
                        <div>
                          <div
                            style={{
                              fontSize: '18px',
                              fontWeight: 'bold',
                              letterSpacing: '-1px',
                              height: '20px',
                              marginBottom: '14px',
                            }}
                          >
                            {/* {this.state.selected.remarks} */}
                          {/* </div> */}

                          {/* <span
                            style={{ position: 'absolute', right: 16, top: 16 }}
                          >
                            <MenuIcon
                              style={{ cursor: 'pointer' }}
                              onClick={() => {
                                this.toggleMenu(true);
                              }}
                            />
                          </span> */}
                           <Tooltip
        title= {this.state.selected.remarks}
        aria-label='Total number of Releases'
      >
      <span>
          {this.state.selected.remarks
            ? this.state.selected.remarks.length > 20
              ? this.state.selected.remarks.substring(0, 20) + '...'
              : this.state.selected.remarks
            : ''}
            </span>
     
      </Tooltip>
                        </div>
                        </div>

                        <div>





                          <span style={{ fontSize: '12px', display: 'block' }}>
                            Release ID: {this.state.selected.externalReleaseId}
                          </span>
                          <span style={{ fontSize: '12px', display: 'block' }}>
                            Created on: {this.state.selected.createdOn}
                          </span>
                        </div>
                      </div>
                      <div
                        style={{
                          borderBottom: '1px solid #eee',
                          padding: '16px',
                        }}
                      >
                        <div
                          style={{
                            fontSize: '14px',
                            fontWeight: 'bold',
                            color: getColor[this.state.selected.releaseStatus],
                          }}
                        >
                          {this.state.selected.releaseStatus}
                        </div>
                        <span style={{ fontSize: '12px', display: 'block' }}>
                          {this.state.selected.pendingWith}
                        </span>
                      </div>
                     {/* <div
                        style={{
                          borderBottom: '1px solid #eee',
                          padding: '16px',
                        }}
                      >
                        <div style={{ fontSize: '12px', fontWeight: 'bold' }}>
                          No. of price plans
                        </div>
                        <span
                          style={{
                            fontSize: '12px',
                            display: 'block',
                            fontWeight: 'bold',
                          }}
                        >
                          No. of bundles
                        </span>
                        </div> */}
                    </React.Fragment>
                  )}
                  <div style={{ padding: '16px 32px', marginTop: 'auto' }}>
                    <StyledButton
                      style={{ width: '100%' }}
                      onClick={() => {
                        this.props.onReleaseEnter(this.state.selected);
                        this.props.history.push('/editRelease');
                      }}
                    >
                      Edit release details
                    </StyledButton>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        <ModalAction
          label={'Required'}
          show={this.state.show}
          modalClosed={this.modalCloseHandler}
          actionDisabled={this.state.remarks.length === 0}
          actionText={'Create'}
          title={'Create New Release'}
          action={this.actionHandler}
          size={'sm'}
        >
          <Grid item xs={12}>
            <Box mt={2}>
              <span
                style={{
                  fontWeight: 'bold',
                }}
              >
                Release Objective<span style={{ color: '#ff0000' }}>*</span>
              </span>
              <span
                style={{
                  marginLeft: '5px',
                }}
              >
                (Max Length 2000)
              </span>
            </Box>
            <Box mt={2}>
              <TextField
                inputProps={{
                  maxLength: 2000,
                }}
                name='remarks'
                fullWidth
                value={this.state.remarks}
                onChange={this.valueChangeHandler}
                // required={true}
                placeholder='Release Objective'
                rowsMin={4}
                rowsMax={5}
                multiline
                variant='outlined'
              />
            </Box>
            <span>Max Remaining: {2000 - this.state.remarks.length}</span>
          </Grid>

          {/* <TextareaAutosize
                    rowsMin={10} placeholder="Release Objective"
                    style={{ width: '100%' }}
                    name='remarks' value={this.state.remarks} onChange={this.valueChangeHandler} />; */}
        </ModalAction>
        <ModalAction
        show={this.state.showModal}
				size={'sm'}
				modalClosed={this.modalCloseHandler}
				title={'Do You Want to Cancel The Release' }>
        {
					
						<React.Fragment>
							<div
								style={{
									display: 'flex',
									justifyContent: 'center',
									alignItems: 'center',
									minHeight: '20vh',
								}}>
								<Button
									variant="outlined"
									color="primary"
									onClick={this.showCancelHandler
									}
									style={{
										textTransform: 'none',
										marginRight: 20,
                    borderRadius:'20px',
                    cursor:'pointer',
                    boxShadow:'0 5px 10px 0  #cfd4de',

									}}>
									{' '}
									Cancel
								</Button>

								<Button
									variant="outlined"
									color="primary"
									onClick={
										this.cancelRelease}
									style={{
										textTransform: 'none',
                    borderRadius:'20px',
                    cursor:'pointer',
                    boxShadow:'0 5px 10px 0  #cfd4de',
                    
									}}>
									{' '}
									Continue
								</Button>
							</div>
						</React.Fragment>
					
					
				}

        </ModalAction>
      </React.Fragment>
      
    );

    if (this.state.loading) myReleases = <Loader />;
    return myReleases;
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
    roleGroup: state.roleSelected.roleGroup,
    releaseData: state.releaseData.releaseData

  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onReleaseEnter: (releaseData) =>
      dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: releaseData }),
      changeRoleGroup: (roleGroup) =>
      dispatch({ type: actionTypes.CHANGE_ROLE_GROUP, roleGroup }),
      onPopulateApprovers: (workflowApprovers) =>
			dispatch({
				type: actionTypes.WORKFLOW_APPROVER,
				workflowApprovers,
			}),
  };
};





export default connect(
  mapStateToProps,
  mapDispatchToProps
)(WithErrorHandler(withRouter(Releases), axios));

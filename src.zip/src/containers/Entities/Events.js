import React, { Component } from 'react';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../axios-epc';
import Loader from '../../UI/Loader/Loader';
import EventAvailableIcon from '@material-ui/icons/EventAvailable';
import InputAdornment from '@material-ui/core/InputAdornment';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import IconButton from '@material-ui/core/IconButton';
import SearchIcon from '@material-ui/icons/Search';
import Modal from '../../UI/Modal/Modal';
import List from '@material-ui/core/List';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Typography from '@material-ui/core/Typography';
import ExpandMore from '@material-ui/icons/ExpandMore';
import Divider from '@material-ui/core/Divider';
import ExpandLess from '@material-ui/icons/ExpandLess';
import SaveIcon from '@material-ui/icons/Save';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
// import Button from "@material-ui/core/Button";
import Button from '../../UI/Button/Button';
import moment from 'moment';
import StyledButton from '../../UI/Button/Button';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import EventRentalMatrix from '../Entities/Pricing/EventRentalMatrix';
import DeleteIcon from '@material-ui/icons/Delete';

const useStyles = (theme) => ({
  cardHeader: {
    // background: "#546D7A",
    // height: "4.5vh",
    paddingBottom: 0,
  },
  subheader: {
    color: 'rgba(0, 0, 0, 0.87)',
    fontSize: '16px',
    fontWeight: '600',
    // color: "white",
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
  root: {
    width: '100%',
    maxWidth: '99%',
    backgroundColor: theme.palette.background.paper,
    position: 'relative',
    overflow: 'auto',
    maxHeight: 300,
  },
  listSection: {
    backgroundColor: 'inherit',
  },
  ul: {
    backgroundColor: 'inherit',
    padding: 0,
  },
});

class Events extends Component {
  _isMounted = false;

  state = {
    loading: true,
    events: [],
    showEvents: [],
    show: false,
    searchEvents: '',
    showModal: false,
    modalContent: null,
    showCard: 'rules',
  };

  componentDidMount() {
    this._isMounted = true;
    this.getEvents().then(() => {
      this.getBundledEvent().then(() => {
        this.setState({
          loading: false,
        });
      });
    });
  }

  getBundledEvent() {
    return axios
      .get(
        'package/events?id=' +
          this.props.id +
          '&releaseId=' +
          this.props.releaseData.releaseId,
        {
          headers: {
            opId: this.props.userInfo.opId,
          },
        }
      )
      .then((res) => {
        console.log(res);
        res.data.data.catalogId === 'Y'
          ? this.setState({
              selEvent: '',
            })
          : this.setState({
              selEvent: res.data.data.eventId,
            });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }
  deleteMatrix = () => {
    axios
      .get(
        'package/events/delete/matrix?id=' +
          this.props.id +
          '&&releaseID=' +
          this.props.releaseData.releaseId,
        {}
      )
      .then((response) => {
        console.log(response);

        window.location.reload();
        // this.setState({
        //   loading: false,
        // });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  getEvents = () => {
    return axios
      .get(
        'attribute/event/list?releaseId=' + this.props.releaseData.releaseId,
        {
          headers: {
            opId: this.props.userInfo.opId,
          },
        }
      )
      .then((res) => {
        console.log(res);
        let events = [];
        Object.keys(res.data.data).map((event) => {
          events.push({
            val: event + '/' + res.data.data[event],
            show: false,
            content: [],
          });
        });
        this.setState({
          events: events,
          showEvents: events,
        });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  modalCloseHandler = () => {
    this.setState({
      show: false,
    });
  };

  searchHandler = (event) => {
    console.log(event);
    this.setState({ searchEvents: event.target.value });
    let searchItems = [];
    if (event.target.value.length == 0) {
      searchItems = [...this.state.events];
      this.setState({ showEvents: searchItems });
    } else {
      searchItems = this.state.events.filter(function (item) {
        return item.val
          .toUpperCase()
          .includes(event.target.value.toUpperCase());
      });
      this.setState({ showEvents: searchItems });
    }
  };

  eventDetails(item) {
    console.log(item);
    let showItem = !item.show;
    if (!item.show) {
      axios
        .get(
          'attribute/event/basicDetails?releaseId=' +
            this.props.releaseData.releaseId +
            '&eventId=' +
            item.val.split('/')[0],
          {
            headers: {
              opId: this.props.userInfo.opId,
            },
          }
        )
        .then((res) => {
          console.log(res.data.data);
          this.setState({ loading: false });
          this.setState({
            showEvents: this.state.showEvents.map((el) =>
              el.val === item.val
                ? {
                    ...el,
                    show: showItem,
                    content: res.data.data.paramDetailsVo,
                  }
                : el
            ),
          });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else
      this.setState({
        showEvents: this.state.showEvents.map((el) =>
          el.val === item.val
            ? {
                ...el,
                show: showItem,
              }
            : el
        ),
      });
  }

  saveEvent = () => {
    if (this.props.id) {
      this.setState({ loading: true });
      let payload = {};
      let date = moment().format('DD-MMM-YY');
      payload.itemId = this.props.id;
      payload.releaseId = this.props.releaseData.releaseId;
      payload.itemType = this.props.entity;
      payload.eventId = this.state.selEvent;
      payload.createdBy = this.props.userInfo.id;
      payload.createdDate = date;
      payload.startDate = date;
      payload.endDate = '30-Dec-30';
      payload.opId = this.props.userInfo.opId;
      payload.buId = this.props.userInfo.buId;
      console.log(payload);
      axios
        .post('package/events', payload)
        .then((response) => {
          console.log(response);
          this.setState({
            productComponentId: response.data.data,
            loading: false,
          });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      let modalContent = (
        <Typography variant='h6'>
          {' '}
          Submit Basic {this.props.entity} Details first.{' '}
        </Typography>
      );
      this.setState({ modalContent: modalContent, showModal: true });
    }
  };

  errorConfirmedHandler = () => {
    this.setState({ showModal: false });
  };

  render() {
    const { classes } = this.props;

    let events = (
      <React.Fragment>
        <Modal
          show={this.state.showModal}
          modalClosed={this.errorConfirmedHandler}
          title={'Something Went Wrong!'}
        >
          {this.state.modalContent}
        </Modal>
        <Modal
          show={this.state.show}
          modalClosed={this.modalCloseHandler}
          title={'Events'}
        >
          <List style={{ width: '100%', maxHeight: '30vh', overflow: 'auto' }}>
            <TextField
              onChange={this.searchHandler}
              fullWidth
              value={this.state.searchEvents}
              InputProps={{
                startAdornment: (
                  <InputAdornment position='start'>
                    <SearchIcon style={{ color: '#ff1921' }} />
                  </InputAdornment>
                ),
              }}
            />
            {this.state.showEvents.length > 0 ? (
              this.state.showEvents.map((event) => {
                return (
                  <React.Fragment>
                    <ListItem key={event}>
                      <ListItemIcon className={classes.navIcon}>
                        {event.show ? (
                          <ExpandLess
                            style={{ cursor: 'pointer' }}
                            onClick={() => this.eventDetails(event)}
                          />
                        ) : (
                          <ExpandMore
                            style={{ cursor: 'pointer' }}
                            onClick={() => this.eventDetails(event)}
                          />
                        )}
                      </ListItemIcon>
                      <ListItemText
                        style={{ cursor: 'pointer' }}
                        onClick={() => this.eventDetails(event)}
                        primary={event.val}
                      />
                      <SaveIcon
                        style={{ cursor: 'pointer', color: 'green' }}
                        onClick={() => {
                          this.setState({
                            selEvent: event.val,
                          });
                        }}
                      />
                    </ListItem>
                    {event.show && (
                      <TableContainer
                        component={Paper}
                        style={{ marginTp: '3vh' }}
                      >
                        <Table className={classes.table} size='small'>
                          <TableHead>
                            <TableRow>
                              <TableCell>Applied On</TableCell>
                              <TableCell>Id</TableCell>
                              <TableCell>Value</TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {event.content.map((obj) => {
                              return (
                                <TableRow key={obj.attributeId}>
                                  <TableCell
                                    style={{
                                      width: '20%',
                                    }}
                                  >
                                    {obj.attrName}
                                  </TableCell>
                                  <TableCell
                                    style={{
                                      width: '30%',
                                    }}
                                  >
                                    {obj.attributeId}
                                  </TableCell>
                                  <TableCell
                                    style={{
                                      width: '30%',
                                    }}
                                  >
                                    {obj.attrValue}
                                  </TableCell>
                                </TableRow>
                              );
                            })}
                          </TableBody>
                        </Table>
                      </TableContainer>
                    )}

                    <Divider />
                  </React.Fragment>
                );
              })
            ) : (
              <Typography
                variant='h6'
                className={classes.center}
                style={{
                  marginTop: '1.5%',
                }}
              >
                {' '}
                No Events Found.
              </Typography>
            )}
          </List>
        </Modal>
        <h3>Rule Type</h3>
        <RadioGroup
          row
          aria-label='position'
          name='position'
          value={this.state.showCard}
          onChange={(event) => {
            this.setState({
              showCard: event.target.value,
            });
            // if (event.target.value === 'use') {
            //   let getLatestData =
            //     this.state.getLatestData.length > 10
            //       ? 'key'
            //       : this.state.getLatestData + 1;
            //   this.setState({
            //     getLatestData,
            //   });
            //   console.log(getLatestData);
            // } else
            // this.setState({
            //   typeRatePlan: event.target.value,
            // });
          }}
          style={{ marginBottom: '2%' }}
        >
          <FormControlLabel
            value='rules'
            control={<Radio style={{ color: '#ff1921' }} />}
            label='UnConditional'
          />
          <FormControlLabel
            value='matrix'
            control={<Radio style={{ color: '#ff1921' }} />}
            label='Conditional'
          />
        </RadioGroup>
        {this.state.showCard === 'rules' ? (
          <Card>
            <CardHeader
              className={classes.cardHeader}
              classes={{
                subheader: classes.subheader,
              }}
              subheader={'Inclusion & Exclusion Rules'}
            />

            <CardContent>
              <Grid container spacing={1} alignItems='flex-end'>
                <Grid item sm={4}>
                  <TextField
                    onChange={this.searchHandlerUpgrade}
                    disabled
                    fullWidth
                    value={this.state.selEvent}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position='start'>
                          <EventAvailableIcon style={{ color: 'orange' }} />
                        </InputAdornment>
                      ),
                    }}
                  />
                </Grid>
                <Grid item>
                  <IconButton
                    onClick={() => {
                      this.setState({
                        show: true,
                      });
                    }}
                  >
                    <SearchIcon />
                  </IconButton>
                </Grid>
                <Grid item>
                  <IconButton onClick={this.deleteMatrix}>
                    <DeleteIcon style={{ color: 'red', cursor: 'pointer' }} />
                  </IconButton>
                </Grid>
              </Grid>
              {this.props.releaseData.releaseId && (
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'flex-end',
                    alignItems: 'center',
                  }}
                >
                  <StyledButton
                    //   variant="contained"
                    onClick={this.saveEvent}
                    style={{
                      // background: "#02bfa0",
                      textTransform: 'none',
                      marginTop: '1%',
                      marginBottom: '1%',
                      background: '#5dc17f',
                    }}
                  >
                    Save
                  </StyledButton>
                </div>
              )}
            </CardContent>
          </Card>
        ) : (
          <>
            <EventRentalMatrix
              offerVersion={this.state.offerVersion}
              userInfo={this.props.userInfo}
              releaseData={this.props.releaseData}
              id={this.props.id}
              entity={this.props.entity}
            />
          </>

          /* <Grid item sm={4}>
                  <TextField
                    onChange={this.searchHandlerUpgrade}
                    disabled
                    fullWidth
                    value={this.state.selEvent}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position='start'>
                          <EventAvailableIcon style={{ color: 'orange' }} />
                        </InputAdornment>
                      ),
                    }}
                  />
                </Grid> */
          /* <Grid item xs={1}>
                  <IconButton
                    onClick={() => {
                      this.setState({
                        show: true,
                      });
                    }}
                  >
                    <SearchIcon />
                  </IconButton>
                </Grid> */

          /* {this.props.releaseData.releaseId && (
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'flex-end',
                    alignItems: 'center',
                  }}
                >
                  <StyledButton
                    //   variant="contained"                                               
                    onClick={this.saveEvent}
                    style={{
                      // background: "#02bfa0",
                      textTransform: 'none',
                      marginTop: '1%',
                      marginBottom: '1%',
                      background: '#5dc17f',
                    }}
                  >
                    Save
                  </StyledButton>
                </div>
              )} */
        )}
      </React.Fragment>
    );
    if (this.state.loading) events = <Loader relative />;

    return events;
  }
}

export default withStyles(useStyles)(WithErrorHandler(Events, axios));

import React, { Component } from "react";
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import axios from "../../axios-epc";
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";
import { withStyles } from "@material-ui/core/styles";
import LastPageIcon from "@material-ui/icons/LastPage";
import { connect } from "react-redux";
import Loader from "../../UI/Loader/Loader";
import Input from "../../UI/Input/Input";
import Grid from "@material-ui/core/Grid";
import Button from "@material-ui/core/Button";
import moment from "moment";
import Tooltip from "@material-ui/core/Tooltip";
import MultiSelect from "../../UI/Input/MultiSelect";
import Box from "@material-ui/core/Box";
import CreatableSelect from "react-select/creatable";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Typography from "@material-ui/core/Typography";
import Divider from "@material-ui/core/Divider";
import Select from "react-select";
import MaterialTable, { MTableToolbar } from "material-table";
import { forwardRef } from "react";
import AddBox from "@material-ui/icons/AddBox";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import Check from "@material-ui/icons/Check";
import ChevronLeft from "@material-ui/icons/ChevronLeft";
import ChevronRight from "@material-ui/icons/ChevronRight";
import Clear from "@material-ui/icons/Clear";
import DeleteOutline from "@material-ui/icons/DeleteOutline";
import Edit from "@material-ui/icons/Edit";
import FilterList from "@material-ui/icons/FilterList";
import FirstPage from "@material-ui/icons/FirstPage";
import LastPage from "@material-ui/icons/LastPage";
import Remove from "@material-ui/icons/Remove";
import SaveAlt from "@material-ui/icons/SaveAlt";
import Search from "@material-ui/icons/Search";
import ViewColumn from "@material-ui/icons/ViewColumn";
import { ThemeProvider, IconButton } from "@material-ui/core";
import { createMuiTheme } from "@material-ui/core/styles";
import KeyboardArrowDownIcon from "@material-ui/icons/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@material-ui/icons/KeyboardArrowUp";
import * as actionTypes from "../../store/actions/actionTypes";
import Title from "../../UI/Typography/Title";

const CONFIG = {
  radioColor: "#3f74c5",
  buttonBG: "#ff1921",
  buttonColor: "#FFF",
  linkColor: "#ff1921",
};

const tableIcons = {
  Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  DetailPanel: forwardRef((props, ref) => (
    <ChevronRight {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  PreviousPage: forwardRef((props, ref) => (
    <ChevronLeft {...props} ref={ref} />
  )),
  ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};

const theme = createMuiTheme({
  overrides: {
    MuiTable: {
      root: {
        tableLayout: "fixed",
      },
    },
    MuiTableCell: {
      root: {
        padding: "10px",
        paddingLeft: "10px",
      },
    },
    MuiPaper: {
      width: "100%",
    },
  },
});

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: "#525354",
    color: "white",
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

const useStyles = (theme) => ({
  cardHeader: {
    background: "#546D7A",
    height: "4.5vh",
  },
  subheader: {
    color: "white",
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "96%",
    flexShrink: 0,
  },
});

const CustomPaginationComponent = (props) => {
  const { page, rowsPerPage, count, onPageChange } = props;
  let from = rowsPerPage * page + 1;
  let to = rowsPerPage * (page + 1);
  if (to > count) {
    to = count;
  }
  return (
    <div style={{ background: "#272c2f" }}>
      {" "}
      <Grid container alignItems="center" justify="center">
        {" "}
        <Grid item>
          {" "}
          <IconButton
            disabled={page === 0}
            onClick={(e) => onPageChange(e, page - 1)}
            style={{
              fontFamily: "BrighterSans",
              color: page === 0 ? "disabled" : "#fff",
              fontSize: "18px",
            }}
          >
            Previous{" "}
            <span style={{ margin: "0 10px", color: "rgba(255,255,255, 0.4" }}>
              |
            </span>{" "}
            <KeyboardArrowUpIcon
              // fontSize="small"
              color={page === 0 ? "disabled" : "#fff"}
            />{" "}
          </IconButton>{" "}
          <IconButton
            style={{ padding: "12px 0", fontSize: "18px", cursor: "default" }}
          >
            <span style={{ color: "rgba(255,255,255, 0.2" }}>|</span>
          </IconButton>
          {/* </Grid>{" "}
        <Grid item> */}{" "}
          <IconButton
            disabled={to >= count}
            onClick={(e) => onPageChange(e, page + 1)}
            style={{
              fontFamily: "BrighterSans",
              color: to < count ? "#fff" : "rgba(0, 0, 0, 0.26)",
              fontSize: "18px",
            }}
          >
            {" "}
            <KeyboardArrowDownIcon
              // fontSize="small"
              color={to < count ? "#fff" : "disabled"}
            />{" "}
            <span style={{ margin: "0 10px", color: "rgba(255,255,255, 0.4" }}>
              |
            </span>
            Next
          </IconButton>{" "}
        </Grid>{" "}
      </Grid>{" "}
    </div>
  );
};

class AdvanceSearch extends Component {
  _isMounted = false;

  state = {
    SearchType: "",
    loading: true,
    searchCriteria: [],
    schema: [],
    searchData: {},
    searchEntites: [],
    selSearchCriteria: [],
    searchDataInput: {},
    data: [],
    columns: [
      {
        title: "Entity Id",
        field: "responseId",
        sorting: true,
        cellStyle: {
          width: "13%",
          color:
            // this.props.releaseData.releaseId
            // ?
            CONFIG.linkColor || "#ff1921",
          // : "rgba(0, 0, 0, 0.87)",
        },
      },

      {
        title: "Entity Name",
        field: "responseName",
        sorting: true,
        cellStyle: { width: "8%" },
      },
    ],
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState["SearchType"] !== this.state["SearchType"]) {
      if (this.state.SearchType) {
        this.state.selSearchCriteria.map((el) => {
          this.setState({ [el]: [] });
        });
        this.setState({ loading: true });
        axios
          .post("dashboard/AdvSearch/select", {
            searchIn: this.state.SearchType,
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          })
          .then((res) => {
            console.log(res);
            let searchDataInput = {};
            Object.keys(res.data.data).map((key) => {
              searchDataInput = {
                ...searchDataInput,
                ...res.data.data[key],
              };
            });
            console.log(searchDataInput);
            this.setState({
              loading: false,
              searchData: res.data.data,
              searchEntites: [],
              selSearchCriteria: [],
              searchCriteria: [],
              searchDataInput: searchDataInput,
              data: [],
            });
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      }
    }
  }

  componentDidMount() {
    this._isMounted = true;
    this.setState({
      loading: false,
    });
    this.setState({ SearchType: "Package" });
  }

  backToRelease = () => {
    this.props.history.push("/editRelease");
  };

  attributeGrpData() {
    return axios
      .get("package/attrGrp?releaseId=" + this.props.releaseData.releaseId, {
        headers: {
          opId: this.props.userInfo.opId,
        },
      })
      .then((res) => {
        console.log(res);
        let attrGrps = [];
        res.data.data.map((attributeGrp) => {
          attrGrps.push(attributeGrp.attrGrpName);
        });
        let searchData = { ...this.state.searchData };
        console.log(searchData);

        Object.keys(this.state.searchData).map((entity) => {
          Object.keys(this.state.searchData[entity]).map((field) => {
            searchData[entity][field] = {
              ...this.state.searchDataInput[field],
            };
          });
        });
        searchData["Attribute"] = {
          ...this.state.searchData["Attribute"],
          Attribute: {
            constraint: attrGrps.join(),
            type: "MultiSelect",
          },
        };
        console.log(searchData);

        let searchDataInput = {};
        Object.keys(searchData).map((key) => {
          searchDataInput = {
            ...searchDataInput,
            ...searchData[key],
          };
        });
        console.log(searchDataInput);

        this.setState({
          searchData: searchData,
          searchDataInput: searchDataInput,
        });
      });
  }

  inputHelper(value, name) {
    let formElement = {
      ...value,
      uiName: name,
    };
    if (formElement.type == "MultiSelect") {
      return (
        <Grid item xs={12} sm={12} key={formElement.uiName}>
          <Box>
            <span style={{}}>{formElement.uiName}</span>
          </Box>
          <Box mt={2}>
            {/* < MultiSelect
                        refLovs={formElement.constraint ? formElement.constraint.split(',') : []}
                        value={this.state[formElement.uiName]}
                        changed={(selected) => {
                            console.log(selected)
                            if (!(selected instanceof Array))
                                selected = [selected]

                            this.setState({
                                [formElement.uiName]:
                                    selected
                            })
                        }
                        }
                    /> */}

            <Select
              menuPlacement="top"
              menuPortalTarget={document.body}
              styles={{
                menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                option: (base, state) => ({
                  ...base,
                  fontSize: "12px",
                }),
              }}
              isMulti
              closeMenuOnSelect={false}
              onChange={(selectedOptions) => {
                console.log(selectedOptions);
                let lovs = [];
                if (selectedOptions) {
                  selectedOptions.map((lov) => {
                    lovs.push(lov.value);
                  });
                }
                this.setState({
                  [formElement.uiName]: lovs,
                });
              }}
              value={
                this.state[formElement.uiName]
                  ? this.state[formElement.uiName].map((lov) => {
                      return {
                        value: lov,
                        label: lov,
                      };
                    })
                  : []
              }
              options={
                formElement.constraint
                  ? formElement.constraint.split(",").map((lov) => {
                      return {
                        value: lov,
                        label: lov,
                      };
                    })
                  : []
              }
            />
          </Box>
        </Grid>
      );
    } else if (formElement.type == "Creatable") {
      return (
        <Grid item xs={12} sm={10} key={formElement.uiName}>
          <Box>
            <span style={{}}>{formElement.uiName}</span>
          </Box>
          <Box mt={2}>
            <CreatableSelect
              isMulti
              onChange={(selectedOptions) => {
                console.log(selectedOptions);
                let lovs = [];
                if (selectedOptions) {
                  selectedOptions.map((lov) => {
                    lovs.push(lov.value);
                  });
                }
                this.setState({
                  [formElement.uiName]: lovs,
                });
              }}
              value={
                this.state[formElement.uiName]
                  ? this.state[formElement.uiName].map((lov) => {
                      return {
                        value: lov,
                        label: lov,
                      };
                    })
                  : []
              }
              options={
                formElement.constraint
                  ? formElement.constraint.split(",").map((lov) => {
                      return {
                        value: lov,
                        label: lov,
                      };
                    })
                  : []
              }
            />
          </Box>
        </Grid>
      );
    } else
      return (
        <Input
          resize
          key={formElement.uiName}
          value={this.state[formElement.uiName]}
          // disabled={formElement.isDisabled == 'Y' ? true : false}
          // required={formElement.isMandatory == 'Y' ? true : false}
          changed={(event) => {
            if (!event.target) {
              this.setState({
                [formElement.uiName]: event,
              });
            } else {
              if (event.target.type !== "checkbox")
                this.setState({
                  [formElement.uiName]: event.target.value,
                });
              else {
                console.log(event.target.checked);
                this.setState({
                  [formElement.uiName]: event.target.checked,
                });
              }
            }
          }}
        />
      );
  }

  searchHandler = () => {
    let payload = { ...this.state.searchData };
    Object.keys(payload).map((entity) => {
      Object.keys(payload[entity]).map((field) => {
        payload[entity][field] = this.state[field] ? this.state[field] : [];
      });
    });
    let searchPayload = {
      searchIn: this.state.SearchType,
      opId: this.props.userInfo.opId,
      buId: this.props.userInfo.buId,
      search: [payload],
    };
    console.log(searchPayload);

    this.setState({ loading: true });
    axios
      .post("dashboard/AdvSearch/search", searchPayload)
      .then((res) => {
        console.log(res);
        this.setState({
          loading: false,
          data: res.data.data,
        });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  render() {
    const { classes } = this.props;

    let advanceSearch = (
      <div>
        <Title>
          Advance Search{" "}
          {this.props.releaseData.releaseId &&
            `( Release ${this.props.releaseData.releaseId} )`}
        </Title>
        {/* <Card style={{ overflow: "visible", minHeight: "90vh" }}>
          <CardHeader
            className={classes.cardHeader}
            classes={{
              subheader: classes.subheader,
            }}
            action={
              this.props.releaseData.releaseId && (
                <React.Fragment>
                  <div>
                    <LightTooltip title="Back To Release" arrow>
                      <LastPageIcon
                        onClick={this.backToRelease}
                        style={{ color: "white", cursor: "pointer" }}
                      />
                    </LightTooltip>
                  </div>
                </React.Fragment>
              )
            }
            subheader={
              this.props.releaseData.releaseId
                ? "Advance Search You are inside release " +
                  this.props.releaseData.releaseId
                : "Advance Search"
            }
          />

          <CardContent style={{ marginBottom: "2%" }}> */}
        <Grid
          container
          alignContent="flex-start"
          spacing={2}
          style={{ overflow: "visible", marginBottom: "1vh" }}
        >
          {/* <Grid
            item
            xs={4}
            sm={4}
            md={2}
            style={{
              display: "flex",
              alignItems: "center",
            }}
          >
            <Typography variant="subtitle1"> Search</Typography>
          </Grid> */}
          <Grid item xs={8} sm={8} md={10}>
            <RadioGroup
              row
              aria-label="position"
              name="position"
              defaultValue="top"
              value={this.state.SearchType}
              onChange={(event) => {
                this.setState({
                  SearchType: event.target.value,
                });
              }}
            >
              <FormControlLabel
                value={"Package"}
                control={
                  <Radio style={{ color: CONFIG.radioColor || "#3f74c5" }} />
                }
                label="Package"
              />
              <FormControlLabel
                value="Product"
                control={
                  <Radio style={{ color: CONFIG.radioColor || "#3f74c5" }} />
                }
                label="Product"
              />
            </RadioGroup>
          </Grid>
        </Grid>
        <Grid container alignContent="flex-start" spacing={2}>
          <Grid item xs={6} sm={6}>
            <Grid container alignContent="flex-start" spacing={2}>
              <Grid item xs={12} sm={6}>
                {/* <Box> */}
                <span style={{ fontSize: 14 }}>Entities</span>
                {/* </Box> */}
                <Box mt={2}>
                  <MultiSelect
                    refLovs={Object.keys(this.state.searchData)}
                    value={this.state.searchEntites}
                    changed={(selected) => {
                      let searchCriteria = [];
                      let removeInput = [];
                      let selSearchCriteria = [...this.state.selSearchCriteria];
                      let diff = this.state.searchEntites.filter(
                        (x) => !selected.includes(x)
                      );
                      diff.map((entity) => {
                        removeInput.push(
                          ...Object.keys(this.state.searchData[entity])
                        );
                      });
                      selected.map((entity) => {
                        searchCriteria.push(
                          ...Object.keys(this.state.searchData[entity])
                        );
                      });
                      console.log(removeInput);
                      console.log(searchCriteria);

                      removeInput.map((el) => {
                        this.setState({ [el]: [] });
                        if (selSearchCriteria.includes(el))
                          selSearchCriteria.splice(
                            selSearchCriteria.indexOf(el),
                            1
                          );
                      });
                      // selSearchCriteria = selSearchCriteria.
                      //     filter((el) => {
                      //         this.setState({ [el]: [] })
                      //         return !removeInput.includes(el)
                      //     }
                      //     );

                      this.setState({
                        searchEntites: selected,
                        searchCriteria: searchCriteria,
                        selSearchCriteria: selSearchCriteria,
                      });
                    }}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} sm={6}>
                {/* <Box> */}
                <span style={{ fontSize: 14 }}>Search Criteria</span>
                {/* </Box> */}
                <Box mt={2}>
                  <MultiSelect
                    refLovs={this.state.searchCriteria}
                    value={this.state.selSearchCriteria}
                    changed={(selected) => {
                      if (
                        !this.state.selSearchCriteria.includes("Attribute") &&
                        selected.includes("Attribute")
                      ) {
                        console.log("Attribute");
                        this.setState({ loading: true });
                        this.attributeGrpData().then(() => {
                          this.setState({ loading: false });
                        });
                      }
                      let diff = this.state.selSearchCriteria.filter(
                        (x) => !selected.includes(x)
                      );
                      diff.map((el) => {
                        this.setState({
                          [el]: [],
                        });
                      });
                      this.setState({
                        selSearchCriteria: selected,
                      });
                    }}
                  />
                </Box>
              </Grid>
            </Grid>
            {/* <Divider
              style={{
                background: "grey",
                marginTop: "2vh",
                marginBottom: "2vh",
              }}
            /> */}

            {/* <div style={{ maxHeight: "65vh", overflow: "auto" }}> */}
          </Grid>

          {this.state.selSearchCriteria &&
            this.state.selSearchCriteria.length > 0 && (
              <Grid item xs={12}>
                <Card>
                  <CardContent>
                    <div style={{ marginTop: "8px" }}>
                      <Grid container spacing={2}>
                        {this.state.selSearchCriteria.map((formElement) => {
                          return (
                            <Grid item xs={3}>
                              <div style={{ marginBottom: "2vh" }}>
                                {this.inputHelper(
                                  this.state.searchDataInput[formElement],
                                  formElement
                                )}
                              </div>
                            </Grid>
                          );
                        })}
                      </Grid>

                      {/* </div> */}

                      <div style={{ textAlign: "right" }}>
                        <Button
                          style={{
                            textTransform: "capitalize",
                            background: CONFIG.buttonBG || "#ff1921",
                            color: CONFIG.buttonColor || "#fff",
                            fontSize: "16px",
                            borderRadius: "50px",
                            padding: "6px 60px",
                          }}
                          onClick={this.searchHandler}
                        >
                          Search
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Divider style={{ margin: "20px 0" }} />
              </Grid>
            )}

          <Grid item xs={12} sm={12}>
            <ThemeProvider theme={theme}>
              <MaterialTable
                tableRef={this.selectTable}
                icons={tableIcons}
                title={"Search Results"}
                columns={this.state.columns}
                data={this.state.data}
                style={{ padding: "20px" }}
                onRowClick={
                  // this.props.releaseData.releaseId
                  //   ?
                  (event, rowData) => {
                    console.log(rowData.responseId);
                    if (this.state.SearchType == "Package") {
                      this.props.changePackageActiveStep(0);
                      let pkgData = {};
                      pkgData["packageId"] = rowData.responseId;
                      this.props.onPackageEnter(pkgData);
                      this.props.changePackageKey(this.props.pkgKey + "1");
                      this.props.history.push("/planConfiguration");
                    } else if (this.state.SearchType == "Product") {
                      this.props.changeProductActiveStep(0);
                      let proData = {};
                      proData["productId"] = rowData.responseId;
                      this.props.onProductEnter(proData);
                      this.props.changeProductKey(this.props.productKey + "1");
                      this.props.history.push("/productConfiguration");
                    }
                  }
                  // : null
                }
                options={{
                  pageSize: 10,
                  pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
                  toolbar: true,
                  paging: true,
                  rowStyle: {
                    fontSize: "14px",
                    // fontWeight: "600"
                  },
                  headerStyle: {
                    fontWeight: "bold",
                  },
                  searchFieldAlignment: "left",
                  searchFieldVariant: "outlined",
                  showTitle: false,
                  searchFieldStyle: {
                    borderRadius: 50,
                    border: "1px solid rgba(0, 0, 0, 0.04)",
                    background: "#fff",
                    height: 40,
                    width: 560,
                  },
                }}
                components={{
                  Pagination: (props) => {
                    return <CustomPaginationComponent {...props} />;
                  },
                  Toolbar: (props) => (
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        marginLeft: "-24px",
                        // padding: "0 24px 0 0",
                      }}
                    >
                      <MTableToolbar {...props} />
                    </div>
                  ),
                }}
              />
            </ThemeProvider>
          </Grid>
        </Grid>
        {/* </CardContent>
        </Card> */}
      </div>
    );

    if (this.state.loading) advanceSearch = <Loader />;

    return advanceSearch;
  }
}

const mapStateToProps = (state) => {
  return {
    releaseData: state.releaseData.releaseData,
    userInfo: state.login.loggedInUserInfo,
    pkgKey: state.packageData.pkgKey,
    productKey: state.productData.productKey,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onPackageEnter: (packageData) =>
      dispatch({ type: actionTypes.INSIDE_PACKAGE, packageData: packageData }),
    changePackageKey: (pkgKey) =>
      dispatch({ type: actionTypes.CHANGE_PACKAGE_KEY, pkgKey: pkgKey }),
    changePackageActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
        activeStep: activeStep,
      }),
    changeProductKey: (productKey) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_KEY,
        productKey: productKey,
      }),
    onProductEnter: (productData) =>
      dispatch({ type: actionTypes.INSIDE_PRODUCT, productData: productData }),
    changeProductActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP,
        activeStep: activeStep,
      }),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(AdvanceSearch, axios)));

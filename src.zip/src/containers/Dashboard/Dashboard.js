import React, { Component } from "react";
import Releases from "./Releases";
import Attachment from "./Attachment";
import AuditLogs from "./AuditLogs";
import Literature from "./Literature";
import Workflow from "./Workflow";
import TreeView from "./TreeView";
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import { connect } from "react-redux";
import Loader from "../../UI/Loader/Loader";
import ServiceSelection from './ServiceSelection';
import axios from "axios";

class Dashboard extends Component {
  _isMounted = false;

  state = {
    literature: false,
    attachment: false,
    treeView: false,
    auditLogs: false,
    workflow: false,
    relData: {},
    approversVersion: "",
    approversData: {},
    loading: false,
    
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;
    if (this._isMounted) this.setState({ loading: true });
    // this.versionsHandler().then(() => {
    this.approversDataHandler().then(() => {
      if (this._isMounted) this.setState({ loading: false });
      // })
    });
  }
  // versionsHandler() {
  //     return axios
  //         .all([
  //             axios.get(
  //                 process.env.REACT_APP_URL +
  //                 "config/version?entityName=approversData",
  //                 {
  //                     headers: {
  //                         opId: this.props.userInfo.opId,
  //                         buId: this.props.userInfo.buId
  //                     }
  //                 }
  //             )
  //         ])
  //         .then(
  //             axios.spread((approversDataVersion) => {
  //                 console.log(approversDataVersion);
  //                 if (this._isMounted)
  //                     this.setState({ approversVersion: approversDataVersion.data.data.version })
  //             })
  //         )
  //         .catch(error => {
  //             console.log(error)
  //             if (this._isMounted)
  //                 this.setState({ loading: false })
  //         });
  // }

  approversDataHandler(isInRelease) {
    console.log('fetching from api');
   
		const opId = this.props?.userInfo?.opId ?? this.userInfo.opId;
		const buId = this.props?.userInfo?.buId ?? this.userInfo.buId;
		const authUserId = this.props?.userInfo?.id ?? this.userInfo.id;
		const Authorization = this.props?.userInfo?.jwt ?? this.userInfo.jwt;
    const role=this.props?.roleGroup?? this.roleGroup;
		return axios
			.get(process.env.REACT_APP_URL + 'TeleAuthentication/approver', {
				headers: {
					opId: opId,
					buId: buId,
					// role: localStorage.getItem('isB2c') === 'true' ? 'b2c' : 'b2b',
					 role: role,
					lob: 'Postpaid',
					authUserId: authUserId,
					Authorization: 'Bearer ' + Authorization,
				},
			})
			.then((res) => {
				let approvalData = res.data.data;
				if (this._isMounted)
					this.setState({ approversData: { ...approvalData } });
				localStorage.setItem('approversData', JSON.stringify(approvalData));
				if (isInRelease) {
					this.props.onPopulateApprovers(approvalData);
				} else {
					this.onPopulateApprovers(approvalData);
				}
				localStorage.approversData_version = this.state.approversVersion;
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
  }
  attachmentHandler = (relData) => {
    this.setState({ relData: { ...relData } });
    this.setState({ attachment: true });
  };
  auditLogsHandler = (relData) => {
    this.setState({ relData: { ...relData } });
    this.setState({ auditLogs: true });
  };

  literatureHandler = (relData) => {
    this.setState({ relData: { ...relData } });
    this.setState({ literature: true });
  };

  workflowHandler = (relData) => {
    this.setState({ relData: { ...relData } });
    this.setState({ workflow: true });
  };

  treeViewHandler = (relData) => {
     this.setState({ relData: { ...relData } });
    this.setState({ treeView: true });
  };
  showAttachmentHandler = () => {
    this.setState({ attachment: false });
  };

  showTreeViewHandler = () => {
    this.setState({ treeView: false });
  };

  showLiteratureHandler = () => {
    this.setState({ literature: false });
  };

  showAuditLogsHandler = () => {
    this.setState({ auditLogs: false });
  };
  showWorkflowHandler = () => {
    this.setState({ workflow: false });
  };

  


  render() {

    let dashboard = (
    
      <React.Fragment>
      {
        this.state.literature ? (
          <Literature
            userInfo={this.props.userInfo}
            showLiterature={this.showLiteratureHandler}
            releaseData={this.state.relData}
          />
        ) : null}
        {this.state.treeView ? (
          <TreeView
            userInfo={this.props.userInfo}
            showTreeView={this.showTreeViewHandler}
            releaseData={this.state.relData}
          />
        ) : null}
        {this.state.attachment ? (
          <Attachment
            userInfo={this.props.userInfo}
            showAttachment={this.showAttachmentHandler}
            releaseData={this.state.relData}
          />
        ) : null}
        {this.state.auditLogs ? (
          <AuditLogs
            showAuditLogs={this.showAuditLogsHandler}
            releaseData={this.state.relData}
          />
        ) : null}
        {this.state.workflow ? (
          <Workflow
            showWorkflow={this.showWorkflowHandler}
            userInfo={this.props.userInfo}
            releaseData={this.state.relData}
            approvers={this.state.approversData}
          />
        ) : null}
        {this.props.roleGroup ? <Releases
          attachmentUpload={this.attachmentHandler}
          auditLogs={this.auditLogsHandler}
          literature={this.literatureHandler}
          workflow={this.workflowHandler}
          treeView={this.treeViewHandler}
          approverHandler={this.approversDataHandler}
        /> : <ServiceSelection/>}
      </React.Fragment>
    
    );
    if (this.state.loading) dashboard = <Loader />;
    return dashboard;
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
    roleGroup: state.roleSelected.roleGroup,
  };
};




export default connect(mapStateToProps)(WithErrorHandler(Dashboard, axios));

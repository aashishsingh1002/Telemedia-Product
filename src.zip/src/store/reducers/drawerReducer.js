import * as actionTypes from '../actions/actionTypes';

const initialState = {
    open: true
};

const drawerToggle = (state, action) => {
    return {
        ...state,
        open: action.open,
    }
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.DRAWER_TOGGLE: return drawerToggle(state, action);
        default:
            return state;
    }
};

export default reducer;
import React, { Component } from 'react';
import ModalAction from '../../UI/ModalAction/ModalAction';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import { withStyles } from '@material-ui/core/styles';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Autocomplete from '@material-ui/lab/Autocomplete';
import TextField from '@material-ui/core/TextField';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
import Button from '../../UI/Button/Button';
import InputLabel from '@material-ui/core/InputLabel';
import BasicDetails from './BasicDetails';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import { useLocation, useHistory } from 'react-router-dom';

function Alert(props) {
  return <MuiAlert elevation={6} variant='filled' {...props} />;
}
const useStyles = (theme) => ({
  center: {
    textAlign: 'center',
  },
  root: {
    '& .MuiPaper-root': {
      width: '100%',
    },
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '33.33%',
    flexShrink: 0,
  },
});

class SelectApprover extends Component {
  _isMounted = false;

  constructor(props) {
    super(props);

    // cellStyle: { width: '20%' }
    this.state = {
      approvers: [],
      showModal: false,
      show: true,
      loading: true,
      expanded: false,
      worklowVariables: {},
      smsNotiData: {},
      data: [],
      workflowType: 'CVM',
      openSnack: false,
    };
  }
  workflowVariableChangeHandler(event, varName) {
    let worklowVariables = {
      ...this.state.worklowVariables,
    };
    worklowVariables[varName] = event.target.value;
    this.setState({ worklowVariables: worklowVariables });
  }

  modalCloseHandler = () => {
    this.setState({ show: false });
    this.props.showWorkflow();
  };

  approversDataHandler(id) {
    const opId = this.props?.userInfo?.opId ?? this.userInfo.opId;
		const buId = this.props?.userInfo?.buId ?? this.userInfo.buId;
		const authUserId = this.props?.userInfo?.id ?? this.userInfo.id;
		const Authorization = this.props?.userInfo?.jwt ?? this.userInfo.jwt;
    return axios
      .get(process.env.REACT_APP_URL + 'TeleAuthentication/approver', {
        headers: {
          opId: opId,
          buId:buId,
          role: this.props.roleGroup,
          lob: 'Postpaid',
          // circle: 'Hobs',
          authUserId:authUserId,
					Authorization: Authorization,
          
        },
      })
      .then((res) => {
        console.log(res);
        if (res) {
          let workflow = {};
          let smsNotiData = {};

          Object.keys(res.data.data).forEach((key) => {
            res.data.data[key].filter((el) => {
              smsNotiData[el['grpName']] = {
                primarymail: el['primarysignatory'][0]
                  ? el['primarysignatory'][0]
                  : null,
                secondarymail: el['primarysignatory'][1]
                  ? el['primarysignatory'][1]
                  : null,
              };
              if (el['disabled'] == 'true')
                workflow[el['varName']] = 'Mandatory';
              else workflow[el['varName']] = 'FYI';
            });
          });
          this.setState({
            approvers: { ...res.data.data },
            worklowVariables: workflow,
            smsNotiData,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  componentWillUnmount() {
    this._isMounted = false;
  }
  componentDidMount = () => {
    this._isMounted = true;
    this.setState({ loading: true });

    this.approversDataHandler().then(() => {
      this.setState({ loading: false });
    });
  };
  handleClose = (event, reason) => {
    this.setState({ openSnack: false });
  };
  changeHandler = (panel) => (event, isExpanded) => {
    this.setState({ expanded: isExpanded ? panel : false });
  };
  initiateApprovalHandler = () => {
    console.log(this.props.releaseData);
    console.log(this.props.releaseData.pendingWith);
    if (this.props.releaseData.pendingWith == 'WorkFlow Not Initiated') {
      console.log(this.state.workflowType);
      if (this.state.workflowType) {
        this.setState({ loading: true });
        let variables = {};
        variables.releaseCreatedBy = {
          value: this.props.releaseData.createdBy,
          type: 'String',
        };
        variables.releaseId = {
          value: this.props.releaseData.releaseId,
          type: 'String',
        };
        variables.releaseObjective = {
          value: this.props.releaseData.remarks,
          type: 'String',
        };
        variables.releaseCreationDate = {
          value: this.props.releaseData.createdOn,
          type: 'String',
        };
        variables.releaseStatus = {
          value: this.props.releaseData.releaseStatus,
          type: 'String',
        };
        let worklowVariables = {};
        Object.keys(this.state.worklowVariables).filter((key) => {
          if (this.state.worklowVariables[key] == 'Mandatory')
            worklowVariables[key] = {
              value: true,
            };
          else
            worklowVariables[key] = {
              value: false,
            };
        });
        let smsNotiPayload = {};
        let roles = [];
        Object.keys(this.state.approvers).map((role) => {
          this.state.approvers[role].map((approver) => {
            let obj = {};
            obj.taskname = approver.grpName;
            obj.primarymail =
              this.state.smsNotiData[approver.grpName].primarymail;
            obj.secondarymail =
              this.state.smsNotiData[approver.grpName].secondarymail;
            obj.varname = approver.varName;
            obj.value =
              this.state.worklowVariables[approver.varName].toLowerCase();
            roles.push(obj);
          });
        });
        smsNotiPayload.roles = roles;
        console.log(smsNotiPayload);
        let payloadVar = {};
        payloadVar.variables = worklowVariables;
        let payloadWorkflowStart = {};
        payloadWorkflowStart.variables = variables;
        payloadWorkflowStart.businessKey = 'myBusinessKey';
        payloadWorkflowStart.withVariablesInReturn = true;

        let url = 'Telerest/process-definition/key/cvmflow/start';
        if (this.state.workflowType === 'Device')
          url = 'Telerest/process-definition/key/devflow/start';
        else if (this.state.workflowType === 'Online')
          url = 'Telerest/process-definition/key/Onflow/start';
        else if (this.props.userInfo.opId === 'HOB')
          url = 'Telerest/process-definition/key/cloud_flow/start';

        console.log(url);
        console.log('url hit');
        console.log('opid' + this.props.userInfo.opId);
        console.log(payloadWorkflowStart);
        axios
          .post(url, payloadWorkflowStart)
          .then((response) => {
            axios
              .get('Telecustom/taskId?executionId=' + response.data.id)
              .then((res) => {
                console.log(res);
                console.log(res.data.data.taskId);
                axios
                  .post(
                    'Telerest/task/' + res.data.data.taskId + '/complete',
                    payloadVar,
                    {
                      headers: {
                        'Content-Type': 'application/json',
                      },
                    }
                  )
                  .then((response) => {
                    console.log(response);
                    setTimeout(() => {
                      this.props.history.push('/');
                    }, 2000);
                    // let url =
                    //   'dashboard/notifyApproval?createdBy=' +
                    //   this.props.userInfo.id +
                    //   '&releaseId=' +
                    //   this.props.releaseData.releaseId +
                    //   '&opId=' +
                    //   this.props.userInfo.opId +
                    //   '&buId=' +
                    //   this.props.userInfo.buId;

                    // axios
                    //   .get(url, {})
                    //   .then((response) => {
                    //     this.setState({ loading: false, openSnack: true });
                    //     //this.modalCloseHandler();
                    //     // window.location.reload();
                    //     setTimeout(() => {
                    //       this.props.history.push('/');
                    //     }, 2000);
                    //   })
                    //   .catch((error) => {
                    //     console.log(error);
                    //     this.setState({ loading: false });
                    //   });
                    // // axios
                    //     .post(
                    //         "SmsNotificationService/sendsms/" +
                    //         this.props.releaseData.releaseId,
                    //         smsNotiPayload,
                    //         {
                    //             headers: {
                    //                 opId: this.props.userInfo.opId,
                    //                 buId: this.props.userInfo.buId,
                    //                 lob: "Postpaid",
                    //                 initiateapproval: true
                    //             }
                    //         }
                    //     )
                    //     .then(response => {
                    //         console.log(response);
                    //         // this.setState({ loading: false })
                    //         this.modalCloseHandler();
                    //         window.location.reload();

                    //     })
                    //     .catch(error => {
                    //         console.log(error);
                    //         this.setState({ loading: false })

                    //     });
                  })
                  .catch((error) => {
                    console.log(error);
                    this.setState({ loading: false });
                  });
              })
              .catch((error) => {
                console.log(error);
                this.setState({ loading: false });
              });
          })
          .catch((error) => {
            console.log(error);
            this.setState({ loading: false });
          });
      }
    } else this.setState({ showModal: true });
  };
  render() {
    const { classes } = this.props;
    let panels = [];

    Object.keys(this.state.approvers).forEach((key) => {
      let panel = null;
      panel = (
        <Accordion
          key={key}
          expanded={this.state.expanded === key}
          onChange={this.changeHandler(key)}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls='panel1bh-content'
            id='panel1bh-header'
          >
            <Typography className={classes.heading}>{key}</Typography>
          </AccordionSummary>
          <AccordionDetails style={{ display: 'block' }}>
            <TableContainer component={Paper} style={{ overflow: 'visible' }}>
              <Table aria-label='collapsible table'>
                <TableHead>
                  <TableRow>
                    <TableCell>Group</TableCell>
                    <TableCell>Primary Signatory</TableCell>
                    <TableCell>Secondary Signatory</TableCell>
                    <TableCell>Mandatory / FYI / N/A</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {this.state.approvers[key].map((row) => {
                    return (
                      <TableRow className={classes.root} key={row.grpName}>
                        <TableCell style={{ width: '15%' }}>
                          {row.grpName}
                        </TableCell>

                        <TableCell style={{ width: '25%' }}>
                         {/* // <Autocomplete
                          //   disableClearable
                          //   value={
                          //     this.state.smsNotiData[row.grpName].primarymail
                          //   }
                          //   options={row.primarysignatory}
                          //   onChange={(event, selected) => {
                          //     let smsNotiData = {
                          //       ...this.state.smsNotiData,
                          //     };
                          //     let approveData = {
                          //       ...smsNotiData[[row.grpName]],
                          //     };
                          //     approveData.primarymail = selected;
                          //     smsNotiData[row.grpName] = approveData;
                          //     this.setState({ smsNotiData: smsNotiData });
                          //   }}
                          //   renderInput={(params) => (
                          //     <TextField {...params} margin='normal' />
                          //   )}
                    // /> */}
                        </TableCell>

                        <TableCell style={{ width: '25%' }}>
                          {/*<Autocomplete
                            disableClearable
                            onChange={(event, selected) => {
                              let smsNotiData = {
                                ...this.state.smsNotiData,
                              };
                              let approveData = {
                                ...smsNotiData[[row.grpName]],
                              };
                              approveData.secondarymail = selected;
                              smsNotiData[row.grpName] = approveData;
                              this.setState({ smsNotiData: smsNotiData });
                            }}
                            value={
                              this.state.smsNotiData[row.grpName].secondarymail
                            }
                            options={row.secondarysignatory}
                            renderInput={(params) => (
                              <TextField {...params} margin='normal' />
                            )}
                            /> */}
                        </TableCell>

                        <TableCell style={{ width: '35%' }}>
                          <RadioGroup
                            row
                            aria-label='position'
                            name='position'
                            onChange={(event) =>
                              this.workflowVariableChangeHandler(
                                event,
                                row['varName']
                              )
                            }
                            value={this.state.worklowVariables[row['varName']]}
                          >
                            <FormControlLabel
                              value={'Mandatory'}
                              control={<Radio style={{ color: '#ffc800' }} />}
                              label='Mandatory'
                              disabled={row.disabled == 'true' ? true : false}
                            />
                            <FormControlLabel
                              value='FYI'
                              control={<Radio style={{ color: '#ffc800' }} />}
                              label='FYI'
                              disabled={row.disabled == 'true' ? true : false}
                            />
                            <FormControlLabel
                              disabled={row.disabled == 'true' ? true : false}
                              value='N/A'
                              control={<Radio style={{ color: '#ffc800' }} />}
                              label='N/A'
                            />
                          </RadioGroup>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          </AccordionDetails>
        </Accordion>
      );
      panels.push(panel);
    });
    let modalChild = panels;
    if (this.state.showModal)
      modalChild = (
        <Typography variant='h5' className={classes.center}>
          {' '}
          WorkFlow Already Initiated
        </Typography>
      );
    else if (this.state.loading) modalChild = <Loader />;

    let workflow = (
      <>
        <Snackbar
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
          open={this.state.openSnack}
          autoHideDuration={1500}
          onClose={this.handleClose}
        >
          <Alert onClose={this.handleClose} severity='success'>
            Approval Initiated
          </Alert>
        </Snackbar>
        <BasicDetails
          releaseData={this.props.releaseData}
          userInfo={this.props.userInfo}
        />
        <div style={{ padding: '0 24px 24px' }}>
          <div
            style={{ padding: '20px 0', fontSize: '18px', fontWeight: '600' }}
          >
            Workflow
          </div>
          <div>
            <Paper
              style={{
                //   background: "#fff",
                //   marginBottom: "24px",
                //   width: "100%",
                //   borderRadius: "50px",
                padding: '12px',
                // display: "flex",
              }}
            >
              {this.props.userInfo.opId !== 'HOB' && (
                <div
                  style={{
                    padding: '20px 0',
                    fontSize: '18px',
                    fontWeight: '600',
                  }}
                >
                  Select Workflow
                </div>
              )}
              {this.props.userInfo.opId !== 'HOB' && (
                <FormControl
                  style={{
                    marginBottom: '16px',
                  }}
                >
                  <InputLabel style={{ color: '#000', fontSize: '20px' }}>
                    Workflow
                  </InputLabel>
                  <Select
                    value={this.state.workflowType}
                    onChange={(event) => {
                      this.setState({
                        loading: true,
                      });
                      this.approversDataHandler(event.target.value).then(() => {
                        this.setState({ loading: false });
                        this.setState({
                          workflowType: event.target.value,
                        });
                      });
                    }}
                    input={<Input />}
                    renderValue={(selected) => {
                      if (selected) {
                        if (selected.length === 0) {
                          return <em>WorkFlow</em>;
                        }
                        return selected;
                      }
                    }}
                    inputProps={{ 'aria-label': 'Without label' }}
                  >
                    <MenuItem disabled value=''>
                      <em>WorkFlow</em>
                    </MenuItem>
                    {['B2B',
                    'B2C',
                    'B2BPRI',
                    'B2BMANUAL',
                    'B2CMANUAL',
                    'PRIMANUAL',].map((name) => (
                      <MenuItem key={name} value={name}>
                        {name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              )}
              {modalChild}

              <div style={{ marginTop: '12px', textAlign: 'right' }}>
                <Button
                  style={{
                    color: '#000',
                    padding: '6px 32px',
                    background: '#fff',
                    border: '2px solid #ff1921',
                  }}
                  onClick={() => this.props.history.push('/')}
                >
                  Close
                </Button>
                <Button
                  style={{ padding: '6px 32px', marginLeft: '6px' }}
                  onClick={() => this.initiateApprovalHandler()}
                >
                  {this.props.userInfo.opId === 'HOB'
                    ? 'Initiate Workflow'
                    : 'Initiate approval'}
                </Button>
              </div>
            </Paper>
          </div>
        </div>
      </>
    );

    let workflow2 = (
      <ModalAction
        show={this.state.show}
        modalClosed={this.modalCloseHandler}
        data={this.props.releaseData}
        actionText={'Initiate Approval'}
        title={'Release Id ' + this.props.releaseData.releaseId}
        action={this.initiateApprovalHandler}
      >
        <div className={classes.root} style={{ minHeight: '30vh' }}>
          {!this.state.loading && (
            <div style={{ marginBottom: '20px' }}>
              <FormControl
                style={{
                  minWidth: '300px',
                }}
              >
                <InputLabel>WorkFlow</InputLabel>
                <Select
                  value={this.state.workflowType}
                  onChange={(event) => {
                    this.setState({
                      loading: true,
                    });
                    this.approversDataHandler(event.target.value).then(() => {
                      this.setState({ loading: false });
                      this.setState({
                        workflowType: event.target.value,
                      });
                    });
                  }}
                  input={<Input />}
                  renderValue={(selected) => {
                    if (selected) {
                      if (selected.length === 0) {
                        return <em>WorkFlow</em>;
                      }
                      return selected;
                    }
                  }}
                  inputProps={{ 'aria-label': 'Without label' }}
                >
                  <MenuItem disabled value=''>
                    <em>WorkFlow</em>
                  </MenuItem>
                  {['B2B',
									'B2C',
									'B2BPRI',
									'B2BMANUAL',
									'B2CMANUAL',
									'PRIMANUAL',].map((name) => (
                    <MenuItem key={name} value={name}>
                      {name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </div>
          )}
          {modalChild}
        </div>
      </ModalAction>
    );

    return workflow;
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
    releaseData: state.releaseData.releaseData,
    roleGroup: state.roleSelected.roleGroup,
  };
};

export default connect(mapStateToProps)(
  withStyles(useStyles)(WithErrorHandler(withRouter(SelectApprover), axios))
);

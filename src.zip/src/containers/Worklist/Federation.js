import React, { Component } from 'react';
import ModalAction from '../../UI/ModalAction/ModalAction';
import Loader from '../../UI/Loader/Loader';
import axios from 'axios';
import configuredAxios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import { withStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemSecondaryAction from '@material-ui/core/ListItemSecondaryAction';
import ListItemText from '@material-ui/core/ListItemText';
import Checkbox from '@material-ui/core/Checkbox';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import SettingsSystemDaydreamIcon from '@material-ui/icons/SettingsSystemDaydream';
import VideoLabelIcon from '@material-ui/icons/VideoLabel';
import Box from '@material-ui/core/Box';
import Divider from '@material-ui/core/Divider';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { directiveLiteral } from '@babel/types';

const useStyles = (theme) => ({
	root: {
		width: '100%',
	},
	heading: {
		fontSize: theme.typography.pxToRem(15),
		flexBasis: '65%',
		flexShrink: 0,
	},
	secondaryHeading: {
		fontSize: theme.typography.pxToRem(15),
	},
});

function TabPanel(props) {
	const { children, value, index, ...other } = props;

	return (
		<div
			role="tabpanel"
			hidden={value !== index}
			id={`simple-tabpanel-${index}`}
			aria-labelledby={`simple-tab-${index}`}
			{...other}>
			{value === index && (
				<Box p={3}>
					<Typography>{children}</Typography>
				</Box>
			)}
		</div>
	);
}

class Federate extends Component {
	_isMounted = false;

	state = {
		show: true,
		loading: false,
		federate: [],
		activeTab: 0,
		fedResponse: {},
		fedResponseCit: {},
	};

	modalCloseHandler = () => {
		this.setState({ show: false });
		this.props.showFederation();
	};

	componentWillUnmount() {
		this._isMounted = false;
	}

	fedStatusHandler = () => {
		return axios
			.get(process.env.REACT_APP_URL + 'addonService/status', {
				headers: {
					opId: this.props.userInfo.opId,
					buId: this.props.userInfo.buId,
					releaseId: this.props.releaseData.releaseId,
					authUserId: this.props.userInfo.id,
					Authorization: 'Bearer ' + this.props.userInfo.jwt,
					// environment: 'preprod',
					environment:
						this.props.releaseData.releaseStatus === 'Federate to Production' ||
						this.props.releaseData.releaseStatus === 'Prod Federation Failed'
							? 'prod'
							: 'preprod',
				},
			})
			.then((res) => {
				console.log(res);
				if (res) {
					this.setState({
						fedResponse: res.data.data,
					});
				}
			})
			.catch((error) => {
				console.log(error);
			});
	};

	fedStatusHandlerCit = () => {
		return axios
			.get(process.env.REACT_APP_URL + 'addonService/federateStatus', {
				headers: {
					opId: this.props.userInfo.opId,
					buId: this.props.userInfo.buId,
					releaseId: this.props.releaseData.releaseId,
					authUserId: this.props.userInfo.id,
					Authorization: 'Bearer ' + this.props.userInfo.jwt,
				},
			})
			.then((res) => {
				console.log(res);
				if (res) {
					this.setState({
						fedResponseCit: res.data.data,
					});
				}
			})
			.catch((error) => {
				console.log(error);
			});
	};

	componentDidMount() {
		this._isMounted = true;
		this.setState({ loading: true });
		this.fedStatusHandler().then(() => {
			this.setState({ loading: false });
		});
	}

	handleToggle = (value) => () => {
		const currentIndex = this.state.federate.indexOf(value);
		const newFederate = [...this.state.federate];

		if (currentIndex === -1) {
			newFederate.push(value);
		} else {
			newFederate.splice(currentIndex, 1);
		}
		this.setState({
			federate: newFederate,
		});
	};

	fxFederation = () => {
		if (this.state.federate.includes('FX')) {
			console.log(
				// `fx-fed-telemedia-rs/fxfed-Telemedia/execget?epcEnv=${
				// 	process.env.REACT_APP_ENV === 'sit'
				// 		? 'preprod'
				// 		: this.props.releaseData.releaseStatus === 'Federate to Production'
				// 		? 'prod'
				// 		: 'preprod'
				// }&relName=` +
				// 	// 'fx-fed-telemedia-rs/fxfed-Telemedia/execget?epcEnv=preprod&relName=' +
				// 	this.props.releaseData.releaseId +
				// 	'&fedBy=' +
				// 	this.props.userInfo.id +
				// 	'&opId=' +
				// 	this.props.userInfo.opId +
				// 	'&buId=' +
				// this.props.userInfo.buId

				`ratePlan/fxfed?epcEnv=${
					this.props.releaseData.releaseStatus === 'Federate to Production' ||
					this.props.releaseData.releaseStatus === 'Prod Federation Failed'
						? 'prod'
						: 'preprod'
				}&relName=${this.props.releaseData.releaseId}&fedBy=${
					this.props.userInfo.id
				}&url=${
					process.env.REACT_APP_ENV === 'sit'
						? process.env.REACT_APP_URL
						: 'hobs-aims-cs.airtelworld.in'
				}&opId=${this.props.userInfo.opId}&buId=${this.props.userInfo.buId}`
			);
			return axios
				.get(
					// process.env.REACT_APP_URL +
					// 	`fx-fed-telemedia-rs/fxfed-Telemedia/execget?epcEnv=${
					// 		process.env.REACT_APP_ENV === 'sit'
					// 			? 'preprod'
					// 			: this.props.releaseData.releaseStatus ===
					// 			  'Federate to Production'
					// 			? 'prod'
					// 			: 'preprod'
					// 	}&relName=` +
					// 	// 'fx-fed-telemedia-rs/fxfed-Telemedia/execget?epcEnv=preprod&relName=' +
					// 	this.props.releaseData.releaseId +
					// 	'&fedBy=' +
					// 	this.props.userInfo.id +
					// 	'&opId=' +
					// 	this.props.userInfo.opId +
					// 	'&buId=' +
					// this.props.userInfo.buId,

					`${process.env.REACT_APP_URL}ratePlan/fxfed?epcEnv=${
						this.props.releaseData.releaseStatus === 'Federate to Production' ||
						this.props.releaseData.releaseStatus === 'Prod Federation Failed'
							? 'prod'
							: 'preprod'
					}&relName=${this.props.releaseData.releaseId}&fedBy=${
						this.props.userInfo.id
					}&url=${
						process.env.REACT_APP_ENV === 'sit'
							? process.env.REACT_APP_URL
							: 'hobs-aims-cs.airtelworld.in'
					}&opId=${this.props.userInfo.opId}&buId=${this.props.userInfo.buId}`,

					{
						headers: {
							authUserId: this.props.userInfo.id,
							Authorization: 'Bearer ' + this.props.userInfo.jwt,
						},
					}
				)
				.then((res) => {
					console.log(res);
				})
				.catch((error) => {
					console.log(error);
				});
		} else return Promise.resolve();
  };
  

  // fxFederation = () => {
  //   if (this.state.federate.includes("FX")) {
  //     console.log(
  //       "fx-fed-telemedia-rs/fxfed-Telemedia/execget?epcEnv=preprod&relName=" +
  //         this.props.releaseData.releaseId +
  //         "&fedBy=" +
  //         this.props.userInfo.id +
  //         "&opId=" +
  //         this.props.userInfo.opId +
  //         "&buId=" +
  //         this.props.userInfo.buId
  //     );
  //     return axios
  //       .get(
  //         process.env.REACT_APP_URL +
  //           "fx-fed-telemedia-rs/fxfed-Telemedia/execget?epcEnv=preprod&relName=" +
  //           this.props.releaseData.releaseId +
  //           "&fedBy=" +
  //           this.props.userInfo.id +
  //           "&opId=" +
  //           this.props.userInfo.opId +
  //           "&buId=" +
  //           this.props.userInfo.buId,
  //         {
  //           headers: {
  //             authUserId: this.props.userInfo.id,
  //             // Authorization: 'Bearer ' + this.props.userInfo.jwt
  //           },
  //         }
  //       )
  //       .then((res) => {
  //         console.log(res);
  //       })
  //       .catch((error) => {
  //         console.log(error);
  //       });
  //   } else return Promise.resolve();
  // };

	dirsFederation = () => {
		if (this.state.federate.includes('DIRS')) {
			return axios
				.get(
					process.env.REACT_APP_URL +
						'ratePlan/dirsFed?releaseId=' +
						this.props.releaseData.releaseId +
						'&opId=' +
						this.props.userInfo.opId +
						'&federatedBy=' +
						this.props.userInfo.id +
						'&authUserId=' +
						this.props.userInfo.id,
					{
						headers: {
							// opId: this.props.userInfo.opId,
							authUserId: this.props.userInfo.id,
							Authorization: 'Bearer ' + this.props.userInfo.jwt,
							federatedBy: this.props.userInfo.id,
						},
					}
				)
				.then((res) => {
					console.log(res);
				})
				.catch((error) => {
					console.log(error);
				});
		} else return Promise.resolve();
	};

	siebelFederation = () => {
		if (this.state.federate.includes('Siebel')) {
			return axios
				.get(process.env.REACT_APP_URL + 'addonService/SiebelFederate', {
					headers: {
						opId: this.props.userInfo.opId,
						buId: this.props.userInfo.buId,
						releaseId: this.props.releaseData.releaseId,
						federatedBy: this.props.userInfo.id,
						// environment: 'preprod',
						environment:
							this.props.releaseData.releaseStatus ===
								'Federate to Production' ||
							this.props.releaseData.releaseStatus === 'Prod Federation Failed'
								? 'prod'
								: 'preprod',
						authUserId: this.props.userInfo.id,
						Authorization: 'Bearer ' + this.props.userInfo.jwt,
					},
				})
				.then((res) => {
					console.log(res);
				})
				.catch((error) => {
					console.log(error);
				});
		} else return Promise.resolve();
	};

	omFederation = () => {
		if (this.state.federate.includes('OM')) {
			return axios
				.get(process.env.REACT_APP_URL + 'addonService/OMfederate', {
					headers: {
						opId: this.props.userInfo.opId,
						buId: this.props.userInfo.buId,
						releaseId: this.props.releaseData.releaseId,
						federatedBy: this.props.userInfo.id,
						authUserId: this.props.userInfo.id,
						Authorization: 'Bearer ' + this.props.userInfo.jwt,
						// environment: 'preprod',
						environment:
							this.props.releaseData.releaseStatus ===
								'Federate to Production' ||
							this.props.releaseData.releaseStatus === 'Prod Federation Failed'
								? 'prod'
								: 'preprod',
					},
				})
				.then((res) => {
					console.log(res);
				})
				.catch((error) => {
					console.log(error);
				});
		} else return Promise.resolve();
	};

	fedEmailCheck = (error) => {
		const payload = {
			releaseId: this.props.releaseData.releaseId,
			fedStatus: error.length === 0 ? 'AllSuccess' : null,
			// env: 'preprod',
			env:
				this.props.releaseData.releaseStatus === 'Federate to Production' ||
				this.props.releaseData.releaseStatus === 'Prod Federation Failed'
					? 'prod'
					: 'preprod',
		};
		return configuredAxios
			.post('TeleSelectApprovers/send/email/to/ct-ops', payload, {
				headers: {
					opId: this.props.userInfo.opId,
					buId: this.props.userInfo.buId,
				},
			})
			.then((res) => {
				console.log(res);
			})
			.catch((err) => console.error());
	};

	postComplete = (payload) => {
		return configuredAxios.post(
			'Telerest/task/' + this.props.releaseData.taskId + '/complete',
			payload,
			{
				headers: {
					'Content-Type': 'application/json',
				},
			}
		);
	};

	fedToProd = (isFailure) => {
		if (this.props.releaseData.releaseStatus === 'Federate to Production') {
			return configuredAxios
				.get('Telecustom/cancelTask', {
					headers: {
						taskId: this.props.releaseData.taskId,
						group: this.props.selGrp,
					},
				})
				.then((res) => {
					console.log(res);
					const variables = {
						approve: {
							value: !isFailure,
						},
						remarks: {
							value: 'Federated to Production',
						},
					};
					const payload = {};
					payload.variables = variables;
					this.postComplete(payload)
						.then((res) => {
							console.log(res);
							const url = isFailure
								? 'Telecustom/updateForProdFedFailed'
								: 'Telecustom/updateForProdDumpUpload';
							configuredAxios
								.get(url, {
									headers: {
										releaseId: this.props.releaseData.releaseId,
										opId: this.props.userInfo.opId,
										buId: this.props.userInfo.buId,
									},
								})
								.then(console.log);
						})
						.catch((err) => console.error());
				})
				.catch((err) => console.error());
		} else if (
			this.props.releaseData.releaseStatus === 'Prod Federation Failed'
		) {
			const variables = {
				approve: {
					value: !isFailure,
				},
				remarks: {
					value: 'OK',
				},
			};
			const payload = {};
			payload.variables = variables;
			return this.postComplete(payload)
				.then((res) => {
					console.log(res);
					const url = isFailure
						? 'Telecustom/updateForProdFedFailed'
						: 'Telecustom/updateForProdDumpUpload';
					configuredAxios
						.get(url, {
							headers: {
								releaseId: this.props.releaseData.releaseId,
								opId: this.props.userInfo.opId,
								buId: this.props.userInfo.buId,
							},
						})
						.then(console.log);
				})
				.catch((err) => console.error());
		} else {
			return Promise.resolve();
		}
	};

	federationHandler = () => {
		if (this.state.federate.length > 0) {
			try {
				this.setState({ loading: true });
				this.fxFederation().then(async () => {
					if (
						this.props.releaseData.releaseStatus === 'Federate to Production' ||
						this.props.releaseData.releaseStatus === 'Prod Federation Failed'
					) {
						await this.dirsFederation();
					}
					this.siebelFederation().then(() => {
						this.omFederation().then(() => {
							this.fedStatusHandler().then(async () => {
								const fedResponse = this.state.fedResponse;
								const error = [];
								Object.keys(fedResponse).map((sys) => {
									if (
										fedResponse[sys]['Overall Status']['Overall Status'] !==
										'Success'
									) {
										error.push({
											title: sys,
											status:
												fedResponse[sys]['Overall Status']['Overall Status'],
										});
									}
								});
								if (
									this.props.releaseData.releaseStatus ===
										'Federate to Production' ||
									(this.props.releaseData.releaseStatus ===
										'Prod Federation Failed' &&
										error.length === 0)
								) {
									await this.fedEmailCheck(error.map((err) => err.title));
								}
								if (this.props.userInfo.group[0] === 'CIT_OPS') {
									if (
										error.length === 0 ||
										(error.map((err) => err.status).includes('Failure') &&
											this.props.releaseData.releaseStatus ===
												'Federate to Production')
									) {
										this.fedStatusHandlerCit().then(() => {
											this.fedToProd(
												error.map((err) => err.status).includes('Failure')
											).then(() => {
												this.setState({
													loading: false,
													activeTab: 1,
												});
											});
										});
									} else if (error.length === 1 && error[0].title === 'DIRS') {
										const variables = {
											approve: {
												value: true,
											},
											remarks: {
												value: 'OK',
											},
										};
										const payload = {};
										payload.variables = variables;
										this.postComplete(payload).then(() => {
											configuredAxios
												.get('Telecustom/updateAfterPreProdFed', {
													headers: {
														opId: this.props.userInfo.opId,
														buId: this.props.userInfo.buId,
														releaseId: this.props.releaseData.releaseId,
													},
												})
												.then((res) => {
													console.log(res.data.data);
													this.setState({
														loading: false,
														activeTab: 1,
													});
												});
										});
									} else {
										this.setState({
											loading: false,
											activeTab: 1,
										});
									}
								} else if (
									(this.props.userInfo.group[0] === 'radB2c' ||
										this.props.userInfo.group[0] === 'radB2b') &&
									(error.length === 0 ||
										error.map((err) => err.status).includes('Failure'))
								) {
									this.fedToProd(
										error.map((err) => err.status).includes('Failure')
									).then(() => {
										this.setState({
											loading: false,
											activeTab: 1,
										});
									});
								} else {
									this.setState({
										loading: false,
										activeTab: 1,
									});
								}
							});
						});
					});
					// });
				});
			} catch (error) {
				console.log(error);
				this.setState({
					loading: false,
				});
			}
		}
	};

	render() {
		const { classes } = this.props;

		let federate = (
			<ModalAction
				show={this.state.show}
				modalClosed={this.modalCloseHandler}
				actionText={'Federate'}
				size="md"
				title={'Release Id ' + this.props.releaseData.externalReleaseId}
				action={this.federationHandler}>
				{this.state.loading ? (
					<div style={{ minHeight: '35vh' }}>
						<Loader />
					</div>
				) : (
					<Paper square style={{ minHeight: '35vh' }}>
						<Tabs
							value={this.state.activeTab}
							onChange={(event, newValue) => {
								this.setState({
									activeTab: newValue,
								});
							}}
							variant="fullWidth"
							indicatorColor="white"
							textColor="primary">
							<Tab icon={<SettingsSystemDaydreamIcon />} label="Federation" />
							<Tab icon={<VideoLabelIcon />} label="Status" />
						</Tabs>

						<TabPanel value={this.state.activeTab} index={0}>
							{this.state.fedResponse &&
								Object.keys(this.state.fedResponse).length > 0 && (
									<List>
										{this.state.fedResponse['FX'] && (
											<ListItem
												disabled={
													this.state.fedResponse['FX']['Overall Status'][
														'Overall Status'
													] == 'Success'
												}
												dense
												button
												onClick={this.handleToggle('FX')}>
												<ListItemIcon>
													<Checkbox
														disabled={
															this.state.fedResponse['FX']['Overall Status'][
																'Overall Status'
															] == 'Success'
														}
														edge="start"
														checked={this.state.federate.indexOf('FX') !== -1}
														tabIndex={-1}
														disableRipple
														style={{ color: '#ff1921' }}
													/>
												</ListItemIcon>
												<ListItemText primary={'FX'} />
											</ListItem>
										)}

										{(this.props.releaseData.releaseStatus ===
											'Federate to Production' ||
											this.props.releaseData.releaseStatus ===
												'Prod Federation Failed') &&
											this.state.fedResponse['FX'] && (
												<ListItem
													disabled={
														this.state.fedResponse['FX']['Overall Status'][
															'Overall Status'
														] == 'Success'
															? false
															: true
													}
													dense
													button
													onClick={this.handleToggle('DIRS')}>
													<ListItemIcon>
														<Checkbox
															disabled={
																this.state.fedResponse['FX']['Overall Status'][
																	'Overall Status'
																] == 'Success'
																	? false
																	: true
															}
															edge="start"
															checked={
																this.state.federate.indexOf('DIRS') !== -1
															}
															tabIndex={-1}
															disableRipple
															style={{ color: '#ff1921' }}
														/>
													</ListItemIcon>
													<ListItemText primary={'DIRS'} />
												</ListItem>
											)}

										<ListItem
											dense
											button
											onClick={this.handleToggle('Siebel')}>
											<ListItemIcon>
												<Checkbox
													edge="start"
													checked={this.state.federate.indexOf('Siebel') !== -1}
													tabIndex={-1}
													disableRipple
													style={{ color: '#ff1921' }}
												/>
											</ListItemIcon>
											<ListItemText primary={'Siebel'} />
										</ListItem>
										<ListItem
											disabled={
												!(
													this.state.fedResponse['FX']['Overall Status'][
														'Overall Status'
													] == 'Success' &&
													this.state.fedResponse['Siebel']['Overall Status'][
														'Overall Status'
													] == 'Success'
												)
											}
											dense
											button
											onClick={this.handleToggle('OM')}>
											<ListItemIcon>
												<Checkbox
													disabled={
														!(
															this.state.fedResponse['FX']['Overall Status'][
																'Overall Status'
															] == 'Success' &&
															this.state.fedResponse['Siebel'][
																'Overall Status'
															]['Overall Status'] == 'Success'
														)
													}
													edge="start"
													checked={this.state.federate.indexOf('OM') !== -1}
													tabIndex={-1}
													disableRipple
													style={{ color: '#ff1921' }}
												/>
											</ListItemIcon>
											<ListItemText primary={'OM'} />
										</ListItem>
									</List>
								)}
						</TabPanel>

						<TabPanel value={this.state.activeTab} index={1}>
							{this.state.fedResponse &&
								Object.keys(this.state.fedResponse).length > 0 && (
									<React.Fragment>
										<Grid container alignContent="flex-end" spacing={2}>
											<Grid item xs={4}>
												<Typography variant="subtitle1"> System</Typography>
											</Grid>
											<Grid item xs={3}></Grid>
											<Grid item xs={5}>
												<Typography variant="subtitle1"> Status</Typography>
											</Grid>
										</Grid>
										<Divider
											style={{ marginBottom: '10px', marginTop: '5px' }}
										/>
										{this.state.fedResponse['FX']['Overall Status'][
											'Overall Status'
										] == 'Not Federated' ? (
											<React.Fragment>
												<Grid container alignContent="flex-end" spacing={2}>
													<Grid item xs={4}>
														<Typography variant="subtitle1">
															{' '}
															FX Status
														</Typography>
													</Grid>
													<Grid item xs={3}></Grid>
													<Grid item xs={5}>
														<Typography
															variant="subtitle1"
															style={{ wordBreak: 'break-all' }}>
															{' '}
															{
																this.state.fedResponse['FX']['Overall Status'][
																	'Overall Status'
																]
															}
														</Typography>
													</Grid>
												</Grid>
											</React.Fragment>
										) : (
											<Accordion>
												<AccordionSummary expandIcon={<ExpandMoreIcon />}>
													<Typography className={classes.heading}>
														FX Status
													</Typography>
													<Typography className={classes.secondaryHeading}>
														{
															this.state.fedResponse['FX']['Overall Status'][
																'Overall Status'
															]
														}
													</Typography>
												</AccordionSummary>
												<AccordionDetails style={{}}>
													<Grid container alignContent="flex-end" spacing={2}>
														{Object.keys(
															this.state.fedResponse['FX']['Api Status']
														).map((key) => {
															return (
																<React.Fragment>
																	<Grid
																		item
																		xs={4}
																		style={{
																			borderBottom: '1px solid #b3b3b3',
																		}}>
																		<span style={{ wordBreak: 'break-all' }}>
																			{' '}
																			{key}
																		</span>
																	</Grid>
																	<Grid
																		item
																		xs={1}
																		style={{
																			borderBottom: '1px solid #b3b3b3',
																		}}></Grid>
																	<Grid
																		item
																		xs={7}
																		style={{
																			borderBottom: '1px solid #b3b3b3',
																		}}>
																		<span style={{ wordBreak: 'break-all' }}>
																			{
																				this.state.fedResponse['FX'][
																					'Api Status'
																				][key]
																			}
																		</span>
																	</Grid>
																</React.Fragment>
															);
														})}
													</Grid>
												</AccordionDetails>
											</Accordion>
										)}
										<Divider
											style={{ marginBottom: '10px', marginTop: '5px' }}
										/>

										{this.props.releaseData.releaseStatus ===
											'Federate to Production' ||
										this.props.releaseData.releaseStatus ===
											'Prod Federation Failed' ? (
											this.state.fedResponse['DIRS']['Overall Status'][
												'Overall Status'
											] == 'Not Federated' ? (
												<React.Fragment>
													<Grid container alignContent="flex-end" spacing={2}>
														<Grid item xs={4}>
															<Typography variant="subtitle1">
																{' '}
																DIRS Status
															</Typography>
														</Grid>
														<Grid item xs={3}></Grid>
														<Grid item xs={5}>
															<Typography
																variant="subtitle1"
																style={{ wordBreak: 'break-all' }}>
																{' '}
																{
																	this.state.fedResponse['DIRS'][
																		'Overall Status'
																	]['Overall Status']
																}
															</Typography>
														</Grid>
													</Grid>
												</React.Fragment>
											) : (
												<Accordion>
													<AccordionSummary expandIcon={<ExpandMoreIcon />}>
														<Typography className={classes.heading}>
															DIRS Status
														</Typography>
														<Typography className={classes.secondaryHeading}>
															{
																this.state.fedResponse['DIRS'][
																	'Overall Status'
																]['Overall Status']
															}
														</Typography>
													</AccordionSummary>
													<AccordionDetails style={{}}>
														<Grid container alignContent="flex-end" spacing={2}>
															{Object.keys(
																this.state.fedResponse['DIRS']['Api Status']
															).map((key) => {
																return (
																	<React.Fragment>
																		<Grid
																			item
																			xs={4}
																			style={{
																				borderBottom: '1px solid #b3b3b3',
																			}}>
																			<span style={{ wordBreak: 'break-all' }}>
																				{' '}
																				{key}
																			</span>
																		</Grid>
																		<Grid
																			item
																			xs={1}
																			style={{
																				borderBottom: '1px solid #b3b3b3',
																			}}></Grid>
																		<Grid
																			item
																			xs={7}
																			style={{
																				borderBottom: '1px solid #b3b3b3',
																			}}>
																			<span style={{ wordBreak: 'break-all' }}>
																				{
																					this.state.fedResponse['DIRS'][
																						'Api Status'
																					][key]
																				}
																			</span>
																		</Grid>
																	</React.Fragment>
																);
															})}
														</Grid>
													</AccordionDetails>
												</Accordion>
											)
										) : null}
										{(this.props.releaseData.releaseStatus ===
											'Federate to Production' ||
											this.props.releaseData.releaseStatus ===
												'Prod Federation Failed') && (
											<Divider
												style={{ marginBottom: '10px', marginTop: '5px' }}
											/>
										)}

										{this.state.fedResponse['Siebel']['Overall Status'][
											'Overall Status'
										] == 'Not Federated' ? (
											<React.Fragment>
												<Grid container alignContent="flex-end" spacing={2}>
													<Grid item xs={4}>
														<Typography variant="subtitle1">
															{' '}
															Siebel Status
														</Typography>
													</Grid>
													<Grid item xs={3}></Grid>
													<Grid item xs={5}>
														<Typography
															variant="subtitle1"
															style={{ wordBreak: 'break-all' }}>
															{' '}
															{
																this.state.fedResponse['Siebel'][
																	'Overall Status'
																]['Overall Status']
															}
														</Typography>
													</Grid>
												</Grid>
											</React.Fragment>
										) : (
											<Accordion>
												<AccordionSummary expandIcon={<ExpandMoreIcon />}>
													<Typography className={classes.heading}>
														Siebel Status
													</Typography>
													<Typography className={classes.secondaryHeading}>
														{
															this.state.fedResponse['Siebel'][
																'Overall Status'
															]['Overall Status']
														}
													</Typography>
												</AccordionSummary>
												<AccordionDetails style={{}}>
													<Grid container alignContent="flex-end" spacing={2}>
														{Object.keys(
															this.state.fedResponse['Siebel']['Api Status']
														).map((key) => {
															return (
																<React.Fragment>
																	<Grid
																		item
																		xs={4}
																		style={{
																			borderBottom: '1px solid #b3b3b3',
																		}}>
																		<span style={{ wordBreak: 'break-all' }}>
																			{' '}
																			{key}
																		</span>
																	</Grid>
																	<Grid
																		item
																		xs={1}
																		style={{
																			borderBottom: '1px solid #b3b3b3',
																		}}></Grid>

																	<Grid
																		item
																		xs={7}
																		style={{
																			borderBottom: '1px solid #b3b3b3',
																		}}>
																		<span style={{ wordBreak: 'break-all' }}>
																			{
																				this.state.fedResponse['Siebel'][
																					'Api Status'
																				][key]
																			}
																		</span>
																	</Grid>
																</React.Fragment>
															);
														})}
													</Grid>
												</AccordionDetails>
											</Accordion>
										)}

										<Divider
											style={{ marginBottom: '10px', marginTop: '5px' }}
										/>

										{this.state.fedResponse['OM']['Overall Status'][
											'Overall Status'
										] == 'Not Federated' ? (
											<React.Fragment>
												<Grid container alignContent="flex-end" spacing={2}>
													<Grid item xs={4}>
														<Typography variant="subtitle1">
															{' '}
															OM Status
														</Typography>
													</Grid>
													<Grid item xs={3}></Grid>
													<Grid item xs={5}>
														<Typography
															variant="subtitle1"
															style={{ wordBreak: 'break-all' }}>
															{' '}
															{
																this.state.fedResponse['OM']['Overall Status'][
																	'Overall Status'
																]
															}
														</Typography>
													</Grid>
												</Grid>
											</React.Fragment>
										) : (
											<Accordion>
												<AccordionSummary expandIcon={<ExpandMoreIcon />}>
													<Typography className={classes.heading}>
														OM Status
													</Typography>
													<Typography className={classes.secondaryHeading}>
														{
															this.state.fedResponse['OM']['Overall Status'][
																'Overall Status'
															]
														}
													</Typography>
												</AccordionSummary>
												<AccordionDetails style={{}}>
													<Grid container alignContent="flex-end" spacing={2}>
														{Object.keys(
															this.state.fedResponse['OM']['Api Status']
														).map((key) => {
															return (
																<React.Fragment>
																	<Grid
																		item
																		xs={4}
																		style={{
																			borderBottom: '1px solid #b3b3b3',
																		}}>
																		<span style={{ wordBreak: 'break-all' }}>
																			{' '}
																			{key}
																		</span>
																	</Grid>
																	<Grid
																		item
																		xs={1}
																		style={{
																			borderBottom: '1px solid #b3b3b3',
																		}}></Grid>

																	<Grid
																		item
																		xs={7}
																		style={{
																			borderBottom: '1px solid #b3b3b3',
																		}}>
																		<span style={{ wordBreak: 'break-all' }}>
																			{
																				this.state.fedResponse['OM'][
																					'Api Status'
																				][key]
																			}
																		</span>
																	</Grid>
																</React.Fragment>
															);
														})}
													</Grid>
												</AccordionDetails>
											</Accordion>
										)}
									</React.Fragment>
								)}
						</TabPanel>
					</Paper>
				)}
			</ModalAction>
		);

		return federate;
	}
}

export default withStyles(useStyles)(Federate);

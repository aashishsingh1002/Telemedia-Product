const en = {
    loginPage: {
        userName: "User Name",
        password: "Password",
        login: 'Login'
    },
    dashboard: {
        myReleases: 'My Releases',
        newRelease: 'Create New Release',
        releaseNo: 'Release No',
        releaseObj: 'Release Objective',
        creationDate: 'Creation Date',
        status: 'Status',
        pendingWith: 'Pending With',
        enablers: 'Enablers',
        proConfig: 'Product Configuration',
        bundles: 'Bundles',
        products: 'Products',
        contracts: 'Contracts',
        contractsProfiles: 'Contracts Profiles',
        attributeConfiguration: 'Attribute Configuration',
        ratePlanConfiguration: 'Rate Plan',
        eventsConfiguration: 'Events Configuration',
        workQueue: 'Work Queue',
        productPerformance: 'Product Performance',
        attachment: 'Attachment',
        auditLogs: 'Audit Logs',
        releaseTreeView: 'Release Tree View',
        selectApprover: 'Select Approver',
        advanceSearch: 'Advance Search'

    },
    editRelease: {
        inRelease: 'You are inside release',
        releaseObj: 'Release Objective',
        maxLength: 'Max Length 2000',
        creationDate: 'Creation Date',
        maxRemaining: 'Max Remaining:',
        createdBy: 'Created By',
        releaseStatus: 'Release Status',
        save: 'Save',
        cancel: 'Cancel',
        deploy: 'Deploy',
        deployRelease: 'Do you want to deploy release ',
        cancelRelease: 'Do you want to cancel release '
    }
}

export default en;





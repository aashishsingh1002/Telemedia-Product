import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
// import Button from "@material-ui/core/Button";
import Button from '../../../UI/Button/Button';
import Checkbox from '@material-ui/core/Checkbox';
import FormLabel from '@material-ui/core/FormLabel';
import FormControl from '@material-ui/core/FormControl';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Switch from '@material-ui/core/Switch';
import axios from '../../../axios-epc';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import Loader from '../../../UI/Loader/Loader';
import TextField from '@material-ui/core/TextField';
import InputAdornment from '@material-ui/core/InputAdornment';
import SearchIcon from '@material-ui/icons/Search';
import moment from 'moment';
import Modal from '../../../UI/Modal/Modal';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import StyledButton from '../../../UI/Button/Button';

const useStyles = (theme) => ({
  cardHeader: {
    // background: "#546D7A",
    // height: "4.5vh",
    paddingBottom: 0,
  },
  subheader: {
    color: 'rgba(0, 0, 0, 0.87)',
    fontSize: '16px',
    fontWeight: '600',
    // color: "white",
    // fontWeight: 'bold'
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
  btn: {
    textTransform: 'unset !important',
  },
});

class UpgradeDowngrade extends Component {
  _isMounted = false;

  componentDidMount() {
    this._isMounted = true;
    this.searchItems().then(() => {
      this.upDownPkgs().then(() => {
        this.setState({ loading: false });
      });
    });
  }
  componentWillUnmount() {
    this._isMounted = false;
  }

  state = {
    show: false,
    modalContent: null,
    showUpgradePkgs: [],
    showDowngradePkgs: [],
    searchDowngrade: '',
    upgradePkgs: [],
    downgradePkgs: [],
    allDowngrade: false,
    allUpgrade: false,
    searchItems: [],
    loading: true,
    searchUpgrade: '',
  };

  searchItems() {
    return axios
      .get(
        'package/basicDetails/search?releaseID=' +
          this.props.releaseData.releaseId,
        {
          headers: {
            opId: this.props.userInfo.opId,
            Authorization: 'Bearer ' +this.props.userInfo.jwt
          },
        }
      )
      .then((res) => {
        console.log(res);
        let searchItems = [];
        Object.keys(res.data.data).forEach((key) => {
          searchItems.push(key + '/' + res.data.data[key]);
        });
        this.setState({
          searchItems: searchItems,
          showUpgradePkgs: searchItems,
          showDowngradePkgs: searchItems,
        });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  upDownPkgs() {
    return axios
      .get(
        'package/upgradeDowngrade/id?id=' +
          this.props.packageData.packageId +
          '&releaseId=' +
          this.props.releaseData.releaseId,
        {
          headers: {
            opId: this.props.userInfo.opId,
          },
        }
      )
      .then((res) => {
        console.log(res.data.data.upgradeIds);
        console.log(res.data.data.downgradeIds);
        if (this._isMounted)
          this.setState({
            upgradePkgs: res.data.data.upgradeIds,
            downgradePkgs: res.data.data.downgradeIds,
          });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  deleteUpDownHandler = () => {
    this.setState({ loading: true });

    axios
      .get(
        'package/upgradeDowngrade/delete?id=' +
          this.props.packageData.packageId +
          '&releaseId=' +
          this.props.releaseData.releaseId,
        {
          headers: {
            opId: this.props.userInfo.opId,
          },
        }
      )
      .then((res) => {
        console.log(res);
        this.setState({
          loading: false,
          upgradePkgs: [],
          downgradePkgs: [],
        });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  savePkgsUpDownHandler = () => {
    if (this.props.packageData.packageId) {
      this.setState({ loading: true });
      let payload = {};
      let date = moment().format('DD-MMM-YY');
      payload.upgradeIds = this.state.upgradePkgs;
      payload.downgradeIds = this.state.downgradePkgs;
      payload.releaseId = this.props.releaseData.releaseId;
      payload.id = this.props.packageData.packageId;
      payload.opId = this.props.userInfo.opId;
      payload.buId = this.props.userInfo.buId;
      payload.createdBy = this.props.userInfo.buId;
      payload.startDate = date;
      payload.endDate = '31-dec-31';
      console.log(payload);
      axios
        .post('package/upgradeDowngrade', payload)
        .then((response) => {
          console.log(response);
          if (this._isMounted) this.setState({ loading: false });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      let modalContent = (
        <Typography variant='h6'>
          {' '}
          Submit Basic Package Details first.{' '}
        </Typography>
      );
      this.setState({ modalContent: modalContent, show: true });
    }
  };

  errorConfirmedHandler = () => {
    this.setState({ show: false });
  };

  searchHandlerUpgrade = (event) => {
    this.setState({ searchUpgrade: event.target.value });
    let searchItems = [];
    if (event.target.value.length == 0) {
      searchItems = [...this.state.searchItems];
      this.setState({ showUpgradePkgs: searchItems });
    } else {
      searchItems = this.state.searchItems.filter(function (item) {
        return item.toUpperCase().includes(event.target.value.toUpperCase());
      });
      this.setState({ showUpgradePkgs: searchItems });
    }
  };

  searchHandlerDowngrade = (event) => {
    this.setState({ searchDowngrade: event.target.value });
    let searchItems = [];
    if (event.target.value.length == 0) {
      searchItems = [...this.state.searchItems];
      this.setState({ showDowngradePkgs: searchItems });
    } else {
      searchItems = this.state.searchItems.filter(function (item) {
        return item.toUpperCase().includes(event.target.value.toUpperCase());
      });
      this.setState({ showDowngradePkgs: searchItems });
    }
  };

  render() {
    const { classes } = this.props;
    let upgradeDowngrade = (
      <React.Fragment>
        <Modal
          show={this.state.show}
          modalClosed={this.errorConfirmedHandler}
          title={'Something Went Wrong!'}
        >
          {this.state.modalContent}
        </Modal>

        <Grid container spacing={3}>
          <Grid item xs={12} sm={6}>
            <Card style={{ height: '100%' }}>
              <CardHeader
                className={classes.cardHeader}
                classes={{
                  subheader: classes.subheader,
                }}
                subheader={'Upgrade List'}
              />

              <CardContent style={{ maxHeight: '40vh', overflow: 'auto' }}>
                <FormControl
                  component='fieldset'
                  className={classes.formControl}
                  style={{ width: '100%' }}
                >
                  <FormLabel component='legend'>
                    <FormControlLabel
                      control={
                        <Switch
                          edge='start'
                          color='primary'
                          onChange={() => {
                            let upgradeValues = [];
                            let switchData = this.state.allUpgrade;
                            switchData = !switchData;
                            if (switchData)
                              upgradeValues = [...this.state.searchItems];

                            this.setState({
                              allUpgrade: switchData,
                              upgradePkgs: upgradeValues,
                            });
                          }}
                          checked={this.state.allUpgrade}
                        />
                      }
                      label='Select All'
                    />
                  </FormLabel>
                  <div>
                    <TextField
                      fullWidth
                      value={this.state.searchUpgrade}
                      onChange={this.searchHandlerUpgrade}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position='start'>
                            <SearchIcon style={{ color: '#ff1921' }} />
                          </InputAdornment>
                        ),
                      }}
                    />
                  </div>
                  <FormGroup>
                    {this.state.showUpgradePkgs.map((value) => {
                      return (
                        <FormControlLabel
                          key={value}
                          control={
                            <Checkbox
                              style={{ color: '#ff1921' }}
                              onChange={(event) => {
                                let items = [...this.state.upgradePkgs];
                                if (items.includes(value))
                                  items = items.filter((o) => o !== value);
                                else items = [value].concat(items);

                                this.setState({
                                  upgradePkgs: [...items],
                                });
                              }}
                              checked={this.state.upgradePkgs.includes(value)}
                            />
                          }
                          label={value}
                        />
                      );
                    })}
                  </FormGroup>
                </FormControl>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} sm={6}>
            <Card style={{ height: '100%' }}>
              <CardHeader
                className={classes.cardHeader}
                classes={{
                  subheader: classes.subheader,
                }}
                subheader={'Downgrade List'}
              />

              <CardContent style={{ maxHeight: '40vh', overflow: 'auto' }}>
                <FormControl
                  component='fieldset'
                  className={classes.formControl}
                  style={{ width: '100%' }}
                >
                  <FormLabel component='legend'>
                    <FormControlLabel
                      control={
                        <Switch
                          edge='start'
                          color='primary'
                          onChange={() => {
                            let downgradeValues = [];
                            let switchData = this.state.allDowngrade;
                            switchData = !switchData;
                            if (switchData)
                              downgradeValues = [...this.state.searchItems];

                            this.setState({
                              allDowngrade: switchData,
                              downgradePkgs: downgradeValues,
                            });
                          }}
                          checked={this.state.allDowngrade}
                        />
                      }
                      label='Select All'
                    />
                  </FormLabel>
                  <div>
                    <TextField
                      fullWidth
                      value={this.state.searchDowngrade}
                      onChange={this.searchHandlerDowngrade}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position='start'>
                            <SearchIcon style={{ color: '#ff1921' }} />
                          </InputAdornment>
                        ),
                      }}
                    />
                  </div>
                  <FormGroup>
                    {this.state.showDowngradePkgs.map((value) => {
                      return (
                        <FormControlLabel
                          key={value}
                          control={
                            <Checkbox
                              style={{ color: '#ff1921' }}
                              onChange={(event) => {
                                let items = [...this.state.downgradePkgs];
                                if (items.includes(value))
                                  items = items.filter((o) => o !== value);
                                else items = [value].concat(items);

                                this.setState({
                                  downgradePkgs: [...items],
                                });
                              }}
                              checked={this.state.downgradePkgs.includes(value)}
                            />
                          }
                          label={value}
                        />
                      );
                    })}
                  </FormGroup>
                </FormControl>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12}>
            <Card>
              <CardHeader
                className={classes.cardHeader}
                classes={{
                  subheader: classes.subheader,
                }}
                subheader={'Selected Packages'}
              />

              <CardContent>
                {
                  <List
                    component='nav'
                    aria-labelledby='nested-list-subheader'
                    style={{
                      width: '100%',
                      maxHeight: '20vh',
                      overflow: 'auto',
                    }}
                  >
                    {
                      <React.Fragment>
                        <ListItem>
                          <ListItemText
                            primary='Upgrade List'
                            secondary={this.state.upgradePkgs.join()}
                          />
                        </ListItem>
                        <Divider />
                        <ListItem>
                          <ListItemText
                            primary='Downgrade List'
                            secondary={this.state.downgradePkgs.join()}
                          />
                        </ListItem>
                      </React.Fragment>
                    }
                  </List>
                }
              </CardContent>
            </Card>
          </Grid>

          {this.props.releaseData.releaseId && (
            <div
              style={{
                display: 'flex',
                justifyContent: 'flex-end',
                alignItems: 'center',
                width: '100%',
                marginTop: '1%',
              }}
            >
              <Button
                style={{
                  background: '#fff',
                  color: '#ff1921',
                  //   background: "#0273bf",
                }}
                // color="secondary"
                // variant="contained"
                className={classes.btn}
                onClick={this.deleteUpDownHandler}
              >
                Delete
              </Button>
              <StyledButton
                onClick={this.savePkgsUpDownHandler}
                style={{
                  //   background: "#02bfa0",
                  marginLeft: '1%',
                  background: '#5dc17f',
                }}
                // variant="contained"
                className={classes.btn}
              >
                Save
              </StyledButton>
            </div>
          )}
        </Grid>
      </React.Fragment>
    );

    if (this.state.loading) upgradeDowngrade = <Loader relative />;

    return upgradeDowngrade;
  }
}

export default withStyles(useStyles)(WithErrorHandler(UpgradeDowngrade, axios));
